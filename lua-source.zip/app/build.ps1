$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$taskFramework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$taskWpf = Join-Path $taskFramework 'WPF'
$taskReferences = @('System.dll','netstandard.dll','System.Core.dll','System.Management.dll','System.Web.Extensions.dll','System.Windows.Forms.dll','System.Drawing.dll','Microsoft.CSharp.dll','System.Xaml.dll','System.Xml.Linq.dll','Microsoft.VisualBasic.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll') | ForEach-Object { '/reference:' + (Join-Path $taskFramework $_) }
$taskReferences += @('PresentationCore.dll','PresentationFramework.dll','WindowsBase.dll') | ForEach-Object { '/reference:' + (Join-Path $taskWpf $_) }
$taskReferences += '/reference:' + (Join-Path $taskRoot 'LibreHardwareMonitorLib.dll')
$taskReferences += '/reference:' + (Join-Path $taskRoot 'NAudio.Core.dll')
$taskReferences += '/reference:' + (Join-Path $taskRoot 'NAudio.Wasapi.dll')
$taskSources = Get-ChildItem (Join-Path $taskRoot 'src') -Filter '*.cs' | Where-Object {$_.Name -notin @('LuaFpsHost.cs','LuaSensorsHost.cs')} | ForEach-Object { $_.FullName }
& (Join-Path $taskFramework 'csc.exe') /nologo /target:winexe /platform:x64 /optimize+ /codepage:65001 ('/out:' + (Join-Path $taskRoot 'LUA.exe')) ('/win32icon:' + (Join-Path $taskRoot 'src\LUA.ico')) ('/win32manifest:' + (Join-Path $taskRoot 'src\LuaMonitor.exe.manifest')) ('/resource:' + (Join-Path $taskRoot 'src\MainWindow.xaml') + ',LUA.MainWindow.xaml') @taskReferences @taskSources
if ($LASTEXITCODE -ne 0) { throw 'Falha ao compilar o LUA.' }
$taskHostHash = (Get-FileHash (Join-Path $taskRoot 'src\LuaFpsHost.cs') -Algorithm SHA256).Hash
$taskHostStamp = Join-Path $taskRoot 'tools\LuaFpsCapture.source.sha256'
if (-not (Test-Path (Join-Path $taskRoot 'tools\LuaFpsCapture.exe')) -or -not (Test-Path $taskHostStamp) -or [IO.File]::ReadAllText($taskHostStamp).Trim() -ne $taskHostHash) {
& (Join-Path $taskFramework 'csc.exe') /nologo /target:winexe /platform:x64 /optimize+ /codepage:65001 ('/out:' + (Join-Path $taskRoot 'tools\LuaFpsCapture.exe')) (Join-Path $taskRoot 'src\LuaFpsHost.cs')
if ($LASTEXITCODE -ne 0) { throw 'Falha ao compilar o capturador de FPS.' }
[IO.File]::WriteAllText($taskHostStamp,$taskHostHash)
}
& (Join-Path $taskFramework 'csc.exe') /nologo /target:winexe /platform:x64 /optimize+ /codepage:65001 ('/out:' + (Join-Path $taskRoot 'LuaSensorsHost.exe')) ('/reference:' + (Join-Path $taskRoot 'LibreHardwareMonitorLib.dll')) ('/reference:' + (Join-Path $taskFramework 'netstandard.dll')) ('/reference:' + (Join-Path $taskFramework 'System.Core.dll')) (Join-Path $taskRoot 'src\LuaSensorsHost.cs')
if ($LASTEXITCODE -ne 0) { throw 'Falha ao compilar o assistente de sensores.' }
Write-Output 'LUA.exe, capturador e assistente de sensores compilados com sucesso.'
