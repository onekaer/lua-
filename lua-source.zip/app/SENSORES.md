# Leitura permanente da temperatura da CPU

No LUA 1.10.4 ou posterior, abra Configurações > Temperatura da CPU e permissões > Configurar leitura da CPU > Ativar leitura permanente. A mesma opção aparece em Hardware > Sensores. Confirme a instalação no aviso do Windows. O driver oficial PawnIO precisa estar instalado; instalar o driver tem confirmação própria.

O botão instala o serviço LuaCpuSensors, executado como LocalSystem e iniciado automaticamente com o Windows. Ele fica em segundo plano após fechar o painel e consulta somente o hardware da CPU a cada 1,5 s. Não abre portas de rede nem recebe comandos ou caminhos do painel. Publica somente temperatura/status local, em arquivo fixo; valores inválidos e leituras com mais de 6 s são descartados.

Os executáveis e dependências ficam em Program Files/LUA Sensors. Somente Administradores e SYSTEM podem modificá-los; usuários comuns têm leitura. O caminho do executável é fixo e entre aspas. DLLs e configuração são conferidas por SHA-256 antes da cópia. O painel continua sem elevação. A instalação é opcional e específica deste PC; não é ativada por uma atualização silenciosa.

Para remover: Configurar leitura da CPU > Remover leitura permanente, confirmando no Windows. Isso para e remove o serviço; os componentes protegidos permanecem inativos para eventual reinstalação. Desmarcar Conectar aos sensores ao iniciar o LUA apenas desconecta o painel; não remove o serviço. Reparar o serviço ou instalar um driver pode pedir autorização novamente. Atualizar o painel não substitui automaticamente o serviço privilegiado.

Sem serviço, Ler somente nesta sessão pede autorização e encerra o assistente com o LUA. Cancelar não provoca novas tentativas automáticas. Se um serviço instalado estiver sem dados recentes, o painel informa a falha e permite reparo manual; não tenta elevar outro processo silenciosamente.

O Windows não grava uma exceção de UAC para lembrar um executável. Esta opção usa a instalação explícita de um serviço, mantendo as proteções do sistema. Assinar o aplicativo identifica o editor, mas não substitui a autorização de administrador.

Referências: https://learn.microsoft.com/en-us/windows/security/application-security/application-control/user-account-control/how-it-works e https://learn.microsoft.com/en-us/windows/win32/services/service-security-and-access-rights
