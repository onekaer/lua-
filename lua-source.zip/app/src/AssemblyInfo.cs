using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("LUA Monitor")]
[assembly: AssemblyDescription("Monitor local de hardware, rede, armazenamento e jogos para Windows")]
[assembly: AssemblyProduct("LUA Monitor")]
[assembly: AssemblyVersion("1.11.0.0")]
[assembly: AssemblyFileVersion("1.11.0.0")]
[assembly: ComVisible(false)]
