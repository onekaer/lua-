using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace LuaMonitor {
public sealed partial class DesktopController {
    static readonly string[] MainNavigation = { "home", "games", "recording", "tools" };
    static readonly string[] DefaultNavigation = {
        "home", "hardware", "network", "storage", "games", "recording", "gallery", "gaming",
        "processes", "analysis", "overlay", "settings"
    };

    // Older menu preferences belong to the independent in-game overlay.
    List<string> OrderedNavigation() {
        return (prefs.NavigationOrder ?? new List<string>()).Concat(DefaultNavigation)
            .Where(DefaultNavigation.Contains).Distinct().ToList();
    }

    void SetupNavigation() {
        var tabs = Find<UniformGrid>("CompactNavPanel");
        tabs.Children.Clear();
        tabs.Columns = MainNavigation.Length;
        nav.Children.Clear();
        foreach (string id in MainNavigation) {
            tabs.Children.Add(compactButtons[id]);
            nav.Children.Add(navButtons[id]);
        }
        Find<TextBlock>("SidebarVersion").Text = "LUA " + AppUpdate.Current + " · Beta";
        AutomationProperties.SetName(Find<Button>("NavSettingsButton"), "Configurações");
    }

    static string MainArea(string id) {
        switch (id) {
            case "hardware": return "home";
            case "sessions": case "gaming": return "games";
            case "gallery": case "capture-settings": return "recording";
            case "network": case "storage": case "processes": case "analysis": case "cleanup": return "tools";
            case "overlay": return "settings";
            default: return id;
        }
    }

    void SelectNavigation() {
        string active = MainArea(page);
        foreach (string id in MainNavigation) {
            bool selected = id == active;
            var wide = navButtons[id];
            var narrow = compactButtons[id];
            wide.Background = narrow.Background = UI.Brush(selected ? "#292431" : "Transparent");
            var wideLabel = (StackPanel)wide.Content;
            var narrowLabel = (StackPanel)narrow.Content;
            foreach (var label in new[] { wideLabel, narrowLabel }) {
                ((FluentIcon)label.Children[0]).Tint = UI.Brush(selected ? "#D4C3FA" : "#ABADB3");
                ((TextBlock)label.Children[1]).Foreground = UI.Brush(selected ? "#F3EDF9" : "#C2C4CA");
            }
        }
        Find<Button>("NavSettingsButton").Background = UI.Brush(active == "settings" ? "#292431" : "Transparent");
    }

    void AddSectionNavigation(string id) {
        if (widgetSurface) return;
        if (MainArea(id) == "games") {
            var tabs = new UniformGrid { Rows = 1, Columns = 3 };
            foreach (var entry in new[] {
                Tuple.Create("games", "Biblioteca"), Tuple.Create("sessions", "Sessões"), Tuple.Create("gaming", "FPS")
            }) {
                var button = UI.Button(entry.Item2, () => BuildPage(entry.Item1), entry.Item1 == id);
                button.Margin = new Thickness(2, 4, 2, 4);
                tabs.Children.Add(button);
            }
            tabs.Margin = new Thickness(0, 0, 0, 10);
            body.Children.Add(tabs);
        } else if (id == "hardware") {
            body.Children.Add(UI.Button("← Visão geral", () => BuildPage("home")));
        } else if (id != "tools" && MainArea(id) == "tools") {
            body.Children.Add(UI.Button("← Ferramentas", () => BuildPage("tools")));
        } else if (id == "gallery" || id == "capture-settings") {
            body.Children.Add(UI.Button("← Capturas", () => BuildPage("recording")));
        } else if (id == "overlay") {
            body.Children.Add(UI.Button("← Configurações", () => BuildPage("settings")));
        }
    }
}
}
