using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace LuaMonitor {
public sealed partial class DesktopController {
    static readonly string[] MainNavigation = { "home", "games", "recording", "tools" };
    static readonly string[] SidebarMain = { "home", "games", "recording" };
    static readonly string[] SidebarTools = { "processes", "analysis", "network", "storage", "cleanup" };
    static readonly string[] DefaultNavigation = {
        "home", "hardware", "network", "storage", "games", "recording", "gallery", "gaming",
        "processes", "analysis", "overlay", "settings"
    };

    // Older menu preferences belong to the independent in-game overlay.
    List<string> OrderedNavigation() {
        return (prefs.NavigationOrder ?? new List<string>()).Concat(DefaultNavigation)
            .Where(DefaultNavigation.Contains).Distinct().ToList();
    }

    void SetupNavigation() {
        var tabs = Find<UniformGrid>("CompactNavPanel");
        tabs.Children.Clear();
        tabs.Columns = MainNavigation.Length;
        foreach (string id in MainNavigation) tabs.Children.Add(compactButtons[id]);
        nav.Children.Clear();
        AddSidebarGroup("Geral", SidebarMain);
        AddSidebarGroup("Ferramentas", SidebarTools);
        Find<TextBlock>("SidebarVersion").Text = "LUA " + AppUpdate.Current + " · Beta";
        AutomationProperties.SetName(Find<Button>("NavSettingsButton"), "Configurações");
    }

    void AddSidebarGroup(string label, IEnumerable<string> pages) {
        var heading = UI.Text(label, 12, "#A6A2AE", true);
        heading.Margin = new Thickness(12, 12, 0, 6);
        nav.Children.Add(heading);
        foreach (string id in pages) nav.Children.Add(navButtons[id]);
    }

    static string MainArea(string id) {
        switch (id) {
            case "hardware": return "home";
            case "sessions": case "gaming": return "games";
            case "gallery": case "capture-settings": return "recording";
            case "network": case "storage": case "processes": case "analysis": case "cleanup": return "tools";
            case "overlay": return "settings";
            default: return id;
        }
    }

    void SelectNavigation() {
        string active = MainArea(page);
        foreach (string id in MainNavigation) {
            StyleNavigationButton(compactButtons[id], id == active);
        }
        string sidebarPage = SidebarTools.Contains(page) ? page : active;
        foreach (string id in SidebarMain.Concat(SidebarTools))
            StyleNavigationButton(navButtons[id], id == sidebarPage);
        Find<Button>("NavSettingsButton").Background = UI.Brush(active == "settings" ? "#292431" : "Transparent");
    }

    static void StyleNavigationButton(Button button, bool selected) {
        button.Background = UI.Brush(selected ? "#2C2636" : "Transparent");
        var label = (StackPanel)button.Content;
        ((FluentIcon)label.Children[0]).Tint = UI.Brush(selected ? "#D4C3FA" : "#B2AFBC");
        ((TextBlock)label.Children[1]).Foreground = UI.Brush(selected ? "#F3EDF9" : "#C4C1CD");
    }

    void AddSectionNavigation(string id) {
        if (widgetSurface) return;
        if (MainArea(id) == "games") {
            var tabs = new UniformGrid { Rows = 1, Columns = 3, HorizontalAlignment = HorizontalAlignment.Left };
            foreach (var entry in new[] {
                Tuple.Create("games", "Biblioteca"), Tuple.Create("sessions", "Sessões"), Tuple.Create("gaming", "FPS")
            }) {
                var button = UI.Button(entry.Item2, () => BuildPage(entry.Item1));
                button.Style = (Style)window.FindResource("PanelAction");
                button.Background = UI.Brush(entry.Item1 == id ? "#2C2636" : "#1D1C22");
                button.MinWidth = compact ? 86 : 106;
                button.MinHeight = 36;
                button.Padding = new Thickness(9, 5, 9, 5);
                button.Margin = new Thickness(0, 2, 5, 2);
                tabs.Children.Add(button);
            }
            tabs.Margin = new Thickness(0, 0, 0, 10);
            body.Children.Add(tabs);
        } else if (id == "hardware") {
            body.Children.Add(UI.Button("← Visão geral", () => BuildPage("home")));
        } else if (compact && SidebarTools.Contains(id)) {
            body.Children.Add(UI.Button("← Ferramentas", () => BuildPage("tools")));
        } else if (id == "gallery" || id == "capture-settings") {
            body.Children.Add(UI.Button("← Capturas", () => BuildPage("recording")));
        } else if (id == "overlay") {
            body.Children.Add(UI.Button("← Configurações", () => BuildPage("settings")));
        }
    }
}
}
