using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace LuaMonitor {
public sealed partial class DesktopController {
    static readonly string[] MainNavigation = { "home", "games", "gallery", "tools" };
    static readonly string[] SidebarMain = { "home", "games", "gallery" };
    static readonly string[] SidebarTools = { "processes", "analysis", "network", "storage", "cleanup" };
    static readonly string[] DefaultNavigation = {
        "home", "hardware", "network", "storage", "games", "recording", "gallery", "gaming",
        "processes", "analysis", "overlay", "settings"
    };

    // Older menu preferences belong to the independent in-game overlay.
    List<string> OrderedNavigation() {
        return (prefs.NavigationOrder ?? new List<string>()).Concat(DefaultNavigation)
            .Where(DefaultNavigation.Contains).Distinct().ToList();
    }

    void SetupNavigation() {
        var tabs = Find<UniformGrid>("CompactNavPanel");
        tabs.Children.Clear();
        tabs.Columns = MainNavigation.Length;
        foreach (string id in MainNavigation) tabs.Children.Add(compactButtons[id]);
        nav.Children.Clear();
        foreach (string id in SidebarMain) nav.Children.Add(navButtons[id]);
        AddSidebarGroup("Ferramentas", SidebarTools);
        Find<TextBlock>("SidebarVersion").Text = "LUA " + AppUpdate.Current + " · Beta";
        AutomationProperties.SetName(Find<Button>("NavSettingsButton"), "Configurações");
    }

    void AddSidebarGroup(string label, IEnumerable<string> pages) {
        var heading = UI.Text(label, 12, "#A6A2AE", true);
        heading.Margin = new Thickness(12, 12, 0, 6);
        nav.Children.Add(heading);
        foreach (string id in pages) nav.Children.Add(navButtons[id]);
    }

    static string MainArea(string id) {
        switch (id) {
            case "hardware": return "home";
            case "sessions": case "gaming": return "games";
            case "recording": case "capture-settings": return "gallery";
            case "network": case "storage": case "processes": case "analysis": case "cleanup": return "tools";
            case "overlay": return "settings";
            default: return id;
        }
    }

    void SelectNavigation() {
        string active = MainArea(page);
        foreach (string id in MainNavigation) {
            StyleNavigationButton(compactButtons[id], id == active);
        }
        string sidebarPage = SidebarTools.Contains(page) ? page : active;
        foreach (string id in SidebarMain.Concat(SidebarTools))
            StyleNavigationButton(navButtons[id], id == sidebarPage);
        Find<Button>("NavSettingsButton").Background = UI.Brush(active == "settings" ? "#292431" : "Transparent");
    }

    static void StyleNavigationButton(Button button, bool selected) {
        button.Background = UI.Brush(selected ? "#2C2636" : "Transparent");
        var label = (Panel)button.Content;
        ((FluentIcon)label.Children[0]).Tint = UI.Brush(selected ? "#D4C3FA" : "#B2AFBC");
        ((TextBlock)label.Children[1]).Foreground = UI.Brush(selected ? "#F3EDF9" : "#C4C1CD");
    }

    void AddSectionNavigation(string id) {
        if (widgetSurface) return;
        if (MainArea(id) == "games") {
            AddGameHeader(id);
        } else if (id == "hardware") {
            body.Children.Add(UI.Button("← Visão geral", () => BuildPage("home")));
        } else if (compactNavigation && SidebarTools.Contains(id)) {
            body.Children.Add(UI.Button("← Ferramentas", () => BuildPage("tools")));
        } else if (id == "capture-settings") {
            body.Children.Add(UI.Button("← Galeria", () => BuildPage("gallery")));
        } else if (id == "overlay") {
            body.Children.Add(UI.Button("← Configurações", () => BuildPage("settings")));
        }
    }
}
}
