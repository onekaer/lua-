using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task VerifyAppearance(List<string> checks, string directory) {
        if (Preferences.DataDir == Preferences.DefaultDataDir)
            throw new InvalidOperationException("Use uma pasta isolada com --data.");
        timer.Stop();
        await sampling;
        await LoadGames();
        prefs.Video.Folder = Path.Combine(directory, "gallery-demo");
        scanRoot = @"C:\Exemplo";
        cleanupFolder = @"C:\Exemplo\Downloads";
        inventory = new Inventory {
            Cpu = "Processador de exemplo · 8 núcleos / 16 threads",
            Gpu = "Placa de vídeo de exemplo", Ram = "32 GB", Disks = "SSD · 1 TB"
        };
        processReading = true;
        processes = new List<ProcessValue> {
            new ProcessValue { Name = "Jogo demonstrativo", Id = 1000, Cpu = 14, Memory = 2L << 30 },
            new ProcessValue { Name = "LUA", Id = 1001, Cpu = 1, Memory = 128L << 20 }
        };
        library = new GameLibrary();
        library.Games.Add(new GameEntry {
            Name = "Jogo demonstrativo", Platform = "Executável local",
            Folder = @"C:\Exemplo\Jogo", Bytes = 20L << 30, SizeSource = "Dados demonstrativos"
        });
        libraryLoaded = true;
        playtime = new PlaytimeStore(Path.Combine(directory, "appearance-demo.json"));
        playtime.Import("Jogo demonstrativo", "Steam", "Conta de exemplo", 18000);
        snapshot = new Snapshot {
            Cpu = 28, Gpu = 63, GpuTemp = 51, CpuTemp = 58,
            RamTotal = 32UL << 30, RamAvailable = 19UL << 30, CommitTotal = 48UL << 30, CommitAvailable = 29UL << 30,
            Download = 1860000, Upload = 48000, Uptime = TimeSpan.FromHours(6),
            Disks = new List<DiskValue> { new DiskValue { Name = @"C:\", Label = "Unidade de exemplo", Total = 1024L << 30, Free = 680L << 30 } }
        };
        CpuHistory.Clear(); GpuHistory.Clear(); RamHistory.Clear(); DownHistory.Clear();
        for (int i = 0; i < 60; i++) {
            CpuHistory.Add(22 + 6 * Math.Sin(i * .22) + 6 * Math.Sin(i * .49));
            GpuHistory.Add(54 + 17 * Math.Sin(i * .13) + 7 * Math.Cos(i * .36));
            RamHistory.Add(37 + i * .064 + 1.2 * Math.Sin(i * .2));
            DownHistory.Add(12 + 3 * Math.Sin(i * .25) + 2 * Math.Sin(i * .75));
        }
        SetMode(false, false);
        string[] pages = { "home", "hardware", "network", "storage", "games", "recording", "gallery", "gaming", "processes", "analysis", "overlay", "settings", "cleanup" };
        foreach (string id in pages) {
            if (navButtons.ContainsKey(id)) navButtons[id].RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            else BuildPage(id);
            if (page != id || body.Children.Count == 0) throw new InvalidOperationException("Página sem conteúdo: " + id);
            description.Text = description.Text + " · Dados demonstrativos";
            await Task.Delay(170);
            window.UpdateLayout();
            UI.Capture(window, Path.Combine(directory, "visual-" + id + ".png"));
            if (id == "home") {
                string videos = Path.Combine(prefs.Video.Folder, "Videos");
                Directory.CreateDirectory(videos);
                await MakeGalleryFixture(Path.Combine(directory, "visual-home.png"), Path.Combine(videos, "LUA_video_demonstracao.mp4"));
            }
            if (id == "settings") {
                Find<ScrollViewer>("ContentScroll").ScrollToEnd();
                window.UpdateLayout();
                UI.Capture(window, Path.Combine(directory, "visual-updates.png"));
            }
        }
        BuildPage("home");
        sidebarSearchField.Text = "gravacao";
        if (nav.Children.OfType<Button>().Any()) throw new InvalidOperationException("Busca deve ocultar opções sem correspondência.");
        sidebarSearchField.Text = "visao";
        var match = nav.Children.OfType<Button>().Single();
        if (!Equals(match.ToolTip, "Visão geral")) throw new InvalidOperationException("Busca sem acentos falhou.");
        sidebarSearchField.Text = "hardware";
        nav.Children.OfType<Button>().Single().RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        if (page != "hardware") throw new InvalidOperationException("Navegação após filtrar falhou.");
        sidebarSearchField.Clear();
        BuildPage("home");
        window.Width = Math.Min(920, window.Width);
        await Task.Delay(170);
        window.UpdateLayout();
        var responsive = (Grid)body.Children[1];
        if (Grid.GetRow(responsive.Children[1]) != 1) throw new InvalidOperationException("Visão geral estreita não empilhou os cartões.");
        UI.Capture(window, Path.Combine(directory, "visual-narrow-home.png"));
        SetMode(true, false);
        foreach (string id in new[] { "home", "games", "settings" }) {
            BuildPage(id);
            await Task.Delay(170);
            UI.Capture(window, Path.Combine(directory, "visual-compact-" + id + ".png"));
        }
        SetWorkspace(true);
        await Task.Delay(200);
        UI.Capture(workspaceBar, Path.Combine(directory, "visual-widget-bar.png"));
        var capture = widgetControllers["recording"];
        UI.Capture(capture.window, Path.Combine(directory, "visual-capture-widget.png"));
        OpenWidget("home");
        await Task.Delay(200);
        var overview = widgetControllers["home"];
        overview.snapshot = snapshot;
        overview.Refresh();
        UI.Capture(overview.window, Path.Combine(directory, "visual-overview-widget.png"));
        CloseWorkspace();
        workspaceEditing = false;
        checks.Add("Visual nativo renderizado nas 13 páginas, com modo compacto e navegação por busca conferidos.");
    }
}
}
