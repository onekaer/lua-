using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Drawing = System.Drawing;

namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task VerifyAppearance(List<string> checks, string directory) {
        if (Preferences.DataDir == Preferences.DefaultDataDir)
            throw new InvalidOperationException("Use uma pasta isolada com --data.");
        timer.Stop();
        await sampling;
        await LoadGames();
        prefs.Video.Folder = Path.Combine(directory, "gallery-demo");
        scanRoot = @"C:\Exemplo";
        cleanupFolder = @"C:\Exemplo\Downloads";
        inventory = new Inventory {
            Cpu = "Processador de exemplo · 8 núcleos / 16 threads",
            Gpu = "Placa de vídeo de exemplo", Ram = "32 GB", Disks = "SSD · 1 TB"
        };
        processReading = true;
        processes = new List<ProcessValue> {
            new ProcessValue { Name = "Jogo demonstrativo", Id = 1000, Cpu = 14, Memory = 2L << 30 },
            new ProcessValue { Name = "LUA", Id = 1001, Cpu = 1, Memory = 128L << 20 }
        };
        library = new GameLibrary();
        library.Games.Add(new GameEntry {
            Name = "Horizonte Costeiro", Platform = "Executável local",
            Folder = @"C:\Exemplo\Jogo", Bytes = 20L << 30, SizeSource = "Dados demonstrativos",
            CoverPath = DemoPoster(directory, "Circuito", Drawing.Color.MidnightBlue, Drawing.Color.MediumPurple, false)
        });
        library.Games.Add(new GameEntry {
            Name = "Reino das Cinzas", Platform = "Steam",
            Folder = @"C:\Exemplo\Horizonte", Bytes = 46L << 30, SizeSource = "Dados demonstrativos",
            CoverPath = DemoPoster(directory, "Horizonte", Drawing.Color.DarkSlateGray, Drawing.Color.Coral, true)
        });
        library.Games.Add(new GameEntry {
            Name = "Órbita Nove", Platform = "Emulador",
            Folder = @"C:\Exemplo\Orbita", Bytes = 16L << 30, SizeSource = "Dados demonstrativos",
            CoverPath = DemoPoster(directory, "Órbita", Drawing.Color.DarkSlateBlue, Drawing.Color.DodgerBlue, false)
        });
        library.Games.Add(new GameEntry {
            Name = "Vale do Cedro", Platform = "Steam",
            Folder = @"C:\Exemplo\Vale", Bytes = 8L << 30, SizeSource = "Dados demonstrativos",
            CoverPath = DemoPoster(directory, "Vale", Drawing.Color.DarkGreen, Drawing.Color.Goldenrod, false)
        });
        libraryLoaded = true;
        prefs.GamesGrid = true;
        playtime = new PlaytimeStore(Path.Combine(directory, "appearance-demo.json"));
        double[] hours = { 30, 22.5, 9.25, 11 };
        for (int i = 0; i < library.Games.Count; i++) {
            var item = library.Games[i];
            var tracked = playtime.Register(item.Name, item.Platform);
            playtime.Import(item.Name, item.Platform, "Conta de exemplo", hours[i] * 3600);
            string date = DateTime.UtcNow.AddDays(-i).ToString("o");
            playtime.Data.Sessions.Add(new PlaySession { GameId = tracked.Id, StartedUtc = date, EndedUtc = date, Seconds = 2400 });
            if (i == 0) tracked.LastExecutable = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
        }
        snapshot = new Snapshot {
            Cpu = 28, Gpu = 63, GpuTemp = 51, CpuTemp = 58,
            RamTotal = 32UL << 30, RamAvailable = 19UL << 30, CommitTotal = 48UL << 30, CommitAvailable = 29UL << 30,
            Download = 1860000, Upload = 48000, Uptime = TimeSpan.FromHours(6),
            Disks = new List<DiskValue> { new DiskValue { Name = @"C:\", Label = "Unidade de exemplo", Total = 1024L << 30, Free = 680L << 30 } }
        };
        CpuHistory.Clear(); GpuHistory.Clear(); RamHistory.Clear(); DownHistory.Clear();
        for (int i = 0; i < 60; i++) {
            CpuHistory.Add(22 + 6 * Math.Sin(i * .22) + 6 * Math.Sin(i * .49));
            GpuHistory.Add(54 + 17 * Math.Sin(i * .13) + 7 * Math.Cos(i * .36));
            RamHistory.Add(37 + i * .064 + 1.2 * Math.Sin(i * .2));
            DownHistory.Add(12 + 3 * Math.Sin(i * .25) + 2 * Math.Sin(i * .75));
        }
        SetMode(false, false);
        string[] pages = { "home", "hardware", "network", "storage", "games", "recording", "gallery", "gaming", "processes", "analysis", "overlay", "settings", "cleanup", "tools", "sessions", "capture-settings" };
        foreach (string id in pages) {
            if (navButtons.ContainsKey(id)) navButtons[id].RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            else BuildPage(id);
            if (page != id || body.Children.Count == 0) throw new InvalidOperationException("Página sem conteúdo: " + id);
            description.Text = description.Text + " · Dados demonstrativos";
            await Task.Delay(170);
            window.UpdateLayout();
            UI.Capture(window, Path.Combine(directory, "visual-" + id + ".png"));
            if (id == "games") {
                CheckGamePosterLayout();
                double oldWidth = window.Width, oldHeight = window.Height;
                string[] originalCovers = library.Games.Select(game => game.CoverPath).ToArray();
                SetReferenceCovers(directory);
                window.Width = 845;
                window.Height = 754;
                BuildPage("games");
                window.UpdateLayout();
                var posterGrid = gamesArea.Children.OfType<GameGridPanel>().Single();
                if (posterGrid.Columns != 4 || librarySpotlight == null || librarySpotlight.Children.Count == 0)
                    throw new InvalidOperationException("A tela de Jogos não manteve o destaque e as quatro capas a 845 px.");
                UI.Capture(window, Path.Combine(directory, "visual-games-reference.png"));
                for (int i = 0; i < originalCovers.Length; i++) library.Games[i].CoverPath = originalCovers[i];
                window.Width = oldWidth;
                window.Height = oldHeight;
            }
            if (id == "home") {
                string videos = Path.Combine(prefs.Video.Folder, "Videos");
                Directory.CreateDirectory(videos);
                await MakeGalleryFixture(Path.Combine(directory, "visual-home.png"), Path.Combine(videos, "LUA_video_demonstracao.mp4"));
            }
            if (id == "settings") {
                Find<ScrollViewer>("ContentScroll").ScrollToEnd();
                window.UpdateLayout();
                UI.Capture(window, Path.Combine(directory, "visual-updates.png"));
            }
        }
        var sidebarLinks = nav.Children.OfType<Button>().Select(button => Convert.ToString(button.ToolTip));
        if (!sidebarLinks.SequenceEqual(new[] { "Início", "Jogos", "Capturas", "Processos", "Analisar PC",
                "Rede e internet", "Armazenamento", "Limpeza e duplicados" }))
            throw new InvalidOperationException("A barra lateral não mostra os atalhos de Ferramentas.");
        foreach (string id in SidebarTools) {
            navButtons[id].RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            if (page != id || !Equals(((System.Windows.Media.SolidColorBrush)navButtons[id].Background).Color,
                    System.Windows.Media.ColorConverter.ConvertFromString("#2C2636")))
                throw new InvalidOperationException("Atalho lateral não selecionado: " + id);
        }
        BuildPage("home");
        window.Width = Math.Min(920, window.Width);
        await Task.Delay(170);
        window.UpdateLayout();
        var responsive = (Grid)body.Children[1];
        if (Grid.GetRow(responsive.Children[1]) != 1) throw new InvalidOperationException("Visão geral estreita não empilhou os cartões.");
        UI.Capture(window, Path.Combine(directory, "visual-narrow-home.png"));
        SetMode(true, false);
        foreach (string id in new[] { "home", "games", "settings" }) {
            BuildPage(id);
            await Task.Delay(170);
            UI.Capture(window, Path.Combine(directory, "visual-compact-" + id + ".png"));
        }
        double savedScale = prefs.UiScale;
        foreach (double uiScale in new[] { 1.0, 1.25, 1.5 }) {
            prefs.UiScale = uiScale;
            SetMode(true, false);
            BuildPage("games");
            window.UpdateLayout();
            CheckCompactTabs();
            CheckGamePosterLayout();
        }
        prefs.UiScale = savedScale;
        SetMode(true, false);
        SetWorkspace(true);
        await Task.Delay(200);
        UI.Capture(workspaceBar, Path.Combine(directory, "visual-widget-bar.png"));
        var capture = widgetControllers["recording"];
        UI.Capture(capture.window, Path.Combine(directory, "visual-capture-widget.png"));
        OpenWidget("home");
        await Task.Delay(200);
        var overview = widgetControllers["home"];
        overview.snapshot = snapshot;
        overview.Refresh();
        UI.Capture(overview.window, Path.Combine(directory, "visual-overview-widget.png"));
        CloseWorkspace();
        workspaceEditing = false;
        checks.Add("Visual nativo renderizado em 16 páginas, com abas compactas e ferramentas na lateral.");
        checks.Add("Abas e capas Steam 2:3 conferidas em 100%, 125% e 150%. Fallback horizontal preserva a imagem.");
    }

    void SetReferenceCovers(string directory) {
        string sheet = Path.Combine(Preferences.DataDir, "covers-demo.jpg");
        if (!File.Exists(sheet)) return;
        using (var canvas = new Drawing.Bitmap(sheet)) {
            int width = canvas.Width / 2, height = canvas.Height / 2;
            for (int i = 0; i < library.Games.Count; i++) {
                string path = Path.Combine(directory, "demo-cover-" + i + ".png");
                using (var image = canvas.Clone(new Drawing.Rectangle(i % 2 * width, i / 2 * height, width, height), canvas.PixelFormat))
                    image.Save(path, Drawing.Imaging.ImageFormat.Png);
                library.Games[i].CoverPath = path;
            }
        }
    }

    void CheckCompactTabs() {
        var strip = Find<UniformGrid>("CompactNavPanel");
        if (strip.Children.Count != 4) throw new InvalidOperationException("Abas compactas incompletas.");
        foreach (Button button in strip.Children) {
            var bounds = LayoutInformation(button, strip);
            var caption = ((StackPanel)button.Content).Children[1] as TextBlock;
            var textBounds = LayoutInformation(caption, button);
            if (bounds.Bottom > strip.ActualHeight + .5 || textBounds.Bottom > button.ActualHeight - 1 ||
                textBounds.Top < 1 || textBounds.Right > button.ActualWidth + .5)
                throw new InvalidOperationException("A aba compacta foi cortada: " + caption.Text);
        }
    }

    void CheckGamePosterLayout() {
        var grid = gamesArea.Children.OfType<GameGridPanel>().Single();
        var posters = Buttons(grid).Select(button => button.Content).OfType<GamePoster>().ToArray();
        if (posters.Length != 4 || posters.Any(poster => poster.ActualWidth < 1 ||
                Math.Abs(poster.ActualHeight - poster.ActualWidth * 1.5) > 2))
            throw new InvalidOperationException("A biblioteca não manteve a proporção das capas.");
        if (posters.Count(poster => ((Image)poster.Child).Stretch == Stretch.Uniform) != 1)
            throw new InvalidOperationException("A arte horizontal deve ser exibida inteira.");
    }

    static string DemoPoster(string directory, string name, Drawing.Color baseColor, Drawing.Color accent, bool landscape) {
        string path = Path.Combine(directory, name + "-arte-demonstrativa.png");
        using (var art = new Drawing.Bitmap(landscape ? 480 : 360, landscape ? 230 : 540))
        using (var graphics = Drawing.Graphics.FromImage(art))
        using (var wash = new Drawing.Drawing2D.LinearGradientBrush(new Drawing.Rectangle(0, 0, art.Width, art.Height),
            baseColor, Drawing.Color.FromArgb(18, 18, 27), 65))
        using (var ring = new Drawing.Pen(Drawing.Color.FromArgb(185, accent), 5))
        using (var tint = new Drawing.SolidBrush(Drawing.Color.FromArgb(68, accent)))
        using (var font = new Drawing.Font("Segoe UI", 29, Drawing.FontStyle.Bold)) {
            graphics.SmoothingMode = Drawing.Drawing2D.SmoothingMode.AntiAlias;
            graphics.FillRectangle(wash, 0, 0, art.Width, art.Height);
            int diameter = landscape ? 130 : 240;
            int x = (art.Width - diameter) / 2, y = landscape ? 14 : 108;
            graphics.FillEllipse(tint, x, y, diameter, diameter);
            graphics.DrawEllipse(ring, x, y, diameter, diameter);
            graphics.DrawArc(ring, x + 16, y + 16, diameter - 32, diameter - 32, 135, 165);
            graphics.DrawString(name.ToUpperInvariant(), font, Drawing.Brushes.White, 24, art.Height - 72);
            art.Save(path, Drawing.Imaging.ImageFormat.Png);
        }
        return path;
    }
}
}
