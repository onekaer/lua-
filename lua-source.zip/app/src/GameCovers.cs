﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows.Media.Imaging;
namespace LuaMonitor {
public static class GameCovers {
    static string CacheKey(GameEntry game){using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(game.Platform+"|"+game.Name+"|"+game.Folder))).Replace("-","");}
    public static string CachePath(GameEntry game){return Path.Combine(Preferences.DataDir,"covers",CacheKey(game)+".jpg");}
    public static BitmapImage Image(string path,int decodeWidth=200){if(string.IsNullOrEmpty(path)||!File.Exists(path))return null;try{var image=new BitmapImage();image.BeginInit();image.CacheOption=BitmapCacheOption.OnLoad;image.DecodePixelWidth=decodeWidth;image.UriSource=new Uri(Path.GetFullPath(path));image.EndInit();image.Freeze();return image;}catch{return null;}}
    static string Normalize(string value){return Regex.Replace((value??"").ToLowerInvariant(),@"[^\p{L}\p{N}]","");}
    static byte[] Fetch(string url,int limit){ServicePointManager.SecurityProtocol|=SecurityProtocolType.Tls12;var request=(HttpWebRequest)WebRequest.Create(url);request.Timeout=8000;request.ReadWriteTimeout=8000;request.UserAgent="LUA/1.3";using(var response=request.GetResponse())using(var stream=response.GetResponseStream())using(var output=new MemoryStream()){var bytes=new byte[32768];int n;while((n=stream.Read(bytes,0,bytes.Length))>0){if(output.Length+n>limit)throw new IOException("Imagem muito grande");output.Write(bytes,0,n);}return output.ToArray();}}
    public static void Resolve(GameEntry game){
        string cache=CachePath(game);if(Image(cache)!=null){game.CoverPath=cache;game.CoverSource="Capa salva";return;}
        if(!string.IsNullOrEmpty(game.StoreId)||!string.IsNullOrEmpty(game.StoreFamily))try{
            string query=!string.IsNullOrEmpty(game.StoreId)?"products/"+Uri.EscapeDataString(game.StoreId)+"?":"products/lookup?value="+Uri.EscapeDataString(game.StoreFamily)+"&alternateId=PackageFamilyName&";
            var store=new JavaScriptSerializer{MaxJsonLength=8*1024*1024}.Deserialize<StoreCatalog>(Encoding.UTF8.GetString(Fetch("https://displaycatalog.mp.microsoft.com/v7.0/"+query+"market=BR&languages=pt-br,en-us&fieldsTemplate=Details",8*1024*1024)));
            var product=store.Product??(store.Products==null?null:store.Products.FirstOrDefault());var locale=product==null||product.LocalizedProperties==null?null:product.LocalizedProperties.FirstOrDefault();
            if(locale!=null&&locale.Images!=null){var art=locale.Images.Where(x=>x.ImagePurpose=="Poster"||x.ImagePurpose=="BrandedKeyArt"||x.ImagePurpose=="BoxArt").OrderBy(x=>x.ImagePurpose=="Poster"?0:x.ImagePurpose=="BrandedKeyArt"?1:2).FirstOrDefault();if(art!=null){var uri=new Uri(art.Uri.StartsWith("//")?"https:"+art.Uri:art.Uri);if(uri.Scheme=="https"&&uri.Host.EndsWith(".s-microsoft.com",StringComparison.OrdinalIgnoreCase)){Directory.CreateDirectory(Path.GetDirectoryName(cache));File.WriteAllBytes(cache,Fetch(uri.AbsoluteUri,5*1024*1024));if(Image(cache)!=null){game.CoverPath=cache;game.CoverSource="Arte oficial • Microsoft Store";return;}File.Delete(cache);}}}
        }catch{}
        if(!string.IsNullOrEmpty(game.SteamId)&&!string.IsNullOrEmpty(game.SteamRoot))try{
            string root=Path.Combine(game.SteamRoot,"appcache","librarycache");var files=Directory.Exists(root)?Directory.EnumerateFiles(root,game.SteamId+"*library_600x900*",SearchOption.TopDirectoryOnly).ToList():new System.Collections.Generic.List<string>();
            string nested=Path.Combine(root,game.SteamId);if(Directory.Exists(nested))files.AddRange(Directory.EnumerateFiles(nested,"*library_600x900*"));
            string file=files.FirstOrDefault(f=>Image(f)!=null);if(file!=null){game.CoverPath=file;game.CoverSource="Biblioteca Steam";return;}
        }catch{}
        // Exact title matching only: never silently attach artwork from a similarly named game.
        if(string.IsNullOrEmpty(game.SteamId))try{
            var json=Encoding.UTF8.GetString(Fetch("https://store.steampowered.com/api/storesearch/?term="+Uri.EscapeDataString(game.Name)+"&l=portuguese&cc=BR",1024*1024));
            var items=new JavaScriptSerializer().Deserialize<SteamSearch>(json);if(items!=null&&items.items!=null){var match=items.items.FirstOrDefault(x=>Normalize(x.name)==Normalize(game.Name));if(match!=null)game.SteamId=match.id.ToString();}
        }catch{}
        if(string.IsNullOrEmpty(game.SteamId)||!Regex.IsMatch(game.SteamId,@"^\d+$")){if(Image(game.LocalCoverPath)!=null){game.CoverPath=game.LocalCoverPath;game.CoverSource="Arte fornecida pelo jogo";}return;}
        foreach(string host in new[]{"https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/","https://cdn.akamai.steamstatic.com/steam/apps/"})try{
            byte[] data=Fetch(host+game.SteamId+"/library_600x900.jpg",5*1024*1024);Directory.CreateDirectory(Path.GetDirectoryName(cache));string temp=cache+".tmp";File.WriteAllBytes(temp,data);if(Image(temp)==null){File.Delete(temp);continue;}File.Copy(temp,cache,true);File.Delete(temp);game.CoverPath=cache;game.CoverSource="Arte oficial • Steam";return;
        }catch{}
        // Some Steam apps have no portrait asset. Use their official store artwork instead.
        try{
            var metadata=new JavaScriptSerializer().Deserialize<System.Collections.Generic.Dictionary<string,SteamDetails>>(Encoding.UTF8.GetString(Fetch("https://store.steampowered.com/api/appdetails?appids="+game.SteamId+"&l=portuguese&cc=BR",2*1024*1024)));
            SteamDetails detail;if(metadata.TryGetValue(game.SteamId,out detail)&&detail.success&&detail.data!=null){var uri=new Uri(detail.data.header_image);if(uri.Scheme=="https"&&(uri.Host.EndsWith(".steamstatic.com",StringComparison.OrdinalIgnoreCase)||uri.Host.EndsWith(".steamusercontent.com",StringComparison.OrdinalIgnoreCase))){Directory.CreateDirectory(Path.GetDirectoryName(cache));File.WriteAllBytes(cache,Fetch(uri.AbsoluteUri,5*1024*1024));if(Image(cache)!=null){game.CoverPath=cache;game.CoverSource="Arte oficial da loja • sem capa vertical";return;}File.Delete(cache);}}
        }catch{}
    }
    public class SteamSearch {public SteamItem[] items;}
    public class SteamItem {public int id;public string name;}
    public class StoreCatalog {public StoreProduct Product;public StoreProduct[] Products;}
    public class StoreProduct {public StoreLocale[] LocalizedProperties;}
    public class StoreLocale {public StoreImage[] Images;}
    public class StoreImage {public string Uri,ImagePurpose;}
    public class SteamDetails {public bool success;public SteamDetailData data;}
    public class SteamDetailData {public string header_image;}
}
}
