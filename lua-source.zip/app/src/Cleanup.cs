﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;


namespace LuaMonitor {
public class CleanupEntry {public string Path,Hash,Group,Kind;public long Bytes;public DateTime Modified;public bool Selected;}
public class CleanupResult {public string Mode;public List<CleanupEntry> Files=new List<CleanupEntry>();public int Skipped;public bool Cancelled;}
public static class CleanupEngine {
    public static bool Inside(string file,string directory){try{string f=System.IO.Path.GetFullPath(file).TrimEnd('\\'),d=System.IO.Path.GetFullPath(directory).TrimEnd('\\');return f.Equals(d,StringComparison.OrdinalIgnoreCase)||f.StartsWith(d+"\\",StringComparison.OrdinalIgnoreCase);}catch{return false;}}
    public static bool Protected(string file,IEnumerable<string> gameFolders){
        string full;try{full=System.IO.Path.GetFullPath(file);var drive=new DriveInfo(System.IO.Path.GetPathRoot(full));if(drive.DriveType!=DriveType.Fixed)return true;}catch{return true;}
        string temp=System.IO.Path.GetTempPath(),localTemp=System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Temp");bool allowedTemp=Inside(full,temp)||Inside(full,localTemp);
        foreach(var folder in new[]{Environment.GetFolderPath(Environment.SpecialFolder.Windows),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),AppDomain.CurrentDomain.BaseDirectory})if(!string.IsNullOrWhiteSpace(folder)&&Inside(full,folder))return true;
        foreach(var folder in new[]{Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)})if(!allowedTemp&&Inside(full,folder))return true;
        if(gameFolders!=null&&gameFolders.Any(folder=>Inside(full,folder)))return true;
        string[] parts=full.Split('\\');if(parts.Any(p=>p.Equals("$Recycle.Bin",StringComparison.OrdinalIgnoreCase)||p.Equals("System Volume Information",StringComparison.OrdinalIgnoreCase)||p.Equals("Recovery",StringComparison.OrdinalIgnoreCase)||p.Equals(".git",StringComparison.OrdinalIgnoreCase)))return true;
        if(new[]{"pagefile.sys","hiberfil.sys","swapfile.sys","bootmgr","ntldr","ntdetect.com"}.Contains(System.IO.Path.GetFileName(full),StringComparer.OrdinalIgnoreCase))return true;
        return false;
    }
    static IEnumerable<FileInfo> Walk(string root,CancellationToken token,Action skipped,Func<string,bool> ignore){
        var stack=new Stack<string>();stack.Push(System.IO.Path.GetFullPath(root));
        while(stack.Count>0){token.ThrowIfCancellationRequested();string folder=stack.Pop();if(ignore(folder)){skipped();continue;}string[] entries;try{if((File.GetAttributes(folder)&FileAttributes.ReparsePoint)!=0){skipped();continue;}entries=Directory.GetFileSystemEntries(folder);}catch{skipped();continue;}
            foreach(string entry in entries){token.ThrowIfCancellationRequested();FileAttributes attrs;try{attrs=File.GetAttributes(entry);}catch{skipped();continue;}if((attrs&FileAttributes.ReparsePoint)!=0){skipped();continue;}if((attrs&FileAttributes.Directory)!=0)stack.Push(entry);else {FileInfo info=null;try{info=new FileInfo(entry);long length=info.Length;}catch{skipped();}if(info!=null)yield return info;}}
        }
    }
    public static string Hash(string path,CancellationToken token){using(var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read,1024*1024,FileOptions.SequentialScan))using(var sha=SHA256.Create()){var buffer=new byte[1024*1024];int read;while((read=file.Read(buffer,0,buffer.Length))>0){token.ThrowIfCancellationRequested();sha.TransformBlock(buffer,0,read,null,0);}sha.TransformFinalBlock(new byte[0],0,0);return BitConverter.ToString(sha.Hash).Replace("-","");}}
    public static CleanupResult Find(string root,string mode,IEnumerable<string> gameFolders,CancellationToken token,Action<string> progress){
        var r=new CleanupResult{Mode=mode};var protectedGames=gameFolders==null?new string[0]:gameFolders.ToArray();long last=0;var watch=System.Diagnostics.Stopwatch.StartNew();
        try{
            var roots=mode=="Temporários antigos"?new[]{System.IO.Path.GetTempPath(),System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Temp")}.Distinct(StringComparer.OrdinalIgnoreCase):new[]{root};
            var candidates=new List<CleanupEntry>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(string folder in roots){if(!Directory.Exists(folder))continue;foreach(var file in Walk(folder,token,()=>r.Skipped++,path=>Protected(path,protectedGames))){if(!seen.Add(file.FullName))continue;
                try{if(Protected(file.FullName,protectedGames)){r.Skipped++;continue;}if(mode=="Temporários antigos"&&file.LastWriteTimeUtc>DateTime.UtcNow.AddDays(-7))continue;if(mode=="Arquivos grandes"&&file.Length<100L*1024*1024)continue;if(mode=="Duplicados"&&file.Length==0)continue;
                    candidates.Add(new CleanupEntry{Path=file.FullName,Bytes=file.Length,Modified=file.LastWriteTimeUtc,Kind=mode});
                }catch{r.Skipped++;}if(watch.ElapsedMilliseconds-last>400){last=watch.ElapsedMilliseconds;progress(candidates.Count+" candidatos • "+file.DirectoryName);}
            }}
            if(mode=="Duplicados"){
                foreach(var sizes in candidates.GroupBy(f=>f.Bytes).Where(g=>g.Count()>1)){
                    var hashed=new List<CleanupEntry>();foreach(var entry in sizes){token.ThrowIfCancellationRequested();try{if(watch.ElapsedMilliseconds-last>350){last=watch.ElapsedMilliseconds;progress("Comparando conteúdo: "+System.IO.Path.GetFileName(entry.Path));}entry.Hash=Hash(entry.Path,token);var now=new FileInfo(entry.Path);if(now.Length!=entry.Bytes||now.LastWriteTimeUtc!=entry.Modified){r.Skipped++;continue;}entry.Group=entry.Bytes+":"+entry.Hash;hashed.Add(entry);}catch(IOException){r.Skipped++;}catch(UnauthorizedAccessException){r.Skipped++;}}
                    foreach(var group in hashed.GroupBy(e=>e.Group).Where(g=>g.Count()>1))r.Files.AddRange(group.OrderBy(e=>e.Path,StringComparer.OrdinalIgnoreCase));
                }
            }else r.Files=candidates.OrderByDescending(f=>f.Bytes).ToList();
        }catch(OperationCanceledException){r.Cancelled=true;}
        return r;
    }
    public static List<string> Recycle(IEnumerable<CleanupEntry> selected,IEnumerable<CleanupEntry> all,IEnumerable<string> games){
        var errors=new List<string>();var list=selected.ToList();var original=all.ToList();
        foreach(var group in list.Where(f=>f.Group!=null).GroupBy(f=>f.Group)){
            var survivors=original.Where(f=>f.Group==group.Key&&!list.Any(s=>s.Path.Equals(f.Path,StringComparison.OrdinalIgnoreCase))).ToList();
            bool retained=survivors.Any(f=>{try{return File.Exists(f.Path)&&new FileInfo(f.Path).Length==f.Bytes&&Hash(f.Path,CancellationToken.None)==f.Hash;}catch{return false;}});
            if(!retained)throw new InvalidOperationException("Mantenha pelo menos uma cópia íntegra de cada grupo de duplicados. Nenhum arquivo foi removido.");
        }
        foreach(var item in list){try{if(Protected(item.Path,games))throw new IOException("Local protegido");string parent=System.IO.Path.GetDirectoryName(item.Path);while(parent!=null){if((File.GetAttributes(parent)&FileAttributes.ReparsePoint)!=0)throw new IOException("Link ou junção não permitido");parent=System.IO.Path.GetDirectoryName(parent);}
                var current=new FileInfo(item.Path);if(!current.Exists||current.Length!=item.Bytes||current.LastWriteTimeUtc!=item.Modified||(current.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("Arquivo alterado desde a análise");if(item.Hash!=null&&Hash(item.Path,CancellationToken.None)!=item.Hash)throw new IOException("Conteúdo alterado desde a comparação");
                RecycleBin.Send(item.Path);
            }catch(Exception ex){errors.Add(item.Path+": "+ex.Message);}}
        return errors;
    }
}
}
