﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;

namespace LuaMonitor {
public sealed class FluentIcon : Viewbox {
    List<System.Windows.Shapes.Path> paths=new List<System.Windows.Shapes.Path>();
    public Brush Tint {set{foreach(var path in paths)path.Fill=value;}}
    public FluentIcon(string name,Brush tint,double size){Width=size;Height=size;Stretch=Stretch.Uniform;var canvas=new Canvas{Width=24,Height=24};Child=canvas;
        using(var reader=XmlReader.Create(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"icons",name+".svg"),new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null})){
            var svg=XDocument.Load(reader);foreach(var element in svg.Descendants().Where(e=>e.Name.LocalName=="path")){var d=(string)element.Attribute("d");if(d==null)continue;var path=new System.Windows.Shapes.Path{Data=Geometry.Parse(((string)element.Attribute("fill-rule")=="evenodd"?"F0 ":"F1 ")+d),Fill=tint};paths.Add(path);canvas.Children.Add(path);}
        }
    }
}
public static partial class UI {
    public static FluentIcon Icon(string name,string color="#A6A6B0",double size=20){return new FluentIcon(name,Brush(color),size);}
    public static void SmoothText(DependencyObject target,bool overlay=false){TextOptions.SetTextFormattingMode(target,TextFormattingMode.Ideal);TextOptions.SetTextRenderingMode(target,TextRenderingMode.Grayscale);TextOptions.SetTextHintingMode(target,TextHintingMode.Fixed);RenderOptions.SetClearTypeHint(target,ClearTypeHint.Auto);}
}
public sealed partial class DesktopController {
    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd,int attribute,ref int value,int length);
    [DllImport("gdi32.dll")] static extern IntPtr CreateRoundRectRgn(int x1,int y1,int x2,int y2,int width,int height);
    [DllImport("user32.dll")] static extern int SetWindowRgn(IntPtr hwnd,IntPtr region,bool redraw);
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr value);
    void RoundOpaqueWindow(){
        var h=new WindowInteropHelper(window).Handle;if(h==IntPtr.Zero||window.ActualWidth<2||window.ActualHeight<2)return;int border=unchecked((int)0xFFFFFFFE),round=2;
        try{DwmSetWindowAttribute(h,34,ref border,4);DwmSetWindowAttribute(h,33,ref round,4);}catch{}
        // Layered windows already have antialiased WPF corners. A binary HRGN
        // clips their smooth edge and produces visible stair steps at high DPI.
        SetWindowRgn(h,IntPtr.Zero,true);

    }
}
}
