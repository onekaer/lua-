﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
namespace LuaMonitor {
public sealed partial class DesktopController {
    // Resize only the visible six-pixel edge; no native dotted grip or frame.
    void AttachWidgetResize(DesktopController child,FrameworkElement shell){
        bool dragging=false;int horizontal=0,vertical=0;Point origin=new Point();Rect initial=Rect.Empty;
        shell.PreviewMouseMove+=(s,e)=>{
            if(!workspaceEditing||!child.window.IsHitTestVisible){shell.Cursor=null;return;}
            if(dragging){var screen=System.Windows.Forms.Cursor.Position;var source=PresentationSource.FromVisual(child.window);var transform=source.CompositionTarget.TransformFromDevice;var at=transform.Transform(new Point(screen.X,screen.Y));var next=WidgetResizeBounds(initial,at-origin,horizontal,vertical,child.window.MinWidth,child.window.MinHeight);child.window.Left=next.Left;child.window.Top=next.Top;child.window.Width=next.Width;child.window.Height=next.Height;e.Handled=true;return;}
            var point=e.GetPosition(shell);horizontal=point.X<6?-1:point.X>shell.ActualWidth-6?1:0;vertical=point.Y<6?-1:point.Y>shell.ActualHeight-6?1:0;
            shell.Cursor=horizontal!=0&&vertical!=0?(horizontal==vertical?Cursors.SizeNWSE:Cursors.SizeNESW):horizontal!=0?Cursors.SizeWE:vertical!=0?Cursors.SizeNS:null;
        };
        shell.PreviewMouseLeftButtonDown+=(s,e)=>{if(!workspaceEditing||(horizontal==0&&vertical==0))return;var screen=System.Windows.Forms.Cursor.Position;origin=PresentationSource.FromVisual(child.window).CompositionTarget.TransformFromDevice.Transform(new Point(screen.X,screen.Y));initial=new Rect(child.window.Left,child.window.Top,child.window.ActualWidth,child.window.ActualHeight);dragging=shell.CaptureMouse();e.Handled=dragging;};
        shell.PreviewMouseLeftButtonUp+=(s,e)=>{if(!dragging)return;dragging=false;shell.ReleaseMouseCapture();RememberWidget(child);e.Handled=true;};
        shell.LostMouseCapture+=(s,e)=>dragging=false;
        shell.MouseLeave+=(s,e)=>{if(!dragging){horizontal=vertical=0;shell.Cursor=null;}};
    }
    static Rect WidgetResizeBounds(Rect initial,Vector delta,int horizontal,int vertical,double minWidth,double minHeight){
        double width=horizontal==0?initial.Width:Math.Max(minWidth,initial.Width+horizontal*delta.X);
        double height=vertical==0?initial.Height:Math.Max(minHeight,initial.Height+vertical*delta.Y);
        return new Rect(horizontal<0?initial.Right-width:initial.Left,vertical<0?initial.Bottom-height:initial.Top,width,height);
    }
}
}
