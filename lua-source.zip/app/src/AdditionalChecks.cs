﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task AdditionalChecks(List<string> checks,string dir){
        var realV1=new FpsReader{Target=4321};realV1.Feed("Application,ProcessID,SwapChainAddress,Runtime,SyncInterval,PresentFlags,Dropped,TimeInSeconds,msInPresentAPI,msBetweenPresents");for(int n=0;n<120;n++)realV1.Feed("game.exe,4321,0x1,DXGI,0,0,0,1,0.1,16.6667");realV1.Update();if(!realV1.Fps.HasValue||Math.Abs(realV1.Fps.Value-60)>.1||realV1.ReceivedFrames!=120)throw new Exception("Cabeçalho oficial v1 não foi reconhecido");realV1.Dispose();checks.Add("FPS: regressão corrigida para msBetweenPresents minúsculo do formato oficial v1");
        string fixture=Path.Combine(Preferences.DataDir,"cleanup-fixture");Directory.CreateDirectory(fixture);
        string a=Path.Combine(fixture,"copy-a.bin"),b=Path.Combine(fixture,"copy-b.bin"),different=Path.Combine(fixture,"different.bin");
        File.WriteAllBytes(a,Enumerable.Repeat((byte)23,4096).ToArray());File.WriteAllBytes(b,Enumerable.Repeat((byte)23,4096).ToArray());File.WriteAllBytes(different,Enumerable.Repeat((byte)24,4096).ToArray());
        var duplicates=await Task.Run(()=>CleanupEngine.Find(fixture,"Duplicados",new string[0],CancellationToken.None,p=>{}));
        if(duplicates.Files.Count!=2||duplicates.Files.Any(e=>e.Selected)||duplicates.Files[0].Hash!=duplicates.Files[1].Hash)throw new Exception("Comparação de duplicados não distinguiu conteúdo");
        bool blocked=false;try{CleanupEngine.Recycle(duplicates.Files,duplicates.Files,new string[0]);}catch(InvalidOperationException){blocked=true;}
        if(!blocked||!File.Exists(a)||!File.Exists(b))throw new Exception("Limpeza permitiu remover todas as cópias");checks.Add("Duplicados: SHA-256, nomes diferentes, conteúdo diferente e retenção de uma cópia: correto");
        var modified=new CleanupEntry{Path=different,Bytes=4096,Modified=File.GetLastWriteTimeUtc(different)};File.AppendAllText(different,"changed");var errors=CleanupEngine.Recycle(new[]{modified},new[]{modified},new string[0]);if(errors.Count!=1||!File.Exists(different))throw new Exception("Limpeza aceitou arquivo alterado");checks.Add("Limpeza: alteração após a análise bloqueada");
        if(!CleanupEngine.Protected(Environment.GetFolderPath(Environment.SpecialFolder.Windows),null)||!CleanupEngine.Protected(AppDomain.CurrentDomain.BaseDirectory,null)||CleanupEngine.Protected(a,null))throw new Exception("Proteção de pastas incorreta");checks.Add("Limpeza: Windows, dados internos, jogos e app protegidos");
        string recyclable=Path.Combine(fixture,"recycle-only-this-test-file.txt");File.WriteAllText(recyclable,"arquivo descartável criado exclusivamente pelo teste LUA");var entry=new CleanupEntry{Path=recyclable,Bytes=new FileInfo(recyclable).Length,Modified=File.GetLastWriteTimeUtc(recyclable)};var recycled=CleanupEngine.Recycle(new[]{entry},new[]{entry},new string[0]);if(recycled.Count>0||File.Exists(recyclable))throw new Exception("Envio à Lixeira falhou: "+string.Join(" | ",recycled));checks.Add("Lixeira: somente arquivo descartável da fixture enviado; nenhum arquivo do usuário removido");
        var parsed=GameCatalog.VdfValues("\"AppState\" { \"name\" \"Example Game\" \"installdir\" \"Example\" \"SizeOnDisk\" \"4096\" \"path\" \"D:\\\\SteamLibrary\" }");if(parsed["SizeOnDisk"]!="4096"||parsed["path"]!="D:\\SteamLibrary")throw new Exception("Manifesto Steam interpretado incorretamente");
        await LoadGames();var catalog=await Task.Run(()=>GameCatalog.Discover(new[]{fixture}));if(!catalog.Games.Any(g=>CleanupEngine.Inside(g.Folder,fixture)))throw new Exception("Pasta de jogo manual não detectada");checks.Add("Jogos: manifestos Steam, adição manual e "+library.Games.Count+" instalações locais detectadas");
        var testOverlay=new OverlayWindow(prefs);testOverlay.Update(snapshot,fps);testOverlay.Show();testOverlay.Apply();await Task.Delay(150);var text=CollectText(testOverlay.Content as DependencyObject);if(!text.Contains("CPU • uso total")||!text.Contains("GPU • uso total")||!text.Any(t=>t.Contains("%")))throw new Exception("Sobreposição sem percentuais CPU/GPU");UI.Capture(testOverlay,Path.Combine(dir,"usage-overlay.png"));testOverlay.Close();checks.Add("Sobreposição: CPU/GPU em percentual, fonte sem escala de bitmap e suavização grayscale");
        BuildPage("cleanup");cleanupMode="Duplicados";cleanupResult=duplicates;RenderCleanup();window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"cleanup-preview.png"));
    }
    static List<string> CollectText(DependencyObject root){var result=new List<string>();if(root==null)return result;var text=root as TextBlock;if(text!=null)result.Add(text.Text);for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++)result.AddRange(CollectText(VisualTreeHelper.GetChild(root,i)));return result;}
}
}
