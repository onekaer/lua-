using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task PublicPreviewChecks(List<string> checks,string dir){
        await sampling;await Task.Delay(700);await SampleAsync();scanRoot=@"C:\Exemplo";cleanupFolder=@"C:\Exemplo";cleanupResult=null;availableUpdate=null;
        prefs.ShowFpsLow=prefs.ShowFpsMinimum=prefs.ShowFpsMaximum=true;
        SetMode(false,false);
        foreach(string id in new[]{"gaming","storage","cleanup","settings"}){
            BuildPage(id);await Task.Delay(400);window.UpdateLayout();
            if(id=="settings"){Find<ScrollViewer>("ContentScroll").ScrollToEnd();await Task.Delay(150);window.UpdateLayout();}
            UI.Capture(window,Path.Combine(dir,"public-"+id+".png"));
        }
        var alerts=NewDialog("Notificações",AttentionOptions());alerts.Show();await Task.Delay(150);alerts.UpdateLayout();UI.Capture(alerts,Path.Combine(dir,"public-attention-options.png"));alerts.Close();
        var permissions=CpuSensorDialog();await Task.Delay(150);permissions.UpdateLayout();UI.Capture(permissions,Path.Combine(dir,"public-cpu-permissions.png"));permissions.Close();
        SetWorkspace(true);OpenWidget("recording");await Task.Delay(250);widgetControllers["recording"].window.UpdateLayout();UI.Capture(widgetControllers["recording"].window,Path.Combine(dir,"public-capture-widget.png"));UI.Capture(workspaceBar,Path.Combine(dir,"public-workspace-bar.png"));OpenWidget("home");await Task.Delay(250);var child=widgetControllers["home"];child.snapshot=snapshot;child.Refresh();child.window.UpdateLayout();UI.Capture(child.window,Path.Combine(dir,"public-home-widget.png"));
        CloseWorkspace();workspaceEditing=false;checks.Add("Prévias públicas: interface própria, pasta C:\\Exemplo, nenhuma análise/limpeza executada e nenhum arquivo pessoal capturado");
    }
}
}
