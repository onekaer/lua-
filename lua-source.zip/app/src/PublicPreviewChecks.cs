﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task PublicPreviewChecks(List<string> checks,string dir){
        await sampling;await Task.Delay(700);await SampleAsync();scanRoot=@"C:\Exemplo";cleanupFolder=@"C:\Exemplo";cleanupResult=null;availableUpdate=null;
        prefs.ShowFpsLow=prefs.ShowFpsMinimum=prefs.ShowFpsMaximum=true;
        SetMode(false,false);
        foreach(string id in new[]{"gaming","storage","cleanup","settings"}){
            BuildPage(id);await Task.Delay(400);window.UpdateLayout();
            if(id=="settings"){Find<ScrollViewer>("ContentScroll").ScrollToEnd();await Task.Delay(150);window.UpdateLayout();}
            UI.Capture(window,Path.Combine(dir,"public-"+id+".png"));
        }
        SetWorkspace(true);UI.Capture(workspaceBar,Path.Combine(dir,"public-workspace-bar.png"));OpenWidget("home");await Task.Delay(250);var child=widgetControllers["home"];child.snapshot=snapshot;child.Refresh();child.window.UpdateLayout();UI.Capture(child.window,Path.Combine(dir,"public-home-widget.png"));
        CloseWorkspace();workspaceEditing=false;checks.Add("Prévias públicas: interface própria, pasta C:\\Exemplo, nenhuma análise/limpeza executada e nenhum arquivo pessoal capturado");
    }
}
}
