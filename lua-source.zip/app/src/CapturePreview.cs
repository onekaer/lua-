﻿using System;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public sealed class CapturePreview:Grid {
    protected override Size MeasureOverride(Size available){double width=double.IsInfinity(available.Width)?320:available.Width;double height=width*9/16;foreach(UIElement child in Children)child.Measure(new Size(width,height));return new Size(width,height);}
}
}
