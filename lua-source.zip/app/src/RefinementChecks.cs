using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
namespace LuaMonitor {
public sealed partial class DesktopController {
    [System.Runtime.InteropServices.DllImport("user32.dll")]static extern int GetWindowRgn(IntPtr handle,IntPtr region);
    async Task RefinementChecks(List<string> checks,string dir){
        var oldWidgets=prefs.Widgets;double oldScale=prefs.UiScale;bool oldGrid=prefs.GamesGrid;string oldSearch=gameSearch;
        try{
            CloseWorkspace();workspaceEditing=false;
            // Regression: an existing 420 x 600 placement must not restore a tall capture panel.
            prefs.Widgets=new Dictionary<string,WidgetPlacement>{{"recording",new WidgetPlacement{Width=420,Height=600,Left=40,Top=100}}};SetWorkspace(true);await Task.Delay(200);
            var capture=widgetControllers["recording"];capture.window.UpdateLayout();double height=capture.window.ActualHeight;
            if(capture.window.ActualWidth!=340||height>200||height<160||capture.window.SizeToContent!=SizeToContent.Height||capture.window.ResizeMode!=ResizeMode.NoResize)throw new Exception("Captura restaurou tamanho antigo: "+capture.window.ActualWidth+" x "+height);
            if(Buttons(capture.body).Count!=4||!Buttons(capture.body).Any(b=>System.Windows.Automation.AutomationProperties.GetName(b)=="Ver galeria"))throw new Exception("Captura não contém somente três ações e galeria");
            var bottom=LayoutInformation(capture.captureWidgetRoot,capture.window.Content as Visual);if(capture.window.ActualHeight-bottom.Bottom>18)throw new Exception("Captura tem espaço vazio no rodapé");
            capture.window.Left+=20;RememberWidget(capture);OpenWidget("recording");capture.window.UpdateLayout();if(Math.Abs(capture.window.ActualHeight-height)>.5)throw new Exception("Reabertura alterou altura compacta");
            var menu=capture.widgetClip.ContextMenu;((MenuItem)menu.Items[1]).RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));if(prefs.QuickClipSeconds!=60)throw new Exception("Duração de clipe não alterou");((MenuItem)menu.Items[0]).RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
            UI.Capture(capture.window,Path.Combine(dir,"capture-refined.png"));checks.Add("Captura: migração de 420 x 600 para 340 x "+height.ToString("0")+", altura pelo conteúdo, mover/reabrir, três ações e galeria; duração do clipe acessível pelo botão direito");
            // Inspect the alpha channel: rounded corners must retain intermediate alpha,
            // rather than being cut by a binary native region or painted resize grip.
            var root=(FrameworkElement)capture.window.Content;var bmp=new RenderTargetBitmap((int)capture.window.ActualWidth,(int)height,96,96,PixelFormats.Pbgra32);bmp.Render(root);var pixels=new byte[bmp.PixelWidth*bmp.PixelHeight*4];bmp.CopyPixels(pixels,bmp.PixelWidth*4,0);bool smooth=false;
            for(int y=0;y<18;y++)for(int x=0;x<18;x++){byte alpha=pixels[(y*bmp.PixelWidth+x)*4+3];if(alpha>0&&alpha<255)smooth=true;}
            var region=CreateRoundRectRgn(0,0,1,1,0,0);int nativeRegion=GetWindowRgn(new WindowInteropHelper(capture.window).Handle,region);DeleteObject(region);
            if(!smooth||nativeRegion!=0)throw new Exception("Canto ainda usa recorte binário ou perdeu antialiasing");checks.Add("Bordas: cantos transparentes com alfa suavizado, sem região nativa serrilhada e sem marcador pontilhado");
            OpenWidget("home");var home=widgetControllers["home"];if(home.window.ResizeMode!=ResizeMode.NoResize)throw new Exception("Widget ainda usa grip nativo");var resized=WidgetResizeBounds(new Rect(30,40,420,650),new Vector(150,500),-1,-1,340,250);if(resized!=new Rect(110,440,340,250))throw new Exception("Redimensionamento não preservou canto oposto/limites");
            prefs.Widgets["home"].Pinned=true;SetWorkspace(false);if(home.window.IsHitTestVisible||(Native.GetWindowLong(new WindowInteropHelper(home.window).Handle,-20)&0x20)==0)throw new Exception("Borda do widget fixado intercepta jogo");checks.Add("Janelas: redimensionamento pelas bordas respeita mínimos e canto oposto; fixar continua permitindo cliques no jogo");CloseWorkspace();workspaceEditing=false;window.Show();
            await LoadGames();prefs.GamesGrid=true;
            foreach(bool small in new[]{true,false})foreach(double scale in new[]{1.0,1.25,1.5}){
                prefs.UiScale=scale;SetMode(small,false);BuildPage("games");window.UpdateLayout();var search=FindSearchFields(body).First();var view=Buttons(body).First(b=>System.Windows.Automation.AutomationProperties.GetName(b)=="Visualizar em grade");var filter=Buttons(body).First(b=>Convert.ToString(b.ToolTip)=="Mostrar filtros");
                var a=LayoutInformation(search,body);var viewRect=LayoutInformation(view,body);var f=LayoutInformation(filter,body);if(viewRect.Top<a.Bottom||f.Left<a.Right||a.Width<100||Math.Abs(f.Top+f.Height/2-a.Top-a.Height/2)>1)throw new Exception("Busca/filtro/ícones desalinhados na escala "+scale);
                filter.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));window.UpdateLayout();if(LayoutInformation(view,body).Top<=viewRect.Top)throw new Exception("Filtros sobrepuseram seletor de visualização");filter.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                search.Focus();search.Text="__LUA_SEM_RESULTADO__";window.UpdateLayout();if(gameSearch!=search.Text||gamesArea.Children.OfType<GameGridPanel>().Any())throw new Exception("Busca não filtrou biblioteca");search.Text="";window.UpdateLayout();
                await Task.Delay(180);UI.Capture(window,Path.Combine(dir,"games-refined-"+(small?"compact-":"expanded-")+(scale*100).ToString("0")+".png"));
            }
            prefs.UiScale=oldScale;SetMode(true,false);BuildPage("games");window.UpdateLayout();Buttons(body).First(b=>System.Windows.Automation.AutomationProperties.GetName(b)=="Visualizar em lista").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));if(prefs.GamesGrid)throw new Exception("Alternância para lista falhou");window.UpdateLayout();Buttons(body).First(b=>System.Windows.Automation.AutomationProperties.GetName(b)=="Visualizar em grade").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));if(!prefs.GamesGrid)throw new Exception("Alternância para grade falhou");checks.Add("Jogos: busca digitada, filtros retráteis, grade/lista abaixo da pesquisa, alternância e alinhamento em dois modos e escalas 100%, 125%, 150%");
        }finally{CloseWorkspace();workspaceEditing=false;prefs.Widgets=oldWidgets;prefs.UiScale=oldScale;prefs.GamesGrid=oldGrid;gameSearch=oldSearch;SetMode(true,false);window.Show();BuildPage("home");}
    }
}
}
