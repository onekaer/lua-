using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace LuaMonitor {
public sealed partial class DesktopController {
    StackPanel continueGameHost, sessionContent;
    string continueGameKey;
    string sessionsGame = "";
    int sessionsDays = 7;
    readonly List<double> gameFpsHistory = new List<double>();
    int gameFpsGeneration = -1;

    void RecordGameFps() {
        if (gameFpsGeneration != fps.Generation) {
            gameFpsHistory.Clear();
            gameFpsGeneration = fps.Generation;
        }
        if (fps.Target > 0) AddHistory(gameFpsHistory, fps.Fps);
    }

    UIElement GameFpsTimeline() {
        return UI.Card(UI.Stack(UI.Text("FPS nas últimas leituras", 16, "#EFE9F8", true),
            Value(s => fps.Fps.HasValue ? "Jogo em monitoramento · " + fps.TargetName :
                "Aguardando leituras do jogo em execução.", 12, "#C5B9D4"),
            Chart(gameFpsHistory, "#BCA7EF", 76, true)), 15);
    }

    void ResetGameExperience() {
        continueGameHost = sessionContent = null;
        continueGameKey = null;
        playtimeLabels.Clear();
    }

    GameEntry CatalogGame(TrackedGame tracked) {
        var matches = library.Games.Where(game => PlaytimeStore.Identity(game.Name) == tracked.Id);
        var installed = matches.FirstOrDefault(game => MatchesInstalledPath(game, tracked.LastExecutable)) ??
            matches.FirstOrDefault(game => SamePath(game.Folder, tracked.Folder)) ?? matches.FirstOrDefault();
        return installed ?? TrackedLibraryEntry(tracked);
    }

    static bool SamePath(string left, string right) {
        return !string.IsNullOrEmpty(left) && !string.IsNullOrEmpty(right) &&
            string.Equals(left.TrimEnd('\\', '/'), right.TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase);
    }

    static bool MatchesInstalledPath(GameEntry game, string path) {
        return !string.IsNullOrEmpty(game.Folder) && !string.IsNullOrEmpty(path) &&
            path.StartsWith(game.Folder.TrimEnd('\\', '/') + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
    }

    static GameEntry TrackedLibraryEntry(TrackedGame tracked) {
        string folder = tracked.Folder;
        if (string.IsNullOrEmpty(folder) && !string.IsNullOrEmpty(tracked.Executable))
            try { folder = Path.GetDirectoryName(tracked.Executable); } catch (ArgumentException) {}
        var entry = new GameEntry {
            Name = tracked.Name,
            Platform = tracked.Platform ?? "Outra",
            Folder = folder,
            TrackingOnly = true,
            SizeSource = string.IsNullOrEmpty(tracked.Executable) ? "Instalação não detectada" : "Executável cadastrado"
        };
        entry.CoverPath = GameCovers.CachePath(entry);
        if (File.Exists(entry.CoverPath)) entry.CoverSource = "Capa salva";
        return entry;
    }

    static DateTime SessionUtc(string date) {
        DateTime timestamp;
        return DateTime.TryParse(date, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out timestamp)
            ? timestamp.ToUniversalTime() : DateTime.MinValue;
    }

    static DateTime SessionLast(PlaySession session) {
        var last = SessionUtc(session.EndedUtc);
        return last == DateTime.MinValue ? SessionUtc(session.StartedUtc) : last;
    }

    static string SessionDate(PlaySession session) {
        var started = SessionUtc(session.StartedUtc);
        return started == DateTime.MinValue ? "Data indisponível" : started.ToLocalTime().ToString("g");
    }

    static string SessionDuration(double seconds) {
        long total = (long)Math.Round(seconds);
        if (total < 60) return total + " s";
        long minutes = total / 60;
        if (minutes < 60) return minutes + " min";
        return (minutes / 60) + " h" + (minutes % 60 == 0 ? "" : " " + (minutes % 60) + " min");
    }

    Grid GameCoverRow(UIElement cover, UIElement details) {
        var row = new Grid();
        row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        row.ColumnDefinitions.Add(new ColumnDefinition());
        var thumbnail = new Border { Child = cover, Margin = new Thickness(0, 0, 12, 0) };
        row.Children.Add(thumbnail);
        Grid.SetColumn(details, 1);
        row.Children.Add(details);
        return row;
    }

    void ShowGameDetails(GameEntry entry) {
        var tracked = Playtime == null ? null : Playtime.Find(entry.Name);
        var cover = MakeGamePoster(entry, 192);
        cover.Width = 70;
        var heading = UI.Stack(UI.Text(entry.Name, 19, "#F2EEF8", true),
            UI.Text(entry.Platform + (entry.Bytes.HasValue ? " · " + Format.Bytes(entry.Bytes.Value) : ""), 12, "#BBB4CA"),
            UI.Text(tracked == null ? "Nenhuma hora registrada" : Hours(tracked.TotalSeconds) + " no total", 15, "#D8C8FB", true));
        heading.VerticalAlignment = VerticalAlignment.Center;
        var sections = UI.Stack(GameCoverRow(cover, heading), UI.Line());
        var totals = UI.Stack(UI.Text("Tempo por origem", 15, "#EDE7F5", true),
            UI.Row(UI.Text("Registrado neste PC"), UI.Text(Hours(tracked == null ? 0 : tracked.Seconds))));
        if (tracked != null) foreach (var imported in tracked.Imports)
            totals.Children.Add(UI.Row(UI.Text(imported.Platform + " · " + imported.Account), UI.Text(Hours(imported.Seconds))));
        sections.Children.Add(totals);
        var history = UI.Stack(UI.Text("Sessões recentes", 15, "#EDE7F5", true));
        var recent = tracked == null ? new PlaySession[0] : Playtime.Data.Sessions.Where(s => s.GameId == tracked.Id && s.Seconds > 0)
            .OrderByDescending(SessionLast).Take(4).ToArray();
        foreach (var session in recent)
            history.Children.Add(UI.Row(UI.Text(SessionDate(session), 12), UI.Text(SessionDuration(session.Seconds), 12)));
        if (recent.Length == 0) history.Children.Add(UI.Text("Nenhuma sessão local registrada.", 12, "#B9B3C4"));
        sections.Children.Add(UI.Line());
        sections.Children.Add(history);

        var dialog = NewDialog("Detalhes do jogo", new ScrollViewer {
            Content = sections, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            MaxHeight = Math.Max(150, Math.Min(425, SystemParameters.WorkArea.Height - 270))
        });
        var actions = new ActionGrid();
        var play = GameLaunchButton(entry, tracked, false);
        if (play != null) actions.Children.Add(play);
        actions.Children.Add(UI.Button("Importar horas", () => ShowGameImportOptions(entry.Name)));
        actions.Children.Add(UI.Button("Trocar capa", () => {
            ChooseCover(entry);
            var fresh = MakeGamePoster(entry, 192);
            var art = fresh.Child;
            fresh.Child = null;
            cover.Child = art;
        }));
        if (tracked != null && recent.Length > 0)
            actions.Children.Add(UI.Button("Ver histórico", () => { sessionsGame = tracked.Id; dialog.Close(); BuildPage("sessions"); }));
        actions.Children.Add(UI.Button("Fechar", () => dialog.Close()));
        ((StackPanel)dialog.Tag).Children.Add(actions);
        dialog.ShowDialog();
    }

    static ProcessStartInfo CreateGameStart(GameEntry entry, TrackedGame tracked, bool recent) {
        if (entry.Platform == "Emulador" || (tracked != null && !string.IsNullOrEmpty(tracked.WindowTitle)))
            return null;
        string observed = tracked == null ? null : tracked.LastExecutable;
        if (recent && ValidGameExecutable(observed)) return GameExecutableStart(observed);
        if (entry.Platform == "Steam" && Regex.IsMatch(entry.SteamId ?? "", @"^[0-9]+$") &&
            Directory.Exists(entry.Folder))
            return new ProcessStartInfo("steam://run/" + entry.SteamId) { UseShellExecute = true };
        if (ValidGameExecutable(entry.Executable)) return GameExecutableStart(entry.Executable);
        if (tracked != null && ValidGameExecutable(tracked.Executable)) return GameExecutableStart(tracked.Executable);
        return ValidGameExecutable(observed) ? GameExecutableStart(observed) : null;
    }

    static bool ValidGameExecutable(string path) {
        try {
            return !string.IsNullOrEmpty(path) && Path.IsPathRooted(path) &&
                string.Equals(path, Path.GetFullPath(path), StringComparison.OrdinalIgnoreCase) &&
                string.Equals(Path.GetExtension(path), ".exe", StringComparison.OrdinalIgnoreCase) &&
                File.Exists(path) && !IsEmulator(path);
        } catch (ArgumentException) { return false; }
        catch (NotSupportedException) { return false; }
        catch (PathTooLongException) { return false; }
    }

    static ProcessStartInfo GameExecutableStart(string path) {
        return new ProcessStartInfo(path) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(path) };
    }

    Button GameLaunchButton(GameEntry entry, TrackedGame tracked, bool recent) {
        if ((tracked != null && Playtime != null && Playtime.Active.ContainsKey(tracked.Id)) ||
            CreateGameStart(entry, tracked, recent) == null) return null;
        return UI.Button("Jogar", () => {
            if (tracked != null && Playtime != null && Playtime.Active.ContainsKey(tracked.Id)) {
                Notice("Este jogo já está em execução.");
                return;
            }
            try {
                var start = CreateGameStart(entry, tracked, recent);
                if (start == null) { Notice("O executável do jogo não está disponível."); return; }
                using (Process.Start(start)) {}
            } catch (Exception error) { Notice("Não foi possível abrir o jogo: " + error.Message); }
        }, true);
    }

    void AddContinueGame() {
        if (widgetSurface) return;
        continueGameHost = new StackPanel();
        body.Children.Add(continueGameHost);
        RenderContinueGame();
    }

    void RenderContinueGame() {
        if (continueGameHost == null) return;
        var store = Playtime;
        var last = store == null || store.Data == null ? null : store.Data.Sessions.Where(s => s.Seconds > 0)
            .OrderByDescending(SessionLast).FirstOrDefault();
        var tracked = last == null ? null : store.Data.Games.FirstOrDefault(g => g.Id == last.GameId);
        if (tracked == null) {
            continueGameHost.Children.Clear();
            continueGameKey = null;
            return;
        }
        var entry = CatalogGame(tracked);
        bool active = store.Active.ContainsKey(tracked.Id);
        var start = active ? null : CreateGameStart(entry, tracked, true);
        string key = tracked.Id + "|" + last.StartedUtc + "|" + entry.CoverPath + "|" + active + "|" + (start == null ? "" : start.FileName);
        if (key == continueGameKey) return;
        continueGameKey = key;
        continueGameHost.Children.Clear();
        var info = UI.Stack(UI.Text(entry.Name, 17, "#F0ECF8", true),
            UI.Text(active ? "Em jogo agora" : "Última sessão · " + SessionDate(last), 12, "#C3B8D0"));
        var row = GameCoverRow(GamePosterButton(entry, 130, 57), info);
        var actions = new ActionGrid();
        var play = GameLaunchButton(entry, tracked, true);
        if (play != null) actions.Children.Add(play);
        actions.Children.Add(UI.Button("Ver detalhes", () => ShowGameDetails(entry)));
        var clean = UI.Stack(UI.Text("Continuar jogando", 18, "#EEE8F8", true), row, actions);
        row.Margin = new Thickness(0, 8, 0, 4);
        var card = UI.Card(clean, 15);
        card.Background = UI.Brush("#1C1822");
        continueGameHost.Children.Add(card);
    }

    void PlaytimeSessions() {
        var store = Playtime;
        if (store == null || store.Data == null) {
            body.Children.Add(UI.Card(UI.Text(store == null ? "O histórico aparece quando o monitoramento está ativo." : store.Error)));
            return;
        }
        var gameChoice = new ComboBox();
        gameChoice.Items.Add(new ComboBoxItem { Content = "Todos os jogos", Tag = "" });
        foreach (var game in store.Data.Games.Where(g => g.Seconds > 0).OrderBy(g => g.Name))
            gameChoice.Items.Add(new ComboBoxItem { Content = game.Name, Tag = game.Id });
        gameChoice.SelectedItem = gameChoice.Items.OfType<ComboBoxItem>().FirstOrDefault(item => Equals(item.Tag, sessionsGame));
        if (gameChoice.SelectedItem == null) { sessionsGame = ""; gameChoice.SelectedIndex = 0; }
        gameChoice.SelectionChanged += (sender, args) => {
            var selection = gameChoice.SelectedItem as ComboBoxItem;
            if (selection != null) { sessionsGame = (string)selection.Tag; RenderSessionList(); }
        };
        var ranges = new Dictionary<string, int> { { "Últimos 7 dias", 7 }, { "Últimos 30 dias", 30 }, { "Todo o período", 0 } };
        var period = UI.Choice(ranges.Keys, ranges.First(pair => pair.Value == sessionsDays).Key,
            label => { sessionsDays = ranges[label]; RenderSessionList(); });
        gameChoice.Margin = period.Margin;
        System.Windows.Automation.AutomationProperties.SetName(gameChoice, "Filtrar sessões por jogo");
        System.Windows.Automation.AutomationProperties.SetName(period, "Período das sessões");
        body.Children.Add(UI.Card(UI.Stack(UI.Text("Histórico de sessões", 18, "#EDE8F5", true), UI.Inline(gameChoice, period))));
        sessionContent = new StackPanel();
        body.Children.Add(sessionContent);
        RenderSessionList();
    }

    void RenderSessionList() {
        if (sessionContent == null) return;
        var store = Playtime;
        if (store == null || store.Data == null) return;
        var since = sessionsDays == 0 ? DateTime.MinValue : DateTime.Today.AddDays(1 - sessionsDays).ToUniversalTime();
        var matches = store.Data.Sessions.Where(s => s.Seconds > 0 &&
            (sessionsGame == "" || s.GameId == sessionsGame) && SessionLast(s) >= since).OrderByDescending(SessionLast).ToList();
        sessionContent.Children.Clear();
        int gameCount = matches.Select(s => s.GameId).Distinct().Count();
        sessionContent.Children.Add(UI.Card(UI.Stack(
            UI.Text(SessionDuration(matches.Sum(s => s.Seconds)) + " neste PC", 17, "#EDE8F5", true),
            UI.Text(matches.Count + (matches.Count == 1 ? " sessão · " : " sessões · ") +
                gameCount + (gameCount == 1 ? " jogo" : " jogos"), 12, "#BFBCD0")), 13));
        var entries = new StackPanel();
        var games = store.Data.Games.ToDictionary(game => game.Id);
        var catalog = new Dictionary<string, GameEntry>();
        foreach (var session in matches.Take(100)) {
            GameEntry entry;
            if (!catalog.TryGetValue(session.GameId, out entry)) {
                TrackedGame tracked;
                entry = games.TryGetValue(session.GameId, out tracked) ? CatalogGame(tracked)
                    : new GameEntry { Name = session.GameId, Platform = "Histórico" };
                catalog[session.GameId] = entry;
            }
            var detail = UI.Row(UI.Stack(UI.Text(entry.Name, 14, "#F0EAF8", true),
                UI.Text(SessionDate(session) + " · " + entry.Platform, 11, "#BEB8CE")), UI.Text(SessionDuration(session.Seconds), 12, "#D6C5FA", true));
            detail.VerticalAlignment = VerticalAlignment.Center;
            var cover = GamePosterButton(entry, 85, 37);
            var row = GameCoverRow(cover, detail);
            row.Margin = new Thickness(0, 4, 0, 4);
            entries.Children.Add(row);
        }
        if (matches.Count == 0) entries.Children.Add(UI.Text("Nenhuma sessão nesse período.", 12, "#BEB8CE"));
        if (matches.Count > 100) entries.Children.Add(UI.Text("Exibindo as 100 sessões mais recentes.", 11, "#BEB8CE"));
        sessionContent.Children.Add(UI.Card(entries, 13));
    }
}
}
