using System;
using System.IO;
using System.Linq;

namespace LuaMonitor {
public static class PlaytimeChecks {
    static void Check(bool value, string message) { if (!value) throw new Exception("Horas: " + message); }
    public static void Run() {
        string directory = Path.Combine(Path.GetTempPath(), "lua-playtime-check-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        try {
            string file = Path.Combine(directory, "history.json");
            var store = new PlaytimeStore(file);
            var game = store.Register("Forza Horizon", "Executável local");
            game.Executable = @"C:\Games\Forza\game.exe";
            var process = new RunningGameProcess { Path = game.Executable, Title = "Forza", HasWindow = false };
            Check(PlaytimeStore.Matches(game, process), "executável independente sem janela");
            Check(!PlaytimeStore.Matches(game, new RunningGameProcess { Path = @"C:\Games\Forza\other.exe" }), "executável exato");
            var folder = new TrackedGame { Folder = @"C:\Games\Forza" };
            process.HasWindow = true;
            Check(PlaytimeStore.Matches(folder, process), "detecção pela instalação");
            Check(!PlaytimeStore.Matches(folder, new RunningGameProcess { Path = @"C:\Games\Forza2\game.exe", HasWindow = true }), "limite de pasta");
            Check(!PlaytimeStore.Matches(folder, new RunningGameProcess { Path = @"C:\Games\Forza\launcher.exe", HasWindow = true }), "launcher excluído");
            var emulator = new TrackedGame { Executable = @"C:\Emulators\pcsx2.exe", WindowTitle = "SLUS-12345" };
            Check(PlaytimeStore.Matches(emulator, new RunningGameProcess { Path = emulator.Executable, Title = "Game | SLUS-12345" }), "jogo emulado identificado");
            Check(!PlaytimeStore.Matches(emulator, new RunningGameProcess { Path = emulator.Executable, Title = "PCSX2" }), "menu do emulador excluído");
            var now = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            store.Tick(new[] { game.Id, game.Id }, 0, now);
            store.Tick(new[] { game.Id, game.Id }, 5, now.AddSeconds(5));
            Check(game.Seconds == 5 && store.Data.Sessions.Count == 1, "processos duplicados contam uma vez");
            store.Tick(new[] { game.Id }, 3600, now.AddHours(1));
            Check(game.Seconds == 5 && store.Data.Sessions.Count == 2, "suspensão encerra a sessão sem contar a pausa");
            store.Import(game.Name, "Steam", "conta-a", 3600);
            store.Import(game.Name, "Steam", "conta-a", 3600);
            Check(game.TotalSeconds == 3600 && game.Imports.Count == 1, "reimportação idempotente");
            store.Import(game.Name, "Steam", "conta-b", 7200);
            Check(game.TotalSeconds == 10800, "soma de contas");
            store.Tick(new[] { game.Id }, 5, now.AddHours(1).AddSeconds(5));
            Check(game.TotalSeconds == 10805, "novas horas após importação");
            store.Import(game.Name, "Steam", "conta-a", 3600);
            Check(game.TotalSeconds == 10805, "snapshot antigo preserva sessões novas");
            store.Tick(new string[0], 5, now.AddHours(1).AddSeconds(10));
            Check(store.Active.Count == 0 && game.Seconds == 10, "encerramento do processo");
            Check(!PlaytimeStore.ValidSeconds(double.NaN) && !PlaytimeStore.ValidSeconds(-1), "valores inválidos");
            var steamNames = new System.Collections.Generic.Dictionary<string, string> { { "123", "Jogo" } };
            string vdf = "\"UserLocalConfigStore\" { \"Software\" { \"Valve\" { \"Steam\" { \"apps\" { \"123\" { \"Playtime\" \"60\" \"PlaytimeDisconnected\" \"30\" } } } } } }";
            var local = SteamLocalPlaytime.Read(vdf, "76561198000000001", steamNames);
            Check(local.Count == 1 && local[0].Hours == 1.5, "Steam local inclui minutos desconectados");
            bool rejected = false;
            try { SteamLocalPlaytime.Parse("\"broken\" {"); } catch (InvalidDataException) { rejected = true; }
            Check(rejected, "VDF truncado rejeitado");
            var rpcs3 = EmulatorPlaytime.Read("rpcs3.exe", "FPS: 59.94 | Vulkan | 0.0.38 | Demon's Souls [BLUS30443]");
            Check(rpcs3 != null && rpcs3.Name == "Demon's Souls" && rpcs3.Token == "BLUS30443", "RPCS3 automático");
            Check(EmulatorPlaytime.Read("rpcs3.exe", "RPCS3 0.0.38 | master") == null, "RPCS3 ocioso");
            Check(EmulatorPlaytime.Read("PPSSPPWindows64.exe", "PPSSPP v1.19 - ULUS12345 : Example Game").Name == "Example Game", "PPSSPP automático");
            Check(EmulatorPlaytime.Read("Ryujinx.exe", "Ryujinx 1.1.0 - Example Game v1.0.0 (0100000000000001) (64-bit)").Name == "Example Game", "Ryujinx automático");
            Check(EmulatorPlaytime.Read("Cemu.exe", "Cemu 2.0 - FPS: 60 [Vulkan] [TitleId: 00050000-12345678] Example Game [US v32]").Name == "Example Game", "Cemu automático");
            Check(EmulatorPlaytime.Read("mGBA.exe", "mGBA - Example Game (60 fps) - 0.10.0").Name == "Example Game", "mGBA automático");
            Check(EmulatorPlaytime.Read("mGBA.exe", "mGBA - 0.10.0") == null, "mGBA ocioso");
            store.Save(); store.Save();
            var loaded = new PlaytimeStore(file);
            Check(loaded.Find(game.Name).TotalSeconds == 10805 && loaded.Active.Count == 0 && File.Exists(file + ".bak"), "persistência e reinício sem sessão fantasma");
            File.WriteAllText(file, "corrompido");
            var broken = new PlaytimeStore(file); broken.Save();
            Check(broken.Data == null && File.ReadAllText(file) == "corrompido", "histórico corrompido preservado");
            File.WriteAllText(file, "{\"Version\":99,\"Games\":[],\"Sessions\":[]}");
            var future = new PlaytimeStore(file); future.Save();
            Check(future.Data == null && File.ReadAllText(file).Contains("99"), "versão desconhecida preservada");
            string current = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
            Check(PlaytimeStore.Processes().Any(p => string.Equals(p.Path, current, StringComparison.OrdinalIgnoreCase)), "enumeração real de processos");
        } finally { Directory.Delete(directory, true); }
    }
}
public sealed partial class DesktopController {
    async System.Threading.Tasks.Task VerifyPlaytimeUi(System.Collections.Generic.List<string> checks, string directory) {
        if (Preferences.DataDir == Preferences.DefaultDataDir) throw new Exception("Use --data com uma pasta de teste.");
        await LoadGames();
        playtime = new PlaytimeStore(Path.Combine(directory, "preview-playtime.json"));
        playtime.Data = new PlaytimeData();
        var game = playtime.Register("Jogo demonstrativo", "Executável local");
        playtime.Import(game.Name, "Steam", "Conta de exemplo A", 7200);
        playtime.Import(game.Name, "Steam", "Conta de exemplo B", 3600);
        playtime.Tick(new[] { game.Id }, 0, DateTime.UtcNow);
        playtime.Tick(new[] { game.Id }, 5, DateTime.UtcNow.AddSeconds(5));
        library = new GameLibrary();
        library.Games.Add(new GameEntry { Name = game.Name, Platform = "Executável local", Folder = @"C:\Exemplo\Jogo", Bytes = 1024L * 1024 * 1024, SizeSource = "Dados demonstrativos" });
        libraryLoaded = true;
        SetMode(false, false); BuildPage("games");
        await System.Threading.Tasks.Task.Delay(200);
        window.UpdateLayout();
        UI.Capture(window, Path.Combine(directory, "playtime-library.png"));
        if (playtimeSummary.Children.Count < 2) throw new Exception("Resumo ou sessão ausente na biblioteca.");
        SetMode(true, false); BuildPage("games");
        await System.Threading.Tasks.Task.Delay(200);
        UI.Capture(window, Path.Combine(directory, "playtime-compact.png"));
        if (library.Games.Count != 1 || library.Games[0].Name != "Jogo demonstrativo") throw new Exception("A prévia deve conter somente os dados demonstrativos.");
        checks.Add("Biblioteca ampliada e compacta renderizadas com sessão e contas demonstrativas.");
        playtime = new PlaytimeStore(Path.Combine(directory, "live-process-check.json"));
        playtime.Data = new PlaytimeData();
        var probe = playtime.Register("Processo de teste do LUA", "Teste");
        probe.Executable = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
        playtimeCatalogRefresh = DateTime.UtcNow.AddHours(1);
        await ScanPlaytime();
        await System.Threading.Tasks.Task.Delay(5100);
        await ScanPlaytime();
        if (probe.Seconds < 5 || probe.Seconds > 15 || !playtime.Active.ContainsKey(probe.Id)) throw new Exception("O monitor não contou o processo real.");
        probe.Executable = Path.Combine(directory, "processo-ausente.exe");
        await ScanPlaytime();
        if (playtime.Active.ContainsKey(probe.Id)) throw new Exception("O monitor não encerrou a sessão.");
        checks.Add("Monitor integrado contou um processo real iniciado externamente, persistiu e encerrou a sessão ao perder o processo cadastrado.");
    }
}
}
