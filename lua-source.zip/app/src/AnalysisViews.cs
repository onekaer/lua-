using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace LuaMonitor {
public sealed partial class DesktopController {
    const string AnalysisMuted = "#AEAAAF", AnalysisText = "#F0EDF2", AnalysisWarning = "#EBC86F";
    bool analysisRefreshing;
    string analysisRefreshMessage;
    Task<Inventory> inventoryReading;

    async Task ReadInventory() {
        if (inventoryReading == null || inventoryReading.IsCompleted)
            inventoryReading = Task.Run(() => Inventory.Load());
        var result = await inventoryReading;
        if (!exiting) inventory = result;
    }

    async void InitializeInventory() {
        try {
            await ReadInventory();
            if (exiting) return;
            if (page == "hardware") BuildPage(page);
            else Refresh();
        } catch (Exception ex) { System.Diagnostics.Debug.WriteLine(ex.Message); }
    }

    async void RefreshAnalysis() {
        var owner = sharedOwner ?? this;
        if (owner.analysisRefreshing) return;
        owner.analysisRefreshing = true;
        owner.analysisRefreshMessage = null;
        owner.Refresh();
        DateTime previous = owner.snapshot.Time;
        try {
            var hardware = owner.ReadInventory();
            if (!owner.sampling.IsCompleted) await owner.sampling;
            await owner.SampleAsync();
            await hardware;
            if (owner.snapshot.Time == previous) owner.analysisRefreshMessage = "Não foi possível obter uma nova leitura.";
        } catch (Exception) {
            owner.analysisRefreshMessage = "Não foi possível concluir a atualização.";
        } finally {
            owner.analysisRefreshing = false;
            if (!owner.exiting) owner.Refresh();
        }
    }

    void Analysis() {
        var owner = sharedOwner ?? this;
        if (!widgetSurface) {
            var title = UI.Stack(UI.Text("Analisar PC", compact ? 23 : 31, AnalysisText, true),
                UI.Text("Confira os componentes e as leituras do sistema.", 12, AnalysisMuted));
            var refresh = LibraryButton("Atualizar diagnóstico", RefreshAnalysis, true, "\uE72C");
            updates.Add(s => refresh.IsEnabled = !owner.analysisRefreshing);
            var export = LibraryButton("Exportar relatório", ExportReport, glyph:"\uE896");
            var actions = new WrapPanel { VerticalAlignment = VerticalAlignment.Center };
            export.Margin = new Thickness(0,0,6,4);
            refresh.Margin = new Thickness(0,0,0,4);
            actions.Children.Add(export);
            actions.Children.Add(refresh);
            var header = UI.Row(title, actions);
            header.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            header.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            header.SizeChanged += (sender, args) => {
                bool stack = args.NewSize.Width < 610;
                Grid.SetRow(actions, stack ? 1 : 0);
                Grid.SetColumn(actions, stack ? 0 : 1);
                Grid.SetColumnSpan(actions, stack ? 2 : 1);
                actions.HorizontalAlignment = stack ? HorizontalAlignment.Left : HorizontalAlignment.Right;
                actions.Margin = new Thickness(0, stack ? 10 : 0, 0, 0);
            };
            header.Margin = new Thickness(0,0,0,14);
            body.Children.Add(header);
        } else {
            body.Children.Add(UI.Columns(UI.Button("Atualizar diagnóstico", RefreshAnalysis, true),
                UI.Button("Exportar relatório", ExportReport)));
        }

        body.Children.Add(AnalysisSummary());
        var metrics = new ActionGrid { Margin = new Thickness(0,0,0,13) };
        metrics.Children.Add(AnalysisMetric("Processador", "hardware", CpuLine,
            s => Format.Percent(s.Cpu), s => "Uso da CPU", s => TemperatureLine(s.CpuTemp)));
        metrics.Children.Add(AnalysisMetric("Placa de vídeo", "gaming", GpuLine,
            s => Format.Percent(s.Gpu), s => "Uso da GPU", s => TemperatureLine(s.GpuTemp)));
        metrics.Children.Add(AnalysisMetric("Memória RAM", "processes", MemoryLine,
            s => Format.Percent(s.RamTotal == 0 ? (double?)null : s.RamPercent),
            s => s.RamTotal == 0 ? "Capacidade indisponível" : BytesUsed(s.RamTotal,s.RamAvailable),
            s => s.RamTotal == 0 ? "Disponível —" : Format.Bytes(s.RamAvailable) + " disponíveis"));
        body.Children.Add(metrics);
        var system = OverviewColumns(AnalysisStorage(), AnalysisNetwork());
        body.Children.Add(system);
        body.Children.Add(AnalysisInventory());
    }

    static bool HasAnalysisSample(Snapshot s) {
        return s.Cpu.HasValue || s.Gpu.HasValue || s.RamTotal > 0 || s.Disks.Count > 0 || s.Networks.Count > 0
            || s.CpuTemp.HasValue || s.GpuTemp.HasValue || s.Uptime > TimeSpan.Zero;
    }

    List<string> AnalysisFindings(Snapshot s) {
        var findings = new List<string>();
        if (s.Cpu >= 90) findings.Add("CPU em " + Format.Percent(s.Cpu) + " nesta leitura");
        if (s.CpuTemp >= prefs.CpuWarning) findings.Add("CPU a " + Format.Temp(s.CpuTemp));
        if (s.RamTotal > 0 && s.RamPercent >= prefs.RamWarning)
            findings.Add("Memória em " + Format.Percent(s.RamPercent));
        foreach (var disk in s.Disks.Where(d => d.Total > 0 && d.UsedPercent >= 90))
            findings.Add(disk.Name + " com " + Format.Bytes(disk.Free) + " livres");
        return findings;
    }

    Border AnalysisSummary() {
        var owner = sharedOwner ?? this;
        var status = UI.Text("", 18, AnalysisText, true);
        var detail = UI.Text("", 12, AnalysisMuted);
        var time = UI.Text("", 11, AnalysisMuted);
        var glyph = UI.Icon("analysis", UI.FocusColor, 20);
        var action = LibraryButton("Ver processos", () => BuildPage("processes"));
        var text = UI.Stack(status, detail);
        detail.Margin = new Thickness(0,4,0,0);
        glyph.Margin = new Thickness(0,0,10,0);
        glyph.VerticalAlignment = VerticalAlignment.Top;
        var leading = new DockPanel();
        DockPanel.SetDock(glyph,Dock.Left);
        leading.Children.Add(glyph);
        leading.Children.Add(text);
        var footer = UI.Row(time,action);
        footer.Margin = new Thickness(0,9,0,0);
        var card = UI.Card(UI.Stack(leading,footer),15);
        card.BorderThickness = new Thickness(1);
        card.Margin = new Thickness(0,0,0,13);
        updates.Add(s => {
            bool sampled = HasAnalysisSample(s);
            var findings = AnalysisFindings(s);
            int count = findings.Count;
            status.Text = !sampled ? "Aguardando a primeira leitura" : count == 0 ? "Sem alertas na leitura atual"
                : count == 1 ? "1 ponto de atenção" : count + " pontos de atenção";
            glyph.Tint = UI.Brush(count == 0 ? UI.FocusColor : AnalysisWarning);
            status.Foreground = UI.Brush(count == 0 ? AnalysisText : AnalysisWarning);
            detail.Text = count == 0 ? "Uso, temperatura e espaço das unidades nos sensores disponíveis."
                : string.Join(" · ", findings) + ".";
            time.Text = owner.analysisRefreshing ? "Atualizando…" : owner.analysisRefreshMessage ??
                (sampled ? "Leitura às " + s.Time.ToString("HH:mm:ss") : "Aguardando os sensores…");
        });
        return card;
    }

    static string BytesUsed(ulong total, ulong available) {
        return Format.Bytes(total - Math.Min(total,available)) + " de " + Format.Bytes(total) + " em uso";
    }

    static string TemperatureLine(double? value) {
        return value.HasValue ? Format.Temp(value) + " · temperatura" : "Temperatura indisponível";
    }

    Border AnalysisMetric(string label, string icon, string color, Func<Snapshot,string> value,
        Func<Snapshot,string> note, Func<Snapshot,string> detail) {
        var reading = Value(value,28,AnalysisText,true);
        reading.Margin = new Thickness(0,4,0,2);
        var panel = UI.Stack(UI.Row(UI.Text(label,13,AnalysisText,true),UI.Icon(icon,color,16)),
            reading,Value(note,11,AnalysisMuted),Value(detail,11,color));
        var card = UI.Card(panel,13);
        card.Margin = new Thickness(0);
        return card;
    }

    Border AnalysisStorage() {
        var units = new StackPanel();
        string last = null;
        updates.Add(s => {
            string state = string.Join("|",s.Disks.Select(d => d.Name + ":" + d.Label + ":" + d.Total + ":" + d.Free));
            if (last == state) return;
            last = state;
            units.Children.Clear();
            if (s.Disks.Count == 0) units.Children.Add(UI.Text("Nenhuma unidade com leitura disponível.",12,AnalysisMuted));
            foreach (var disk in s.Disks) {
                bool full = disk.Total > 0 && disk.UsedPercent >= 90;
                string name = string.IsNullOrWhiteSpace(disk.Label) ? disk.Name : disk.Name + " · " + disk.Label;
                var usage = UI.Text(disk.Total > 0 ? Format.Percent(disk.UsedPercent) : "—",12,full?AnalysisWarning:AnalysisMuted);
                var line = UI.Row(UI.Text(name,13,AnalysisText,true),usage);
                var space = UI.Text(disk.Total > 0 ? Format.Bytes(disk.Free) + " livres de " + Format.Bytes(disk.Total)
                    : "Capacidade indisponível",11,AnalysisMuted);
                var row = UI.Stack(line,space);
                row.Margin = new Thickness(0,0,0,6);
                if (disk.Total > 0) row.Children.Add(new ProgressBar {
                    Value = Math.Max(0,Math.Min(100,disk.UsedPercent)),
                    Foreground = UI.Brush(full ? AnalysisWarning : UI.FocusColor),
                    Margin = new Thickness(0,5,0,0)
                });
                units.Children.Add(row);
            }
        });
        return DashboardCard("Armazenamento",units,LibraryButton("Ver armazenamento",()=>BuildPage("storage")));
    }

    Border AnalysisNetwork() {
        var content = UI.Stack(
            Value(s => s.Networks.Count == 0 ? "Nenhuma interface ativa identificada"
                : s.Networks.Count == 1 ? "1 interface ativa" : s.Networks.Count + " interfaces ativas",13,AnalysisText,true),
            Value(s => s.Networks.Count == 0 ? "Recebimento —" : "↓ " + Format.Rate(s.Download) + " de recebimento",12,AnalysisMuted),
            Value(s => s.Networks.Count == 0 ? "Envio —" : "↑ " + Format.Rate(s.Upload) + " de envio",12,AnalysisMuted));
        return DashboardCard("Rede local",content,LibraryButton("Ver rede e testar conexão",()=>BuildPage("network")));
    }

    Border AnalysisInventory() {
        var cpu = InventoryField("Processador", i => i.Cpu);
        var gpu = InventoryField("Placa de vídeo", i => i.Gpu);
        var board = InventoryField("Placa-mãe", i => i.Board);
        var os = InventoryField("Windows", i => i.Os);
        var ram = InventoryField("Módulos de RAM", i => i.Ram);
        var disks = InventoryField("Discos físicos", i => i.Disks);
        var readings = Value(s => s.SensorStatus,12,AnalysisMuted);
        var details = UI.Stack(UI.Columns(UI.Stack(os,cpu,gpu),UI.Stack(board,ram,disks)),readings,
            UI.Text("A análise usa as leituras disponíveis. O espaço livre não mede a saúde física do disco.",11,AnalysisMuted),
            LibraryButton("Ver sensores de hardware",()=>BuildPage("hardware")));
        return UI.Card(UI.Fold("Inventário e sensores",details),14);
    }

    StackPanel InventoryField(string label, Func<Inventory,string> read) {
        var model = Value(s => {
            string value = read(inventory);
            return string.IsNullOrWhiteSpace(value) ? "Não disponível" : value;
        },12,AnalysisText);
        var row = UI.Stack(UI.Label(label),model);
        row.Margin = new Thickness(0,0,0,8);
        return row;
    }

    string Report() {
        var s = snapshot;
        var report = new StringBuilder();
        report.AppendLine("LUA • RELATÓRIO DO COMPUTADOR");
        report.AppendLine(HasAnalysisSample(s) ? "Leitura de " + s.Time.ToString("dd/MM/yyyy HH:mm:ss") : "Leitura ainda indisponível");
        var findings = AnalysisFindings(s);
        report.AppendLine("\nPONTOS DE ATENÇÃO");
        if (findings.Count == 0) report.AppendLine(HasAnalysisSample(s) ? "Nenhum alerta na leitura atual." : "Ainda sem dados.");
        else foreach (string finding in findings) report.AppendLine("• " + finding);
        report.AppendLine("\nINVENTÁRIO\n" + inventory.Os + "\nCPU: " + inventory.Cpu + "\nGPU: " + inventory.Gpu
            + "\nPlaca-mãe: " + inventory.Board + "\nRAM: " + inventory.Ram + "\nDiscos físicos: " + inventory.Disks);
        report.AppendLine("\nLEITURAS\nCPU: " + Format.Percent(s.Cpu) + " | GPU: " + Format.Percent(s.Gpu));
        report.AppendLine("Temperatura CPU: " + Format.Temp(s.CpuTemp) + " | GPU: " + Format.Temp(s.GpuTemp));
        report.AppendLine("RAM: " + (s.RamTotal > 0 ? BytesUsed(s.RamTotal,s.RamAvailable) : "—"));
        report.AppendLine("Rede local: " + s.Networks.Count + " interfaces ativas");
        if (s.Networks.Count > 0) report.AppendLine("Recebimento: " + Format.Rate(s.Download) + " | Envio: " + Format.Rate(s.Upload));
        report.AppendLine("Tempo ligado: " + (HasAnalysisSample(s) ? s.Uptime.ToString(@"d\.hh\:mm\:ss") : "—"));
        foreach (var disk in s.Disks) report.AppendLine(disk.Name + " " + (disk.Total > 0
            ? Format.Bytes(disk.Free) + " livres de " + Format.Bytes(disk.Total) : "Capacidade indisponível"));
        report.AppendLine("\nSENSORES\n" + s.SensorStatus);
        foreach (var sensor in s.Sensors) report.AppendLine(sensor.Device + " / " + sensor.Name + ": " + sensor.Value.ToString("0.0") + " " + sensor.Unit);
        if (inventory.Errors.Count > 0) report.AppendLine("\nINVENTÁRIO PARCIAL\n" + string.Join("\n",inventory.Errors));
        report.AppendLine("\nA análise reflete a coleta atual e não inclui benchmark, teste de estresse ou saúde SMART.");
        return report.ToString();
    }

    void ExportReport() {
        var dialog = new SaveFileDialog { Filter = "Texto|*.txt", FileName = "LUA-diagnostico.txt" };
        if (dialog.ShowDialog(window) != true) return;
        try {
            File.WriteAllText(dialog.FileName,Report(),new UTF8Encoding(true));
            ShowToast("Relatório salvo",Path.GetFileName(dialog.FileName));
        } catch (Exception ex) { Notice(ex.Message); }
    }
}
}
