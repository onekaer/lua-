﻿using System;
using System.Collections.Generic;
using System.Linq;
using NAudio.CoreAudioApi;
using NAudio.Wave;
namespace LuaMonitor {
public static class AudioDevices {
    public static Dictionary<string,string> List(bool microphone){var result=new Dictionary<string,string>{{"Padrão do Windows",""}};try{using(var enumerator=new MMDeviceEnumerator()){foreach(var device in enumerator.EnumerateAudioEndPoints(microphone?DataFlow.Capture:DataFlow.Render,DeviceState.Active)){using(device)result[device.FriendlyName+" • "+result.Count]=device.ID;}}}catch{}return result;}
    public static MMDevice Get(string id,bool microphone){using(var enumerator=new MMDeviceEnumerator())return string.IsNullOrWhiteSpace(id)?enumerator.GetDefaultAudioEndpoint(microphone?DataFlow.Capture:DataFlow.Render,Role.Multimedia):enumerator.GetDevice(id);}
    public static short Mix(short system,short microphone,double systemGain,double micGain){return (short)Math.Max(short.MinValue,Math.Min(short.MaxValue,(int)(system*Math.Max(0,Math.Min(1,systemGain))+microphone*Math.Max(0,Math.Min(1,micGain)))));}
}
public sealed partial class DesktopController {
    System.Windows.UIElement AudioOptions(){var outputs=AudioDevices.List(false);var inputs=AudioDevices.List(true);return UI.Stack(UI.Check("Gravar áudio do PC",prefs.Video.Audio,v=>{prefs.Video.Audio=v;Save();}),UI.Label("Saída de áudio"),UI.Choice(outputs.Keys,outputs.FirstOrDefault(p=>p.Value==prefs.Video.OutputDevice).Key??outputs.Keys.First(),v=>{prefs.Video.OutputDevice=outputs[v];Save();}),UI.Label("Volume do PC na gravação"),Slider(0,1,prefs.Video.SystemGain,v=>{prefs.Video.SystemGain=v;Save();},v=>(v*100).ToString("0")+"%"),UI.Check("Gravar microfone",prefs.Video.Microphone,v=>{prefs.Video.Microphone=v;Save();}),UI.Label("Microfone"),UI.Choice(inputs.Keys,inputs.FirstOrDefault(p=>p.Value==prefs.Video.InputDevice).Key??inputs.Keys.First(),v=>{prefs.Video.InputDevice=inputs[v];Save();}),UI.Label("Volume do microfone na gravação"),Slider(0,1,prefs.Video.MicGain,v=>{prefs.Video.MicGain=v;Save();},v=>(v*100).ToString("0")+"%"),UI.Text("As duas fontes são combinadas no vídeo. Alterações valem para a próxima captura. O microfone começa desligado.",11,"#AAAABC"));}
}
}
