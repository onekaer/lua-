using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace LuaMonitor {
public sealed class OverlayWindow : Window {
    Preferences prefs;Border shell;StackPanel rows;IntPtr handle;string signature="";Dictionary<string,TextBlock> values=new Dictionary<string,TextBlock>();TextBlock state;
    public OverlayWindow(Preferences p){prefs=p;Title="LUA • Sobreposição";WindowStyle=WindowStyle.None;AllowsTransparency=true;Background=Brushes.Transparent;Topmost=true;ShowInTaskbar=false;ShowActivated=false;SizeToContent=SizeToContent.WidthAndHeight;ResizeMode=ResizeMode.NoResize;UseLayoutRounding=true;SnapsToDevicePixels=true;FontFamily=UI.Font;UI.SmoothText(this,true);
        rows=new StackPanel();shell=UI.Card(rows,14);shell.Margin=new Thickness(0);Content=shell;
        SourceInitialized+=(s,e)=>{handle=new WindowInteropHelper(this).Handle;HwndSource.FromHwnd(handle).AddHook(InputHook);Apply();};MouseLeftButtonDown+=(s,e)=>{if(!prefs.OverlayLocked)try{DragMove();}catch{}};Loaded+=(s,e)=>Position();
    }
    IntPtr InputHook(IntPtr hwnd,int message,IntPtr wp,IntPtr lp,ref bool handled){if(message==0x21){handled=true;return new IntPtr(3);}if(message==0x84&&prefs.OverlayLocked){handled=true;return new IntPtr(-1);}return IntPtr.Zero;}
    public void Apply(){shell.IsHitTestVisible=!prefs.OverlayLocked;Focusable=false;shell.Opacity=1;shell.Background=new SolidColorBrush(Color.FromArgb((byte)(prefs.OverlayOpacity*255),20,22,22));shell.BorderBrush=new SolidColorBrush(Color.FromArgb((byte)(prefs.OverlayOpacity*255),46,52,49));shell.LayoutTransform=Transform.Identity;shell.Padding=new Thickness(14*prefs.OverlayScale);
        if(handle!=IntPtr.Zero){int style=Native.GetWindowLong(handle,-20)|0x80|0x08000000;if(prefs.OverlayLocked)style|=0x20;else style&=~0x20;Native.SetWindowLong(handle,-20,style);}UpdateLayout();Position();
    }
    public void Position(){var screen=System.Windows.Forms.Screen.FromPoint(System.Windows.Forms.Cursor.Position).WorkingArea;var source=PresentationSource.FromVisual(this);double sx=source==null?1:source.CompositionTarget.TransformFromDevice.M11,sy=source==null?1:source.CompositionTarget.TransformFromDevice.M22;Left=prefs.OverlayPosition.Contains("direito")?(screen.Right*sx)-ActualWidth-22:screen.Left*sx+22;Top=prefs.OverlayPosition.Contains("Inferior")?screen.Bottom*sy-ActualHeight-22:screen.Top*sy+22;}
    void Build(){
        values.Clear();rows.Children.Clear();var brand=UI.Text("LUA  /  MONITOR",11*prefs.OverlayScale,"#C2CBC6",true);UI.SmoothText(brand,true);rows.Children.Add(brand);
        if(prefs.ShowFps)Add("FPS","gaming","FPS");if(prefs.ShowFpsLow)Add("LOW","gaming","1% low");if(prefs.ShowFpsMinimum)Add("MIN","gaming","FPS mínimo");if(prefs.ShowFpsMaximum)Add("MAX","gaming","FPS máximo");if(prefs.ShowCpu)Add("CPU","hardware","CPU • uso total");if(prefs.ShowGpu)Add("GPU","hardware","GPU • uso total");if(prefs.ShowRam)Add("RAM","processes","Memória");if(prefs.ShowTemps)Add("TEMP","hardware","Temperaturas");if(prefs.ShowNetwork)Add("REDE","network","Rede");
        state=UI.Text("",11*prefs.OverlayScale,"#ACACB8");state.MaxWidth=350*prefs.OverlayScale;state.Margin=new Thickness(0,8,0,0);UI.SmoothText(state,true);rows.Children.Add(state);
    }
    void Add(string key,string icon,string label){var left=new StackPanel{Orientation=Orientation.Horizontal};left.Children.Add(UI.Icon(icon,"#A3A3B0",16*prefs.OverlayScale));var text=UI.Text(label,12*prefs.OverlayScale,"#B0B0BB");text.Margin=new Thickness(7,0,15,0);UI.SmoothText(text,true);left.Children.Add(text);var value=UI.Text("—",14*prefs.OverlayScale,"#F5F5F7",true);UI.SmoothText(value,true);var row=UI.Row(left,value);row.Margin=new Thickness(0,9*prefs.OverlayScale,0,0);rows.Children.Add(row);values[key]=value;}
    void Set(string key,string text){TextBlock value;if(values.TryGetValue(key,out value))value.Text=text;}
    public void Update(Snapshot s,FpsReader fps){string next=string.Join("|",prefs.ShowFps,prefs.ShowFpsLow,prefs.ShowFpsMinimum,prefs.ShowFpsMaximum,prefs.ShowCpu,prefs.ShowGpu,prefs.ShowRam,prefs.ShowTemps,prefs.ShowNetwork,prefs.OverlayScale);if(signature!=next){signature=next;Build();}
        Set("FPS",DesktopController.FpsText(fps.Fps));Set("LOW",DesktopController.FpsText(fps.Low));Set("MIN",DesktopController.FpsText(fps.Minimum));Set("MAX",DesktopController.FpsText(fps.Maximum));Set("CPU",s.Cpu.HasValue?Format.Percent(s.Cpu):"coletando…");Set("GPU",s.Gpu.HasValue?Format.Percent(s.Gpu):"indisponível");Set("RAM",Format.Bytes(s.RamTotal-s.RamAvailable)+" / "+Format.Bytes(s.RamTotal));Set("TEMP","CPU "+Format.Temp(s.CpuTemp)+"  •  GPU "+Format.Temp(s.GpuTemp));Set("REDE","↓ "+Format.Rate(s.Download)+"  ↑ "+Format.Rate(s.Upload));
        state.Text=!prefs.OverlayLocked?"Arraste para mover":prefs.ShowFps&&!fps.Fps.HasValue?(fps.Running?"FPS: aguardando frames do jogo":"FPS: "+fps.Status):"";state.Visibility=state.Text==""?Visibility.Collapsed:Visibility.Visible;ApplyBackground();
    }
    void ApplyBackground(){shell.Background=new SolidColorBrush(Color.FromArgb((byte)(prefs.OverlayOpacity*255),20,22,22));shell.Opacity=1;}
}
public sealed partial class DesktopController {

    bool KnownGame(int pid){try{using(var p=System.Diagnostics.Process.GetProcessById(pid)){string path=p.MainModule.FileName;return library.Games.Exists(g=>CleanupEngine.Inside(path,g.Folder));}}catch{return false;}}
    void RememberForegroundGame(){try{uint pid;Native.GetWindowThreadProcessId(Native.GetForegroundWindow(),out pid);if(pid==0||pid==System.Diagnostics.Process.GetCurrentProcess().Id||!KnownGame((int)pid))return;using(var p=System.Diagnostics.Process.GetProcessById((int)pid)){targetPid=(int)pid;targetName=p.ProcessName;}}catch{}}
}
}
