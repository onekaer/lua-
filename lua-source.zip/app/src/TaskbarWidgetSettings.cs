using System;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Interop;
using Drawing = System.Drawing;

namespace LuaMonitor {
public sealed partial class DesktopController {
    TaskbarWidget taskbarWidget;
    Window taskbarEditor;

    void ApplyTaskbarWidget() {
        if (sharedOwner != null) { sharedOwner.ApplyTaskbarWidget(); return; }
        if (!prefs.Taskbar.Enabled) {
            CloseTaskbarWidget();
            return;
        }
        bool initial = taskbarWidget == null;
        if (initial) taskbarWidget = new TaskbarWidget(window.Resources, TaskbarMonitorPoint,
            () => { ShowMain(); BuildPage("home"); }, EditTaskbarWidget);
        taskbarWidget.Configure(prefs.Taskbar);
        taskbarWidget.Update(snapshot, fps.Fps);
        if (initial) taskbarWidget.Start();
    }

    Drawing.Point TaskbarMonitorPoint() {
        var handle = new WindowInteropHelper(window).Handle;
        // Keep using the main window's last monitor while it is in the notification area.
        var area = handle == IntPtr.Zero ? System.Windows.Forms.Screen.PrimaryScreen.Bounds
            : System.Windows.Forms.Screen.FromHandle(handle).Bounds;
        return new Drawing.Point(area.Left + area.Width / 2, area.Top + area.Height / 2);
    }

    void CloseTaskbarWidget() {
        if (taskbarWidget == null) return;
        var widget = taskbarWidget;
        taskbarWidget = null;
        widget.Close();
    }

    UIElement TaskbarSettings() {
        var enabled = UI.Check("Mostrar widget na barra de tarefas", prefs.Taskbar.Enabled, value => {
            prefs.Taskbar.Enabled = value;
            Save();
            ApplyTaskbarWidget();
        });
        return UI.Card(UI.Stack(
            UI.Text("Widget da barra de tarefas", 17, "#EFEAF9", true),
            enabled,
            UI.Button("Editar posição e métricas", EditTaskbarWidget)));
    }

    void EditTaskbarWidget() {
        if (sharedOwner != null) { sharedOwner.EditTaskbarWidget(); return; }
        if (taskbarEditor != null) { taskbarEditor.Activate(); return; }
        ShowMain();
        var current = prefs.Taskbar;
        var draft = new TaskbarWidgetOptions {
            Enabled = current.Enabled, Right = current.Right, FollowWindow = current.FollowWindow,
            ClickToOpen = current.ClickToOpen, Animate = current.Animate,
            Inset = current.Inset, Tint = current.Tint, Metrics = current.Metrics.ToList()
        };
        var metrics = new StackPanel();
        var validation = UI.Text("", 12, "#FFB8BD");
        Action render = null;
        render = () => {
            metrics.Children.Clear();
            var order = draft.Metrics.Concat(TaskbarWidget.MetricNames.Except(draft.Metrics)).ToList();
            foreach (string metric in order) {
                int index = draft.Metrics.IndexOf(metric);
                string label = index >= 0 && index < 3 ? metric + " · cápsula" : metric;
                var check = UI.Check(label, index >= 0, enabled => {
                    if (enabled) draft.Metrics.Add(metric); else draft.Metrics.Remove(metric);
                    validation.Text = "";
                    render();
                });
                AutomationProperties.SetName(check, metric);
                var moveUp = UI.IconButton("move-up", "Mover " + metric + " para cima", () => {
                    draft.Metrics.RemoveAt(index);
                    draft.Metrics.Insert(index - 1, metric);
                    render();
                });
                var moveDown = UI.IconButton("move-down", "Mover " + metric + " para baixo", () => {
                    draft.Metrics.RemoveAt(index);
                    draft.Metrics.Insert(index + 1, metric);
                    render();
                });
                moveUp.IsEnabled = index > 0;
                moveDown.IsEnabled = index >= 0 && index < draft.Metrics.Count - 1;
                foreach (var button in new[] { moveUp, moveDown }) { button.Width = button.Height = 27; button.MinHeight = 0; }
                var controls = new StackPanel { Orientation = Orientation.Horizontal };
                controls.Children.Add(moveUp);
                controls.Children.Add(moveDown);
                metrics.Children.Add(UI.Row(check, controls));
            }
        };
        render();

        var distance = new TextBox { Text = draft.Inset.ToString(), Margin = new Thickness(0, 3, 0, 8) };
        AutomationProperties.SetName(distance, "Distância da borda em pixels");
        var fields = UI.Stack(
            UI.Check("Mostrar widget", draft.Enabled, value => draft.Enabled = value),
            UI.Label("Lado da barra de tarefas"),
            UI.Choice(new[] { "Esquerda", "Direita" }, draft.Right ? "Direita" : "Esquerda", value => draft.Right = value == "Direita"),
            UI.Label("Monitor"),
            UI.Choice(new[] { "Principal", "Mesmo monitor do painel" }, draft.FollowWindow ? "Mesmo monitor do painel" : "Principal",
                value => draft.FollowWindow = value == "Mesmo monitor do painel"),
            UI.Label("Abrir informações"),
            UI.Choice(new[] { "Ao passar o mouse", "Ao clicar" }, draft.ClickToOpen ? "Ao clicar" : "Ao passar o mouse",
                value => draft.ClickToOpen = value == "Ao clicar"),
            UI.Label("Cor da cápsula"),
            UI.Choice(new[] { "Violeta", "Verde", "Grafite" }, draft.Tint, value => draft.Tint = value),
            UI.Label("Distância da borda (8 a 240 px)"),
            distance,
            UI.Check("Animar abertura e fechamento", draft.Animate, value => draft.Animate = value),
            UI.Text("As três primeiras métricas aparecem na cápsula.", 12, "#B8B3C3"),
            metrics);
        var dialog = NewDialog("Editar widget", new ScrollViewer {
            Content = fields, MaxHeight = Math.Max(210, Math.Min(495, SystemParameters.WorkArea.Height - 165)),
            Padding = new Thickness(0, 8, 5, 0)
        });
        ((Border)dialog.Content).Background = UI.Brush("#191721");
        ((Border)dialog.Content).BorderBrush = UI.Brush("#453B55");
        ((Border)dialog.Content).BorderThickness = new Thickness(1);
        var panel = (StackPanel)dialog.Tag;
        panel.Children.Add(validation);
        var actions = new ActionGrid();
        var cancel = UI.Button("Cancelar", () => dialog.Close());
        cancel.IsCancel = true;
        actions.Children.Add(cancel);
        actions.Children.Add(UI.Button("Aplicar", () => {
            int inset;
            if (!int.TryParse(distance.Text, out inset) || inset < 8 || inset > 240) {
                validation.Text = "Informe uma distância entre 8 e 240 pixels.";
                distance.Focus();
                return;
            }
            if (draft.Metrics.Count == 0) {
                validation.Text = "Escolha pelo menos uma métrica.";
                return;
            }
            draft.Inset = inset;
            prefs.Taskbar = draft;
            Save();
            dialog.Close();
            ApplyTaskbarWidget();
            if (page == "settings") BuildPage("settings");
        }, true));
        panel.Children.Add(actions);
        taskbarEditor = dialog;
        try { dialog.ShowDialog(); }
        finally { taskbarEditor = null; }
    }
}
}
