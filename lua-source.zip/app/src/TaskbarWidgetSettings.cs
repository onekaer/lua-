using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Interop;
using Drawing = System.Drawing;

namespace LuaMonitor {
public sealed partial class DesktopController {
    TaskbarWidget taskbarWidget;
    Window taskbarEditor;

    void ApplyTaskbarWidget() {
        if (sharedOwner != null) { sharedOwner.ApplyTaskbarWidget(); return; }
        if (!prefs.Taskbar.Enabled) {
            CloseTaskbarWidget();
            return;
        }
        bool initial = taskbarWidget == null;
        if (initial) {
            taskbarWidget = new TaskbarWidget(window.Resources, TaskbarMonitorPoint, EditTaskbarWidget,
                ToggleTaskbarPanel, () => taskbarDocked || window.IsActive);
            taskbarWidget.PositionChanged += RepositionTaskbarPanel;
        }
        taskbarWidget.Configure(prefs.Taskbar);
        taskbarWidget.Update(snapshot, fps.Fps);
        if (initial) taskbarWidget.Start();
        if (compact && window.IsVisible) DockTaskbarPanel();
    }

    Drawing.Point TaskbarMonitorPoint() {
        var handle = new WindowInteropHelper(window).Handle;
        // Keep using the main window's last monitor while it is in the notification area.
        var area = handle == IntPtr.Zero ? System.Windows.Forms.Screen.PrimaryScreen.Bounds
            : System.Windows.Forms.Screen.FromHandle(handle).Bounds;
        return new Drawing.Point(area.Left + area.Width / 2, area.Top + area.Height / 2);
    }

    void CloseTaskbarWidget() {
        if (taskbarWidget == null) return;
        bool wasDocked = taskbarDocked;
        ReleaseTaskbarPanel();
        var widget = taskbarWidget;
        taskbarWidget = null;
        widget.PositionChanged -= RepositionTaskbarPanel;
        widget.Close();
        if (wasDocked && window.IsVisible && !exiting) SetMode(true, false);
    }

    UIElement TaskbarSettings() {
        var enabled = UI.Check("Mostrar widget na barra de tarefas", prefs.Taskbar.Enabled, value => {
            prefs.Taskbar.Enabled = value;
            Save();
            ApplyTaskbarWidget();
        });
        return UI.Card(UI.Stack(
            UI.Text("Barra de tarefas", 17, "#EFEAF9", true),
            enabled,
            UI.Button("Personalizar barra de tarefas", EditTaskbarWidget)));
    }

    void EditTaskbarWidget() {
        if (sharedOwner != null) { sharedOwner.EditTaskbarWidget(); return; }
        if (taskbarEditor != null) { taskbarEditor.Activate(); return; }
        ShowMain();
        var current = prefs.Taskbar;
        var draft = new TaskbarWidgetOptions {
            Enabled = current.Enabled, Right = current.Right, Center = current.Center, FollowWindow = current.FollowWindow,
            ClickToOpen = current.ClickToOpen, Animate = current.Animate,
            Inset = current.Inset, Tint = current.Tint, Metrics = current.Metrics.ToList(), WeatherCity = current.WeatherCity,
            CapsuleMetrics = current.SummaryMetrics()
        };
        var metrics = new StackPanel();
        var validation = UI.Text("", 12, "#FFB8BD");
        Action render = null;
        render = () => {
            metrics.Children.Clear();
            var order = draft.Metrics.Concat(TaskbarWidget.MetricNames.Except(draft.Metrics)).ToList();
            foreach (string metric in order) {
                int index = draft.Metrics.IndexOf(metric);
                var check = UI.Check(metric, index >= 0, enabled => {
                    if (enabled) draft.Metrics.Add(metric); else draft.Metrics.Remove(metric);
                    validation.Text = "";
                    render();
                });
                AutomationProperties.SetName(check, metric);
                var moveUp = UI.IconButton("move-up", "Mover " + metric + " para cima", () => {
                    draft.Metrics.RemoveAt(index);
                    draft.Metrics.Insert(index - 1, metric);
                    render();
                });
                var moveDown = UI.IconButton("move-down", "Mover " + metric + " para baixo", () => {
                    draft.Metrics.RemoveAt(index);
                    draft.Metrics.Insert(index + 1, metric);
                    render();
                });
                moveUp.IsEnabled = index > 0;
                moveDown.IsEnabled = index >= 0 && index < draft.Metrics.Count - 1;
                foreach (var button in new[] { moveUp, moveDown }) { button.Width = button.Height = 27; button.MinHeight = 0; }
                var controls = new StackPanel { Orientation = Orientation.Horizontal };
                controls.Children.Add(moveUp);
                controls.Children.Add(moveDown);
                metrics.Children.Add(UI.Row(check, controls));
            }
        };
        render();

        var distance = new TextBox { Text = draft.Inset.ToString(), Margin = new Thickness(0, 3, 0, 8) };
        AutomationProperties.SetName(distance, "Distância da borda em pixels");
        const string noMetric = "Nenhum";
        var slots = draft.CapsuleMetrics.Concat(Enumerable.Repeat(noMetric, 3)).Take(3).ToArray();
        var indicators = new StackPanel();
        for (int i = 0; i < slots.Length; i++) {
            int slot = i;
            string label = "Indicador " + (i + 1);
            var choice = UI.Choice(new[] { noMetric }.Concat(TaskbarWidget.MetricNames), slots[i], value => {
                slots[slot] = value;
                validation.Text = "";
            });
            AutomationProperties.SetName(choice, label);
            indicators.Children.Add(UI.Label(label));
            indicators.Children.Add(choice);
        }
        bool iconOnly = draft.CapsuleMetrics.Count == 0;
        indicators.Visibility = iconOnly ? Visibility.Collapsed : Visibility.Visible;
        var onlyMoon = UI.Check("Mostrar apenas o ícone da lua", iconOnly, value => {
            iconOnly = value;
            indicators.Visibility = value ? Visibility.Collapsed : Visibility.Visible;
            validation.Text = "";
        });
        var fields = UI.Stack(
            UI.Check("Mostrar LUA na barra de tarefas", draft.Enabled, value => draft.Enabled = value),
            UI.Fold("Cápsula na barra", UI.Stack(onlyMoon, indicators), true),
            UI.Label("Posição na barra de tarefas"),
            UI.Choice(new[] { "Esquerda", "Centro", "Direita" }, draft.Center ? "Centro" : draft.Right ? "Direita" : "Esquerda",
                value => { draft.Center = value == "Centro"; draft.Right = value == "Direita"; }),
            UI.Label("Monitor"),
            UI.Choice(new[] { "Principal", "Mesmo monitor do painel" }, draft.FollowWindow ? "Mesmo monitor do painel" : "Principal",
                value => draft.FollowWindow = value == "Mesmo monitor do painel"),
            UI.Check("Prévia ao passar o mouse", !draft.ClickToOpen, value => draft.ClickToOpen = !value),
            UI.Label("Cor da cápsula"),
            UI.Choice(new[] { "Violeta", "Verde", "Grafite" }, draft.Tint, value => draft.Tint = value),
            UI.Label("Distância da borda (8 a 240 px)"),
            distance,
            UI.Check("Animar abertura e fechamento", draft.Animate, value => draft.Animate = value),
            UI.Fold("Cartões do painel", metrics),
            UI.Fold("Cidade para o clima", WeatherCityPicker(draft)));
        var dialog = NewDialog("Personalizar barra de tarefas", new ScrollViewer {
            Content = fields, MaxHeight = Math.Max(210, Math.Min(495, SystemParameters.WorkArea.Height - 165)),
            Padding = new Thickness(0, 8, 5, 0)
        });
        ((Border)dialog.Content).Background = UI.Brush("#191721");
        ((Border)dialog.Content).BorderBrush = UI.Brush("#453B55");
        ((Border)dialog.Content).BorderThickness = new Thickness(1);
        var panel = (StackPanel)dialog.Tag;
        panel.Children.Add(validation);
        var actions = new ActionGrid();
        var cancel = UI.Button("Cancelar", () => dialog.Close());
        cancel.IsCancel = true;
        actions.Children.Add(cancel);
        actions.Children.Add(UI.Button("Aplicar", () => {
            int inset;
            if (!int.TryParse(distance.Text, out inset) || inset < 8 || inset > 240) {
                validation.Text = "Informe uma distância entre 8 e 240 pixels.";
                distance.Focus();
                return;
            }
            if (draft.Metrics.Count == 0) {
                validation.Text = "Escolha pelo menos uma métrica.";
                return;
            }
            var selected = iconOnly ? new List<string>() : slots.Where(value => value != noMetric).ToList();
            if (selected.Count != selected.Distinct().Count()) {
                validation.Text = "Escolha indicadores diferentes para a cápsula.";
                return;
            }
            draft.CapsuleMetrics = selected;
            draft.Inset = inset;
            prefs.Taskbar = draft;
            Save();
            dialog.Close();
            ApplyTaskbarWidget();
            if (page == "settings") BuildPage("settings");
        }, true));
        panel.Children.Add(actions);
        taskbarEditor = dialog;
        try { dialog.ShowDialog(); }
        finally { taskbarEditor = null; }
    }

    StackPanel WeatherCityPicker(TaskbarWidgetOptions draft) {
        var query = new TextBox { MaxLength = 100, Margin = new Thickness(0, 4, 0, 4) };
        AutomationProperties.SetName(query, "Cidade para o clima");
        var status = UI.Text(draft.WeatherCity == null ? "Nenhuma cidade selecionada" : draft.WeatherCity.Name, 12, "#C1C4D0");
        var results = new StackPanel();
        Button search = null;
        search = UI.Button("Buscar cidade", async () => {
            string text = query.Text.Trim();
            if (text.Length < 2) { status.Text = "Digite pelo menos duas letras."; return; }
            search.IsEnabled = false;
            results.Children.Clear();
            status.Text = "Buscando cidades…";
            try {
                var cities = await Task.Run(() => WidgetWeather.Search(text));
                status.Text = cities.Count == 0 ? "Nenhuma cidade encontrada." : "Selecione a cidade.";
                foreach (var city in cities) {
                    var selected = city;
                    results.Children.Add(UI.Button(selected.Name, () => {
                        draft.WeatherCity = selected;
                        status.Text = selected.Name;
                        results.Children.Clear();
                    }));
                }
            } catch (Exception error) {
                System.Diagnostics.Debug.WriteLine(error);
                status.Text = "Busca indisponível. Tente novamente.";
            } finally { search.IsEnabled = true; }
        });
        query.KeyDown += (sender, args) => {
            if (args.Key == System.Windows.Input.Key.Enter && search.IsEnabled) {
                search.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                args.Handled = true;
            }
        };
        // Use a text link to credit the data provider without taking space in the card.
        var credit = UI.Text("", 11, "#B8B3C3");
        credit.Inlines.Add(new System.Windows.Documents.Run("Previsão e busca de cidade por "));
        var link = new System.Windows.Documents.Hyperlink(new System.Windows.Documents.Run("Open-Meteo")) {
            NavigateUri = new Uri("https://open-meteo.com/"), Foreground = UI.Brush("#C9AAFF")
        };
        link.Click += (sender, args) => OpenPath(link.NavigateUri.AbsoluteUri);
        credit.Inlines.Add(link);
        return UI.Stack(UI.Line(), UI.Text("Cidade do clima", 14, "#EFEAF9", true), query, search, status, results,
            UI.Button("Remover cidade", () => { draft.WeatherCity = null; results.Children.Clear(); status.Text = "Nenhuma cidade selecionada"; }),
            credit);
    }
}
}
