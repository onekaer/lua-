using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Image=System.Windows.Controls.Image;
using Brushes=System.Windows.Media.Brushes;
using Color=System.Windows.Media.Color;
namespace LuaMonitor {
public class GalleryItem {public string Path,Kind,Name;public long Bytes;public DateTime Date;}
public static class MediaLibrary {
    public static List<GalleryItem> Scan(string root){var list=new List<GalleryItem>();foreach(string folder in new[]{root,System.IO.Path.Combine(root,"Videos"),System.IO.Path.Combine(root,"Vídeos"),System.IO.Path.Combine(root,"Clipes"),System.IO.Path.Combine(root,"Prints")}.Distinct(StringComparer.OrdinalIgnoreCase))try{if(!Directory.Exists(folder))continue;foreach(string path in Directory.EnumerateFiles(folder).Take(10000)){var file=new FileInfo(path);if((file.Attributes&FileAttributes.ReparsePoint)!=0)continue;string ext=file.Extension.ToLowerInvariant(),kind=new[]{".png",".jpg",".jpeg",".bmp"}.Contains(ext)?"Prints":new[]{".mp4",".mkv",".webm",".mov",".avi"}.Contains(ext)?(file.Name.StartsWith("LUA_clipe_",StringComparison.OrdinalIgnoreCase)||System.IO.Path.GetFileName(folder)=="Clipes"?"Clipes":"Vídeos"):null;if(kind!=null)list.Add(new GalleryItem{Path=file.FullName,Name=file.Name,Kind=kind,Bytes=file.Length,Date=file.LastWriteTime});}}catch{}return list;}
    public static string Thumbnail(GalleryItem item){if(item.Kind=="Prints")return item.Path;string key;using(var sha=SHA256.Create())key=BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(item.Path+"|"+item.Bytes+"|"+item.Date.Ticks))).Replace("-","");string folder=System.IO.Path.Combine(Preferences.DataDir,"thumbnails");Directory.CreateDirectory(folder);string path=System.IO.Path.Combine(folder,key+".jpg");if(File.Exists(path))return path;
        try{using(var process=new Process{StartInfo=new ProcessStartInfo(System.IO.Path.Combine(ScreenRecorder.Tools,"ffmpeg.exe"),"-hide_banner -loglevel error -nostdin -y -ss 0.1 -i "+ScreenRecorder.Quote(item.Path)+" -frames:v 1 -threads 1 -vf scale=480:-2 -q:v 3 "+ScreenRecorder.Quote(path)){UseShellExecute=false,CreateNoWindow=true,RedirectStandardError=true,RedirectStandardOutput=true}}){process.Start();process.BeginErrorReadLine();process.BeginOutputReadLine();if(!process.WaitForExit(8000)){process.Kill();return null;}LocalHistory.TrimCache(UI.CacheLimitMb);return process.ExitCode==0&&File.Exists(path)?path:null;}}catch{return null;}}
    public static string Screenshot(int screen, string root) {
        var screens = System.Windows.Forms.Screen.AllScreens;
        var bounds = screens[Math.Max(0, Math.Min(screens.Length - 1, screen))].Bounds;
        string folder = System.IO.Path.Combine(root, "Prints");
        Directory.CreateDirectory(folder);
        string path = System.IO.Path.Combine(folder, "LUA_print_" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss_fff") + ".png");
        using (var bitmap = new Bitmap(bounds.Width, bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppRgb))
        using (var graphics = Graphics.FromImage(bitmap)) {
            IntPtr desktop = GetDC(IntPtr.Zero);
            if (desktop == IntPtr.Zero) throw new System.ComponentModel.Win32Exception();
            try {
                IntPtr destination = graphics.GetHdc();
                try {
                    const uint CopyVisibleLayers = (uint)CopyPixelOperation.SourceCopy | (uint)CopyPixelOperation.CaptureBlt;
                    if (!BitBlt(destination, 0, 0, bounds.Width, bounds.Height, desktop, bounds.Left, bounds.Top, CopyVisibleLayers))
                        throw new System.ComponentModel.Win32Exception();
                } finally { graphics.ReleaseHdc(destination); }
            } finally { ReleaseDC(IntPtr.Zero, desktop); }
            bitmap.Save(path, ImageFormat.Png);
        }
        return path;
    }

    [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
    static extern IntPtr GetDC(IntPtr window);
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    static extern int ReleaseDC(IntPtr window, IntPtr context);
    [System.Runtime.InteropServices.DllImport("gdi32.dll", SetLastError = true)]
    static extern bool BitBlt(IntPtr destination, int x, int y, int width, int height, IntPtr source, int left, int top, uint operation);
}
public sealed partial class DesktopController {
    List<GalleryItem> galleryItems=new List<GalleryItem>();string galleryTab="Vídeos",gallerySearch="",galleryOrder="Mais recentes",galleryDate="Qualquer data";bool galleryLoading;StackPanel galleryArea;Grid galleryTabs;int galleryLimit=12;CancellationTokenSource galleryThumbCancel;
    void Gallery(){
        galleryTabs=new Grid{Margin=new Thickness(0,0,0,12)};foreach(string kind in new[]{"Vídeos","Clipes","Prints"}){galleryTabs.ColumnDefinitions.Add(new ColumnDefinition());var tab=UI.Button(kind,()=>{galleryTab=kind;galleryLimit=12;RenderGallery();});tab.Margin=new Thickness(0,0,kind=="Prints"?0:6,0);Grid.SetColumn(tab,galleryTabs.Children.Count);galleryTabs.Children.Add(tab);}body.Children.Add(galleryTabs);
        var filters=UI.Stack(UI.Label("Ordenar por"),UI.Choice(new[]{"Mais recentes","Mais antigos","Maior tamanho","Menor tamanho","Nome A–Z"},galleryOrder,v=>{galleryOrder=v;RenderGallery();}),UI.Label("Período"),UI.Choice(new[]{"Qualquer data","Hoje","Últimos 7 dias","Últimos 30 dias"},galleryDate,v=>{galleryDate=v;RenderGallery();}));
        var toolbar=new Grid();toolbar.ColumnDefinitions.Add(new ColumnDefinition());toolbar.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(40)});toolbar.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(40)});var search=UI.Search(gallerySearch,"Buscar capturas",v=>{gallerySearch=v;galleryLimit=12;RenderGallery();},filters);foreach(var field in FindSearchFields(search)){System.Windows.Automation.AutomationProperties.SetName(field,"Pesquisar capturas");field.ToolTip="Pesquisar capturas";}toolbar.Children.Add(search);var refresh=UI.IconButton("refresh","Atualizar galeria",async()=>await LoadGallery());var print=UI.IconButton("screenshot","Tirar print",TakeScreenshot);int col=1;foreach(var button in new[]{refresh,print}){button.Width=button.Height=32;button.MinHeight=0;button.Margin=new Thickness(5,4,0,0);button.VerticalAlignment=VerticalAlignment.Top;Grid.SetColumn(button,col++);toolbar.Children.Add(button);}body.Children.Add(UI.Card(toolbar,10));galleryArea=new StackPanel();body.Children.Add(galleryArea);RenderGallery();LoadGallery();
    }
    async Task LoadGallery(){if(galleryLoading)return;galleryLoading=true;RenderGallery();try{string folder=prefs.Video.Folder;galleryItems=await Task.Run(()=>MediaLibrary.Scan(folder));}catch(Exception ex){ShowToast("Galeria",ex.Message);}finally{galleryLoading=false;if(page=="gallery")RenderGallery();}}
    async void RenderGallery(){if(galleryArea==null||page!="gallery")return;if(galleryThumbCancel!=null){galleryThumbCancel.Cancel();galleryThumbCancel.Dispose();}galleryThumbCancel=new CancellationTokenSource();var token=galleryThumbCancel.Token;galleryArea.Children.Clear();foreach(Button tab in galleryTabs.Children){string label=(tab.Content as TextBlock).Text;tab.Background=UI.Brush(label==galleryTab?"#282D2A":"#181A1A");}
        DateTime since=galleryDate=="Hoje"?DateTime.Today:galleryDate=="Últimos 7 dias"?DateTime.Now.AddDays(-7):galleryDate=="Últimos 30 dias"?DateTime.Now.AddDays(-30):DateTime.MinValue;var entries=galleryItems.Where(i=>i.Kind==galleryTab&&(i.Name+" "+MediaServices.Title(i)+" "+MediaServices.Info(i.Path).Game).IndexOf(gallerySearch,StringComparison.OrdinalIgnoreCase)>=0&&i.Date>=since);entries=galleryOrder=="Mais antigos"?entries.OrderBy(i=>i.Date):galleryOrder=="Maior tamanho"?entries.OrderByDescending(i=>i.Bytes):galleryOrder=="Menor tamanho"?entries.OrderBy(i=>i.Bytes):galleryOrder=="Nome A–Z"?entries.OrderBy(i=>i.Name):entries.OrderByDescending(i=>i.Date);var items=entries.ToList();galleryArea.Children.Add(UI.Text(galleryLoading?"Atualizando galeria…":items.Count+" "+galleryTab.ToLower()+" • "+Format.Bytes(items.Sum(i=>(double)i.Bytes)),11,"#9999AC"));
        if(items.Count==0){galleryArea.Children.Add(UI.Card(UI.Stack(UI.Icon("gallery",size:32),UI.Text("Ainda não há "+galleryTab.ToLower()+" aqui",16,"#DDDDDF",true),UI.Text(gallerySearch!=""||galleryDate!="Qualquer data"?"Experimente mudar a busca ou os filtros.":"Seus momentos salvos aparecem aqui. Use o botão de clipe ou tire um print na aba Capturas.",12,"#9999AB"),UI.Button("Ir para capturas",()=>BuildPage("recording")))));return;}
        galleryArea.Children.Add(FilterChips(new[]{galleryDate=="Qualquer data"?null:galleryDate,gallerySearch==""?null:"Busca: "+gallerySearch},()=>{galleryDate="Qualquer data";gallerySearch="";BuildPage("gallery");}));var thumbs=new List<Tuple<GalleryItem,Image,TextBlock,TextBlock>>();var cards=new Grid();int columns=compact?1:Math.Max(1,Math.Min(3,(int)((body.ActualWidth>0?body.ActualWidth:900)/295))),row=0,column=0;for(int n=0;n<columns;n++)cards.ColumnDefinitions.Add(new ColumnDefinition());galleryArea.Children.Add(cards);DateTime lastDate=DateTime.MinValue;bool groupDates=galleryOrder=="Mais recentes"||galleryOrder=="Mais antigos";
        foreach(var item in items.Take(galleryLimit)){var entry=item;if(groupDates&&entry.Date.Date!=lastDate){if(column!=0){row++;column=0;}lastDate=entry.Date.Date;cards.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});var date=UI.Text(lastDate==DateTime.Today?"Hoje":lastDate==DateTime.Today.AddDays(-1)?"Ontem":lastDate.ToString("dd MMMM yyyy",System.Globalization.CultureInfo.GetCultureInfo("pt-BR")),13,"#D3D3DF",true);date.Margin=new Thickness(0,12,0,8);Grid.SetRow(date,row++);Grid.SetColumnSpan(date,columns);cards.Children.Add(date);}if(column==0)cards.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});var picture=new Image{Stretch=Stretch.Uniform};RenderOptions.SetBitmapScalingMode(picture,BitmapScalingMode.HighQuality);var preview=new CapturePreview{Background=UI.Brush("#15151A")};preview.Children.Add(picture);if(entry.Kind!="Prints"){var play=new Border{Width=42,Height=42,CornerRadius=new CornerRadius(21),Background=new SolidColorBrush(Color.FromArgb(150,14,15,20)),HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center,Child=new System.Windows.Shapes.Path{Data=Geometry.Parse("M 0 0 L 0 16 L 13 8 Z"),Fill=Brushes.White,Width=13,Height=16,Margin=new Thickness(4,0,0,0),Stretch=Stretch.Uniform}};preview.Children.Add(play);}var type=UI.Text(entry.Kind=="Clipes"?"CLIPE":entry.Kind=="Prints"?"PRINT":"VÍDEO",11,"#F0F0F7",true);var badge=new Border{Child=type,Background=new SolidColorBrush(Color.FromArgb(200,30,32,42)),CornerRadius=new CornerRadius(5),Padding=new Thickness(7,3,7,3),HorizontalAlignment=HorizontalAlignment.Left,VerticalAlignment=VerticalAlignment.Top,Margin=new Thickness(8)};preview.Children.Add(badge);var duration=UI.Text("",11,"#FFFFFF",true);var durationBadge=new Border{Child=duration,Background=new SolidColorBrush(Color.FromArgb(200,16,17,22)),CornerRadius=new CornerRadius(5),Padding=new Thickness(6,3,6,3),HorizontalAlignment=HorizontalAlignment.Right,VerticalAlignment=VerticalAlignment.Bottom,Margin=new Thickness(8),Visibility=entry.Kind=="Prints"?Visibility.Collapsed:Visibility.Visible};preview.Children.Add(durationBadge);var open=new Button{Content=preview,Padding=new Thickness(0),BorderThickness=new Thickness(0),HorizontalAlignment=HorizontalAlignment.Stretch,ToolTip="Visualizar "+MediaServices.Title(entry)};System.Windows.Automation.AutomationProperties.SetName(open,"Visualizar "+MediaServices.Title(entry));open.Click+=(s,e)=>OpenMedia(entry);var title=UI.Text(MediaServices.Title(entry),13,"#EEEEF5",true);title.TextTrimming=TextTrimming.CharacterEllipsis;title.MaxHeight=36;var metadata=UI.Text("",11,"#A7A7B9");SetCaptureMetadata(metadata,duration,MediaServices.Info(entry.Path));var info=UI.Stack(title,metadata,UI.Text(entry.Date.ToString("dd MMM • HH:mm",System.Globalization.CultureInfo.GetCultureInfo("pt-BR"))+" • "+Format.Bytes(entry.Bytes),11,"#9696A9"),GalleryActions(entry));info.Margin=new Thickness(0,10,0,0);var card=UI.Card(UI.Stack(open,info),10);card.Margin=new Thickness(column==0?0:5,0,column==columns-1?0:5,12);Grid.SetRow(card,row);Grid.SetColumn(card,column);cards.Children.Add(card);thumbs.Add(Tuple.Create(entry,picture,metadata,duration));column++;if(column==columns){column=0;row++;}}
        if(items.Count>galleryLimit)galleryArea.Children.Add(UI.Button("Carregar mais",()=>{galleryLimit+=12;RenderGallery();}));foreach(var thumb in thumbs){if(token.IsCancellationRequested||exiting)return;string path=await Task.Run(()=>MediaLibrary.Thumbnail(thumb.Item1));if(token.IsCancellationRequested||exiting)return;thumb.Item2.Source=GameCovers.Image(path,480);try{var details=await MediaServices.Probe(thumb.Item1);if(token.IsCancellationRequested)return;SetCaptureMetadata(thumb.Item3,thumb.Item4,details);}catch{}}
    }
    void SetCaptureMetadata(TextBlock text,TextBlock duration,MediaInfo info){text.Text=(info.Width>0?info.Width+" × "+info.Height:"")+(info.Game==""?"":" • "+info.Game);duration.Text=info.Duration>0?TimeSpan.FromSeconds(info.Duration).ToString(info.Duration>=3600?@"hh\:mm\:ss":@"mm\:ss"):"—";}
    async void TakeScreenshot(){if(sharedOwner!=null){sharedOwner.TakeScreenshot();return;}if(exiting)return;try{int monitor=prefs.Video.Screen;string root=prefs.Video.Folder;string file=await Task.Run(()=>MediaLibrary.Screenshot(monitor,root));galleryTab="Prints";ShowToast("Print salvo",Path.GetFileName(file),()=>{ShowMain();BuildPage("gallery");});if(page=="gallery")await LoadGallery();}catch(Exception ex){ShowToast("Não foi possível tirar o print",ex.Message);}}
    RecordingOptions VideoOptions(bool full){var v=prefs.Video;return new RecordingOptions{Screen=v.Screen,Fps=v.Fps,Height=v.Height,ReplaySeconds=v.ReplaySeconds,Bitrate=v.Bitrate,Audio=v.Audio,Cursor=v.Cursor,Microphone=v.Microphone,OutputDevice=v.OutputDevice,InputDevice=v.InputDevice,SystemGain=v.SystemGain,MicGain=v.MicGain,Engine=v.Engine,StopFreeMb=v.StopFreeMb,Folder=full?Path.Combine(v.Folder,"Videos"):v.Folder};}
}
}
