using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
namespace LuaMonitor {
public class GalleryItem {public string Path,Kind,Name;public long Bytes;public DateTime Date;}
public static class MediaLibrary {
    public static List<GalleryItem> Scan(string root){var list=new List<GalleryItem>();foreach(string folder in new[]{root,System.IO.Path.Combine(root,"Videos"),System.IO.Path.Combine(root,"Vídeos"),System.IO.Path.Combine(root,"Clipes"),System.IO.Path.Combine(root,"Prints")}.Distinct(StringComparer.OrdinalIgnoreCase))try{if(!Directory.Exists(folder))continue;foreach(string path in Directory.EnumerateFiles(folder).Take(10000)){var file=new FileInfo(path);if((file.Attributes&FileAttributes.ReparsePoint)!=0)continue;string ext=file.Extension.ToLowerInvariant(),kind=new[]{".png",".jpg",".jpeg",".bmp"}.Contains(ext)?"Prints":new[]{".mp4",".mkv",".webm",".mov",".avi"}.Contains(ext)?(file.Name.StartsWith("LUA_clipe_",StringComparison.OrdinalIgnoreCase)||System.IO.Path.GetFileName(folder)=="Clipes"?"Clipes":"Vídeos"):null;if(kind!=null)list.Add(new GalleryItem{Path=file.FullName,Name=file.Name,Kind=kind,Bytes=file.Length,Date=file.LastWriteTime});}}catch{}return list;}
    public static string Thumbnail(GalleryItem item){if(item.Kind=="Prints")return item.Path;string key;using(var sha=SHA256.Create())key=BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(item.Path+"|"+item.Bytes+"|"+item.Date.Ticks))).Replace("-","");string folder=System.IO.Path.Combine(Preferences.DataDir,"thumbnails");Directory.CreateDirectory(folder);string path=System.IO.Path.Combine(folder,key+".jpg");if(File.Exists(path))return path;
        try{using(var process=new Process{StartInfo=new ProcessStartInfo(System.IO.Path.Combine(ScreenRecorder.Tools,"ffmpeg.exe"),"-hide_banner -loglevel error -nostdin -y -ss 0.1 -i "+ScreenRecorder.Quote(item.Path)+" -frames:v 1 -threads 1 -vf scale=480:-2 -q:v 3 "+ScreenRecorder.Quote(path)){UseShellExecute=false,CreateNoWindow=true,RedirectStandardError=true,RedirectStandardOutput=true}}){process.Start();process.BeginErrorReadLine();process.BeginOutputReadLine();if(!process.WaitForExit(8000)){process.Kill();return null;}LocalHistory.TrimCache(UI.CacheLimitMb);return process.ExitCode==0&&File.Exists(path)?path:null;}}catch{return null;}}
    public static string Screenshot(int screen, string root) {
        var screens = System.Windows.Forms.Screen.AllScreens;
        var bounds = screens[Math.Max(0, Math.Min(screens.Length - 1, screen))].Bounds;
        string folder = System.IO.Path.Combine(root, "Prints");
        Directory.CreateDirectory(folder);
        string path = System.IO.Path.Combine(folder, "LUA_print_" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss_fff") + ".png");
        using (var bitmap = new Bitmap(bounds.Width, bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppRgb))
        using (var graphics = Graphics.FromImage(bitmap)) {
            IntPtr desktop = GetDC(IntPtr.Zero);
            if (desktop == IntPtr.Zero) throw new System.ComponentModel.Win32Exception();
            try {
                IntPtr destination = graphics.GetHdc();
                try {
                    const uint CopyVisibleLayers = (uint)CopyPixelOperation.SourceCopy | (uint)CopyPixelOperation.CaptureBlt;
                    if (!BitBlt(destination, 0, 0, bounds.Width, bounds.Height, desktop, bounds.Left, bounds.Top, CopyVisibleLayers))
                        throw new System.ComponentModel.Win32Exception();
                } finally { graphics.ReleaseHdc(destination); }
            } finally { ReleaseDC(IntPtr.Zero, desktop); }
            bitmap.Save(path, ImageFormat.Png);
        }
        return path;
    }

    [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
    static extern IntPtr GetDC(IntPtr window);
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    static extern int ReleaseDC(IntPtr window, IntPtr context);
    [System.Runtime.InteropServices.DllImport("gdi32.dll", SetLastError = true)]
    static extern bool BitBlt(IntPtr destination, int x, int y, int width, int height, IntPtr source, int left, int top, uint operation);
}
}
