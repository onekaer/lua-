using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task Mp4Checks(List<string> checks,string dir){
        var options=new RecordingOptions{Folder=Path.Combine(Preferences.DataDir,"mp4-check"),Height=720,Fps=30,Bitrate=4,Audio=false,Microphone=false,ReplaySeconds=30};
        using(var test=new ScreenRecorder()){
            await test.StartRecording(options);await Task.Delay(3000);await test.StopRecording();
            string video=test.LastFile;string videoInfo=await ProbeVideo(video);
            if(Path.GetExtension(video)!=".mp4"||!videoInfo.Contains("h264")||Directory.GetFiles(options.Folder,"*.mkv").Any())throw new Exception("Gravação não finalizou em MP4 H.264");
            await test.StartReplay(options);await Task.Delay(6000);string clip=await test.SaveClip(3,options.Folder);await test.StopReplay();
            string clipInfo=await ProbeVideo(clip);if(Path.GetExtension(clip)!=".mp4"||!clipInfo.Contains("h264"))throw new Exception("Clipe não finalizou em MP4 H.264");
            foreach(string path in new[]{video,clip}){var bytes=File.ReadAllBytes(path);if(bytes.Length<1024||System.Text.Encoding.ASCII.GetString(bytes,4,4)!="ftyp"||System.Text.Encoding.ASCII.GetString(bytes,8,4)=="qt  ")throw new Exception("Contêiner final não é MP4");}
            checks.Add("MP4 REAL: gravação comum e clipe anterior finalizados em contêiner MP4/H.264; intermediário da gravação removido após sucesso. Vídeos de teste permanecem apenas na pasta isolada local.");
        }
    }
}
}
