﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
namespace LuaMonitor {
public sealed partial class DesktopController {
    static List<Button> Buttons(DependencyObject root){var result=new List<Button>();if(root==null)return result;var button=root as Button;if(button!=null)result.Add(button);for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++)result.AddRange(Buttons(VisualTreeHelper.GetChild(root,i)));return result;}
    async Task InterfaceChecks(List<string> checks,string dir){
        uint mods,key;if(!ShortcutKeys.Parse("Ctrl+Alt+F6",out mods,out key)||mods!=3||key!=117||ShortcutKeys.Parse("R",out mods,out key))throw new Exception("Conversão de atalhos incorreta");string oldKey=prefs.PrintKey;if(!ApplyVideoKey(82,"Ctrl+Alt+F6")||prefs.PrintKey!="Ctrl+Alt+F6"||ApplyVideoKey(82,prefs.RecordKey))throw new Exception("Conflito de atalhos não foi tratado");prefs.PrintKey=oldKey;checks.Add("Atalhos: combinação personalizada aceita, tecla sem modificador recusada, conflito interno preserva preferência");
        var actions=new ActionGrid();for(int n=0;n<3;n++)actions.Children.Add(UI.Button(n==0?"Uma ação com nome maior":"Ação",()=>{}));actions.Measure(new Size(330,500));actions.Arrange(new Rect(0,0,330,actions.DesiredSize.Height));var a=(FrameworkElement)actions.Children[0];var b=(FrameworkElement)actions.Children[1];var c=(FrameworkElement)actions.Children[2];var ra=LayoutInformation(a,actions);var rb=LayoutInformation(b,actions);var rc=LayoutInformation(c,actions);if(Math.Abs(ra.Width-rb.Width)>.1||Math.Abs(ra.Height-rb.Height)>.1||ra.Right>rb.Left||rc.Top<Math.Max(ra.Bottom,rb.Bottom)||Math.Abs(rc.Width-330)>.1)throw new Exception("Botões desalinhados no modo compacto");checks.Add("Botões: duas colunas alinhadas, alturas iguais e última ação ocupa a linha completa");
        SetMode(true,false);
        BuildPage("games");window.UpdateLayout();
        Buttons(body).Single(button=>System.Windows.Automation.AutomationProperties.GetName(button)=="Sessões")
            .RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        if(page!="sessions")throw new Exception("Sessões não abriu pela biblioteca");
        Find<Button>("NavSettingsButton").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        if(page!="settings")throw new Exception("Engrenagem não abriu Configurações");
        window.UpdateLayout();
        UI.Capture(window,Path.Combine(dir,"navigation-settings.png"));
        BuildPage("games");window.UpdateLayout();
        var filter=Buttons(body).FirstOrDefault(x=>Convert.ToString(x.ToolTip)=="Mostrar filtros");
        if(filter==null)throw new Exception("Ícone de filtro não está ao lado da busca");
        filter.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));window.UpdateLayout();
        UI.Capture(window,Path.Combine(dir,"search-filters-open.png"));
        filter.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        checks.Add("Navegação: Sessões na biblioteca, Configurações na engrenagem e filtros de jogos.");
        bool clicked=false;ShowToast("Captura salva","Notificação própria do LUA • teste de interface",()=>clicked=true);await Task.Delay(220);UI.Capture(luaToast,Path.Combine(dir,"lua-notification.png"));var toastAction=Buttons(luaToast.Content as DependencyObject).FirstOrDefault(x=>(x.Content as TextBlock)!=null&&(x.Content as TextBlock).Text=="Ver galeria");if(toastAction==null)throw new Exception("Notificação sem ação de galeria");toastAction.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));if(!clicked)throw new Exception("Notificação não executou ação");checks.Add("Notificação própria: janela LUA, animação, fechamento e ação de galeria");
        var previousVideo=prefs.Video;string root=Path.Combine(Preferences.DataDir,"gallery-fixture");prefs.Video=new RecordingOptions{Folder=Path.Combine(Preferences.DataDir,"capture-real"),Height=720,Fps=30,Audio=false,Bitrate=4};
        try{
            await Recorder.StartRecording(VideoOptions(true));SyncRecordingHud();await Task.Delay(2000);if(recordingHud==null||!recordingHud.IsVisible||!CollectText(recordingHud.Content as DependencyObject).Any(t=>t.StartsWith("REC")))throw new Exception("Indicador de gravação não apareceu");uint affinity;CaptureWindowStyle.GetWindowDisplayAffinity(new WindowInteropHelper(recordingHud).Handle,out affinity);int style=Native.GetWindowLong(new WindowInteropHelper(recordingHud).Handle,-20);if((style&0x08000000)==0)throw new Exception("Indicador bloqueou cliques");UI.Capture(recordingHud,Path.Combine(dir,"recording-indicator.png"));checks.Add("Gravação REAL: indicador topmost com cronômetro, botão Parar sem ativar a janela e afinidade de captura "+affinity);
            string print=await Task.Run(()=>MediaLibrary.Screenshot(0,prefs.Video.Folder));await Recorder.StopRecording();SyncRecordingHud();if(recordingHud.IsVisible)throw new Exception("Indicador permaneceu após parada");string video=Recorder.LastFile;if(!File.Exists(video)||GameCovers.Image(print)==null)throw new Exception("Captura ou print não foi salvo");checks.Add("MP4 e PNG reais de captura preservados somente nos dados privados de teste");prefs.Video.Folder=root;Directory.CreateDirectory(Path.Combine(root,"Prints"));Directory.CreateDirectory(Path.Combine(root,"Videos"));string frame=Path.Combine(root,"Prints","LUA_print_interface_fixture.png");UI.Capture(window,frame);video=Path.Combine(root,"Videos","LUA_video_interface_fixture.mp4");await MakeGalleryFixture(frame,video);Directory.CreateDirectory(Path.Combine(root,"Clipes"));File.Copy(video,Path.Combine(root,"Clipes","LUA_clipe_fixture.mp4"),true);
            galleryItems=await Task.Run(()=>MediaLibrary.Scan(root));if(galleryItems.Count!=3||galleryItems.Select(i=>i.Kind).Distinct().Count()!=3)throw new Exception("Galeria não separou vídeos, clipes e prints");string thumbnail=await Task.Run(()=>MediaLibrary.Thumbnail(galleryItems.First(i=>i.Kind=="Vídeos")));if(GameCovers.Image(thumbnail)==null)throw new Exception("Miniatura real de vídeo não foi gerada");checks.Add("Galeria: classificação das três mídias e miniatura por FFmpeg; prévias usam somente arquivos demonstrativos da interface LUA, sem conteúdo privado da tela");
            galleryTab="Vídeos";BuildPage("gallery");await LoadGallery();await Task.Delay(350);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"gallery-videos.png"));galleryTab="Clipes";RenderGallery();await Task.Delay(250);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"gallery-clips.png"));galleryTab="Prints";RenderGallery();await Task.Delay(250);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"gallery-prints.png"));
            galleryOrder="Mais antigos";galleryDate="Hoje";RenderGallery();gallerySearch="__nenhum_arquivo__";RenderGallery();if(!CollectText(galleryArea).Any(t=>t.StartsWith("Ainda não há")))throw new Exception("Filtro vazio da galeria incorreto");gallerySearch="";galleryDate="Qualquer data";galleryOrder="Mais recentes";checks.Add("Galeria: abas, ordenação, período, busca e estado vazio verificados");
        }finally{prefs.Video=previousVideo;}
        BuildPage("recording");window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"capture-folded.png"));BuildPage("capture-settings");window.UpdateLayout();foreach(var expander in FindExpanders(body))expander.IsExpanded=true;window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"capture-options-open.png"));BuildPage("network");await Task.Delay(350);window.UpdateLayout();var rd=LayoutInformation(speedDown,body);var ru=LayoutInformation(speedUp,body);if(rd.Right>ru.Left)throw new Exception("Resultados de velocidade sobrepostos");UI.Capture(window,Path.Combine(dir,"speed-refreshed.png"));
    }
    async Task MakeGalleryFixture(string frame,string output){using(var process=new System.Diagnostics.Process{StartInfo=new System.Diagnostics.ProcessStartInfo(Path.Combine(ScreenRecorder.Tools,"ffmpeg.exe"),"-hide_banner -loglevel error -y -loop 1 -i "+ScreenRecorder.Quote(frame)+" -t 2 -an -vf scale=-2:720,format=yuv420p -c:v libopenh264 -b:v 2M "+ScreenRecorder.Quote(output)){UseShellExecute=false,CreateNoWindow=true,RedirectStandardError=true,RedirectStandardOutput=true}}){process.Start();process.BeginErrorReadLine();process.BeginOutputReadLine();bool done=await Task.Run(()=>process.WaitForExit(10000));if(!done){process.Kill();throw new Exception("Fixture de galeria não finalizou");}if(process.ExitCode!=0)throw new Exception("Fixture de galeria falhou");}}
    static Rect LayoutInformation(FrameworkElement element,Visual parent){return element.TransformToAncestor(parent).TransformBounds(new Rect(new Size(element.ActualWidth,element.ActualHeight)));}
    static List<Expander> FindExpanders(DependencyObject root){var result=new List<Expander>();if(root==null)return result;var expander=root as Expander;if(expander!=null)result.Add(expander);for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++)result.AddRange(FindExpanders(VisualTreeHelper.GetChild(root,i)));return result;}
}
}
