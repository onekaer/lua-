﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using LibreHardwareMonitor.Hardware;
class LuaSensorsHost {
    static int Main(string[] args){int at=Array.IndexOf(args,"--pipe"),parentAt=Array.IndexOf(args,"--parent");if(at<0||at+1>=args.Length||parentAt<0||parentAt+1>=args.Length)return 2;int parent;if(!int.TryParse(args[parentAt+1],out parent)||!args[at+1].StartsWith("LUA_CPU_"))return 2;var computer=new Computer{IsCpuEnabled=true};using(var pipe=new NamedPipeClientStream(".",args[at+1],PipeDirection.InOut,PipeOptions.Asynchronous)){try{pipe.Connect(25000);using(var writer=new StreamWriter(pipe,new UTF8Encoding(false),1024,true){AutoFlush=true})using(var reader=new StreamReader(pipe,Encoding.UTF8,false,1024,true)){var stop=new CancellationTokenSource();Task.Run(async()=>{try{string line;while((line=await reader.ReadLineAsync())!=null){if(line=="STOP")break;} }catch{}stop.Cancel();});computer.Open();while(!stop.IsCancellationRequested){try{using(var process=Process.GetProcessById(parent)){if(process.HasExited)break;}}catch{break;}double? value=null;foreach(var hardware in computer.Hardware){hardware.Update();foreach(var sensor in hardware.Sensors){if(sensor.SensorType!=SensorType.Temperature||!sensor.Value.HasValue)continue;double reading=sensor.Value.Value;if(double.IsNaN(reading)||double.IsInfinity(reading)||reading<=0||reading>150)continue;value=Math.Max(value??reading,reading);}}writer.WriteLine(value.HasValue?"TEMP:"+value.Value.ToString("0.00",CultureInfo.InvariantCulture):"STATUS:Sensor da CPU sem leitura. Confira o PawnIO e a permissão.");if(stop.Token.WaitHandle.WaitOne(1500))break;}}return 0;}catch{return 1;}finally{try{computer.Close();}catch{}}}}
}
