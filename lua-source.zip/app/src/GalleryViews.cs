using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace LuaMonitor {
public sealed partial class DesktopController {
    static readonly CultureInfo GalleryCulture = CultureInfo.GetCultureInfo("pt-BR");
    List<GalleryItem> galleryItems = new List<GalleryItem>();
    string galleryTab = "Todas", gallerySearch = "", galleryOrder = "Mais recentes", galleryDate = "Qualquer data";
    string galleryLoadedFolder;
    bool galleryLoading;
    int galleryLimit = 12, galleryRequest;
    StackPanel galleryArea;
    WrapPanel galleryTabs;
    Button galleryRecording;
    CancellationTokenSource galleryThumbCancel;

    void Gallery() {
        var heading = UI.Stack(UI.Text("Galeria", compact ? 23 : 31, "#F5F2FA", true),
            UI.Text("Seus prints, clipes e gravações", 12, "#B9B0C7"));
        var actions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        galleryRecording = LibraryButton("Parar gravação", ToggleRecording);
        galleryRecording.Visibility = Visibility.Collapsed;
        galleryRecording.Margin = new Thickness(0,0,6,0);
        actions.Children.Add(galleryRecording);
        actions.Children.Add(LibraryButton("Nova captura", ShowCaptureDialog, true, "\uE722"));
        var header = UI.Row(heading, actions);
        header.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        header.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        header.SizeChanged += (s,e) => {
            bool narrow = e.NewSize.Width < 570;
            Grid.SetColumn(actions, narrow ? 0 : 1);
            Grid.SetColumnSpan(actions, narrow ? 2 : 1);
            Grid.SetRow(actions, narrow ? 1 : 0);
            actions.Margin = narrow ? new Thickness(0, 8, 0, 0) : new Thickness(12, 0, 0, 0);
        };
        header.Margin = new Thickness(0,0,0,15);
        body.Children.Add(header);

        string[] periods = { "Qualquer data", "Hoje", "Últimos 7 dias", "Últimos 30 dias" };
        var period = UI.Choice(periods, galleryDate, value => { galleryDate = value; ResetGalleryLimit(); });
        AutomationProperties.SetName(period, "Filtrar por período");
        var search = UI.Search(gallerySearch, "Buscar capturas", value => { gallerySearch = value; ResetGalleryLimit(); },
            UI.Stack(UI.Label("Período"), period, LibraryButton("Atualizar galeria", async () => await LoadGallery())), 37);
        var frame = (Border)search.Children[0];
        frame.Background = UI.Brush(UI.Surface);
        frame.BorderBrush = UI.Brush("#353535");

        var sort = UI.Choice(new[]{"Mais recentes","Mais antigos","Maior tamanho","Menor tamanho","Nome A–Z"},
            galleryOrder, value => { galleryOrder = value; ResetGalleryLimit(); });
        AutomationProperties.SetName(sort, "Ordenar arquivos");
        sort.MinWidth = 0;
        sort.Width = 127;
        sort.Height = 37;
        sort.Margin = new Thickness(8,0,0,0);
        sort.VerticalAlignment = VerticalAlignment.Top;
        var tools = UI.Row(search, sort);
        tools.Margin = new Thickness(0,0,0,10);
        body.Children.Add(tools);

        galleryTabs = new WrapPanel { Margin = new Thickness(0,0,0,10) };
        foreach (string kind in new[]{"Todas","Prints","Clipes","Vídeos","Favoritas"}) {
            var button = LibraryButton(kind == "Vídeos" ? "Gravações" : kind,
                () => { galleryTab = kind; ResetGalleryLimit(); });
            button.Tag = kind;
            button.Margin = new Thickness(0,0,6,6);
            galleryTabs.Children.Add(button);
        }
        body.Children.Add(galleryTabs);
        galleryArea = new StackPanel();
        body.Children.Add(galleryArea);
        UpdateVideo();
        LoadGallery();
    }

    void ResetGalleryLimit() {
        galleryLimit = 12;
        RenderGallery();
    }

    async Task LoadGallery() {
        int request = ++galleryRequest;
        string folder = prefs.Video.Folder;
        if (!string.Equals(folder, galleryLoadedFolder, StringComparison.OrdinalIgnoreCase))
            galleryItems.Clear();
        galleryLoading = true;
        RenderGallery();
        try {
            var loaded = await Task.Run(() => MediaLibrary.Scan(folder));
            if (request != galleryRequest || exiting) return;
            galleryItems = loaded;
            galleryLoadedFolder = folder;
        } catch (Exception ex) {
            if (request == galleryRequest) ShowToast("Galeria", ex.Message);
        } finally {
            if (request == galleryRequest) {
                galleryLoading = false;
                if (!exiting) RenderGallery();
            }
        }
    }

    List<GalleryItem> GalleryResults() {
        DateTime since = galleryDate == "Hoje" ? DateTime.Today
            : galleryDate == "Últimos 7 dias" ? DateTime.Now.AddDays(-7)
            : galleryDate == "Últimos 30 dias" ? DateTime.Now.AddDays(-30) : DateTime.MinValue;
        string query = gallerySearch.Trim();
        var items = galleryItems.Where(item => {
            if (item.Date < since) return false;
            var info = MediaServices.Info(item.Path);
            bool kind = galleryTab == "Todas" || (galleryTab == "Favoritas" ? info.Favorite : item.Kind == galleryTab);
            return kind && (query.Length == 0 || GalleryCulture.CompareInfo.IndexOf(
                item.Name + " " + MediaServices.Title(item) + " " + info.Game, query,
                CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) >= 0);
        });
        switch (galleryOrder) {
            case "Mais antigos": return items.OrderBy(i => i.Date).ToList();
            case "Maior tamanho": return items.OrderByDescending(i => i.Bytes).ThenByDescending(i => i.Date).ToList();
            case "Menor tamanho": return items.OrderBy(i => i.Bytes).ThenByDescending(i => i.Date).ToList();
            case "Nome A–Z": return items.OrderBy(i => MediaServices.Title(i), StringComparer.Create(GalleryCulture, true)).ToList();
            default: return items.OrderByDescending(i => i.Date).ToList();
        }
    }

    async void RenderGallery() {
        if (galleryArea == null || page != "gallery") return;
        if (galleryThumbCancel != null) { galleryThumbCancel.Cancel(); galleryThumbCancel.Dispose(); }
        galleryThumbCancel = new CancellationTokenSource();
        var token = galleryThumbCancel.Token;
        galleryArea.Children.Clear();
        foreach (Button button in galleryTabs.Children) {
            bool selected = Equals(button.Tag, galleryTab);
            button.Background = UI.Brush(selected ? "#30263E" : UI.ControlSurface);
            button.BorderBrush = UI.Brush(selected ? "#5C4B70" : "#353535");
            AutomationProperties.SetItemStatus(button, selected ? "Selecionado" : "");
        }
        var items = GalleryResults();
        string count = galleryLoading ? "Atualizando…" : items.Count == 1 ? "1 arquivo" : items.Count + " arquivos";
        var summary = UI.Row(UI.Text("Arquivos", 18, "#F5F2FA", true), UI.Text(count, 12, "#C0B4D0"));
        summary.Margin = new Thickness(0,0,0,9);
        galleryArea.Children.Add(summary);
        if (items.Count == 0) {
            if (galleryLoading) return;
            bool filtered = galleryTab != "Todas" || gallerySearch.Trim().Length > 0 || galleryDate != "Qualquer data";
            galleryArea.Children.Add(UI.Card(UI.Stack(UI.Icon("gallery", "#BAB0C9", 27),
                UI.Text(filtered ? "Nenhum arquivo encontrado" : "Ainda não há capturas", 16, "#ECE6F3", true),
                UI.Text(filtered ? "Altere a busca ou os filtros." : "Seus prints, clipes e gravações aparecem aqui.", 12, "#B9B0C7"))));
            return;
        }

        var grid = new UniformGrid { Columns = compact ? 2 : 3, Margin = new Thickness(-4,0,-4,0) };
        grid.SizeChanged += (s,e) => {
            int columns = e.NewSize.Width >= 560 ? 3 : e.NewSize.Width >= 300 ? 2 : 1;
            if (columns != grid.Columns) grid.Columns = columns;
        };
        galleryArea.Children.Add(grid);
        var thumbnails = new List<Tuple<GalleryItem,Image,TextBlock,TextBlock>>();
        foreach (var item in items.Take(galleryLimit)) {
            Image picture;
            TextBlock metadata, badge;
            grid.Children.Add(GalleryTile(item, out picture, out metadata, out badge));
            thumbnails.Add(Tuple.Create(item,picture,metadata,badge));
        }
        if (items.Count > galleryLimit)
            galleryArea.Children.Add(LibraryButton("Carregar mais", () => { galleryLimit += 12; RenderGallery(); }));
        foreach (var tile in thumbnails) {
            if (token.IsCancellationRequested || exiting) return;
            try {
                var item = tile.Item1;
                var bitmap = await Task.Run(() => GameCovers.Image(MediaLibrary.Thumbnail(item), 480));
                if (token.IsCancellationRequested || exiting) return;
                tile.Item2.Source = bitmap;
                var details = await MediaServices.Probe(item, token);
                if (token.IsCancellationRequested || exiting) return;
                SetGalleryMetadata(item, tile.Item3, tile.Item4, details);
            } catch (OperationCanceledException) { return; }
            catch (Exception) { }
        }
    }

    Grid GalleryTile(GalleryItem item, out Image picture, out TextBlock metadata, out TextBlock badge) {
        string name = MediaServices.Title(item);
        var image = new Image { Stretch = Stretch.UniformToFill };
        RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.HighQuality);
        var preview = new CapturePreview { Background = UI.Brush(UI.Surface), ClipToBounds = true };
        preview.Children.Add(UI.Icon(item.Kind == "Prints" ? "screenshot" : "recording", "#A69BB8", 26));
        preview.Children.Add(image);
        badge = UI.Text("", 11, "#FFFFFF", true);
        preview.Children.Add(new Border {
            Child = badge, Background = UI.Brush("#E5151219"), CornerRadius = new CornerRadius(5),
            HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Bottom,
            Padding = new Thickness(5,2,5,2), Margin = new Thickness(6)
        });
        var title = UI.Text(name, 13, "#F4EFF8", true);
        metadata = UI.Text("", 11, "#BAAFC9");
        foreach (var line in new[]{title,metadata}) {
            line.TextWrapping = TextWrapping.NoWrap;
            line.TextTrimming = TextTrimming.CharacterEllipsis;
        }
        SetGalleryMetadata(item, metadata, badge, MediaServices.Info(item.Path));
        var caption = UI.Stack(title, metadata);
        caption.Margin = new Thickness(8,7,8,7);
        var content = UI.Stack(preview, caption);
        preview.SizeChanged += (s,e) => preview.Clip = new RectangleGeometry(new Rect(e.NewSize), 7, 7);
        var button = LibraryButton("Visualizar " + name, () => OpenMedia(item));
        button.Content = content;
        button.Background = UI.Brush(UI.Surface);
        button.Padding = new Thickness(0);
        button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
        button.VerticalContentAlignment = VerticalAlignment.Top;
        button.ToolTip = item.Name + " · " + item.Date.ToString("dd MMM HH:mm", GalleryCulture) + " · " + Format.Bytes(item.Bytes);
        var zoom = new ScaleTransform(1,1);
        image.RenderTransformOrigin = new Point(.5,.5);
        image.RenderTransform = zoom;
        Action<double> animate = scale => {
            if (!UI.MotionEnabled) return;
            zoom.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(scale, TimeSpan.FromMilliseconds(170)));
            zoom.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(scale, TimeSpan.FromMilliseconds(170)));
        };
        button.MouseEnter += (s,e) => animate(1.045);
        button.MouseLeave += (s,e) => animate(1);

        var menu = GalleryItemMenu(item);
        button.ContextMenu = menu;
        var more = LibraryButton("⋯", () => {
            menu.PlacementTarget = preview;
            menu.IsOpen = true;
        });
        AutomationProperties.SetName(more, "Opções de " + name);
        more.ToolTip = "Opções de " + name;
        more.Padding = new Thickness(2,0,2,1);
        more.Width = more.Height = more.MinHeight = 27;
        more.Margin = new Thickness(0,6,6,0);
        more.HorizontalAlignment = HorizontalAlignment.Right;
        more.VerticalAlignment = VerticalAlignment.Top;
        var result = new Grid { Margin = new Thickness(4,0,4,9) };
        result.Children.Add(button);
        result.Children.Add(more);
        picture = image;
        return result;
    }

    void SetGalleryMetadata(GalleryItem item, TextBlock metadata, TextBlock badge, MediaInfo info) {
        string date = item.Date.ToString("dd MMM · HH:mm", GalleryCulture);
        metadata.Text = (string.IsNullOrWhiteSpace(info.Game) ? date : info.Game) + (info.Favorite ? " · ★" : "");
        badge.Text = item.Kind == "Prints" ? Path.GetExtension(item.Path).TrimStart('.').ToUpperInvariant()
            : info.Duration > 0 ? "▶ " + TimeSpan.FromSeconds(info.Duration).ToString(
                info.Duration >= 3600 ? @"hh\:mm\:ss" : @"mm\:ss") : item.Kind == "Clipes" ? "Clipe" : "Vídeo";
    }

    ContextMenu GalleryItemMenu(GalleryItem entry) {
        var menu = new ContextMenu { Background = UI.Brush("#1F1B26"), Foreground = UI.Brush("#F5EFF9") };
        var favorite = new MenuItem();
        menu.Opened += (s,e) => favorite.Header = MediaServices.Info(entry.Path).Favorite ? "Remover dos favoritos" : "Favoritar";
        favorite.Click += (s,e) => {
            try { MediaServices.ToggleFavorite(entry.Path); RenderGallery(); }
            catch (Exception ex) { ShowToast("Galeria", ex.Message); }
        };
        menu.Items.Add(favorite);
        var location = new MenuItem { Header = "Mostrar na pasta" };
        location.Click += (s,e) => {
            try { Process.Start("explorer.exe", "/select," + ScreenRecorder.Quote(entry.Path)); }
            catch (Exception ex) { Notice(ex.Message); }
        };
        menu.Items.Add(location);
        var rename = new MenuItem { Header = "Renomear" };
        rename.Click += (s,e) => RenameMedia(entry);
        menu.Items.Add(rename);
        var remove = new MenuItem { Header = "Excluir", Foreground = UI.Brush("#FFB1BC"), ToolTip = "Enviar à Lixeira" };
        remove.Click += (s,e) => RecycleMedia(entry);
        menu.Items.Add(remove);
        return menu;
    }

    Task RefreshCaptureGalleries() {
        var galleries = widgetControllers.Values.Where(child => child.page == "gallery" && child.window.IsVisible).ToList();
        if (page == "gallery") galleries.Add(this);
        return Task.WhenAll(galleries.Select(gallery => gallery.LoadGallery()));
    }

    async void TakeScreenshot() {
        if (sharedOwner != null) { sharedOwner.TakeScreenshot(); return; }
        if (exiting) return;
        try {
            int monitor = prefs.Video.Screen;
            string root = prefs.Video.Folder;
            string file = await Task.Run(() => MediaLibrary.Screenshot(monitor,root));
            ShowToast("Print salvo",Path.GetFileName(file),()=>{ ShowMain(); BuildPage("gallery"); });
            await RefreshCaptureGalleries();
        } catch (Exception ex) { ShowToast("Não foi possível tirar o print",ex.Message); }
    }

    RecordingOptions VideoOptions(bool full) {
        var v = prefs.Video;
        return new RecordingOptions {
            Screen=v.Screen,Fps=v.Fps,Height=v.Height,ReplaySeconds=v.ReplaySeconds,Bitrate=v.Bitrate,
            Audio=v.Audio,Cursor=v.Cursor,Microphone=v.Microphone,OutputDevice=v.OutputDevice,InputDevice=v.InputDevice,
            SystemGain=v.SystemGain,MicGain=v.MicGain,Engine=v.Engine,StopFreeMb=v.StopFreeMb,
            Folder=full ? Path.Combine(v.Folder,"Videos") : v.Folder
        };
    }
}
}
