﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
namespace LuaMonitor {
public static class FpsRegression {
    public static void Run(){uint modifiers,key;var old=new Preferences{WorkspaceKey="Ctrl+Shift+Space"};old.UpgradeDefaults();var custom=new Preferences{WorkspaceKey="Alt+F11"};custom.UpgradeDefaults();if(old.WorkspaceKey!="Ctrl+Space"||custom.WorkspaceKey!="Alt+F11"||!ShortcutKeys.Parse(new Preferences().WorkspaceKey,out modifiers,out key)||modifiers!=2||key!=32)throw new Exception("Padrão Ctrl+Espaço ou preservação de atalho personalizado falhou");
        DateTime now=new DateTime(2026,1,1,0,0,0,DateTimeKind.Utc);var reader=new FpsReader{Target=17,Clock=()=>now};
        Action<int,double> feed=(pid,ms)=>{for(int n=0;n<120;n++)reader.Feed("fixture,"+pid+",chain,"+ms.ToString("R",System.Globalization.CultureInfo.InvariantCulture));reader.Update();};
        reader.Feed("Application,ProcessID,SwapChainAddress,MsBetweenPresents");feed(17,1000.0/60);if(Math.Abs(reader.Minimum.Value-60)>.1||Math.Abs(reader.Maximum.Value-60)>.1||!reader.Low.HasValue)throw new Exception("Estatísticas iniciais de FPS incorretas");
        now=now.AddSeconds(3);feed(17,1000.0/120);if(Math.Abs(reader.Fps.Value-120)>.1||Math.Abs(reader.Minimum.Value-60)>.1||Math.Abs(reader.Maximum.Value-120)>.1)throw new Exception("Máximo de FPS não preservou a sessão");
        now=now.AddSeconds(3);feed(17,25);if(Math.Abs(reader.Minimum.Value-40)>.1||Math.Abs(reader.Maximum.Value-120)>.1)throw new Exception("Mínimo de FPS incorreto");
        int generation=reader.Generation;reader.Retarget(18,"fixture-two");if(reader.Fps.HasValue||reader.Minimum.HasValue||reader.Maximum.HasValue||reader.Generation==generation||reader.ReceivedFrames!=0)throw new Exception("Troca de jogo conservou estatísticas antigas");
        reader.Feed("Application,ProcessID,SwapChainAddress,MsBetweenPresents");feed(17,1);if(reader.Fps.HasValue)throw new Exception("Troca de jogo aceitou PID antigo");feed(18,20);if(Math.Abs(reader.Minimum.Value-50)>.1||Math.Abs(reader.Maximum.Value-50)>.1)throw new Exception("Sessões de jogos misturadas");
        now=now.AddSeconds(3);reader.Update();if(reader.Fps.HasValue||reader.Minimum.HasValue||reader.Maximum.HasValue)throw new Exception("FPS antigo permaneceu sem quadros recentes");reader.Retarget(0,"Aguardando jogo");reader.Stop();if(reader.Low.HasValue||reader.Maximum.HasValue)throw new Exception("Parada não limpou métricas");reader.Dispose();
    }
}
public sealed partial class DesktopController {
    [DllImport("user32.dll")]static extern IntPtr SendMessage(IntPtr hwnd,int message,IntPtr wp,IntPtr lp);
    async Task FpsAndFocusChecks(List<string> checks,string dir){
        FpsRegression.Run();checks.Add("FPS: mínimo/máximo da média de 2 s, 1% low, troca de PID, reset de sessão e ausência de quadros recentes corretos em dados controlados");
        bool oldLow=prefs.ShowFpsLow,oldMin=prefs.ShowFpsMinimum,oldMax=prefs.ShowFpsMaximum;var oldUpdate=availableUpdate;
        try{
            prefs.ShowFpsLow=prefs.ShowFpsMinimum=prefs.ShowFpsMaximum=true;
            foreach(bool small in new[]{true,false}){SetMode(small,false);BuildPage("gaming");window.UpdateLayout();var text=CollectText(body);if(text.Contains("Selecione seu jogo")||text.Contains("FPS NA TELA")||!text.Contains("FPS MÁXIMO")||!text.Contains("FPS MÍNIMO")||!text.Contains("1% LOW"))throw new Exception("Página FPS ainda tem seleção manual ou faltam opções");await Task.Delay(350);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,small?"fps-new-compact.png":"fps-new-expanded.png"));}
            var sample=new FpsReader{Fps=60,DisplayedFps=120,Low=45,Minimum=40,Maximum=144};var hud=new OverlayWindow(prefs);hud.Update(snapshot,sample);var hudText=CollectText(hud.Content as DependencyObject);if(hudText.Any(t=>t.Contains("tela")||t.Contains(" jogo"))||!hudText.Contains("60")||!hudText.Contains("144")||!hudText.Contains("1% low"))throw new Exception("Sobreposição não usa FPS único e estatísticas opcionais");hud.Close();checks.Add("FPS: seleção manual removida nos dois tamanhos; sobreposição com FPS único e low/mínimo/máximo opcionais");
            SetMode(true,false);BuildPage("home");window.UpdateLayout();var scroll=LayoutInformation(Find<ScrollViewer>("ContentScroll"),window.Content as Visual);var actions=LayoutInformation(Find<Grid>("CompactActions"),window.Content as Visual);if(actions.Top-scroll.Bottom<7.5)throw new Exception("Galeria/Analisar PC continuam colados ao conteúdo");
            availableUpdate=new UpdateRelease{Version="9.9.9"};Refresh();if(Find<Button>("UpdateCompactButton").Visibility!=Visibility.Visible||Find<Button>("UpdateTitleButton").Visibility!=Visibility.Collapsed)throw new Exception("Botão Atualizar compacto incorreto");await Task.Delay(350);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"update-small-button.png"));SetMode(false,false);Refresh();if(Find<Button>("UpdateTitleButton").Visibility!=Visibility.Visible||Find<Button>("UpdateCompactButton").Visibility!=Visibility.Collapsed)throw new Exception("Botão Atualizar grande incorreto");await Task.Delay(350);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"update-title-button.png"));
            BuildPage("settings");window.UpdateLayout();var last=body.Children[body.Children.Count-1] as Expander;if(last==null||Convert.ToString(last.Header)!="Sobre o LUA e atualizações"||!CollectText(last).Any(t=>t.StartsWith("Atualizações")))throw new Exception("Atualizações no grupo final: "+(last==null?body.Children[body.Children.Count-1].GetType().Name:Convert.ToString(last.Header)+" | "+string.Join(";",CollectText(last))));await Task.Delay(350);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"settings-bottom-updates.png"));checks.Add("Atualização: botões por tamanho, espaço de 8 px antes das ações e seção final de Configurações corretos");
            string fixture=Path.Combine(Preferences.DataDir,"shortcut-fixture");string shortcut=DesktopShortcut.Create(fixture,System.Reflection.Assembly.GetExecutingAssembly().Location);if(!File.Exists(shortcut)||new FileInfo(shortcut).Length==0)throw new Exception("Atalho .lnk não criado");checks.Add("Atalho: arquivo .lnk criado em pasta isolada do teste; Área de Trabalho real não alterada pela verificação");
            SetWorkspace(true);await Task.Delay(150);OpenWidget("home");var child=widgetControllers["home"];child.window.UpdateLayout();if(child.widgetHomeFpsValue==null||child.widgetHomeFpsValue.FontSize!=23)throw new Exception("FPS inicial do widget não tem o tamanho das temperaturas");UI.Capture(child.window,Path.Combine(dir,"home-widget-fps.png"));checks.Add("Início da sobreposição: FPS acima das temperaturas, fonte 23 igual a CPU/GPU e frametime menor");IntPtr handle=new WindowInteropHelper(child.window).Handle;int style=Native.GetWindowLong(handle,-20);if((style&0x08000000)==0||(style&0x20)!=0||SendMessage(handle,0x21,IntPtr.Zero,IntPtr.Zero)!=new IntPtr(3))throw new Exception("Widget editável rouba foco ou não recebe mouse");uint affinity;if(!CaptureWindowStyle.GetWindowDisplayAffinity(new WindowInteropHelper(workspaceBar).Handle,out affinity)||affinity!=0)throw new Exception("Barra continua excluída do print");
            IntPtr foreground=Native.GetForegroundWindow();DragRect bounds;GetWindowRect(handle,out bounds);SetWindowPos(handle,IntPtr.Zero,bounds.Left+12,bounds.Top+8,0,0,0x1|0x4|0x10);await Task.Delay(80);if(Native.GetForegroundWindow()!=foreground)throw new Exception("Mover widget trocou a janela em primeiro plano");
            SetWorkspaceTyping(true);if((Native.GetWindowLong(handle,-20)&0x08000000)!=0)throw new Exception("Modo Digitar não habilitou foco solicitado");SetWorkspaceTyping(false);if((Native.GetWindowLong(handle,-20)&0x08000000)==0)throw new Exception("Modo sem foco não foi restaurado");prefs.Widgets["home"].Pinned=true;SetWorkspace(false);if((Native.GetWindowLong(handle,-20)&0x20)==0)throw new Exception("Widget fixado bloqueia cliques");checks.Add("Sobreposição: edição/movimento sem ativação, teclado explícito, clique através ao fixar e barra incluída nas capturas verificados via Win32");
        }finally{CloseWorkspace();workspaceEditing=false;prefs.ShowFpsLow=oldLow;prefs.ShowFpsMinimum=oldMin;prefs.ShowFpsMaximum=oldMax;availableUpdate=oldUpdate;SetMode(true,false);window.Show();BuildPage("home");}
    }
}
}
