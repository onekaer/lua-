﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LuaMonitor {
public sealed class FpsCapture : IDisposable {
    NamedPipeServerStream pipe;StreamWriter control;Process host;readonly object gate=new object();volatile bool stopping,pending;volatile int requestedTarget;public volatile bool NeedsUserRetry;string session;public string Status="Desligado";
    public static bool CanCapture(){var principal=new WindowsPrincipal(WindowsIdentity.GetCurrent());return principal.IsInRole(WindowsBuiltInRole.Administrator)||principal.IsInRole(new SecurityIdentifier("S-1-5-32-559"));}
    public void Start(int target,Action<string> line,Action<string> status,bool testNoElevation=false){
        Dispose();stopping=false;NeedsUserRetry=false;requestedTarget=target;session="LUA_FPS_"+Guid.NewGuid().ToString("N");string name=session+"_"+WindowsIdentity.GetCurrent().User.Value;
        var security=new PipeSecurity();security.AddAccessRule(new PipeAccessRule(WindowsIdentity.GetCurrent().User,PipeAccessRights.FullControl,AccessControlType.Allow));security.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null),PipeAccessRights.FullControl,AccessControlType.Allow));
        pipe=new NamedPipeServerStream(name,PipeDirection.InOut,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous,4096,4096,security);var connection=pipe;var ownedSession=session;
        Task.Run(async()=>{try{await Task.Factory.FromAsync(connection.BeginWaitForConnection,connection.EndWaitForConnection,null);lock(gate){if(stopping)return;control=new StreamWriter(connection,new UTF8Encoding(false),4096,true){AutoFlush=true};control.WriteLine("TARGET "+requestedTarget);}status("Captura conectada • aguardando frames");using(var reader=new StreamReader(connection,Encoding.UTF8,false,4096,true)){string text;while(!stopping&&(text=await reader.ReadLineAsync())!=null){if(text.StartsWith("LUA_STATUS:"))status(text.Substring(11));else line(text);}}}catch(Exception ex){if(!stopping)status("Captura desconectada: "+ex.Message);}finally{if(!stopping){NeedsUserRetry=true;status("Captura encerrada. Reative em Métricas e detecção.");}}});
        pending=true;Task.Run(()=>{try{
            var start=new ProcessStartInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"tools","LuaFpsCapture.exe"),"--pipe "+name+" --pid "+target+" --session "+ownedSession){UseShellExecute=true,WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory,WindowStyle=ProcessWindowStyle.Hidden};
            if(!testNoElevation&&!CanCapture()){start.Verb="runas";status("Aceite a permissão do Windows para medir FPS.");}
            var started=Process.Start(start);lock(gate){pending=false;if(stopping){if(started!=null)started.Dispose();return;}host=started;}
            Task.Run(async()=>{await Task.Delay(25000);if(!stopping&&!connection.IsConnected){NeedsUserRetry=true;status("A captura não conectou. Reative em Métricas e detecção.");Dispose();}});
        }catch(System.ComponentModel.Win32Exception ex){pending=false;NeedsUserRetry=true;status(ex.NativeErrorCode==1223?"Permissão cancelada. Reative em Métricas e detecção.":"Não foi possível iniciar a captura: "+ex.Message);Dispose();}catch(Exception ex){pending=false;NeedsUserRetry=true;status("Não foi possível iniciar a captura: "+ex.Message);Dispose();}});
    }
    public void SelectTarget(int pid){if(pid<0)throw new ArgumentOutOfRangeException("pid");requestedTarget=pid;lock(gate){try{if(control!=null)control.WriteLine("TARGET "+pid);}catch{NeedsUserRetry=true;}}}
    public bool WaitingPermission {get{return pending;}}
    public bool Running{get{try{return !stopping&&(pending||(host!=null&&!host.HasExited));}catch{return false;}}}
    public void Dispose(){stopping=true;pending=false;lock(gate){try{if(control!=null){control.WriteLine("STOP");control.Dispose();}}catch{}control=null;try{if(pipe!=null)pipe.Dispose();}catch{}pipe=null;if(host!=null){try{host.Dispose();}catch{}host=null;}}}
}
}
