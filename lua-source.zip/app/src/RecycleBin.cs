﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace LuaMonitor {
public static class RecycleBin {
    [ComImport,Guid("947AAB5F-0A5C-4C13-B4D6-4BF7836FC9F8"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IFileOperation {
        [PreserveSig]int Advise(IntPtr sink,out uint cookie);
        [PreserveSig]int Unadvise(uint cookie);
        [PreserveSig]int SetOperationFlags(uint flags);
        [PreserveSig]int SetProgressMessage([MarshalAs(UnmanagedType.LPWStr)]string message);
        [PreserveSig]int SetProgressDialog(IntPtr dialog);
        [PreserveSig]int SetProperties(IntPtr properties);
        [PreserveSig]int SetOwnerWindow(IntPtr owner);
        [PreserveSig]int ApplyPropertiesToItem(IntPtr item);
        [PreserveSig]int ApplyPropertiesToItems(IntPtr items);
        [PreserveSig]int RenameItem(IntPtr item,[MarshalAs(UnmanagedType.LPWStr)]string name,IntPtr sink);
        [PreserveSig]int RenameItems(IntPtr items,[MarshalAs(UnmanagedType.LPWStr)]string name);
        [PreserveSig]int MoveItem(IntPtr item,IntPtr folder,[MarshalAs(UnmanagedType.LPWStr)]string name,IntPtr sink);
        [PreserveSig]int MoveItems(IntPtr items,IntPtr folder);
        [PreserveSig]int CopyItem(IntPtr item,IntPtr folder,[MarshalAs(UnmanagedType.LPWStr)]string name,IntPtr sink);
        [PreserveSig]int CopyItems(IntPtr items,IntPtr folder);
        [PreserveSig]int DeleteItem(IntPtr item,IntPtr sink);
        [PreserveSig]int DeleteItems(IntPtr items);
        [PreserveSig]int NewItem(IntPtr folder,uint attributes,[MarshalAs(UnmanagedType.LPWStr)]string name,[MarshalAs(UnmanagedType.LPWStr)]string template,IntPtr sink);
        [PreserveSig]int PerformOperations();
        [PreserveSig]int GetAnyOperationsAborted([MarshalAs(UnmanagedType.Bool)]out bool aborted);
    }
    [DllImport("shell32.dll",CharSet=CharSet.Unicode,PreserveSig=true)]static extern int SHCreateItemFromParsingName(string name,IntPtr bind,ref Guid iid,out IntPtr item);
    public static void Send(string path){
        if(Thread.CurrentThread.GetApartmentState()!=ApartmentState.STA)throw new InvalidOperationException("A operação da Lixeira precisa de uma thread STA.");
        var operation=(IFileOperation)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("3AD05575-8857-4850-9277-11B85BDB8E09")));IntPtr item=IntPtr.Zero;
        try{var iid=new Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE");Marshal.ThrowExceptionForHR(SHCreateItemFromParsingName(path,IntPtr.Zero,ref iid,out item));
            // RECYCLEONDELETE + ADDUNDORECORD; no permanent-delete fallback is implemented.
            Marshal.ThrowExceptionForHR(operation.SetOperationFlags(0x00080000|0x20000000|0x00000010|0x00000040|0x00004000|0x00000400|0x00100000));Marshal.ThrowExceptionForHR(operation.DeleteItem(item,IntPtr.Zero));Marshal.ThrowExceptionForHR(operation.PerformOperations());bool aborted;Marshal.ThrowExceptionForHR(operation.GetAnyOperationsAborted(out aborted));if(aborted)throw new OperationCanceledException("O Windows não concluiu o envio à Lixeira.");
        }finally{if(item!=IntPtr.Zero)Marshal.Release(item);Marshal.FinalReleaseComObject(operation);}
    }
    public static Task<T> OnSta<T>(Func<T> operation){var task=new TaskCompletionSource<T>();var thread=new Thread(()=>{try{task.SetResult(operation());}catch(Exception ex){task.SetException(ex);}}){IsBackground=true};thread.SetApartmentState(ApartmentState.STA);thread.Start();return task.Task;}
}
}
