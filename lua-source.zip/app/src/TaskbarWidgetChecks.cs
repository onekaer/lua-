using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using Drawing = System.Drawing;
using Forms = System.Windows.Forms;

namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task VerifyTaskbarWidget(List<string> checks, string directory) {
        if (Preferences.DataDir == Preferences.DefaultDataDir)
            throw new InvalidOperationException("Use --data com uma pasta de teste.");
        timer.Stop();
        await sampling;
        var bar = new Drawing.Rectangle(0, 1032, 1920, 48);
        var monitor = new Drawing.Rectangle(0, 0, 1920, 1080);
        if (TaskbarWidget.CoversMonitor(new Drawing.Rectangle(0, 0, 1920, 1032), monitor, true, false) ||
            TaskbarWidget.CoversMonitor(monitor, monitor, true, true) ||
            !TaskbarWidget.CoversMonitor(monitor, monitor, false, false))
            throw new InvalidOperationException("O widget confundiu janela maximizada com tela cheia.");
        var tray = new Drawing.Rectangle(1670, 1032, 250, 48);
        var controls = new[] { new Drawing.Rectangle(0, 1032, 186, 48), new Drawing.Rectangle(620, 1032, 510, 48) };
        int? leading = TaskbarWidget.FindFreeSlot(bar, tray, controls, false, 240, 8, 1, false);
        int? trailing = TaskbarWidget.FindFreeSlot(bar, tray, controls, false, 240, 8, 1, true);
        if (!leading.HasValue || leading.Value < 194 || leading.Value + 240 > 612 ||
            !trailing.HasValue || trailing.Value < 1138 || trailing.Value + 240 > 1662)
            throw new InvalidOperationException("A cápsula cobriu o clima, os aplicativos ou a área de notificação.");
        if (TaskbarWidget.FindFreeSlot(new Drawing.Rectangle(0, 0, 384, 48), Drawing.Rectangle.Empty,
                new Drawing.Rectangle[0], false, 240, 8, 1, true).HasValue)
            throw new InvalidOperationException("A cápsula deve ficar oculta quando a barra não tem espaço.");
        var options = new TaskbarWidgetOptions { Enabled = true, Inset = 24 };
        var snapshot = new Snapshot {
            Cpu = 24, Gpu = 62, CpuTemp = 51, GpuTemp = 59,
            RamTotal = 32UL << 30, RamAvailable = 18UL << 30,
            Download = 1830000, Upload = 82000
        };
        var widget = new TaskbarWidget(window.Resources, TaskbarMonitorPoint, () => {}, () => {});
        try {
            var screen = Forms.Screen.PrimaryScreen;
            widget.Configure(options);
            if (widget.IsVisible) throw new InvalidOperationException("Configurar abriu a janela antes da ativação.");
            widget.Update(snapshot, null);
            widget.ShowPreview(false);
            await Task.Delay(230);
            widget.UpdateLayout();
            var left = widget.CapsuleBounds;
            double collapsedHeight = widget.ActualHeight;
            if (!CollectText(widget.Content as DependencyObject).Contains("24%") || collapsedHeight <= 0 || collapsedHeight > 41)
                throw new InvalidOperationException("Leitura compacta ou tamanho incorreto.");
            if (!screen.Bounds.Contains(left) || screen.WorkingArea.IntersectsWith(left))
                throw new InvalidOperationException("A cápsula deve ocupar a faixa da barra de tarefas.");
            UI.Capture(widget, Path.Combine(directory, "widget-compact.png"));

            widget.ShowPreview(true);
            await Task.Delay(300);
            widget.UpdateLayout();
            var expandedLeft = widget.CapsuleBounds;
            if (!expandedLeft.Equals(left) || widget.ActualHeight <= collapsedHeight ||
                !CollectText(widget.Content as DependencyObject).Any(x => x.Contains("59 °C")))
                throw new InvalidOperationException("Expansão à esquerda sem manter a âncora ou as leituras.");
            CheckPanelCenter(widget, screen.WorkingArea);
            UI.Capture(widget, Path.Combine(directory, "widget-expanded.png"));
            if (widget.ShowInTaskbar || widget.ShowActivated || (Native.GetWindowLong(new WindowInteropHelper(widget).Handle, -20) & 0x08000000) == 0)
                throw new InvalidOperationException("O widget pode roubar o foco ou criar um botão de janela.");
            await CheckTaskbarStacking(widget, left);
            uint affinity;
            if (CaptureWindowStyle.GetWindowDisplayAffinity(new WindowInteropHelper(widget).Handle, out affinity) && affinity != 0)
                throw new InvalidOperationException("O widget está marcado para ser excluído dos prints.");
            int index = Array.FindIndex(Forms.Screen.AllScreens, candidate => candidate.DeviceName == screen.DeviceName);
            string print = await Task.Run(() => MediaLibrary.Screenshot(index, directory));
            using (var actual = new Drawing.Bitmap(print)) {
                // The violet brand fill is distinctive and inside the capsule even with DPI scaling.
                var a = actual.GetPixel(left.Left - screen.Bounds.Left + (int)Math.Round(left.Width * .06),
                    left.Top - screen.Bounds.Top + (int)Math.Round(left.Height * .4));
                if (a.B < a.G + 15 || a.B < a.R + 15)
                    throw new InvalidOperationException("A captura do monitor não contém a cápsula: " + a);
            }
            widget.ShowPreview(false);
            await Task.Delay(260);
            widget.UpdateLayout();
            if (widget.ActualHeight != collapsedHeight) throw new InvalidOperationException("A janela expandida continuou ocupando espaço.");
            options.Right = true;
            options.Tint = "Verde";
            options.Metrics = new List<string> { "Disco", "FPS", "CPU" };
            widget.Configure(options);
            widget.Update(new Snapshot(), null);
            await Task.Delay(100);
            widget.UpdateLayout();
            var right = widget.CapsuleBounds;
            if (right.X <= left.X || !screen.Bounds.Contains(right) || screen.WorkingArea.IntersectsWith(right))
                throw new InvalidOperationException("O lado direito ficou fora da faixa da barra.");
            if (CollectText(widget.Content as DependencyObject).Count(x => x == "—") < 3)
                throw new InvalidOperationException("Uma métrica indisponível foi exibida como medição.");
            widget.ShowPreview(true);
            await Task.Delay(300);
            widget.UpdateLayout();
            var expandedRight = widget.CapsuleBounds;
            if (!expandedRight.Equals(right))
                throw new InvalidOperationException("A expansão alterou a âncora da direita.");
            CheckPanelCenter(widget, screen.WorkingArea);
            await Task.Run(() => MediaLibrary.Screenshot(index, Path.Combine(directory, "right")));
            options.Metrics = new List<string> { "CPU", "GPU", "RAM", "Volume", "Clima", "Bateria", "Relógio", "Tempo ligado" };
            widget.Configure(options);
            widget.Update(snapshot, null);
            await Task.Delay(180);
            widget.UpdateLayout();
            var cards = CollectText(widget.Content as DependencyObject);
            if (!cards.Contains("Volume") || !cards.Contains("Bateria") || !cards.Contains("Relógio") ||
                !cards.Contains("Escolha uma cidade em Editar widgets.") ||
                !Buttons(widget.Content as DependencyObject).Any(button => System.Windows.Automation.AutomationProperties.GetName(button) == "+ Editar widgets"))
                throw new InvalidOperationException("Catálogo ou atalho do editor ausente no painel.");
            UI.Capture(widget, Path.Combine(directory, "widget-cards.png"));
        } finally { widget.Close(); }
        options.WeatherCity = new WidgetCity { name = "São Paulo", admin1 = "São Paulo", country = "Brasil", latitude = -23.55, longitude = -46.63 };
        var saved = new Preferences { Taskbar = options };
        saved.Save();
        var loaded = Preferences.Load();
        loaded.UpgradeDefaults();
        if (!loaded.Taskbar.Enabled || !loaded.Taskbar.Right || loaded.Taskbar.Tint != "Verde" || !loaded.Taskbar.Metrics.SequenceEqual(options.Metrics))
            throw new InvalidOperationException("As preferências do widget não foram restauradas.");
        if (!loaded.Taskbar.WeatherCity.Valid || loaded.Taskbar.WeatherCity.Name != "São Paulo, Brasil" ||
            WidgetWeather.Description(61) != "Chuva" || WidgetWeather.Description(95) != "Trovoadas")
            throw new InvalidOperationException("Cidade do clima ou tradução da condição incorreta.");
        prefs.Taskbar = options;
        BuildPage("settings");
        window.Dispatcher.BeginInvoke(new Action(async () => {
            await Task.Delay(280);
            if (taskbarEditor == null) return;
            try { UI.Capture(taskbarEditor, Path.Combine(directory, "widget-editor.png")); }
            finally { taskbarEditor.Close(); }
        }));
        EditTaskbarWidget();
        if (!File.Exists(Path.Combine(directory, "widget-editor.png"))) throw new InvalidOperationException("O editor não abriu.");
        checks.Add("Widget nativo: painel centralizado e print real, catálogo de cartões, editor, armazenamento da cidade e tradução do clima.");
    }

    async Task CheckTaskbarStacking(TaskbarWidget widget, Drawing.Rectangle capsule) {
        var competitor = new Window {
            WindowStyle = WindowStyle.None, ShowInTaskbar = false, Topmost = true, ShowActivated = false,
            Width = widget.ActualWidth, Height = widget.ActualHeight,
            Background = System.Windows.Media.Brushes.OrangeRed
        };
        try {
            var handle = new WindowInteropHelper(competitor).EnsureHandle();
            competitor.Show();
            var point = widget.PointToScreen(new Point());
            SetWindowPos(handle, new IntPtr(-1), (int)point.X, (int)point.Y, 0, 0, 0x0011);
            var inside = new Drawing.Point(capsule.Left + capsule.Width / 2, capsule.Top + capsule.Height / 2);
            await Task.Delay(80);
            if (NativeWindowAtPoint(inside) != handle)
                throw new InvalidOperationException("A janela concorrente não cobriu a cápsula durante o teste.");
            var foreground = Native.GetForegroundWindow();
            var widgetHandle = new WindowInteropHelper(widget).Handle;
            TaskbarWidget.KeepAboveTaskbar(widgetHandle, handle);
            await Task.Delay(80);
            if (NativeWindowAtPoint(inside) != widgetHandle || Native.GetForegroundWindow() != foreground)
                throw new InvalidOperationException("O widget continuou atrás da barra ou tomou o foco.");
        } finally { competitor.Close(); }
    }

    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "WindowFromPoint")]
    static extern IntPtr NativeWindowAtPoint(Drawing.Point point);

    static void CheckPanelCenter(TaskbarWidget widget, Drawing.Rectangle workArea) {
        var capsule = widget.CapsuleBounds;
        var panel = widget.PanelBounds;
        bool vertical = capsule.Height > capsule.Width;
        int ideal = vertical ? capsule.Top + (capsule.Height - panel.Height) / 2
            : capsule.Left + (capsule.Width - panel.Width) / 2;
        int min = vertical ? workArea.Top : workArea.Left;
        int max = vertical ? workArea.Bottom - panel.Height : workArea.Right - panel.Width;
        int expected = Math.Max(min, Math.Min(ideal, max));
        if (Math.Abs((vertical ? panel.Top : panel.Left) - expected) > 2)
            throw new InvalidOperationException("O painel não está centralizado na cápsula.");
    }
}
}
