using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using Forms = System.Windows.Forms;

namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task VerifyTaskbarWidget(List<string> checks, string directory) {
        if (Preferences.DataDir == Preferences.DefaultDataDir)
            throw new InvalidOperationException("Use --data com uma pasta de teste.");
        timer.Stop();
        await sampling;
        var options = new TaskbarWidgetOptions { Enabled = true, Inset = 24 };
        var snapshot = new Snapshot {
            Cpu = 24, Gpu = 62, CpuTemp = 51, GpuTemp = 59,
            RamTotal = 32UL << 30, RamAvailable = 18UL << 30,
            Download = 1830000, Upload = 82000
        };
        var widget = new TaskbarWidget(window.Resources, TaskbarMonitorPoint, () => {}, () => {});
        try {
            widget.Configure(options);
            if (widget.IsVisible) throw new InvalidOperationException("Configurar abriu a janela antes da ativação.");
            widget.Update(snapshot, null);
            widget.ShowPreview(false);
            await Task.Delay(230);
            widget.UpdateLayout();
            var left = widget.PointToScreen(new Point());
            double collapsedHeight = widget.ActualHeight;
            if (!CollectText(widget.Content as DependencyObject).Contains("24%") || collapsedHeight != 40)
                throw new InvalidOperationException("Leitura compacta ou tamanho incorreto.");
            UI.Capture(widget, Path.Combine(directory, "widget-compact.png"));

            widget.ShowPreview(true);
            await Task.Delay(300);
            widget.UpdateLayout();
            var expandedLeft = widget.PointToScreen(new Point());
            if (Math.Abs(expandedLeft.X - left.X) > 2 || widget.ActualHeight <= collapsedHeight ||
                !CollectText(widget.Content as DependencyObject).Any(x => x.Contains("59 °C")))
                throw new InvalidOperationException("Expansão à esquerda sem manter a âncora ou as leituras.");
            UI.Capture(widget, Path.Combine(directory, "widget-expanded.png"));
            if (widget.ShowInTaskbar || widget.ShowActivated || (Native.GetWindowLong(new WindowInteropHelper(widget).Handle, -20) & 0x08000000) == 0)
                throw new InvalidOperationException("O widget pode roubar o foco ou criar um botão de janela.");
            widget.ShowPreview(false);
            await Task.Delay(260);
            widget.UpdateLayout();
            if (widget.ActualHeight != collapsedHeight) throw new InvalidOperationException("A janela expandida continuou ocupando espaço.");
            options.Right = true;
            options.Tint = "Verde";
            options.Metrics = new List<string> { "Disco", "FPS", "CPU" };
            widget.Configure(options);
            widget.Update(new Snapshot(), null);
            await Task.Delay(100);
            widget.UpdateLayout();
            var right = widget.PointToScreen(new Point(widget.ActualWidth, 0));
            var area = Forms.Screen.PrimaryScreen.WorkingArea;
            if (right.X <= left.X || right.X > area.Right)
                throw new InvalidOperationException("O lado direito ficou fora da área útil.");
            if (CollectText(widget.Content as DependencyObject).Count(x => x == "—") < 3)
                throw new InvalidOperationException("Uma métrica indisponível foi exibida como medição.");
            widget.ShowPreview(true);
            await Task.Delay(300);
            widget.UpdateLayout();
            var expandedRight = widget.PointToScreen(new Point(widget.ActualWidth, 0));
            if (Math.Abs(expandedRight.X - right.X) > 2)
                throw new InvalidOperationException("A expansão alterou a âncora da direita.");
        } finally { widget.Close(); }
        var saved = new Preferences { Taskbar = options };
        saved.Save();
        var loaded = Preferences.Load();
        loaded.UpgradeDefaults();
        if (!loaded.Taskbar.Enabled || !loaded.Taskbar.Right || loaded.Taskbar.Tint != "Verde" || !loaded.Taskbar.Metrics.SequenceEqual(options.Metrics))
            throw new InvalidOperationException("As preferências do widget não foram restauradas.");
        prefs.Taskbar = options;
        BuildPage("settings");
        window.Dispatcher.BeginInvoke(new Action(async () => {
            await Task.Delay(280);
            if (taskbarEditor == null) return;
            try { UI.Capture(taskbarEditor, Path.Combine(directory, "widget-editor.png")); }
            finally { taskbarEditor.Close(); }
        }));
        EditTaskbarWidget();
        if (!File.Exists(Path.Combine(directory, "widget-editor.png"))) throw new InvalidOperationException("O editor não abriu.");
        checks.Add("Widget nativo: expansão e recolhimento, posição esquerda e direita, leituras ausentes, foco preservado e preferências restauradas.");
    }

}
}
