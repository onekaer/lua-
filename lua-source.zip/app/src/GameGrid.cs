using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
namespace LuaMonitor {
public class GameGridPanel:Panel {
    const double Gap = 12, MinimumTileWidth = 142, MaximumTileWidth = 218;
    public int Columns;
    double cell;
    readonly List<double> rowHeights = new List<double>();

    protected override Size MeasureOverride(Size available) {
        double width = double.IsInfinity(available.Width) ? 380 : available.Width;
        Columns = Math.Max(1, Math.Min(6, (int)((width + Gap) / (MinimumTileWidth + Gap))));
        cell = Math.Max(0, Math.Min(MaximumTileWidth, (width - (Columns - 1) * Gap) / Columns));
        rowHeights.Clear();
        for (int i = 0; i < InternalChildren.Count; i++) {
            var child = InternalChildren[i];
            child.Measure(new Size(cell, double.PositiveInfinity));
            int row = i / Columns;
            if (row == rowHeights.Count) rowHeights.Add(0);
            rowHeights[row] = Math.Max(rowHeights[row], child.DesiredSize.Height);
        }
        double height = 0;
        foreach (double rowHeight in rowHeights) height += rowHeight;
        return new Size(width, height + Math.Max(0, rowHeights.Count - 1) * Gap);
    }

    protected override Size ArrangeOverride(Size size) {
        double y = 0;
        for (int i = 0; i < InternalChildren.Count; i++) {
            int col = i % Columns, row = i / Columns;
            if (col == 0 && row > 0) y += rowHeights[row - 1] + Gap;
            InternalChildren[i].Arrange(new Rect(col * (cell + Gap), y, cell, rowHeights[row]));
        }
        return size;
    }
}

internal sealed class GamePoster : Border {
    protected override Size MeasureOverride(Size constraint) {
        double width = double.IsInfinity(constraint.Width) ? 180 : constraint.Width;
        var poster = new Size(width, width * 1.5);
        base.MeasureOverride(poster);
        return poster;
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        Clip = new RectangleGeometry(new Rect(sizeInfo.NewSize), CornerRadius.TopLeft, CornerRadius.TopLeft);
    }
}

public sealed partial class DesktopController {
    GamePoster MakeGamePoster(GameEntry entry, int decodeWidth) {
        var image = GameCovers.Image(entry.CoverPath, decodeWidth);
        var cover = new GamePoster {
            CornerRadius = new CornerRadius(8),
            Background = new LinearGradientBrush((Color)ColorConverter.ConvertFromString("#2C2A3C"),
                (Color)ColorConverter.ConvertFromString("#17171E"), 120),
            VerticalAlignment = VerticalAlignment.Top,
            ToolTip = entry.CoverSource ?? "Sem capa"
        };
        if (image == null) {
            var placeholder = UI.Stack(UI.Icon("games", "#A6A0B6", decodeWidth <= 120 ? 23 : 34));
            placeholder.HorizontalAlignment = HorizontalAlignment.Center;
            placeholder.VerticalAlignment = VerticalAlignment.Center;
            cover.Child = placeholder;
        } else {
            double ratio = (double)image.PixelWidth / image.PixelHeight;
            // Portrait artwork can fill the frame. Preserve logos and edges of horizontal art.
            cover.Child = new Image { Source = image, Stretch = ratio >= .58 && ratio <= .76 ? Stretch.UniformToFill : Stretch.Uniform };
        }
        RenderOptions.SetBitmapScalingMode(cover, BitmapScalingMode.HighQuality);
        return cover;
    }

    Button GamePosterButton(GameEntry entry, int decodeWidth, double width = double.NaN) {
        var poster = MakeGamePoster(entry, decodeWidth);
        var button = UI.Button("Detalhes de " + entry.Name, () => ShowGameDetails(entry));
        button.Style = (Style)window.FindResource("PanelAction");
        button.MinHeight = 0;
        button.Margin = button.Padding = new Thickness(0);
        button.BorderThickness = new Thickness(1);
        button.BorderBrush = UI.Brush("#27242E");
        button.Width = width;
        button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
        button.Content = poster;
        var scale = new ScaleTransform(1, 1);
        poster.Child.RenderTransformOrigin = new Point(.5, .5);
        poster.Child.RenderTransform = scale;
        button.MouseEnter += (sender, args) => AnimateGamePoster(scale, 1.055);
        button.MouseLeave += (sender, args) => AnimateGamePoster(scale, 1);
        return button;
    }

    static void AnimateGamePoster(ScaleTransform scale, double size) {
        if (!UI.MotionEnabled || !SystemParameters.ClientAreaAnimation) {
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, null);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, null);
            return;
        }
        var animation = new DoubleAnimation(size, TimeSpan.FromMilliseconds(170)) {
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, animation);
        scale.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
    }

    UIElement GameTile(GameEntry entry) {
        var title = UI.Text(entry.Name, 13, "#F2EDF8", true);
        title.TextWrapping = TextWrapping.NoWrap;
        title.TextTrimming = TextTrimming.CharacterEllipsis;
        title.ToolTip = entry.Name;
        title.Margin = new Thickness(0, 0, 0, 3);
        var hours = GameHoursLabel(entry, true);
        hours.TextWrapping = TextWrapping.NoWrap;
        hours.TextTrimming = TextTrimming.CharacterEllipsis;
        var caption = UI.Stack(title, hours);
        caption.Margin = new Thickness(8, 7, 8, 8);
        var cover = GamePosterButton(entry, 360);
        var content = UI.Stack(cover, caption);
        content.SizeChanged += (sender, args) => content.Clip =
            new RectangleGeometry(new Rect(args.NewSize), 8, 8);
        return new Border { Child=content, CornerRadius=new CornerRadius(9), Background=UI.Brush("#171717"),
            BorderBrush=UI.Brush("#343434"), BorderThickness=new Thickness(1) };
    }
}
}
