﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace LuaMonitor {
public class GameGridPanel:Panel {
    public int Columns;double cell;List<double> heights=new List<double>();
    protected override Size MeasureOverride(Size available){double width=double.IsInfinity(available.Width)?380:available.Width;Columns=Math.Max(1,Math.Min(5,(int)((width+12)/178)));cell=Math.Max(0,(width-(Columns-1)*12)/Columns);heights.Clear();for(int i=0;i<InternalChildren.Count;i++){InternalChildren[i].Measure(new Size(cell,double.PositiveInfinity));int row=i/Columns;if(heights.Count<=row)heights.Add(0);heights[row]=Math.Max(heights[row],InternalChildren[i].DesiredSize.Height);}return new Size(width,heights.Sum()+Math.Max(0,heights.Count-1)*12);}
    protected override Size ArrangeOverride(Size size){double y=0;for(int i=0;i<InternalChildren.Count;i++){int col=i%Columns,row=i/Columns;if(col==0&&row>0)y+=heights[row-1]+12;InternalChildren[i].Arrange(new Rect(col*(cell+12),y,cell,heights[row]));}return size;}
}
public sealed partial class DesktopController {
    Border GameTile(GameEntry entry){var image=GameCovers.Image(entry.CoverPath);UIElement art=image==null?(UIElement)UI.Stack(UI.Icon("games",size:30),UI.Text("Sem capa",11)):(UIElement)new Image{Source=image,Stretch=Stretch.UniformToFill};var cover=new Border{Height=208,CornerRadius=new CornerRadius(7),Background=UI.Brush("#303036"),ClipToBounds=true,Child=art,ToolTip=entry.CoverSource};RenderOptions.SetBitmapScalingMode(cover,BitmapScalingMode.HighQuality);var title=UI.Text(entry.Name,13,"#ECECF2",true);title.Height=36;title.TextTrimming=TextTrimming.CharacterEllipsis;title.ToolTip=entry.Name;title.Margin=new Thickness(0,9,0,0);var row=GameActions(entry);row.Margin=new Thickness(0,8,0,0);var card=UI.Card(UI.Stack(cover,title,UI.Text(entry.Platform,10,"#ACBDE3"),UI.Text(entry.Bytes.HasValue?Format.Bytes(entry.Bytes.Value):"Pendente",17,"#EEEEF4",true),row),10);card.Margin=new Thickness(0);card.ToolTip=entry.SizeSource+"\n"+entry.Folder;return card;}
    Grid GalleryActions(GalleryItem entry){var folder=UI.Button("Mostrar na pasta",()=>{try{Process.Start("explorer.exe","/select,"+ScreenRecorder.Quote(entry.Path));}catch(Exception ex){Notice(ex.Message);}});var remove=UI.Button("Excluir",()=>RecycleMedia(entry));remove.Background=UI.Brush("#51282F");remove.BorderBrush=UI.Brush("#87404C");remove.Foreground=UI.Brush("#FFB1BC");remove.ToolTip="Enviar à Lixeira";var row=UI.Inline(folder,remove);row.Tag="gallery-actions";return row;}
}
}
