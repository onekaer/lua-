using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace LuaMonitor {
public class GameGridPanel:Panel {
    const double Gap = 15, MinimumTileWidth = 147, MaximumTileWidth = 218;
    public int Columns;
    double cell;
    readonly List<double> rowHeights = new List<double>();

    protected override Size MeasureOverride(Size available) {
        double width = double.IsInfinity(available.Width) ? 380 : available.Width;
        Columns = Math.Max(1, Math.Min(6, (int)((width + Gap) / (MinimumTileWidth + Gap))));
        cell = Math.Max(0, Math.Min(MaximumTileWidth, (width - (Columns - 1) * Gap) / Columns));
        rowHeights.Clear();
        for (int i = 0; i < InternalChildren.Count; i++) {
            var child = InternalChildren[i];
            child.Measure(new Size(cell, double.PositiveInfinity));
            int row = i / Columns;
            if (row == rowHeights.Count) rowHeights.Add(0);
            rowHeights[row] = Math.Max(rowHeights[row], child.DesiredSize.Height);
        }
        double height = 0;
        foreach (double rowHeight in rowHeights) height += rowHeight;
        return new Size(width, height + Math.Max(0, rowHeights.Count - 1) * Gap);
    }

    protected override Size ArrangeOverride(Size size) {
        double y = 0;
        for (int i = 0; i < InternalChildren.Count; i++) {
            int col = i % Columns, row = i / Columns;
            if (col == 0 && row > 0) y += rowHeights[row - 1] + Gap;
            InternalChildren[i].Arrange(new Rect(col * (cell + Gap), y, cell, rowHeights[row]));
        }
        return size;
    }
}

internal sealed class GamePoster : Border {
    protected override Size MeasureOverride(Size constraint) {
        double width = double.IsInfinity(constraint.Width) ? 180 : constraint.Width;
        var poster = new Size(width, width * 1.5);
        base.MeasureOverride(poster);
        return poster;
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        Clip = new RectangleGeometry(new Rect(sizeInfo.NewSize), CornerRadius.TopLeft, CornerRadius.TopLeft);
    }
}

public sealed partial class DesktopController {
    GamePoster MakeGamePoster(GameEntry entry, int decodeWidth) {
        var image = GameCovers.Image(entry.CoverPath, decodeWidth);
        var cover = new GamePoster {
            CornerRadius = new CornerRadius(8),
            Background = new LinearGradientBrush((Color)ColorConverter.ConvertFromString("#2C2A3C"),
                (Color)ColorConverter.ConvertFromString("#17171E"), 120),
            VerticalAlignment = VerticalAlignment.Top,
            ToolTip = entry.CoverSource ?? "Sem capa"
        };
        if (image == null) {
            var placeholder = UI.Stack(UI.Icon("games", "#A6A0B6", decodeWidth <= 120 ? 23 : 34));
            placeholder.HorizontalAlignment = HorizontalAlignment.Center;
            placeholder.VerticalAlignment = VerticalAlignment.Center;
            cover.Child = placeholder;
        } else {
            double ratio = (double)image.PixelWidth / image.PixelHeight;
            // Portrait artwork can fill the frame. Preserve logos and edges of horizontal art.
            cover.Child = new Image { Source = image, Stretch = ratio >= .58 && ratio <= .76 ? Stretch.UniformToFill : Stretch.Uniform };
        }
        RenderOptions.SetBitmapScalingMode(cover, BitmapScalingMode.HighQuality);
        return cover;
    }

    UIElement GameTile(GameEntry entry) {
        var title = UI.Text(entry.Name, 14, "#ECECF2", true);
        title.TextWrapping = TextWrapping.NoWrap;
        title.TextTrimming = TextTrimming.CharacterEllipsis;
        title.ToolTip = entry.Name;
        title.Margin = new Thickness(0, 8, 0, 3);
        string size = entry.Bytes.HasValue ? Format.Bytes(entry.Bytes.Value) : entry.TrackingOnly ? "Histórico" : "Tamanho pendente";
        var metadata = UI.Text(entry.Platform + " · " + size, 11, "#ABA7B6");
        metadata.TextTrimming = TextTrimming.CharacterEllipsis;
        metadata.TextWrapping = TextWrapping.NoWrap;
        metadata.ToolTip = entry.Platform + " · " + size + "\n" + entry.SizeSource;
        var hours = GameHoursLabel(entry);
        hours.TextWrapping = TextWrapping.NoWrap;
        hours.TextTrimming = TextTrimming.CharacterEllipsis;
        var actions = GameActions(entry);
        actions.Margin = new Thickness(0, 4, 0, 0);
        return UI.Stack(MakeGamePoster(entry, 360), title, metadata, hours, actions);
    }
    Grid GalleryActions(GalleryItem entry){var folder=UI.Button("Mostrar na pasta",()=>{try{Process.Start("explorer.exe","/select,"+ScreenRecorder.Quote(entry.Path));}catch(Exception ex){Notice(ex.Message);}});var remove=UI.Button("Excluir",()=>RecycleMedia(entry));remove.Background=UI.Brush("#51282F");remove.BorderBrush=UI.Brush("#87404C");remove.Foreground=UI.Brush("#FFB1BC");remove.ToolTip="Enviar à Lixeira";var row=UI.Inline(folder,remove);row.Tag="gallery-actions";return row;}
}
}
