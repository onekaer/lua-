using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
namespace LuaMonitor {
public sealed partial class DesktopController {
    bool widgetMoving;
    [StructLayout(LayoutKind.Sequential)]struct DragRect{public int Left,Top,Right,Bottom;}
    [DllImport("user32.dll")]static extern bool GetWindowRect(IntPtr hwnd,out DragRect rect);
    void SetWorkspaceTyping(bool enabled){workspaceTyping=enabled;UpdateWorkspaceTyping();foreach(var child in widgetControllers.Values)SetWidgetInput(child,workspaceEditing);if(!enabled)ReturnToGame();}
    void UpdateWorkspaceTyping(){if(workspaceTypingButton==null)return;workspaceTypingButton.Content=workspaceTyping?"Teclado ativo":"Digitar";workspaceTypingButton.Background=UI.Brush(workspaceTyping?"#60502D":"#29292E");}
    // Native no-activate movement reuses the composed surface without DragMove's modal loop.
    void BeginWidgetMove(DesktopController child,FrameworkElement header,MouseButtonEventArgs down){
        if(!workspaceEditing||child.widgetMoving)return;
        var handle=new WindowInteropHelper(child.window).Handle;DragRect initial;if(!GetWindowRect(handle,out initial))return;
        var origin=System.Windows.Forms.Cursor.Position;if(!header.CaptureMouse())return;child.widgetMoving=true;down.Handled=true;
        MouseEventHandler move=null;MouseButtonEventHandler up=null;MouseEventHandler lost=null;
        Action finish=()=>{if(!child.widgetMoving)return;child.widgetMoving=false;header.MouseMove-=move;header.MouseLeftButtonUp-=up;header.LostMouseCapture-=lost;if(header.IsMouseCaptured)header.ReleaseMouseCapture();RememberWidget(child);};
        move=(s,e)=>{if(e.LeftButton!=MouseButtonState.Pressed){finish();return;}var cursor=System.Windows.Forms.Cursor.Position;SetWindowPos(handle,IntPtr.Zero,initial.Left+cursor.X-origin.X,initial.Top+cursor.Y-origin.Y,0,0,0x1|0x4|0x10);e.Handled=true;};
        up=(s,e)=>{finish();e.Handled=true;};lost=(s,e)=>finish();header.MouseMove+=move;header.MouseLeftButtonUp+=up;header.LostMouseCapture+=lost;
    }
}
}
