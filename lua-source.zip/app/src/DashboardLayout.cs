﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public sealed partial class DesktopController {
    Border DashboardCard(string title,UIElement content,Button action,string badge=""){var grid=new Grid();grid.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});grid.RowDefinitions.Add(new RowDefinition());grid.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});grid.Children.Add(UI.Row(UI.Text(title,16,"#DDDDDF",true),UI.Text(badge,11,"#AAAAAF")));Grid.SetRow(content,1);((FrameworkElement)content).VerticalAlignment=VerticalAlignment.Top;grid.Children.Add(content);Grid.SetRow(action,2);action.Margin=new Thickness(0,12,0,0);grid.Children.Add(action);var card=UI.Card(grid);card.MinHeight=218;return card;}
    void NetworkStorageCards(){var network=UI.Stack(UI.Inline(UI.Stack(UI.Label("↓ Recebimento"),Value(s=>Format.Rate(s.Download),22,"#8FD2E7",true)),UI.Stack(UI.Label("↑ Envio"),Value(s=>Format.Rate(s.Upload),22,"#A0BFFA",true))),Chart(DownHistory,"#83D2E5",35,true));var storage=UI.Stack(UI.Text("ESPAÇO LIVRE",11,"#A9BCD9",true),Value(s=>Format.Bytes(s.Disks.Sum(d=>(double)d.Free)),28,"#D7E5FF",true),Value(s=>Format.Bytes(s.Disks.Sum(d=>(double)(d.Total-d.Free)))+" em uso • "+s.Disks.Count+" unidades",11,"#AAAABC"),Bar(s=>s.Disks.Sum(d=>(double)d.Total)==0?0:100*s.Disks.Sum(d=>(double)(d.Total-d.Free))/s.Disks.Sum(d=>(double)d.Total)));body.Children.Add(UI.Columns(DashboardCard("Rede",network,UI.Button("Detalhes da conexão →",()=>BuildPage("network")),"TRÁFEGO ATUAL"),DashboardCard("Armazenamento",storage,UI.Button("Encontrar arquivos grandes →",()=>BuildPage("storage")))));}
}
}
