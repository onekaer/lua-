using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace LuaMonitor {
public sealed partial class DesktopController {
    const string CpuLine = "#E7BD69";
    const string GpuLine = "#76CBB4";
    const string MemoryLine = "#C893D7";

    void Home() {
        body.Children.Add(UI.Columns(
            OverviewMetric("Processador", "hardware", CpuLine, s => Format.Percent(s.Cpu), s => "Uso total da CPU"),
            OverviewMetric("Placa de vídeo", "gaming", GpuLine, s => Format.Percent(s.Gpu), s => s.Gpu.HasValue ? "Maior carga detectada" : "Sensor indisponível"),
            OverviewMetric("Memória RAM", "processes", MemoryLine, s => Format.Percent(s.RamPercent), s => Format.Bytes(s.RamTotal - s.RamAvailable) + " / " + Format.Bytes(s.RamTotal))));
        body.Children.Add(OverviewColumns(OverviewHistory(), OverviewStatus()));
        NetworkStorageCards();
    }

    Border OverviewMetric(string label, string icon, string color, Func<Snapshot, string> value, Func<Snapshot, string> note) {
        var number = Value(value, 34, "#F2F3F1");
        number.Margin = new Thickness(0, 8, 0, 3);
        return UI.Card(UI.Stack(
            UI.Row(UI.Text(label, 13, "#C4C9C6", true), UI.Icon(icon, color, 17)),
            number, Value(note, 12, "#A5ABA7")), 18);
    }

    Grid OverviewColumns(UIElement chart, UIElement status) {
        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition());
        grid.ColumnDefinitions.Add(new ColumnDefinition());
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.Children.Add(chart);
        grid.Children.Add(status);
        var chartCard = (FrameworkElement)chart;
        var statusCard = (FrameworkElement)status;
        grid.SizeChanged += (sender, args) => {
            bool sideBySide = args.NewSize.Width >= 680;
            grid.ColumnDefinitions[0].Width = new GridLength(sideBySide ? 1.75 : 1, GridUnitType.Star);
            grid.ColumnDefinitions[1].Width = sideBySide ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
            Grid.SetColumn(statusCard, sideBySide ? 1 : 0);
            Grid.SetRow(statusCard, sideBySide ? 0 : 1);
            chartCard.Margin = new Thickness(0, 0, sideBySide ? 8 : 0, 16);
            statusCard.Margin = new Thickness(sideBySide ? 8 : 0, 0, 0, 16);
        };
        return grid;
    }

    Border OverviewHistory() {
        var header = UI.Row(UI.Text("Uso de hardware", 18, "#F0F1EF", true), UI.Text("Até 60 leituras", 11, "#A4A9A6"));
        const double plotHeight = 188;
        var chart = new Grid { Height = plotHeight, Margin = new Thickness(0, 16, 0, 12) };
        chart.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
        chart.ColumnDefinitions.Add(new ColumnDefinition());
        var ticks = new Grid { Margin = new Thickness(0, -6, 5, -6) };
        for (int i = 0; i < 5; i++) {
            ticks.RowDefinitions.Add(new RowDefinition());
            var label = UI.Text((100 - i * 25) + "%", 11, "#A4A9A6");
            label.VerticalAlignment = VerticalAlignment.Top;
            label.HorizontalAlignment = HorizontalAlignment.Right;
            Grid.SetRow(label, i);
            ticks.Children.Add(label);
        }
        ticks.RowDefinitions[4].Height = new GridLength(13);
        chart.Children.Add(ticks);
        var cpu = Chart(CpuHistory, CpuLine, plotHeight);
        var gpu = Chart(GpuHistory, GpuLine, plotHeight);
        var memory = Chart(RamHistory, MemoryLine, plotHeight);
        foreach (var series in new[] { cpu, gpu, memory }) {
            series.Margin = new Thickness(0);
            series.SharedScale = true;
            series.ShowGuides = series == cpu;
            Grid.SetColumn(series, 1);
            chart.Children.Add(series);
        }
        var legend = new StackPanel { Orientation = Orientation.Horizontal };
        foreach (var label in new[] { UI.Text("●  CPU", 12, CpuLine), UI.Text("●  GPU", 12, GpuLine), UI.Text("●  RAM", 12, MemoryLine) }) {
            label.Margin = new Thickness(0, 0, 20, 0);
            legend.Children.Add(label);
        }
        return UI.Card(UI.Stack(header, chart, legend), 20);
    }

    Border OverviewStatus() {
        var title = UI.Text("Agora no PC", 18, "#F0F1EF", true);
        title.Margin = new Thickness(0, 0, 0, 12);
        var temperatures = UI.Stack(
            UI.Text("Temperaturas", 13, "#E1E5E2", true),
            UI.Row(UI.Label("Processador"), Value(s => Format.Temp(s.CpuTemp), 14, "#F0F1EF")),
            UI.Row(UI.Label("Placa de vídeo"), Value(s => Format.Temp(s.GpuTemp), 14, "#F0F1EF")));
        var memory = UI.Stack(
            UI.Row(UI.Text("Memória disponível", 13, "#E1E5E2", true), Value(s => Format.Percent(s.RamTotal == 0 ? (double?)null : 100 - s.RamPercent), 12, "#C893D7")),
            Value(s => Format.Bytes(s.RamAvailable), 21, "#F0F1EF"),
            Bar(s => s.RamTotal == 0 ? 0 : 100 - s.RamPercent, MemoryLine),
            UI.Row(UI.Label("Memória comprometida"), Value(s => Format.Bytes(s.CommitTotal - s.CommitAvailable), 12)));
        var status = UI.Stack(title, OverviewStatusRow(temperatures), OverviewStatusRow(memory));
        return UI.Card(status, 20);
    }

    Border OverviewStatusRow(UIElement content) {
        return new Border { Background = UI.Brush("#191B1B"), CornerRadius = new CornerRadius(8), Padding = new Thickness(12), Margin = new Thickness(0, 0, 0, 8), Child = content };
    }

    Border DashboardCard(string title, UIElement content, Button action, string badge = "") {
        var grid = new Grid();
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition());
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.Children.Add(UI.Row(UI.Text(title, 16, "#E7EAE8", true), UI.Text(badge, 11, "#A4A9A6")));
        Grid.SetRow(content, 1);
        ((FrameworkElement)content).VerticalAlignment = VerticalAlignment.Top;
        grid.Children.Add(content);
        Grid.SetRow(action, 2);
        action.Margin = new Thickness(0, 12, 0, 0);
        grid.Children.Add(action);
        var card = UI.Card(grid, 18);
        card.MinHeight = 176;
        return card;
    }

    void NetworkStorageCards() {
        var network = UI.Stack(UI.Inline(
            UI.Stack(UI.Label("↓ Recebimento"), Value(s => Format.Rate(s.Download), 22, GpuLine)),
            UI.Stack(UI.Label("↑ Envio"), Value(s => Format.Rate(s.Upload), 22, MemoryLine))),
            Chart(DownHistory, GpuLine, 28, true));
        var storage = UI.Stack(UI.Label("Espaço livre"),
            Value(s => Format.Bytes(s.Disks.Sum(d => (double)d.Free)), 27, "#F0F1EF"),
            Value(s => Format.Bytes(s.Disks.Sum(d => (double)(d.Total - d.Free))) + " em uso • " + s.Disks.Count + " unidades", 11, "#A4A9A6"),
            Bar(s => s.Disks.Sum(d => (double)d.Total) == 0 ? 0 : 100 * s.Disks.Sum(d => (double)(d.Total - d.Free)) / s.Disks.Sum(d => (double)d.Total)));
        body.Children.Add(UI.Columns(DashboardCard("Rede", network, UI.Button("Detalhes da conexão →", () => BuildPage("network"))),
            DashboardCard("Armazenamento", storage, UI.Button("Encontrar arquivos grandes →", () => BuildPage("storage")))));
    }
}
}
