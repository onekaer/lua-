using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
namespace LuaMonitor {
public sealed partial class DesktopController {
    DateTime autoReplayAfter=DateTime.MinValue;int autoReplayFailures;bool autoReplayStarting;StackPanel captureWidgetRoot;Button widgetRecord,widgetClip;string captureForeground="";
    [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetWindowText(IntPtr hwnd,StringBuilder text,int length);
    void RememberCaptureForeground(){try{var handle=Native.GetForegroundWindow();uint pid;Native.GetWindowThreadProcessId(handle,out pid);if(pid==0||pid==Process.GetCurrentProcess().Id)return;var text=new StringBuilder(512);GetWindowText(handle,text,text.Capacity);if(text.Length>0)captureForeground=text.ToString();}catch{}}
    void ShowClipToast(string title,string text){if(exiting)return;try{LocalHistory.Add(title,text);}catch{}if(luaToast==null)luaToast=new LuaToast();luaToast.Notify(title,text,null,null);}
    async void EnsureAutoReplay(){if(sharedOwner!=null){sharedOwner.EnsureAutoReplay();return;}if(exiting||autoReplayStarting||videoBusy||!prefs.ReplayAlwaysOn||DateTime.UtcNow<autoReplayAfter||(recorder!=null&&recorder.Replaying))return;autoReplayStarting=true;videoBusy=true;captureAction="Preparando histórico";try{var options=VideoOptions(false);string drive=Path.GetPathRoot(Path.GetFullPath(Preferences.DataDir));if(new DriveInfo(drive).AvailableFreeSpace<Math.Max(600,options.StopFreeMb+200)*1024L*1024){autoReplayAfter=DateTime.UtcNow.AddSeconds(30);return;}await Recorder.StartReplay(options);if(!prefs.ReplayAlwaysOn)await Recorder.StopReplay();autoReplayFailures=0;Save();}catch(Exception ex){autoReplayFailures++;autoReplayAfter=DateTime.UtcNow.AddSeconds(Math.Min(120,10*autoReplayFailures));if(autoReplayFailures==1)ShowClipToast("Histórico indisponível",ex.Message);}finally{autoReplayStarting=false;videoBusy=false;captureAction="";UpdateVideo();}}
    async void SetAlwaysReplay(bool enabled){if(sharedOwner!=null){sharedOwner.SetAlwaysReplay(enabled);return;}prefs.ReplayAlwaysOn=enabled;Save();if(enabled){autoReplayAfter=DateTime.MinValue;EnsureAutoReplay();}else if(!videoBusy&&recorder!=null&&recorder.Replaying){videoBusy=true;try{await recorder.StopReplay();}catch(Exception ex){ShowClipToast("Histórico",ex.Message);}finally{videoBusy=false;UpdateVideo();}}}
    async void RestartReplayHistory(){if(sharedOwner!=null){sharedOwner.RestartReplayHistory();return;}if(videoBusy||recorder==null||!recorder.Replaying)return;videoBusy=true;try{await recorder.StopReplay();}catch(Exception ex){ShowClipToast("Histórico",ex.Message);}finally{videoBusy=false;autoReplayAfter=DateTime.MinValue;EnsureAutoReplay();UpdateVideo();}}
    void CaptureWidgetPage(){
        title.Text="Capturas";captureWidgetRoot=new StackPanel();
        var buttons=new UniformGrid{Columns=3,Margin=new Thickness(-3,0,-3,12)};
        var print=CaptureSquare("screenshot","Tirar print • "+prefs.PrintKey,TakeScreenshot);SetCaptureAction(print,"screenshot","Print","#C8C8D5");
        widgetClip=CaptureSquare("replay","Salvar últimos "+prefs.QuickClipSeconds+" s",()=>SaveReplay(prefs.QuickClipSeconds));
        widgetRecord=CaptureSquare("recording","Iniciar / parar gravação • "+prefs.RecordKey,ToggleRecording);
        foreach(var button in new[]{print,widgetClip,widgetRecord})buttons.Children.Add(button);
        captureWidgetRoot.Children.Add(buttons);
        // Keep clip length in the clip action's context menu instead of an extra footer.
        var menu=new ContextMenu();foreach(System.Collections.DictionaryEntry entry in window.Resources)menu.Resources[entry.Key]=entry.Value;
        menu.Style=(Style)window.FindResource(typeof(ContextMenu));
        foreach(int seconds in new[]{30,60,120}){int value=seconds;var item=new MenuItem{Header="Salvar últimos "+seconds+" s"};item.Click+=(o,e)=>{prefs.QuickClipSeconds=value;if(prefs.Video.ReplaySeconds<value){prefs.Video.ReplaySeconds=value;Save();RestartReplayHistory();}else Save();UpdateCaptureWidget();};menu.Items.Add(item);}
        widgetClip.ContextMenu=menu;
        var gallery=UI.Button("Ver galeria",()=>{if(sharedOwner!=null)sharedOwner.OpenWidget("gallery");else BuildPage("gallery");});
        gallery.MinHeight=36;gallery.Margin=new Thickness(0);gallery.Padding=new Thickness(10,7,10,7);gallery.Background=UI.Brush("#2D3038");gallery.BorderBrush=UI.Brush("#424651");
        var galleryRow=new Grid();galleryRow.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(25)});galleryRow.ColumnDefinitions.Add(new ColumnDefinition());galleryRow.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(18)});
        galleryRow.Children.Add(UI.Icon("gallery","#AABFE5",17));var label=UI.Text("Ver galeria",12,"#DADFEA");Grid.SetColumn(label,1);galleryRow.Children.Add(label);var arrow=UI.Text("→",14,"#AABFE5");Grid.SetColumn(arrow,2);galleryRow.Children.Add(arrow);gallery.Content=galleryRow;gallery.HorizontalContentAlignment=HorizontalAlignment.Stretch;
        captureWidgetRoot.Children.Add(gallery);body.Children.Add(captureWidgetRoot);UpdateCaptureWidget();
    }
    Button CaptureSquare(string icon,string label,Action action){var button=UI.IconButton(icon,label,action);button.Width=double.NaN;button.Height=64;button.Margin=new Thickness(3,0,3,0);button.Background=UI.Brush("#2C2C33");button.BorderBrush=UI.Brush("#3D3D48");return button;}
    void SetCaptureAction(Button button,string icon,string label,string color){var glyph=UI.Icon(icon,color,21);var text=UI.Text(label,11,color);text.TextWrapping=TextWrapping.NoWrap;text.HorizontalAlignment=HorizontalAlignment.Center;text.Margin=new Thickness(0,6,0,0);button.Content=UI.Stack(glyph,text);}
    void UpdateCaptureWidget(){
        if(captureWidgetRoot==null||page!="recording")return;var owner=sharedOwner??this;bool recording=owner.recorder!=null&&owner.recorder.Recording,replaying=owner.recorder!=null&&owner.recorder.Replaying;
        widgetRecord.Background=UI.Brush(recording?"#5B2939":"#382A34");widgetRecord.BorderBrush=UI.Brush(recording?"#C65A72":"#6C3E51");
        UIElement recordGlyph=recording?(UIElement)new Border{Width=16,Height=16,CornerRadius=new CornerRadius(3),Background=UI.Brush("#FF9DAF")}:(UIElement)new System.Windows.Shapes.Ellipse{Width=18,Height=18,Fill=UI.Brush("#F18DA3")};
        var recordLabel=UI.Text(recording?"Parar":"Gravar",11,"#F6B5C3");recordLabel.Margin=new Thickness(0,7,0,0);recordLabel.HorizontalAlignment=HorizontalAlignment.Center;
        var glyphHost=new Grid{Height=21};glyphHost.Children.Add(recordGlyph);widgetRecord.Content=UI.Stack(glyphHost,recordLabel);widgetRecord.IsEnabled=!owner.videoBusy;
        widgetRecord.ToolTip=recording?"Parar e salvar • "+owner.recorder.RecordingElapsed.ToString(@"hh\:mm\:ss"):"Iniciar gravação • "+prefs.RecordKey;
        widgetClip.IsEnabled=replaying&&owner.recorder.AvailableSeconds()>0&&!owner.videoBusy;SetCaptureAction(widgetClip,"replay",prefs.QuickClipSeconds+" s ⌄","#ABC4EE");
        widgetClip.ToolTip="Salvar os "+prefs.QuickClipSeconds+" s anteriores • botão direito para alterar duração"+(replaying?"\nHistórico disponível: "+owner.recorder.AvailableSeconds()+" s":"\nPreparando histórico…");
    }
    void UpdateWidgetPin(DesktopController child){if(prefs.Widgets==null||!prefs.Widgets.ContainsKey(child.widgetId))return;bool pinned=prefs.Widgets[child.widgetId].Pinned;child.widgetPin.Content=child.widgetId=="recording"?(object)UI.Icon("pin",pinned?"#86AEFF":"#C6C6D2",19):pinned?"Fixado":"Fixar";child.widgetPin.ToolTip=pinned?"Desafixar janela":"Fixar janela";}
}
}
