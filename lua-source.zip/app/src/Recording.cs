﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NAudio.Wave;
using Forms=System.Windows.Forms;
namespace LuaMonitor {
public class RecordingOptions {
    public int Screen,Fps=30,Height=1080,ReplaySeconds=60,Bitrate=8;
    public bool Audio=true,Cursor=true,Microphone=false;
    public string OutputDevice="",InputDevice="",Engine="Automático";public double SystemGain=1,MicGain=1;public int StopFreeMb=500;
    public string Folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),"LUA");
}
// Owns only LUA child processes. Closing the job prevents orphaned desktop capture after a crash.
sealed class CaptureJob:IDisposable {
    IntPtr handle;
    public CaptureJob(){handle=CreateJobObject(IntPtr.Zero,null);if(handle==IntPtr.Zero)throw new System.ComponentModel.Win32Exception();var info=new Extended();info.Basic.LimitFlags=0x2000;int size=Marshal.SizeOf(info);IntPtr block=Marshal.AllocHGlobal(size);try{Marshal.StructureToPtr(info,block,false);if(!SetInformationJobObject(handle,9,block,(uint)size))throw new System.ComponentModel.Win32Exception();}finally{Marshal.FreeHGlobal(block);}}
    public void Add(Process process){if(!AssignProcessToJobObject(handle,process.Handle))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(),"Não foi possível proteger o processo de captura.");}
    public void Dispose(){if(handle!=IntPtr.Zero){CloseHandle(handle);handle=IntPtr.Zero;}}
    [StructLayout(LayoutKind.Sequential)]struct Basic {public long PerProcess,PerJob;public uint LimitFlags;public UIntPtr MinWorking,MaxWorking;public uint ActiveLimit;public UIntPtr Affinity;public uint Priority,Scheduling;}
    [StructLayout(LayoutKind.Sequential)]struct Io {public ulong ReadOps,WriteOps,OtherOps,ReadBytes,WriteBytes,OtherBytes;}
    [StructLayout(LayoutKind.Sequential)]struct Extended {public Basic Basic;public Io Io;public UIntPtr ProcessMemory,JobMemory,PeakProcessMemory,PeakJobMemory;}
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateJobObject(IntPtr security,string name);
    [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetInformationJobObject(IntPtr job,int type,IntPtr info,uint size);
    [DllImport("kernel32.dll",SetLastError=true)]static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
    [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr handle);
}
sealed class CaptureAudio:IDisposable {
    NamedPipeServerStream pipe;NAudio.CoreAudioApi.WasapiCapture capture,microphone;NAudio.CoreAudioApi.MMDevice outputDevice,inputDevice;BufferedWaveProvider buffer,micBuffer;RecordingOptions options;CancellationTokenSource cancel=new CancellationTokenSource();Task pump;public readonly string Name="LuaAudio_"+Guid.NewGuid().ToString("N");public string Error="";
    public CaptureAudio(RecordingOptions config){options=config;
        var security=new PipeSecurity();security.SetAccessRuleProtection(true,false);security.AddAccessRule(new PipeAccessRule(WindowsIdentity.GetCurrent().User,PipeAccessRights.FullControl,AccessControlType.Allow));
        pipe=new NamedPipeServerStream(Name,PipeDirection.Out,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous,65536,65536,security);
        try{if(options.Audio){outputDevice=AudioDevices.Get(options.OutputDevice,false);capture=new WasapiLoopbackCapture(outputDevice);capture.WaveFormat=new WaveFormat(48000,16,2);}if(options.Microphone){inputDevice=AudioDevices.Get(options.InputDevice,true);microphone=new NAudio.CoreAudioApi.WasapiCapture(inputDevice);microphone.WaveFormat=new WaveFormat(48000,16,2);}}catch{pipe.Dispose();if(capture!=null)capture.Dispose();if(microphone!=null)microphone.Dispose();if(outputDevice!=null)outputDevice.Dispose();if(inputDevice!=null)inputDevice.Dispose();cancel.Dispose();throw;}
        buffer=new BufferedWaveProvider(new WaveFormat(48000,16,2)){BufferDuration=TimeSpan.FromSeconds(1),DiscardOnBufferOverflow=true,ReadFully=true};
        if(capture!=null)capture.DataAvailable+=(s,e)=>{if(buffer.BufferedDuration.TotalMilliseconds>250)buffer.ClearBuffer();buffer.AddSamples(e.Buffer,0,e.BytesRecorded);};
        if(capture!=null)capture.RecordingStopped+=(s,e)=>{if(e.Exception!=null)Error=e.Exception.Message;};
        micBuffer=new BufferedWaveProvider(new WaveFormat(48000,16,2)){BufferDuration=TimeSpan.FromSeconds(1),DiscardOnBufferOverflow=true,ReadFully=true};if(microphone!=null){microphone.DataAvailable+=(s,e)=>{if(micBuffer.BufferedDuration.TotalMilliseconds>250)micBuffer.ClearBuffer();micBuffer.AddSamples(e.Buffer,0,e.BytesRecorded);};microphone.RecordingStopped+=(s,e)=>{if(e.Exception!=null)Error="Microfone: "+e.Exception.Message;};}
        pump=Task.Factory.StartNew(()=>{try{pipe.WaitForConnection();if(cancel.IsCancellationRequested)return;if(capture!=null)capture.StartRecording();if(microphone!=null)microphone.StartRecording();var clock=Stopwatch.StartNew();byte[] bytes=new byte[3840],mic=new byte[3840];long blocks=0;while(!cancel.IsCancellationRequested){double due=blocks*20-clock.Elapsed.TotalMilliseconds;if(due>0){cancel.Token.WaitHandle.WaitOne((int)Math.Min(20,due));continue;}buffer.Read(bytes,0,bytes.Length);micBuffer.Read(mic,0,mic.Length);for(int i=0;i<bytes.Length;i+=2){short mixed=AudioDevices.Mix(BitConverter.ToInt16(bytes,i),BitConverter.ToInt16(mic,i),options.SystemGain,options.MicGain);bytes[i]=(byte)(mixed&255);bytes[i+1]=(byte)((mixed>>8)&255);}pipe.Write(bytes,0,bytes.Length);blocks++;}}catch(Exception ex){if(!cancel.IsCancellationRequested)Error=ex.Message;}},TaskCreationOptions.LongRunning);
    }
    public void Dispose(){cancel.Cancel();try{pipe.Dispose();}catch{}try{if(pump!=null)pump.Wait(2000);}catch{}try{if(capture!=null)capture.Dispose();if(microphone!=null)microphone.Dispose();if(outputDevice!=null)outputDevice.Dispose();if(inputDevice!=null)inputDevice.Dispose();}catch{}cancel.Dispose();}
}
sealed class VideoSession:IDisposable {
    public Process Process;public CaptureAudio Audio;public string Folder,File,Output;public DateTime Started=DateTime.UtcNow;public long Frames;public string Error="";public int Seconds,Screen,StopFreeMb;public string Drive;
    public bool Running {get{try{return Process!=null&&!Process.HasExited;}catch{return false;}}}
    public async Task Stop(){if(Process==null)return;try{if(!Process.HasExited){Process.StandardInput.WriteLine("q");Process.StandardInput.Flush();if(!await Task.Run(()=>Process.WaitForExit(8000))){Process.Kill();await Task.Run(()=>Process.WaitForExit(2000));}}}catch{}finally{if(Audio!=null){Audio.Dispose();Audio=null;}}}
    public void Dispose(){if(Audio!=null)Audio.Dispose();if(Process!=null)Process.Dispose();}
}
public sealed class ScreenRecorder:IDisposable {
    public static readonly string Tools=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"tools","video");
    CaptureJob job=new CaptureJob();VideoSession recording,replay;string encoder;public string CaptureEngine="",Phase="Parada";bool saving,disposed,stopping;
    public int LastClipSeconds;public DateTime LastClipCutoffUtc,LastClipNewestSegmentUtc;public string Status="Captura desligada",LastFile="";public bool Recording {get{return recording!=null&&recording.Running;}}public bool Replaying {get{return replay!=null&&replay.Running;}}public bool Active {get{return Recording||Replaying;}}
    public TimeSpan RecordingElapsed {get{return recording==null?TimeSpan.Zero:DateTime.UtcNow-recording.Started;}}
    public bool LowSpace(Func<string,long> available=null){foreach(var session in new[]{recording,replay})if(session!=null&&session.Running){try{long bytes=available==null?new DriveInfo(session.Drive).AvailableFreeSpace:available(session.Drive);if(bytes<Math.Max(100,session.StopFreeMb)*1024L*1024)return true;}catch{}}return false;}
    public int ActiveScreen {get{return Recording?recording.Screen:replay==null?0:replay.Screen;}}
    public string Encoder {get{return encoder??"Automático • aceleração por GPU quando disponível";}}
    public string Detail {get{return (Recording?"● Gravando • "+(DateTime.UtcNow-recording.Started).ToString(@"hh\:mm\:ss"):"Gravação parada")+"\n"+(Replaying?"● Buffer ativo • "+AvailableSeconds()+" s disponíveis":"Buffer desligado")+(saving?"\nSalvando clipe…":"");}}
    public int AvailableSeconds(){if(replay==null)return 0;try{return Math.Min(replay.Seconds,Math.Max(0,Directory.GetFiles(replay.Folder,"part*.mkv").Length-1));}catch{return 0;}}
    public static string Quote(string value){if(value.IndexOf('"')>=0||value.IndexOf('\r')>=0||value.IndexOf('\n')>=0)throw new ArgumentException("Caminho inválido");return "\""+value.TrimEnd('\\')+"\"";}
    Process Launch(string args,string directory=null){var process=new Process{StartInfo=new ProcessStartInfo(Path.Combine(Tools,"ffmpeg.exe"),"-hide_banner -loglevel warning -y "+args){UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true,WorkingDirectory=directory??Tools}};if(!process.Start())throw new IOException("Não foi possível iniciar o gravador.");try{job.Add(process);}catch{try{process.Kill();}catch{}throw;}return process;}
    async Task<string> DetectEncoder(){
        if(encoder!=null)return encoder;
        foreach(string candidate in new[]{"h264_nvenc","h264_amf","h264_qsv","h264_mf","libopenh264"}){if(stopping)throw new OperationCanceledException();using(var process=Launch("-f lavfi -i color=c=black:s=640x360:r=30 -t 0.12 -an -c:v "+candidate+" -b:v 2M -f null -")){string error="";process.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)error=e.Data;};process.BeginErrorReadLine();process.BeginOutputReadLine();bool done=await Task.Run(()=>process.WaitForExit(12000));if(!done){process.Kill();continue;}if(process.ExitCode==0){encoder=candidate;return encoder;}}}
        throw new IOException("Nenhum codificador H.264 disponível. Atualize o driver de vídeo.");
    }
    async Task<VideoSession> Start(RecordingOptions options,bool ring){
        if(stopping)throw new OperationCanceledException();if(disposed)throw new ObjectDisposedException("ScreenRecorder");if(!File.Exists(Path.Combine(Tools,"ffmpeg.exe")))throw new FileNotFoundException("Extraia a pasta completa do LUA, incluindo tools/video.");
        string selected=await DetectEncoder();if(stopping)throw new OperationCanceledException();Directory.CreateDirectory(options.Folder);var drive=new DriveInfo(Path.GetPathRoot(Path.GetFullPath(options.Folder)));if(drive.AvailableFreeSpace<Math.Max(600,options.StopFreeMb+200)*1024L*1024)throw new IOException("O espaço livre está abaixo da reserva necessária. Libere espaço ou ajuste a proteção.");
        var session=new VideoSession{Screen=options.Screen,Drive=drive.Name,StopFreeMb=options.StopFreeMb,Seconds=Math.Max(30,Math.Min(120,options.ReplaySeconds))};string id=DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss")+"_"+Guid.NewGuid().ToString("N").Substring(0,6);
        session.Folder=ring?Path.Combine(Preferences.DataDir,"replay","session_"+id):options.Folder;Directory.CreateDirectory(session.Folder);
        session.Drive=Path.GetPathRoot(Path.GetFullPath(session.Folder));if(new DriveInfo(session.Drive).AvailableFreeSpace<Math.Max(600,options.StopFreeMb+200)*1024L*1024)throw new IOException("O disco do buffer está sem a reserva necessária.");
        session.File=ring?null:Path.Combine(session.Folder,"LUA_"+id+".mkv");session.Output=ring?null:Path.ChangeExtension(session.File,".mp4");
        Exception failure=null;try{
            int fps=options.Fps==60?60:30;var screen=Forms.Screen.AllScreens[Math.Max(0,Math.Min(Forms.Screen.AllScreens.Length-1,options.Screen))].Bounds;
            bool dxgi=options.Engine=="Duplicação DXGI"||(options.Engine=="Automático"&&Forms.Screen.AllScreens.Length==1);if(dxgi&&Forms.Screen.AllScreens.Length>1)throw new IOException("Para vários monitores, escolha Captura compatível até confirmar a ordem das saídas DXGI.");CaptureEngine=dxgi?"Duplicação DXGI":"Captura compatível";string args=dxgi?"-thread_queue_size 8 -f lavfi -i ddagrab=output_idx=0:framerate="+fps+":draw_mouse="+(options.Cursor?1:0)+" ":"-thread_queue_size 8 -f gdigrab -framerate "+fps+" -offset_x "+screen.X+" -offset_y "+screen.Y+" -video_size "+screen.Width+"x"+screen.Height+" -draw_mouse "+(options.Cursor?1:0)+" -i desktop ";
            if(options.Audio||options.Microphone){session.Audio=new CaptureAudio(options);args+="-thread_queue_size 64 -f s16le -ar 48000 -ac 2 -i "+Quote(@"\\.\pipe\"+session.Audio.Name)+" -map 0:v:0 -map 1:a:0 -c:a aac -b:a 160k -af aresample=async=1:first_pts=0 ";}else args+="-map 0:v:0 -an ";
            int height=options.Height==720?720:options.Height==1080?1080:screen.Height;height=Math.Min(height,screen.Height);height-=height%2;
            args+="-vf "+Quote((dxgi?"hwdownload,format=bgra,":"")+"scale=-2:"+height+":flags=fast_bilinear,format=yuv420p")+" -c:v "+selected+" -b:v "+Math.Max(2,Math.Min(30,options.Bitrate))+"M -maxrate "+Math.Max(2,Math.Min(30,options.Bitrate))+"M -bufsize "+Math.Max(4,Math.Min(60,options.Bitrate*2))+"M -g "+fps+" -force_key_frames "+Quote("expr:gte(t,n_forced*1)")+" -fps_mode cfr -r "+fps+" -progress pipe:1 -stats_period 0.5 ";
            if(selected=="h264_nvenc")args+="-preset p3 -tune ll ";
            args+=ring?"-f segment -segment_time 1 -reset_timestamps 1 -segment_wrap "+(session.Seconds+8)+" -segment_format matroska "+Quote(Path.Combine(session.Folder,"part%03d.mkv")):"-f matroska "+Quote(session.File);
            session.Process=Launch(args);session.Process.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)session.Error=e.Data;};session.Process.OutputDataReceived+=(s,e)=>{long frames;if(e.Data!=null&&e.Data.StartsWith("frame=")&&long.TryParse(e.Data.Substring(6),out frames))Interlocked.Exchange(ref session.Frames,frames);};session.Process.BeginErrorReadLine();session.Process.BeginOutputReadLine();
            for(int n=0;n<60&&session.Running&&Interlocked.Read(ref session.Frames)==0;n++){if(stopping)throw new OperationCanceledException();await Task.Delay(100);}
            if(!session.Running||Interlocked.Read(ref session.Frames)==0)throw new IOException("A captura não iniciou. "+session.Error+(session.Audio!=null&&session.Audio.Error!=""?" Áudio: "+session.Audio.Error:""));
            return session;
        }catch(Exception ex){failure=ex;}await session.Stop();session.Dispose();if(ring)RemoveOwnedSession(session.Folder);throw failure;
    }
    async Task<VideoSession> StartCompatible(RecordingOptions options,bool ring){try{return await Start(options,ring);}catch(Exception ex){if(options.Engine!="Automático")throw;Status="Tentando captura compatível após: "+ex.Message;}var fallback=CaptureProfiles.Clone(options);fallback.Engine="Captura compatível";return await Start(fallback,ring);}
    public async Task StartRecording(RecordingOptions options){if(Recording)return;if(recording!=null){await StopRecording();}Phase="Iniciando gravação";recording=await StartCompatible(options,false);Phase="Gravando";Status="Gravação iniciada • "+encoder;}
    public async Task StartReplay(RecordingOptions options){if(Replaying)return;if(replay!=null)await StopReplay();Phase="Iniciando buffer";replay=await StartCompatible(options,true);Phase="Buffer ativo";Status="Buffer ativado • últimos "+replay.Seconds+" segundos";}
    async Task Convert(string args,string directory=null){using(var process=Launch(args,directory)){string error="";process.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)error=e.Data;};process.BeginErrorReadLine();process.BeginOutputReadLine();bool done=await Task.Run(()=>process.WaitForExit(60000));if(!done){process.Kill();throw new IOException("O vídeo demorou demais para finalizar.");}if(process.ExitCode!=0)throw new IOException(error);}}
    public async Task StopRecording(){var current=recording;recording=null;Phase="Finalizando vídeo";if(current==null)return;try{await current.Stop();if(File.Exists(current.File)&&new FileInfo(current.File).Length>1024){if(new DriveInfo(Path.GetPathRoot(current.File)).AvailableFreeSpace<new FileInfo(current.File).Length+50L*1024*1024){LastFile=current.File;Status="Vídeo salvo em MKV para preservar o espaço livre.";return;}await Convert("-i "+Quote(current.File)+" -map 0 -c copy -movflags +faststart "+Quote(current.Output));LastFile=current.Output;File.Delete(current.File);Status="Vídeo salvo • "+Path.GetFileName(LastFile);}else Status="A captura terminou sem vídeo válido. "+current.Error;}catch(Exception ex){LastFile=current.File;Status="Vídeo original preservado em MKV. "+ex.Message;throw;}finally{current.Dispose();Phase=Replaying?"Buffer ativo":"Parada";}}
    public async Task StopReplay(){var current=replay;replay=null;if(current==null)return;await current.Stop();current.Dispose();RemoveOwnedSession(current.Folder);Status="Buffer desligado";}
    public async Task<string> SaveClip(int seconds,string outputFolder){
        if(!Replaying)throw new InvalidOperationException("Ative o buffer antes do momento que deseja salvar.");if(saving)throw new InvalidOperationException("Um clipe já está sendo salvo.");if(seconds>replay.Seconds)throw new InvalidOperationException("Aumente a duração do buffer para salvar esse período.");saving=true;Phase="Salvando clipe";
        string temp=Path.Combine(Preferences.DataDir,"replay","session_export_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temp);
        try{
            LastClipCutoffUtc=DateTime.UtcNow;var files=new DirectoryInfo(replay.Folder).GetFiles("part*.mkv").Where(f=>f.LastWriteTimeUtc<=LastClipCutoffUtc).OrderBy(f=>f.LastWriteTimeUtc).ThenBy(f=>f.Name,StringComparer.Ordinal).ToList();if(files.Count<2)throw new IOException("O buffer ainda está começando. Aguarde alguns segundos.");files.RemoveAt(files.Count-1);files=files.Skip(Math.Max(0,files.Count-seconds)).ToList();LastClipNewestSegmentUtc=files.Last().LastWriteTimeUtc;var list=new List<string>();long required=files.Sum(f=>f.Length);string tempDrive=Path.GetPathRoot(temp),outputDrive=Path.GetPathRoot(Path.GetFullPath(outputFolder));if(new DriveInfo(tempDrive).AvailableFreeSpace<required*(tempDrive.Equals(outputDrive,StringComparison.OrdinalIgnoreCase)?2:1)+50L*1024*1024||new DriveInfo(outputDrive).AvailableFreeSpace<required+50L*1024*1024)throw new IOException("Libere espaço antes de exportar o clipe. O buffer atual foi mantido.");
            await Task.Run(()=>{foreach(var file in files){string name="clip"+(list.Count/2).ToString("000")+".mkv",target=Path.Combine(temp,name);DateTime time=file.LastWriteTimeUtc;long length=file.Length;using(var input=new FileStream(file.FullName,FileMode.Open,FileAccess.Read,FileShare.Read))using(var output=new FileStream(target,FileMode.CreateNew,FileAccess.Write))input.CopyTo(output);file.Refresh();if(file.LastWriteTimeUtc!=time||file.Length!=length)throw new IOException("O buffer mudou enquanto era copiado. Tente novamente.");list.Add("file '"+name+"'");list.Add("duration 1.000000");}});
            File.WriteAllLines(Path.Combine(temp,"list.ffconcat"),new[]{"ffconcat version 1.0"}.Concat(list),new UTF8Encoding(false));Directory.CreateDirectory(outputFolder);string result=Path.Combine(outputFolder,"LUA_clipe_"+DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss")+"_"+Guid.NewGuid().ToString("N").Substring(0,4)+".mp4");
            await Convert("-f concat -safe 1 -i list.ffconcat -map 0 -c copy -t "+files.Count+" -movflags +faststart "+Quote(result),temp);LastClipSeconds=files.Count;LastFile=result;Status="Clipe salvo • cerca de "+files.Count+" s • "+Path.GetFileName(result);return result;
        }finally{saving=false;Phase=Recording?"Gravando":Replaying?"Buffer ativo":"Parada";RemoveOwnedSession(temp);}
    }
    static void RemoveOwnedSession(string folder){try{string root=Path.GetFullPath(Path.Combine(Preferences.DataDir,"replay"))+Path.DirectorySeparatorChar;string full=Path.GetFullPath(folder);if(!full.StartsWith(root,StringComparison.OrdinalIgnoreCase)||!Path.GetFileName(full).StartsWith("session_",StringComparison.Ordinal)||!Directory.Exists(full)||(File.GetAttributes(full)&FileAttributes.ReparsePoint)!=0)return;foreach(string file in Directory.GetFiles(full)){if((File.GetAttributes(file)&FileAttributes.ReparsePoint)!=0)continue;File.Delete(file);}if(!Directory.EnumerateFileSystemEntries(full).Any())Directory.Delete(full);}catch{}}
    public void CancelStart(){stopping=true;}
    public async Task Shutdown(){stopping=true;Exception failure=null;try{await StopRecording();}catch(Exception ex){failure=ex;}await StopReplay();if(failure!=null)throw failure;}
    public void Dispose(){if(disposed)return;disposed=true;job.Dispose();if(recording!=null)recording.Dispose();if(replay!=null)replay.Dispose();}
}
}
