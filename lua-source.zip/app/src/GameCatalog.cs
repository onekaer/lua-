﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Xml.Linq;
using Microsoft.Win32;

namespace LuaMonitor {
public class GameEntry {
    public bool TrackingOnly;
    public string Name,Platform,Folder,Executable,SteamId,SteamRoot,StoreId,StoreFamily,LocalCoverPath,CoverPath,CoverSource,SizeSource="Ainda não medido";
    public string UninstallCommand;public long? Bytes; public int Skipped;
}
public class GameLibrary {
    public List<GameEntry> Games=new List<GameEntry>();public List<string> Notices=new List<string>();
}
public static class GameCatalog {
    public static Dictionary<string,string> VdfValues(string text){
        var values=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        foreach(Match m in Regex.Matches(text,"\"((?:\\\\.|[^\"\\\\])*)\"\\s*\"((?:\\\\.|[^\"\\\\])*)\"")){values[m.Groups[1].Value]=m.Groups[2].Value.Replace("\\\\","\\").Replace("\\\"","\"");}return values;
    }
    static void Add(GameLibrary library,GameEntry game){
        try{if(Regex.IsMatch(game.Name??"","(?i)^Steamworks Common Redistributables$|^Minecraft Launcher$"))return;if(string.IsNullOrWhiteSpace(game.Folder)||!Directory.Exists(game.Folder))return;game.Folder=Path.GetFullPath(game.Folder).TrimEnd('\\');if((File.GetAttributes(game.Folder)&FileAttributes.ReparsePoint)!=0)return;
            var old=library.Games.FirstOrDefault(g=>string.Equals(g.Folder,game.Folder,StringComparison.OrdinalIgnoreCase));if(old!=null){if(string.IsNullOrEmpty(old.UninstallCommand))old.UninstallCommand=game.UninstallCommand;if(!old.Bytes.HasValue&&game.Bytes.HasValue){old.Bytes=game.Bytes;old.SizeSource=game.SizeSource;}return;}
            if(string.IsNullOrWhiteSpace(game.Name))game.Name=Path.GetFileName(game.Folder);library.Games.Add(game);
        }catch{}
    }
    static string RegistryValue(RegistryHive hive,RegistryView view,string key,string value){try{using(var root=RegistryKey.OpenBaseKey(hive,view))using(var item=root.OpenSubKey(key)){return item==null?null:Convert.ToString(item.GetValue(value));}}catch{return null;}}
    public static GameLibrary Discover(IEnumerable<string> custom){
        var result=new GameLibrary();var steamRoots=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        string steam=RegistryValue(RegistryHive.CurrentUser,RegistryView.Default,@"Software\Valve\Steam","SteamPath");if(!string.IsNullOrWhiteSpace(steam))steamRoots.Add(steam);
        steam=RegistryValue(RegistryHive.LocalMachine,RegistryView.Registry32,@"SOFTWARE\Valve\Steam","InstallPath");if(!string.IsNullOrWhiteSpace(steam))steamRoots.Add(steam);
        steamRoots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Steam"));
        foreach(string initial in steamRoots.ToArray()){
            string libraries=Path.Combine(initial,"steamapps","libraryfolders.vdf");try{if(File.Exists(libraries)){string text=File.ReadAllText(libraries);foreach(Match m in Regex.Matches(text,"\"path\"\\s*\"((?:\\\\.|[^\"\\\\])*)\""))steamRoots.Add(m.Groups[1].Value.Replace("\\\\","\\"));foreach(var pair in VdfValues(text))if(Regex.IsMatch(pair.Key,@"^\d+$")&&Directory.Exists(pair.Value))steamRoots.Add(pair.Value);}}catch(Exception ex){result.Notices.Add("Steam: "+ex.Message);}
        }
        foreach(string root in steamRoots){try{string apps=Path.Combine(root,"steamapps");if(!Directory.Exists(apps))continue;foreach(string manifest in Directory.EnumerateFiles(apps,"appmanifest_*.acf")){try{var v=VdfValues(File.ReadAllText(manifest));string name,dir,size,appId;v.TryGetValue("appid",out appId);if(!v.TryGetValue("installdir",out dir))continue;v.TryGetValue("name",out name);long bytes;long? length=v.TryGetValue("SizeOnDisk",out size)&&long.TryParse(size,out bytes)?(long?)bytes:null;Add(result,new GameEntry{Name=name,Platform="Steam",SteamId=appId,SteamRoot=steamRoots.FirstOrDefault(r=>Directory.Exists(Path.Combine(r,"appcache","librarycache"))),Folder=Path.Combine(apps,"common",dir),Bytes=length,SizeSource=length.HasValue?"Informado pela Steam":"Ainda não medido"});}catch{}}}catch(Exception ex){result.Notices.Add("Biblioteca Steam: "+ex.Message);}}
        string epic=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"Epic","EpicGamesLauncher","Data","Manifests");
        try{if(Directory.Exists(epic))foreach(string file in Directory.EnumerateFiles(epic,"*.item")){try{var d=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(file));string folder=Get(d,"InstallLocation"),name=Get(d,"DisplayName"),exe=Get(d,"LaunchExecutable");long bytes;long? size=long.TryParse(Get(d,"InstallSize"),out bytes)?(long?)bytes:null;Add(result,new GameEntry{Name=name,Folder=folder,Executable=string.IsNullOrWhiteSpace(exe)?null:Path.Combine(folder,exe),Platform="Epic Games",Bytes=size,SizeSource=size.HasValue?"Informado pelo launcher":"Ainda não medido"});}catch{}}}catch(Exception ex){result.Notices.Add("Epic: "+ex.Message);}
        foreach(var hive in new[]{RegistryHive.LocalMachine,RegistryHive.CurrentUser})foreach(var view in new[]{RegistryView.Registry64,RegistryView.Registry32}){
            try{using(var baseKey=RegistryKey.OpenBaseKey(hive,view))using(var games=baseKey.OpenSubKey(@"SOFTWARE\GOG.com\Games")){if(games!=null)foreach(string id in games.GetSubKeyNames())using(var key=games.OpenSubKey(id)){if(key!=null)Add(result,new GameEntry{Name=Convert.ToString(key.GetValue("gameName")),Folder=Convert.ToString(key.GetValue("path")),Executable=Convert.ToString(key.GetValue("exe")),Platform="GOG"});}}}catch{}
            try{using(var baseKey=RegistryKey.OpenBaseKey(hive,view))using(var uninstall=baseKey.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall")){if(uninstall!=null)foreach(string id in uninstall.GetSubKeyNames())using(var key=uninstall.OpenSubKey(id)){if(key==null)continue;string name=Convert.ToString(key.GetValue("DisplayName")),publisher=Convert.ToString(key.GetValue("Publisher")),folder=Convert.ToString(key.GetValue("InstallLocation"));string platform=publisher.IndexOf("Riot",StringComparison.OrdinalIgnoreCase)>=0?"Riot Games":publisher.IndexOf("Rockstar",StringComparison.OrdinalIgnoreCase)>=0?"Rockstar":publisher.IndexOf("Ubisoft",StringComparison.OrdinalIgnoreCase)>=0?"Ubisoft":publisher.IndexOf("Blizzard",StringComparison.OrdinalIgnoreCase)>=0?"Battle.net":publisher.IndexOf("Electronic Arts",StringComparison.OrdinalIgnoreCase)>=0?"EA":publisher.IndexOf("GOG",StringComparison.OrdinalIgnoreCase)>=0?"GOG":null;
                if(platform==null||Regex.IsMatch(name??"","(?i)launcher|connect|battle.net|galaxy|anti.?cheat|EA app|redistributable"))continue;Add(result,new GameEntry{Name=name,Platform=platform,Folder=folder,UninstallCommand=Convert.ToString(key.GetValue("UninstallString"))});}}}catch{}
        }
        try{string riot=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"Riot Games","RiotClientInstalls.json");if(File.Exists(riot)){var metadata=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(riot));object associated;if(metadata.TryGetValue("associated_client",out associated)){var directories=associated as Dictionary<string,object>;if(directories!=null)foreach(string folder in directories.Keys){if(folder.IndexOf("Riot Client",StringComparison.OrdinalIgnoreCase)>=0)continue;string name=folder.IndexOf("VALORANT",StringComparison.OrdinalIgnoreCase)>=0?"VALORANT":folder.IndexOf("League of Legends",StringComparison.OrdinalIgnoreCase)>=0?"League of Legends":Path.GetFileName(folder.TrimEnd('\\','/'));Add(result,new GameEntry{Name=name,Platform="Riot Games",Folder=folder});}}}}catch{}
        foreach(var drive in DriveInfo.GetDrives()){try{if(!drive.IsReady||drive.DriveType!=DriveType.Fixed)continue;string xbox=Path.Combine(drive.RootDirectory.FullName,"XboxGames");if(!Directory.Exists(xbox))continue;foreach(string game in Directory.EnumerateDirectories(xbox)){string config=Path.Combine(game,"Content","MicrosoftGame.config");if(!File.Exists(config))continue;try{var xml=XDocument.Load(config);var identity=xml.Descendants().FirstOrDefault(x=>x.Name.LocalName=="Identity");var name=xml.Descendants().FirstOrDefault(x=>x.Name.LocalName=="ShellVisuals");string label=name==null?null:(string)name.Attribute("DefaultDisplayName");if(string.IsNullOrWhiteSpace(label)||label.StartsWith("ms-resource:"))label=Path.GetFileName(game);var storeId=xml.Descendants().FirstOrDefault(x=>x.Name.LocalName=="StoreId");string identityName=identity==null?null:(string)identity.Attribute("Name");string art=name==null?null:(string)name.Attribute("SplashScreenImage");string actual=game;if(identityName=="Microsoft.MinecraftJavaEdition"){string java=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),".minecraft");if(Directory.Exists(java))actual=java;}
                Add(result,new GameEntry{Name=label,Platform="Xbox / Microsoft Store",Folder=actual,StoreId=storeId==null?null:storeId.Value,StoreFamily=identityName!=null&&identityName.StartsWith("Microsoft.",StringComparison.OrdinalIgnoreCase)?identityName+"_8wekyb3d8bbwe":null,LocalCoverPath=art==null?null:Path.Combine(game,"Content",art)});}catch{}}}catch(Exception ex){result.Notices.Add("Xbox: "+ex.Message);}}
        if(custom!=null)foreach(string folder in custom)Add(result,new GameEntry{Name=Path.GetFileName(folder.TrimEnd('\\')),Platform="Adicionado por você",Folder=folder});
        result.Games=result.Games.OrderBy(g=>g.Name,StringComparer.CurrentCultureIgnoreCase).ToList();return result;
    }
    static string Get(Dictionary<string,object> d,string key){object value;return d.TryGetValue(key,out value)&&value!=null?Convert.ToString(value):"";}
}
}
