using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace LuaMonitor {
public sealed partial class DesktopController {
    StackPanel librarySpotlight;
    string spotlightKey;

    Button LibraryButton(string label, Action click, bool primary = false, string glyph = null) {
        var button = UI.Button(label, click);
        button.Style = (Style)window.FindResource("PanelAction");
        button.Background = UI.Brush(primary ? UI.Violet : UI.ControlSurface);
        button.Foreground = UI.Brush(primary ? UI.PrimaryText : "#F2EFEF");
        button.BorderBrush = UI.Brush(primary ? UI.Violet : "#353535");
        button.MinHeight = 36;
        button.Padding = new Thickness(10, 5, 10, 5);
        button.Margin = new Thickness(0);
        if(glyph!=null) {
            var caption=(TextBlock)button.Content;
            button.Content = null;
            var icon=UI.Text(glyph,14,primary?UI.PrimaryText:"#D9CEE6");
            icon.FontFamily=new FontFamily("Segoe MDL2 Assets");
            icon.Margin=new Thickness(0,0,6,0);
            var line=new StackPanel { Orientation=Orientation.Horizontal };
            line.Children.Add(icon);line.Children.Add(caption);
            button.Content=line;
        }
        return button;
    }

    void AddGameHeader(string id) {
        var heading = UI.Text("Jogos", compact ? 23 : 31, "#F5F2FA", true);
        heading.Margin = new Thickness(0, 0, 10, 0);
        var actions = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var import = LibraryButton("Importar horas", () => ShowGameImportOptions(null), glyph:"\uE896");
        import.Margin = new Thickness(0, 0, 6, 0);
        actions.Children.Add(import);
        actions.Children.Add(LibraryButton("Adicionar jogo", ShowGameAddOptions, true, "\uE710"));
        var header = UI.Row(heading, actions);
        header.Margin = new Thickness(0, 0, 0, 8);
        header.SizeChanged += (sender, args) => {
            if (header.RowDefinitions.Count == 0) {
                header.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                header.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            }
            bool narrow = args.NewSize.Width < 365;
            Grid.SetColumn(actions, narrow ? 0 : 1);
            Grid.SetRow(actions, narrow ? 1 : 0);
            actions.HorizontalAlignment = narrow ? HorizontalAlignment.Left : HorizontalAlignment.Right;
            actions.Margin = narrow ? new Thickness(0, 8, 0, 0) : new Thickness(0);
        };
        body.Children.Add(header);

        var tabs = new StackPanel { Orientation = Orientation.Horizontal };
        foreach (var item in new[] { Tuple.Create("games", "Biblioteca"), Tuple.Create("sessions", "Sessões"), Tuple.Create("gaming", "FPS") }) {
            bool selected = item.Item1 == id;
            var tab = LibraryButton(item.Item2, () => BuildPage(item.Item1));
            tab.Background = Brushes.Transparent;
            tab.BorderBrush = Brushes.Transparent;
            tab.Foreground = UI.Brush(selected ? "#F5EAFF" : "#C6BBD2");
            tab.MinHeight = 37;
            var underline = new Border { Height = 2, Background = selected ? UI.Brush("#D3B9FC") : Brushes.Transparent,
                VerticalAlignment = VerticalAlignment.Bottom, IsHitTestVisible = false };
            var cell = new Grid { Margin = new Thickness(0, 0, 10, 0) };
            cell.Children.Add(tab);
            cell.Children.Add(underline);
            tabs.Children.Add(cell);
        }
        body.Children.Add(new Border {
            Child = tabs, BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = UI.Brush("#332D3A"), Margin = new Thickness(0, 0, 0, 14)
        });
    }

    void AddLibrarySpotlight() {
        librarySpotlight = new StackPanel();
        body.Children.Add(librarySpotlight);
        RenderLibrarySpotlight();
    }

    Grid LibraryToolbar() {
        var advanced = UI.Stack(UI.Label("Espaço ocupado"),
            UI.Choice(new[]{"Todos os tamanhos","Acima de 10 GB","Acima de 50 GB","Acima de 100 GB","Tamanho pendente"},
                gameSize, value => {gameSize=value;RenderGames();}),
            UI.Button("Atualizar biblioteca", async () => {await LoadGames(true);MeasureGames(false);}),
            UI.Inline(UI.Button("Recalcular tamanhos", () => MeasureGames(true)),
                UI.Button("Cancelar medição", () => {if(libraryCancel!=null)libraryCancel.Cancel();})));
        var search = UI.Search(gameSearch,"Buscar jogos", value => {gameSearch=value;RenderGames();}, advanced, 37);
        var searchFrame=(Border)search.Children[0];
        searchFrame.Background=UI.Brush(UI.Surface);
        searchFrame.BorderBrush=UI.Brush("#353535");
        foreach(var field in FindSearchFields(search))
            System.Windows.Automation.AutomationProperties.SetName(field,"Pesquisar jogos ou plataforma");

        var platform = UI.Choice(new[]{"Todas as plataformas","Steam","Epic Games","GOG","Xbox / Microsoft Store","EA",
            "Ubisoft","Battle.net","Riot Games","Rockstar","Executável local","Emulador","Adicionado por você","Outra"},
            gamePlatform, value => {gamePlatform=value;RenderGames();});
        var sort = UI.Choice(new[]{"Recentes","Mais jogados","Nome A–Z","Plataforma","Maior tamanho","Menor tamanho"},
            gameOrder, value => {gameOrder=value;RenderGames();});
        System.Windows.Automation.AutomationProperties.SetName(platform,"Filtrar plataforma");
        System.Windows.Automation.AutomationProperties.SetName(sort,"Ordenar biblioteca");
        platform.Width=162;
        sort.Width=106;
        foreach(var choice in new[]{platform,sort}){
            choice.MinWidth=0;
            choice.Height=37;
            choice.Margin=new Thickness(0,0,7,0);
        }

        var modes = new StackPanel { Orientation=Orientation.Horizontal };
        var tiles = UI.IconButton("grid","Visualizar em grade",()=>{prefs.GamesGrid=true;Save();BuildPage("games");});
        var list = UI.IconButton("list","Visualizar em lista",()=>{prefs.GamesGrid=false;Save();BuildPage("games");});
        foreach(var button in new[]{tiles,list}){
            button.Style=(Style)window.FindResource("PanelAction");
            button.Width=30;
            button.Height=30;
            button.MinHeight=0;
            button.Padding=new Thickness(0);
            button.BorderThickness=new Thickness(1);
            bool selected=(button==tiles)==prefs.GamesGrid;
            button.BorderBrush=Brushes.Transparent;
            button.Background=selected?UI.Brush("#352A44"):Brushes.Transparent;
            ((FluentIcon)button.Content).Tint=UI.Brush(selected?"#E3D2FF":"#B4ACBF");
            modes.Children.Add(button);
        }
        var switcher = new Border { Child=modes, Padding=new Thickness(2), Background=UI.Brush(UI.ControlSurface),
            BorderBrush=UI.Brush("#353535"), BorderThickness=new Thickness(1), CornerRadius=new CornerRadius(8) };
        var controls = new StackPanel { Orientation=Orientation.Horizontal, VerticalAlignment=VerticalAlignment.Top };
        controls.Children.Add(platform);controls.Children.Add(sort);controls.Children.Add(switcher);
        var toolbar = new Grid { Margin=new Thickness(0,0,0,10) };
        toolbar.ColumnDefinitions.Add(new ColumnDefinition());
        toolbar.ColumnDefinitions.Add(new ColumnDefinition { Width=GridLength.Auto });
        toolbar.RowDefinitions.Add(new RowDefinition { Height=GridLength.Auto });
        toolbar.RowDefinitions.Add(new RowDefinition { Height=GridLength.Auto });
        toolbar.Children.Add(search);toolbar.Children.Add(controls);
        Action<double> arrange = width => {
            bool narrow=width<550;
            Grid.SetColumnSpan(search,narrow?2:1);
            Grid.SetRow(controls,narrow?1:0);
            Grid.SetColumn(controls,narrow?0:1);
            Grid.SetColumnSpan(controls,narrow?2:1);
            controls.Margin=narrow?new Thickness(0,7,0,0):new Thickness(7,0,0,0);
            platform.Width=narrow?Math.Max(104,Math.Min(162,width-174)):162;
            sort.Width=narrow?96:106;
        };
        arrange(compact?340:650);
        toolbar.SizeChanged+=(sender,args)=>arrange(args.NewSize.Width);
        return toolbar;
    }

    void RenderLibrarySpotlight() {
        if (librarySpotlight == null) return;
        TrackedGame tracked;
        var last = LastGameSession(out tracked);
        var entry = tracked == null ? library.Games.FirstOrDefault(g => !string.IsNullOrEmpty(g.CoverPath))
            ?? library.Games.FirstOrDefault() : CatalogGame(tracked);
        if (entry == null) { librarySpotlight.Children.Clear(); spotlightKey = null; return; }
        bool active = tracked != null && Playtime.Active.ContainsKey(tracked.Id);
        string summary = entry.Platform + " · " + SessionDuration(TotalGameSeconds(entry)) + " jogadas";
        string key = entry.Name + "|" + entry.Folder + "|" + entry.CoverPath + "|" + (active ? "ativo" : summary);
        if (key == spotlightKey) return;
        spotlightKey = key;
        librarySpotlight.Children.Clear();

        var frame = new Grid();
        frame.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2, GridUnitType.Star) });
        frame.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(3, GridUnitType.Star) });
        var art = GameCovers.Image(entry.CoverPath, 960);
        if (art != null) {
            var backdrop = new Rectangle { Fill = new ImageBrush(art) { Stretch = Stretch.UniformToFill } };
            Grid.SetColumn(backdrop, 1);
            frame.Children.Add(backdrop);
        }
        var veil = new LinearGradientBrush { StartPoint = new Point(0, .5), EndPoint = new Point(1, .5) };
        veil.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString("#211A2B"), 0));
        veil.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString("#FA211A2B"), .38));
        veil.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString("#A8211A2B"), .62));
        veil.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString("#10211A2B"), 1));
        var wash = new Rectangle { Fill = veil };
        Grid.SetColumnSpan(wash, 2);
        frame.Children.Add(wash);

        var title = UI.Text(entry.Name, compact ? 22 : 29, "#FFFFFF", true);
        title.TextWrapping = TextWrapping.NoWrap;
        title.TextTrimming = TextTrimming.CharacterEllipsis;
        title.ToolTip = entry.Name;
        title.Margin = new Thickness(0, 4, 0, 2);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 10, 0, 0) };
        Action launch = GameLaunchAction(entry, tracked, last != null);
        if (launch != null) {
            var play = LibraryButton("Jogar", launch, true, "\uE768");
            play.Margin = new Thickness(0, 0, 6, 0);
            buttons.Children.Add(play);
        }
        buttons.Children.Add(LibraryButton("Ver detalhes", () => ShowGameDetails(entry)));
        var caption = UI.Stack(UI.Text(last == null ? "Em destaque" : "Continuar jogando", 11, "#DECCF5", true),
            title, UI.Text(active ? entry.Platform + " · Em jogo agora" : summary, 12, "#E1D7EC"), buttons);
        caption.Margin = new Thickness(16, 13, 14, 12);
        caption.VerticalAlignment = VerticalAlignment.Center;
        Grid.SetColumnSpan(caption, 2);
        frame.Children.Add(caption);

        var panel = new Border { Child = frame, CornerRadius = new CornerRadius(11), MinHeight = compact ? 147 : 174,
            Background = UI.Brush("#211A2B"), BorderBrush = UI.Brush("#45354F"), BorderThickness = new Thickness(1),
            Margin = new Thickness(0, 0, 0, 15) };
        frame.SizeChanged += (sender, args) => frame.Clip = new RectangleGeometry(new Rect(args.NewSize), 10, 10);
        librarySpotlight.Children.Add(panel);
    }
}
}
