using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using Forms = System.Windows.Forms;

namespace LuaMonitor {
public sealed partial class TaskbarWidget {
    static readonly string[] CardColors = {
        "#211E28", "#1C2427", "#1D2622", "#28231F", "#1D242A", "#26212B", "#272522",
        "#25212D", "#202731", "#1C2520", "#222632", "#24212C"
    };
    Slider volumeSlider;
    Button mute;
    TextBlock outputName, weatherDetail;
    bool updatingVolume;
    DateTime nextAudioRead, nextWeatherRead;
    WidgetCity requestedCity;
    string weatherSummary = "—";
    string weatherStatus;

    void ResetWidgetCards() {
        volumeSlider = null;
        mute = null;
        outputName = weatherDetail = null;
        nextAudioRead = DateTime.MinValue;
    }

    void AddWidgetRow(List<Border> cards) {
        if (cards.Count == 0) return;
        var row = new System.Windows.Controls.Primitives.UniformGrid { Rows = 1, Columns = cards.Count };
        foreach (var card in cards) row.Children.Add(card);
        detailRows.Children.Add(row);
        cards.Clear();
    }

    Border BuildWidgetCard(string metric, int index, string color) {
        var label = UI.Text(metric, 12, "#F5F3FA", true);
        var reading = UI.Text("—", metric == "Volume" ? 24 : index < 3 ? 21 : 15, color, true);
        bigValues[metric] = reading;
        var header = new StackPanel { Orientation = Orientation.Horizontal };
        var icon = new Border {
            Width = 21, Height = 21, CornerRadius = new CornerRadius(6),
            Background = UI.Brush("#26000000"), Child = UI.Icon(MetricIcons[index], color, 14),
            Margin = new Thickness(0, 0, 5, 0)
        };
        header.Children.Add(icon);
        header.Children.Add(label);
        bool wide = metric == "Volume" || metric == "Clima";
        var card = UI.Stack(wide ? (UIElement)UI.Row(header, reading) : header);
        if (!wide) card.Children.Add(reading);
        if (index < 3 || metric == "Disco" || metric == "Bateria") {
            var bar = new ProgressBar { Minimum = 0, Maximum = 100, Height = 4, Foreground = UI.Brush(color),
                Background = UI.Brush("#33FFFFFF"), Margin = new Thickness(0, 6, 0, 0) };
            bars.Add(metric, bar);
            card.Children.Add(bar);
        }
        if (metric == "Volume") {
            outputName = UI.Text("Saída padrão do Windows", 11, "#D0C4DB");
            outputName.TextWrapping = TextWrapping.NoWrap;
            outputName.TextTrimming = TextTrimming.CharacterEllipsis;
            card.Children.Add(outputName);
            volumeSlider = new Slider { Minimum = 0, Maximum = 100, SmallChange = 1, LargeChange = 5,
                IsMoveToPointEnabled = true, VerticalAlignment = VerticalAlignment.Center, IsEnabled = false };
            volumeSlider.SetResourceReference(StyleProperty, "WidgetVolumeSlider");
            AutomationProperties.SetName(volumeSlider, "Volume de saída");
            volumeSlider.ValueChanged += (sender, args) => {
                if (updatingVolume) return;
                SetAudioVolume(args.NewValue / 100, false);
            };
            mute = WidgetIconButton("volume", "Silenciar", () => SetAudioVolume(null, true));
            mute.Content = UI.Icon("volume", color, 17);
            mute.Margin = new Thickness(0, 0, 9, 0);
            mute.Background = UI.Brush("#362B45");
            mute.IsEnabled = false;
            var controls = new Grid { Margin = new Thickness(0, 7, 0, 2) };
            controls.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            controls.ColumnDefinitions.Add(new ColumnDefinition());
            controls.Children.Add(mute);
            Grid.SetColumn(volumeSlider, 1);
            controls.Children.Add(volumeSlider);
            card.Children.Add(controls);
        } else if (metric == "Clima") {
            weatherDetail = UI.Text("Escolha uma cidade em Editar widgets.", 12, "#CBD7E6");
            weatherDetail.ToolTip = "Fonte: Open-Meteo";
            card.Children.Add(weatherDetail);
        }
        return new Border { Tag = index, Child = card, Background = UI.Brush(CardColors[index]),
            CornerRadius = new CornerRadius(11), Padding = new Thickness(9, 6, 9, 7),
            Margin = new Thickness(2, 0, 2, 5) };
    }

    void UpdateOptionalWidgets() {
        if ((volumeSlider != null || smallValues.ContainsKey("Volume")) && DateTime.UtcNow >= nextAudioRead) ReadAudio();
        if (weatherDetail != null || smallValues.ContainsKey("Clima")) RefreshWeather();
        if (bigValues.ContainsKey("Bateria") || smallValues.ContainsKey("Bateria")) {
            var power = Forms.SystemInformation.PowerStatus;
            double percent = power.BatteryLifePercent * 100;
            var state = power.BatteryChargeStatus;
            bool available = state != Forms.BatteryChargeStatus.Unknown &&
                (state & Forms.BatteryChargeStatus.NoSystemBattery) == 0 && percent >= 0 && percent <= 100;
            string compact = available ? percent.ToString("0") + "%" : "—";
            SetWidgetReading("Bateria", compact, available && (state & Forms.BatteryChargeStatus.Charging) != 0
                ? compact + " · carregando" : available ? compact : "Sem bateria");
            ProgressBar battery;
            if (bars.TryGetValue("Bateria", out battery)) {
                battery.Value = available ? percent : 0;
                battery.Visibility = available ? Visibility.Visible : Visibility.Collapsed;
            }
        }
        if (bigValues.ContainsKey("Relógio") || smallValues.ContainsKey("Relógio")) {
            var now = DateTime.Now;
            string time = now.ToString("HH:mm");
            SetWidgetReading("Relógio", time, time + " · " + now.ToString("dd/MM"));
        }
    }

    void SetWidgetReading(string name, string compact, string full) {
        TextBlock summary;
        if (smallValues.TryGetValue(name, out summary) && summary.Text != compact) summary.Text = compact;
        TextBlock detail;
        if (bigValues.TryGetValue(name, out detail) && detail.Text != full) detail.Text = full;
    }

    void ReadAudio() {
        nextAudioRead = DateTime.UtcNow.AddSeconds(1);
        try {
            using (var output = AudioDevices.Get("", false)) {
                var endpoint = output.AudioEndpointVolume;
                OutputReading(output.FriendlyName, 100 * endpoint.MasterVolumeLevelScalar, endpoint.Mute);
            }
        } catch (COMException) { OutputReading(null, 0, false); }
        catch (InvalidOperationException) { OutputReading(null, 0, false); }
    }

    void SetAudioVolume(double? value, bool toggle) {
        try {
            using (var output = AudioDevices.Get("", false)) {
                var endpoint = output.AudioEndpointVolume;
                if (toggle) endpoint.Mute = !endpoint.Mute;
                if (value.HasValue) {
                    endpoint.MasterVolumeLevelScalar = (float)Math.Max(0, Math.Min(1, value.Value));
                    if (value.Value > 0 && endpoint.Mute) endpoint.Mute = false;
                }
                OutputReading(output.FriendlyName, 100 * endpoint.MasterVolumeLevelScalar, endpoint.Mute, toggle);
            }
        } catch (COMException) { OutputReading(null, 0, false); }
        catch (InvalidOperationException) { OutputReading(null, 0, false); }
    }

    void OutputReading(string name, double percent, bool muted, bool syncSlider = true) {
        string volume = name == null ? "—" : percent.ToString("0") + "%";
        SetWidgetReading("Volume", name != null && muted ? "Mudo" : volume, volume);
        if (outputName == null) return;
        outputName.Text = name == null ? "Saída de áudio indisponível" : muted ? "Silenciado · " + name : name;
        outputName.ToolTip = name;
        updatingVolume = true;
        try {
            volumeSlider.IsEnabled = mute.IsEnabled = name != null;
            if (syncSlider && !volumeSlider.IsMouseCaptureWithin) volumeSlider.Value = percent;
            string label = muted ? "Ativar som" : "Silenciar";
            if (AutomationProperties.GetName(mute) != label) {
                mute.Content = UI.Icon(muted ? "volume-mute" : "volume", "#C9AAFF", 17);
                mute.ToolTip = label;
                AutomationProperties.SetName(mute, label);
            }
        } finally { updatingVolume = false; }
    }

    async void RefreshWeather() {
        var city = options.WeatherCity;
        if (city == null || !city.Valid) {
            requestedCity = null;
            SetWidgetReading("Clima", "—", "—");
            if (weatherDetail != null) weatherDetail.Text = "Escolha uma cidade em Editar widgets.";
            return;
        }
        if (!ReferenceEquals(city, requestedCity)) {
            requestedCity = city;
            weatherSummary = "—";
            weatherStatus = city.Name + " · Consultando…";
            nextWeatherRead = DateTime.MinValue;
        }
        RenderWeatherReading();
        if (DateTime.UtcNow < nextWeatherRead) return;
        nextWeatherRead = DateTime.UtcNow.AddMinutes(15);
        try {
            var weather = await Task.Run(() => WidgetWeather.Read(city));
            if (closed || requestedCity != city) return;
            weatherSummary = Format.Temp(weather.temperature_2m);
            weatherStatus = city.Name + " · " + WidgetWeather.Description(weather.weather_code) + " · Open-Meteo";
        } catch (Exception error) {
            if (closed || requestedCity != city) return;
            System.Diagnostics.Debug.WriteLine(error);
            nextWeatherRead = DateTime.UtcNow.AddMinutes(5);
            weatherStatus = city.Name + (weatherSummary == "—" ? " · Clima indisponível" : " · Última leitura") + " · Open-Meteo";
        }
        if (options.WeatherCity == city) RenderWeatherReading();
    }

    void RenderWeatherReading() {
        SetWidgetReading("Clima", weatherSummary, weatherSummary);
        if (weatherDetail != null && weatherDetail.Text != weatherStatus) {
            weatherDetail.Text = weatherStatus;
        }
    }
}
}
