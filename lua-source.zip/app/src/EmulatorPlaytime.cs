using System;
using System.IO;
using System.Text.RegularExpressions;

namespace LuaMonitor {
public class EmulatorGame { public string Name, Token, Platform; }
// Window formats adapted from PlayCounter's MIT adapters. See licenses/PlayCounter.txt.
public static class EmulatorPlaytime {
    public static EmulatorGame Read(string executable, string title) {
        if (string.IsNullOrEmpty(executable) || string.IsNullOrWhiteSpace(title) || title.Length > 2000) return null;
        string exe = Path.GetFileNameWithoutExtension(executable).ToLowerInvariant();
        Match match;
        if (exe.StartsWith("rpcs3")) {
            match = Regex.Match(title, @"(?:^|\|)\s*([^|]+?)\s*\[([A-Z]{4}\d{5})\]", RegexOptions.IgnoreCase);
            return Game(match, 1, 2, "RPCS3");
        }
        if (exe.StartsWith("ppsspp")) {
            match = Regex.Match(title, @"^PPSSPP (?:Gold )?\S+ - ([A-Z]{4}\d{5}) : (.+?)(?: \(instance: \d+\))?$", RegexOptions.IgnoreCase);
            return Game(match, 2, 1, "PPSSPP");
        }
        if (exe.StartsWith("ryujinx")) {
            match = Regex.Match(title, @"^Ryujinx(?: Canary)? \S+(?: - |\s*\n)(.+?)\s+v[\w.+-]+\s+\((01[0-9a-f]{14})\)\s*\((?:32|64)-bit\)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            return Game(match, 1, 2, "Ryujinx");
        }
        if (exe == "cemu") {
            match = Regex.Match(title, @"^Cemu \S+ - FPS: .*?\[(TitleId: [0-9a-f]{8}-[0-9a-f]{8})\](?: \[Online[^\]]*\])? (.+?)(?: \[(?:[A-Z]{2} )?v\d+\])?$", RegexOptions.IgnoreCase);
            return Game(match, 2, 1, "Cemu");
        }
        if (exe == "mgba") {
            match = Regex.Match(title, @"^mGBA - (.+?)(?: \(\d+(?:[.,]\d+)?\s*fps\))? - \S+$", RegexOptions.IgnoreCase);
            return Game(match, 1, 1, "mGBA");
        }
        return null;
    }
    static EmulatorGame Game(Match match, int name, int token, string platform) {
        if (!match.Success) return null;
        string value = match.Groups[name].Value.Trim();
        if (value.Length < 2 || value.Length > 300) return null;
        return new EmulatorGame { Name = value, Token = match.Groups[token].Value.Trim(), Platform = platform };
    }
}
}
