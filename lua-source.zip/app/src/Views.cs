﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Interop;
using System.Windows.Input;

namespace LuaMonitor {
public static partial class UI {
    public static Canvas Planet(){return Moon();}
    public static Brush Brush(string hex){return (Brush)new BrushConverter().ConvertFromString(ContrastColor(hex));}
    public static TextBlock Text(string value,double size=13,string color="#EAEAEA",bool bold=false){var text=new TextBlock{Text=value,FontSize=Math.Max(11,size),FontFamily=Font,Foreground=Brush(color),FontWeight=bold?FontWeights.SemiBold:FontWeights.Normal,TextWrapping=TextWrapping.Wrap,VerticalAlignment=VerticalAlignment.Center};SmoothText(text);return text;}
    public static StackPanel Stack(params UIElement[] children){var s=new StackPanel();foreach(var c in children)s.Children.Add(c);return s;}
    public static Border Card(UIElement content,double padding=18){if(content is Expander)padding=12;return new Border{Background=Brush("#272729"),BorderBrush=Brush("#3B3B43"),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(15),Padding=new Thickness(padding),Child=content,Margin=new Thickness(0,0,0,14)};}
    public static Grid Columns(params UIElement[] children){return Adaptive(children);}
    public static Grid Row(UIElement left,UIElement right){var g=new Grid{Margin=new Thickness(0,5,0,5),ClipToBounds=true};g.ColumnDefinitions.Add(new ColumnDefinition());g.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});g.Children.Add(left);Grid.SetColumn(right,1);g.Children.Add(right);return g;}
    public static TextBlock Label(string text){return Text(text,11,"#9C9C9C");}
    public static Border Line(){return new Border{Height=1,Background=Brush("#404040"),Margin=new Thickness(0,14,0,14)};}
    public static Button Button(string label,Action action,bool primary=false){var b=new Button{HorizontalAlignment=HorizontalAlignment.Stretch,Margin=new Thickness(0,4,0,4),MinHeight=40,HorizontalContentAlignment=HorizontalAlignment.Center};ButtonLabel(b,label);if(primary){b.SetResourceReference(Control.BackgroundProperty,"Accent");b.Foreground=Brush("#FFFFFF");b.BorderThickness=new Thickness(0);}b.Click+=(s,e)=>action();return b;}
    public static CheckBox Check(string label,bool selected,Action<bool> change){var c=new CheckBox{Content=new TextBlock{Text=label,FontFamily=Font,FontSize=Compact?11.5:12.5,TextWrapping=TextWrapping.Wrap,MaxWidth=Compact?275:520},IsChecked=selected};c.Checked+=(s,e)=>change(true);c.Unchecked+=(s,e)=>change(false);return c;}
    public static ComboBox Choice(IEnumerable<string> items,string current,Action<string> change){var c=new ComboBox{Margin=new Thickness(0,6,0,10),HorizontalAlignment=HorizontalAlignment.Stretch};foreach(string item in items)c.Items.Add(item);c.SelectedItem=current;c.SelectionChanged+=(s,e)=>{if(c.SelectedItem!=null)change(c.SelectedItem.ToString());};return c;}
    public static void Capture(Window w,string path){w.UpdateLayout();var root=w.Content as FrameworkElement;var bitmap=new RenderTargetBitmap((int)Math.Ceiling(w.ActualWidth),(int)Math.Ceiling(w.ActualHeight),96,96,PixelFormats.Pbgra32);bitmap.Render(root);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using(var output=File.Create(path))encoder.Save(output);}
}
}
