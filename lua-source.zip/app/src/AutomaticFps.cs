using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public sealed partial class DesktopController {
    bool fpsAutoBlocked;
    TextBlock widgetHomeFpsValue;
    UIElement HomeWidgetFps(){
        widgetHomeFpsValue=Value(s=>FpsText(fps.Fps),23,"#F1F1F4",true);widgetHomeFpsValue.Margin=new Thickness(0,0,10,0);
        var line=new StackPanel{Orientation=Orientation.Horizontal};line.Children.Add(widgetHomeFpsValue);line.Children.Add(UI.Stack(UI.Text("FPS",11,"#BCD1F4",true),Value(s=>fps.FrameMs.HasValue?fps.FrameMs.Value.ToString("0.00")+" ms / frame":"— ms / frame",10,"#A8B9D7")));
        var panel=UI.Stack(line);if(prefs.ShowFpsLow||prefs.ShowFpsMinimum||prefs.ShowFpsMaximum)panel.Children.Add(Value(s=>(prefs.ShowFpsLow?"1% low "+FpsText(fps.Low)+"   ":"")+(prefs.ShowFpsMinimum?"Mín. "+FpsText(fps.Minimum)+"   ":"")+(prefs.ShowFpsMaximum?"Máx. "+FpsText(fps.Maximum):""),10,"#A8B9D7"));return panel;
    }
    public static string FpsText(double? value){return value.HasValue?value.Value.ToString("0"):"—";}
    void SetFpsOption(string name,bool value){if(name=="low")prefs.ShowFpsLow=value;else if(name=="min")prefs.ShowFpsMinimum=value;else prefs.ShowFpsMaximum=value;OverlayChanged();BuildPage("gaming");}
    void RetryAutomaticFps(){if(sharedOwner!=null){sharedOwner.RetryAutomaticFps();return;}fps.Stop();fpsAutoBlocked=false;prefs.AutoFps=true;Save();RememberForegroundGame();EnsureAutomaticFps();Refresh();}
    void EnsureAutomaticFps(){
        if(verify||sharedOwner!=null||exiting)return;
        if(!prefs.AutoFps){if(fps.Running)fps.Stop();return;}
        if(fps.NeedsUserRetry){fpsAutoBlocked=true;return;}
        if(fpsAutoBlocked)return;
        if(targetPid>0){try{using(var game=Process.GetProcessById(targetPid)){if(game.HasExited)targetPid=0;}}catch{targetPid=0;}}
        if(targetPid<=0){if(fps.Target!=0)fps.Retarget(0,"Aguardando jogo");return;}
        if(!KnownGame(targetPid))return;
        if(fps.Running){if(fps.Target!=targetPid)fps.Retarget(targetPid,targetName);}
        else fps.Start(targetPid,targetName);
    }
}
}
