﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace LuaMonitor {
public sealed class Sparkline : FrameworkElement {
    public List<double> Values=new List<double>();
    public Color Color=Color.FromRgb(57,125,246);
    public bool AutoScale;
    double[] previous=new double[0],current=new double[0];
    public static readonly DependencyProperty BlendProperty=DependencyProperty.Register("Blend",typeof(double),typeof(Sparkline),new FrameworkPropertyMetadata(1.0,FrameworkPropertyMetadataOptions.AffectsRender));
    public double Blend {get{return (double)GetValue(BlendProperty);}set{SetValue(BlendProperty,value);}}
    public void RefreshFrame(){
        var next=Values.ToArray();if(current.SequenceEqual(next))return;
        previous=current;current=next;
        if(UI.MotionEnabled&&IsVisible&&previous.Length>1)BeginAnimation(BlendProperty,new DoubleAnimation(0,1,TimeSpan.FromMilliseconds(220)){EasingFunction=new CubicEase{EasingMode=EasingMode.EaseOut}});
        else{BeginAnimation(BlendProperty,null);Blend=1;}
        InvalidateVisual();
    }
    double PointValue(int index){double value=current[index];if(previous.Length==0)return value;double old=previous[Math.Min(index,previous.Length-1)];return old+(value-old)*Blend;}
    protected override void OnRender(DrawingContext dc){
        base.OnRender(dc);double w=ActualWidth,h=ActualHeight;if(w<2||h<2)return;
        var guide=new Pen(new SolidColorBrush(System.Windows.Media.Color.FromRgb(64,64,70)),1){DashStyle=DashStyles.Dot};
        dc.DrawLine(guide,new Point(0,4),new Point(w,4));
        dc.DrawLine(new Pen(new SolidColorBrush(System.Windows.Media.Color.FromRgb(55,55,61)),1),new Point(0,h-1),new Point(w,h-1));
        if(current.Length<2)return;
        double max=AutoScale?Math.Max(1,Math.Max(current.Max(),previous.Length==0?0:previous.Max())*1.15):100;
        var geometry=new StreamGeometry();
        using(var ctx=geometry.Open()){
            ctx.BeginFigure(new Point(0,h-4-Math.Min(1,PointValue(0)/max)*(h-12)),false,false);
            for(int i=1;i<current.Length;i++)ctx.LineTo(new Point(i*w/(current.Length-1),h-4-Math.Min(1,PointValue(i)/max)*(h-12)),true,false);
        }
        geometry.Freeze();dc.DrawGeometry(null,new Pen(new SolidColorBrush(Color),1.7),geometry);
    }
}
}
