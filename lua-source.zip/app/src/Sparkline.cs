﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace LuaMonitor {
public sealed class Sparkline : FrameworkElement {
    public List<double> Values=new List<double>();
    public Color Color=Color.FromRgb(57,125,246);
    public bool AutoScale;
    public bool SharedScale;
    public bool ShowGuides = true;
    double[] previous=new double[0],current=new double[0];
    public static readonly DependencyProperty BlendProperty=DependencyProperty.Register("Blend",typeof(double),typeof(Sparkline),new FrameworkPropertyMetadata(1.0,FrameworkPropertyMetadataOptions.AffectsRender));
    public double Blend {get{return (double)GetValue(BlendProperty);}set{SetValue(BlendProperty,value);}}
    public void RefreshFrame(){
        var next=Values.ToArray();if(current.SequenceEqual(next))return;
        previous=current;current=next;
        if(UI.MotionEnabled&&IsVisible&&previous.Length>1)BeginAnimation(BlendProperty,new DoubleAnimation(0,1,TimeSpan.FromMilliseconds(220)){EasingFunction=new CubicEase{EasingMode=EasingMode.EaseOut}});
        else{BeginAnimation(BlendProperty,null);Blend=1;}
        InvalidateVisual();
    }
    double PointValue(int index) {
        double value = current[index];
        if (previous.Length == 0) return value;
        double old = previous[Math.Min(index, previous.Length - 1)];
        return double.IsNaN(old) ? value : old + (value - old) * Blend;
    }
    protected override void OnRender(DrawingContext dc){
        base.OnRender(dc);double w=ActualWidth,h=ActualHeight;if(w<2||h<2)return;
        if (ShowGuides) {
            var guide = new Pen(UI.Brush("#262B29"), 1);
            int intervals = SharedScale ? 4 : 1;
            for (int i = 0; i <= intervals; i++) {
                double y = SharedScale ? 1 + i * (h - 2) / intervals : i == 0 ? 4 : h - 1;
                dc.DrawLine(guide, new Point(0, y), new Point(w, y));
            }
        }
        if(current.Length<2)return;
        double max=AutoScale?Math.Max(1,Math.Max(current.Max(),previous.Length==0?0:previous.Max())*1.15):100;
        var geometry=new StreamGeometry();
        double baseline = SharedScale ? h - 1 : h - 4;
        double range = SharedScale ? h - 2 : h - 12;
        using (var context = geometry.Open()) {
            bool connected = false;
            for (int i = 0; i < current.Length; i++) {
                double value = PointValue(i);
                if (double.IsNaN(value)) { connected = false; continue; }
                var point = new Point(i * w / (current.Length - 1), baseline - Math.Min(1, value / max) * range);
                if (connected) context.LineTo(point, true, false);
                else context.BeginFigure(point, false, false);
                connected = true;
            }
        }
        geometry.Freeze();dc.DrawGeometry(null,new Pen(new SolidColorBrush(Color),1.7),geometry);
    }
}
}
