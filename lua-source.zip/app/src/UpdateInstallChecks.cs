﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task UpdateInstallChecks(List<string> checks,string dir){
        string fixture=Path.Combine(Preferences.DataDir,"update-fixture");Directory.CreateDirectory(fixture);string zip=Path.Combine(fixture,"release.zip");
        using(var archive=ZipFile.Open(zip,ZipArchiveMode.Create)){archive.CreateEntryFromFile(System.Reflection.Assembly.GetExecutingAssembly().Location,"LUA-test/LUA.exe");foreach(string dll in new[]{"LibreHardwareMonitorLib.dll","NAudio.Core.dll","NAudio.Wasapi.dll","LuaSensorsHost.exe"})archive.CreateEntryFromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,dll),"LUA-test/"+dll);var data=archive.CreateEntry("LUA-test/refined.txt");using(var writer=new StreamWriter(data.Open()))writer.Write("nova versão");}
        var release=new UpdateRelease{Version=AppUpdate.Current,Url="release.zip",Sha256=AppUpdate.Hash(zip),Bytes=new FileInfo(zip).Length,Notes="Teste isolado"};string feed=Path.Combine(fixture,"LUA-atualizacoes.json");File.WriteAllText(feed,new JavaScriptSerializer().Serialize(release));var loaded=AppUpdate.Read(feed);if(loaded.Sha256!=release.Sha256||AppUpdate.Newer(AppUpdate.Current)||AppUpdate.Newer(AppUpdate.Current+".0")||!AppUpdate.Newer("2.0.0")||AppUpdate.Newer("1.7.0")||AppUpdate.Newer("inválida"))throw new Exception("Comparação de versões ou canal inválidos");
        bool rejected=false;try{AppUpdate.PackageSource(feed,"../fora.zip");}catch(IOException){rejected=true;}if(!rejected)throw new Exception("Origem aceitou pacote fora da pasta");rejected=false;try{AppUpdate.ValidateSource("http://exemplo.invalid/versoes.json");}catch(IOException){rejected=true;}if(!rejected)throw new Exception("Origem permitiu HTTP");
        string staged=await Task.Run(()=>AppUpdate.Prepare(feed,loaded,Path.Combine(Preferences.DataDir,"updates","test-"+Guid.NewGuid().ToString("N")),null));if(!File.Exists(Path.Combine(staged,"LUA.exe")))throw new Exception("Preparação não extraiu aplicativo");release.Sha256=new string('0',64);rejected=false;try{await Task.Run(()=>AppUpdate.Prepare(feed,release,Path.Combine(fixture,"bad-hash"),null));}catch(IOException){rejected=true;}if(!rejected)throw new Exception("Pacote corrompido aceito");release.Sha256=loaded.Sha256;
        string traversal=Path.Combine(fixture,"unsafe.zip");using(var archive=ZipFile.Open(traversal,ZipArchiveMode.Create)){using(var writer=new StreamWriter(archive.CreateEntry("../outside.txt").Open()))writer.Write("teste");}rejected=false;try{AppUpdate.Extract(traversal,Path.Combine(fixture,"unsafe"));}catch(IOException){rejected=true;}if(!rejected||File.Exists(Path.Combine(fixture,"outside.txt")))throw new Exception("Extração permitiu escape de pasta");checks.Add("Atualizações: canal local real, comparação de versão, download, tamanho, SHA-256, extração e versão do executável; rejeita HTTP, pacote corrompido e caminho fora da pasta");
        string target=Path.Combine(fixture,"installed");Directory.CreateDirectory(target);File.Copy(System.Reflection.Assembly.GetExecutingAssembly().Location,Path.Combine(target,"LUA.exe"));File.WriteAllText(Path.Combine(target,"refined.txt"),"anterior");File.WriteAllText(Path.Combine(target,"captura-preservada.txt"),"meu arquivo");
        var helper=new Process{StartInfo=new ProcessStartInfo(Path.Combine(staged,"LUA.exe"),"--apply-update "+ScreenRecorder.Quote(staged)+" --target "+ScreenRecorder.Quote(target)+" --parent 2147483647 --restart-verify --data "+ScreenRecorder.Quote(Preferences.DataDir)){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=staged}};helper.Start();bool finished=await Task.Run(()=>helper.WaitForExit(15000));if(!finished||helper.ExitCode!=0)throw new Exception("Instalador isolado não finalizou");helper.Dispose();for(int n=0;n<100&&!File.Exists(Path.Combine(Preferences.DataDir,"update-smoke.txt"));n++)await Task.Delay(100);if(!File.Exists(Path.Combine(Preferences.DataDir,"update-smoke.txt"))||File.ReadAllText(Path.Combine(target,"refined.txt"))!="nova versão"||File.ReadAllText(Path.Combine(target,"captura-preservada.txt"))!="meu arquivo")throw new Exception("Instalação/reabertura não preservou dados");checks.Add("Atualização REAL em pasta descartável: instalador separado substituiu aplicativo, iniciou versão instalada e preservou arquivo do usuário; nenhum app em uso foi atualizado");
        string rollback=Path.Combine(fixture,"rollback-source");Directory.CreateDirectory(rollback);File.Copy(System.Reflection.Assembly.GetExecutingAssembly().Location,Path.Combine(rollback,"LUA.exe"));File.WriteAllText(Path.Combine(rollback,"refined.txt"),"não deve persistir");File.WriteAllText(Path.Combine(rollback,"locked.txt"),"novo");File.WriteAllText(Path.Combine(target,"locked.txt"),"antigo");rejected=false;using(var locked=new FileStream(Path.Combine(target,"locked.txt"),FileMode.Open,FileAccess.ReadWrite,FileShare.None)){try{AppUpdate.InstallFiles(rollback,target,Path.Combine(fixture,"rollback-backup"));}catch(IOException){rejected=true;}}
        if(!rejected||File.ReadAllText(Path.Combine(target,"refined.txt"))!="nova versão"||File.ReadAllText(Path.Combine(target,"locked.txt"))!="antigo")throw new Exception("Falha de cópia não restaurou versão anterior");checks.Add("Atualização: falha real de arquivo bloqueado restaurou arquivos já substituídos; versão anterior preservada em backup");
        var oldRelease=availableUpdate;bool oldBusy=videoBusy,oldAuto=prefs.AutoUpdate;string oldSource=prefs.UpdateSource;try{availableUpdate=new UpdateRelease{Version="2.0.0"};videoBusy=true;InstallAppUpdate();if(updateBusy||!updateState.Contains("Finalize"))throw new Exception("Instalação não aguardou exportação");videoBusy=false;prefs.UpdateSource=feed;CheckAppUpdates(true);for(int n=0;n<100&&updateChecking;n++)await Task.Delay(50);if(availableUpdate!=null||!updateState.Contains("mais recente"))throw new Exception("Verificação apresentou versão atual como nova");availableUpdate=new UpdateRelease{Version="2.0.0"};updateState="Versão 2.0.0 disponível • demonstração de atualização";int automaticStarts=0;prefs.AutoUpdate=true;TryAutoUpdate(()=>automaticStarts++);videoBusy=true;TryAutoUpdate(()=>automaticStarts++);videoBusy=false;prefs.AutoUpdate=false;TryAutoUpdate(()=>automaticStarts++);if(automaticStarts!=1)throw new Exception("Política automática não respeitou preferência/exportação");BuildPage("home");await Task.Delay(180);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"update-available-home.png"));BuildPage("settings");await Task.Delay(180);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"update-options.png"));if(!Buttons(body).Any(b=>System.Windows.Automation.AutomationProperties.GetName(b)=="Instalar versão 2.0.0"))throw new Exception("Nova versão sem botão Instalar");}finally{availableUpdate=oldRelease;videoBusy=oldBusy;prefs.AutoUpdate=oldAuto;prefs.UpdateSource=oldSource;}
        BuildPage("hardware");window.UpdateLayout();
        var sensors=FindExpanders(body).FirstOrDefault(e=>Convert.ToString(e.Header).StartsWith("Sensores •"));
        if(sensors==null||sensors.IsExpanded)throw new Exception("Detalhes de sensores não iniciaram recolhidos");
        sensors.IsExpanded=true;await Task.Delay(180);window.UpdateLayout();
        UI.Capture(window,Path.Combine(dir,"sensors-expanded.png"));
        sensors.IsExpanded=false;
        navButtons["gallery"].RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        window.UpdateLayout();
        if(page!="gallery"||!Buttons(body).Any(b=>System.Windows.Automation.AutomationProperties.GetName(b)=="Nova captura"))
            throw new Exception("Galeria direta sem Nova captura");
        BuildPage("analysis");
        window.UpdateLayout();
        var refreshDiagnosis=Buttons(body).Single(b=>System.Windows.Automation.AutomationProperties.GetName(b)=="Atualizar diagnóstico");
        timer.Stop();
        try {
            await sampling;
            DateTime before=snapshot.Time;
            refreshDiagnosis.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            if(!analysisRefreshing||refreshDiagnosis.IsEnabled)
                throw new Exception("Diagnóstico não sinalizou a coleta em andamento.");
            for(int n=0;n<150&&analysisRefreshing;n++)await Task.Delay(100);
            if(analysisRefreshing||analysisRefreshMessage!=null||!refreshDiagnosis.IsEnabled||snapshot.Time<=before||!HasAnalysisSample(snapshot))
                throw new Exception("Atualizar diagnóstico não renovou a leitura do PC.");
        } finally { timer.Start(); }
        checks.Add("Diagnóstico: atualizar partiu do botão, renovou a coleta real e liberou a ação ao concluir.");
        BuildPage("home");window.UpdateLayout();
        if(!CollectText(body).Any(label=>label.EndsWith(" livres")))
            throw new Exception("Espaço livre ausente na visão geral");
        UI.Capture(window,Path.Combine(dir,"home-free-space.png"));
        checks.Add("Interface: atualização opcional, acesso direto à Galeria, sensores retráteis e espaço livre na visão geral.");
    }
}
}
