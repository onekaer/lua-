using System;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;

namespace LuaMonitor {
public sealed partial class DesktopController {
    Button PageCard(string label, string note, string icon, Action open) {
        return PageCard(label, UI.Text(note, 11, "#B0ADB9"), icon, open);
    }

    Button PageCard(string label, UIElement details, string icon, Action open) {
        var glyph = UI.Icon(icon, "#BBA8E1", 19);
        glyph.Margin = new Thickness(0, 0, 10, 0);
        var content = new DockPanel();
        DockPanel.SetDock(glyph, Dock.Left);
        content.Children.Add(glyph);
        content.Children.Add(UI.Stack(UI.Text(label, 14, "#F0EEF4", true), details));
        var button = UI.Button(label, open);
        button.Content = content;
        button.Style = (Style)window.FindResource("PanelAction");
        button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
        button.Padding = new Thickness(12, 9, 12, 9);
        AutomationProperties.SetName(button, label);
        return button;
    }

    void ToolsPage() {
        body.Children.Add(UI.Columns(
            PageCard("Processos", "Uso de CPU e memória por aplicativo", "processes", () => BuildPage("processes")),
            PageCard("Analisar PC", "Diagnóstico de hardware e sistema", "analysis", () => BuildPage("analysis"))));
        body.Children.Add(UI.Columns(
            PageCard("Rede e internet", "Tráfego, latência e teste de conexão", "network", () => BuildPage("network")),
            PageCard("Armazenamento", "Uso e atividade das unidades", "storage", () => BuildPage("storage"))));
        body.Children.Add(UI.Columns(
            PageCard("Limpeza e duplicados", "Revise arquivos grandes e duplicados", "cleanup", () => BuildPage("cleanup"))));
    }
}
}
