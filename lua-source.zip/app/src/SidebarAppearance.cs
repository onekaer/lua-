using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace LuaMonitor {
public sealed partial class DesktopController {
    string sidebarQuery = "";
    TextBox sidebarSearchField;

    void SetupSidebar() {
        var search = UI.Search("", "Buscar páginas", query => {
            sidebarQuery = query.Trim();
            RenderSidebar(OrderedNavigation());
        }, height: 36);
        Find<ContentControl>("SidebarSearch").Content = search;
        sidebarSearchField = FindSearchFields(search).First();
        sidebarSearchField.PreviewKeyDown += (sender, args) => {
            if (args.Key == Key.Escape) {
                sidebarSearchField.Clear();
                args.Handled = true;
            } else if (args.Key == Key.Enter && sidebarQuery.Length > 0) {
                var match = nav.Children.OfType<Button>().FirstOrDefault();
                if (match == null) return;
                match.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                sidebarSearchField.Clear();
                args.Handled = true;
            }
        };
        var settings = new StackPanel { Orientation = Orientation.Horizontal };
        var glyph = UI.Icon("settings", "#ABB0AD", 17);
        glyph.Margin = new Thickness(0, 0, 10, 0);
        settings.Children.Add(glyph);
        settings.Children.Add(UI.Text("Configurações", 13, "#C2C7C4"));
        var button = Find<Button>("SettingsButton");
        button.Content = settings;
        System.Windows.Automation.AutomationProperties.SetName(button, "Configurações");
        Find<TextBlock>("SidebarVersion").Text = "LUA " + AppUpdate.Current + " · Beta";
    }

    void RenderSidebar(IEnumerable<string> order) {
        nav.Children.Clear();
        string lastGroup = "";
        var compare = CultureInfo.GetCultureInfo("pt-BR").CompareInfo;
        foreach (string id in order) {
            Button button;
            if (!navButtons.TryGetValue(id, out button) || prefs.HiddenNavigation.Contains(id)) continue;
            if (compare.IndexOf(Convert.ToString(button.ToolTip), sidebarQuery, CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) < 0) continue;
            string group = SidebarGroup(id);
            if (sidebarQuery.Length == 0 && group != lastGroup) {
                var heading = UI.Text(group, 11, "#9BA19E");
                heading.Margin = new Thickness(10, lastGroup.Length == 0 ? 8 : 17, 0, 5);
                nav.Children.Add(heading);
                lastGroup = group;
            }
            button.Visibility = Visibility.Visible;
            nav.Children.Add(button);
        }
        if (sidebarQuery.Length > 0 && compare.IndexOf("Configurações", sidebarQuery, CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) >= 0) {
            var settings = UI.Button("Configurações", () => BuildPage("settings"));
            settings.Style = (Style)window.FindResource("Nav");
            settings.HorizontalContentAlignment = HorizontalAlignment.Left;
            nav.Children.Add(settings);
        }
        if (sidebarQuery.Length > 0 && nav.Children.Count == 0) {
            var empty = UI.Text("Nenhuma página encontrada.", 12, "#A4A9A6");
            empty.Margin = new Thickness(10, 8, 4, 0);
            nav.Children.Add(empty);
        }
    }

    static string SidebarGroup(string id) {
        switch (id) {
            case "home": case "hardware": case "network": case "storage":
                return "Monitoramento";
            case "games": case "recording": case "gallery": case "gaming":
                return "Jogos e mídia";
            default:
                return "Ferramentas";
        }
    }
}
}
