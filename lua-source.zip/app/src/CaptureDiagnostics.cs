﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
namespace LuaMonitor {
public sealed partial class DesktopController {
    string FpsDiagnosis(){string text="PID "+fps.Target+" • "+fps.ReceivedFrames.ToString("N0")+" quadros recebidos";if(fps.Fps.HasValue)return text+" • leitura ativa";if(fps.Target==0)return "Abra um jogo reconhecido da biblioteca para iniciar a leitura automática.";try{using(var process=Process.GetProcessById(fps.Target)){string name=process.ProcessName.ToLowerInvariant();if(name=="steam"||name.Contains("launcher")||name=="epicgameslauncher")return text+"\nAguardando o executável do jogo, além do launcher.";}}catch{return text+"\nO processo selecionado foi encerrado.";}if(fps.ReceivedFrames>0)return text+"\nSem apresentações recentes. Volte ao jogo e confira se está em foco.";return text+"\n"+fps.Status;}
    async void TestCapturePreview(){if(sharedOwner!=null){sharedOwner.TestCapturePreview();return;}if(videoBusy||(recorder!=null&&recorder.Active)){Notice("Pare a captura atual antes de fazer a prévia.");return;}videoBusy=true;ScreenRecorder test=null;try{test=new ScreenRecorder();var options=CaptureProfiles.Clone(prefs.Video);options.Folder=Path.Combine(Preferences.DataDir,"capture-previews");options.Audio=false;options.Microphone=false;await test.StartRecording(options);ShowToast("Teste de captura","Gravando prévia local de 3 segundos…");await Task.Delay(3000);await test.StopRecording();var file=new FileInfo(test.LastFile);var item=new GalleryItem{Path=file.FullName,Name=file.Name,Bytes=file.Length,Date=file.LastWriteTime,Kind="Vídeos"};ShowToast("Prévia pronta",test.CaptureEngine+" • "+test.Encoder);OpenMedia(item);}catch(Exception ex){Notice("A captura não pôde iniciar: "+ex.Message);}if(test!=null){try{await test.Shutdown();}catch{}test.Dispose();}videoBusy=false;UpdateVideo();}
}
}
