using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Forms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace LuaMonitor {
public sealed class TaskbarWidgetOptions {
    public bool Enabled, Right, Center, FollowWindow, ClickToOpen;
    public bool Animate = true;
    public int Inset = 24;
    public string Tint = "Violeta";
    public WidgetCity WeatherCity;
    public List<string> Metrics = new List<string> { "CPU", "GPU", "RAM", "Temperaturas", "Rede", "Volume" };

    // Null preserves the three legacy indicators, while an empty list means icon only.
    public List<string> CapsuleMetrics;

    internal List<string> SummaryMetrics() {
        return (CapsuleMetrics ?? Metrics).Where(TaskbarWidget.MetricNames.Contains).Distinct().Take(3).ToList();
    }

    public void Normalize() {
        Inset = Math.Max(8, Math.Min(240, Inset));
        if (Tint != "Violeta" && Tint != "Verde" && Tint != "Grafite") Tint = "Violeta";
        var valid = (Metrics ?? new List<string>()).Where(TaskbarWidget.MetricNames.Contains).Distinct().ToList();
        Metrics = valid.Count == 0 ? new List<string> { "CPU" } : valid;
        if (CapsuleMetrics != null) CapsuleMetrics = SummaryMetrics();
    }
}

public sealed partial class TaskbarWidget : Window {
    internal static readonly string[] MetricNames = {
        "CPU", "GPU", "RAM", "Temperaturas", "Rede", "FPS", "Disco", "Volume", "Clima", "Bateria", "Relógio", "Tempo ligado"
    };
    static readonly string[] MetricIcons = {
        "hardware", "gpu", "processes", "temperature", "network", "fps", "storage",
        "volume", "weather", "battery", "clock", "timer"
    };
    static readonly string[] MetricColors = {
        "#B9A8FF", "#85DAD6", "#9BD8AE", "#FFBD8A", "#97B6FA", "#E2A9ED", "#DBC7A3",
        "#C9AAFF", "#F6CE83", "#9BD8AE", "#AFC8F7", "#C6B8F1"
    };
    const int CompactHeight = 40;
    const int ExpandedWidth = 340;
    static readonly TimeSpan Frame = TimeSpan.FromMilliseconds(190);

    readonly Func<Drawing.Point> monitorPoint;
    readonly Func<bool> panelInUse;
    internal event Action PositionChanged;
    readonly DispatcherTimer hover, closeDelay, placement, stacking;
    readonly Button capsule;
    readonly Border capsuleFace, panel, capsuleBrand;
    readonly Canvas layout = new Canvas();
    readonly StackPanel capsuleValues = new StackPanel { Orientation = Orientation.Horizontal };
    readonly StackPanel detailRows = new StackPanel();
    readonly ScrollViewer detailScroll;
    readonly Grid panelHeader;
    readonly TranslateTransform panelSlide = new TranslateTransform();
    readonly Dictionary<string, TextBlock> smallValues = new Dictionary<string, TextBlock>();
    readonly Dictionary<string, TextBlock> bigValues = new Dictionary<string, TextBlock>();
    readonly Dictionary<string, ProgressBar> bars = new Dictionary<string, ProgressBar>();
    TaskbarWidgetOptions options;
    bool expanded, preview;
    ContentControl cardHost;
    Drawing.Rectangle anchor, taskbarBounds;
    double compactWidth, scale = 1;
    Drawing.Rectangle workArea, monitorBounds;
    IntPtr taskbarWindow, foregroundHook;
    readonly WinEventCallback foregroundChanged;
    IntPtr inspectedTaskbar;
    Drawing.Rectangle inspectedBounds;
    Drawing.Rectangle[] shellControls = new Drawing.Rectangle[0];
    DateTime nextInspection;
    bool inspecting, closed;
    bool dockAtTop;
    static readonly IntPtr TopmostWindow = new IntPtr(-1);
    const uint NoSize = 0x0001, NoMove = 0x0002, NoActivate = 0x0010, NoOwnerZOrder = 0x0200;
    long change;

    public TaskbarWidget(ResourceDictionary styles, Func<Drawing.Point> monitorPoint, Action edit,
        Action openPanel = null, Func<bool> panelInUse = null) {
        this.monitorPoint = monitorPoint;
        this.panelInUse = panelInUse;
        Title = "LUA • Widget da barra de tarefas";
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        ShowActivated = false;
        ShowInTaskbar = false;
        Topmost = true;
        ResizeMode = ResizeMode.NoResize;
        FontFamily = UI.Font;
        Width = 200;
        Height = CompactHeight;
        UseLayoutRounding = true;
        UI.SmoothText(this);
        foreach (System.Collections.DictionaryEntry resource in styles) Resources[resource.Key] = resource.Value;
        SourceInitialized += (sender, args) => {
            var hwnd = new WindowInteropHelper(this).Handle;
            CaptureWindowStyle.Apply(this, false, excludeCapture: false);
            HwndSource.FromHwnd(hwnd).AddHook(WindowMessage);
        };

        capsuleBrand = new Border {
            Width = 25, Height = 25, CornerRadius = new CornerRadius(13),
            Margin = new Thickness(0, 0, 9, 0),
            Child = new Viewbox { Width = 17, Height = 17, Child = UI.Moon() }
        };
        var line = new StackPanel { Orientation = Orientation.Horizontal };
        line.Children.Add(capsuleBrand);
        line.Children.Add(capsuleValues);
        capsuleFace = new Border {
            Height = CompactHeight, CornerRadius = new CornerRadius(20), Padding = new Thickness(8, 0, 12, 0),
            BorderThickness = new Thickness(1), BorderBrush = UI.Brush("#1AFFFFFF"), Child = line
        };
        capsuleFace.Background = UI.Brush("#EE252525");
        capsule = new Button { Content = capsuleFace, Height = CompactHeight, Padding = new Thickness(0), Margin = new Thickness(0), Cursor = Cursors.Hand };
        var template = new ControlTemplate(typeof(Button));
        template.VisualTree = new FrameworkElementFactory(typeof(ContentPresenter));
        capsule.Template = template;
        AutomationProperties.SetName(capsule, "Abrir ou recolher o menu compacto do LUA");
        capsule.Click += (sender, args) => { ClosePeek(); if (openPanel != null) openPanel(); };
        capsule.MouseRightButtonUp += (sender, args) => { edit(); args.Handled = true; };

        detailScroll = new ScrollViewer { Content = detailRows, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var panelContent = new DockPanel { LastChildFill = true };
        var headerTitle = UI.Text("Visão rápida", 20, "#F5F3FA", true);
        var header = panelHeader = new Grid { Margin = new Thickness(0, 0, 0, 10) };
        header.ColumnDefinitions.Add(new ColumnDefinition());
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        header.Children.Add(headerTitle);
        var editor = WidgetIconButton("edit", "Editar widgets", edit);
        Grid.SetColumn(editor, 1);
        header.Children.Add(editor);
        DockPanel.SetDock(header, Dock.Top);
        panelContent.Children.Add(header);
        panelContent.Children.Add(detailScroll);
        panel = new Border {
            Width = ExpandedWidth, Child = panelContent, Padding = new Thickness(14), RenderTransform = panelSlide,
            CornerRadius = new CornerRadius(22), BorderThickness = new Thickness(1),
            BorderBrush = UI.Brush("#37323E"), Visibility = Visibility.Collapsed
        };
        layout.Children.Add(panel);
        layout.Children.Add(capsule);
        Content = layout;

        hover = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(125) };
        hover.Tick += (sender, args) => { hover.Stop(); if (capsule.IsMouseOver && CanPeek) SetExpanded(true); };
        closeDelay = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(255) };
        closeDelay.Tick += (sender, args) => { closeDelay.Stop(); if (!IsMouseOver) SetExpanded(false); };
        capsule.MouseEnter += (sender, args) => { if (!expanded && CanPeek) hover.Start(); };
        MouseEnter += (sender, args) => closeDelay.Stop();
        MouseLeave += (sender, args) => { hover.Stop(); if (expanded) closeDelay.Start(); };
        placement = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        placement.Tick += (sender, args) => Reposition();
        stacking = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(90) };
        stacking.Tick += (sender, args) => {
            if (IsVisible) KeepAboveTaskbar(new WindowInteropHelper(this).Handle, taskbarWindow);
        };
        foregroundChanged = (hook, eventId, hwnd, objectId, childId, thread, time) =>
            Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => {
                if (!closed && placement.IsEnabled) Reposition();
            }));
        Closed += (sender, args) => {
            closed = true;
            hover.Stop(); closeDelay.Stop(); placement.Stop(); stacking.Stop();
            if (foregroundHook != IntPtr.Zero) UnhookWinEvent(foregroundHook);
        };
    }

    IntPtr WindowMessage(IntPtr hwnd, int message, IntPtr wp, IntPtr lp, ref bool handled) {
        if (message == 0x21) { handled = true; return new IntPtr(3); }
        if (message == 0x02e0 || message == 0x007e) Dispatcher.BeginInvoke(new Action(() => {
            if (placement.IsEnabled) Reposition();
        }));
        return IntPtr.Zero;
    }

    Button WidgetIconButton(string icon, string label, Action click) {
        var button = UI.IconButton(icon, label, click);
        button.Width = button.Height = 31;
        button.MinHeight = 0;
        button.Margin = new Thickness(4, 0, 0, 0);
        return button;
    }

    public void Configure(TaskbarWidgetOptions next) {
        options = next;
        options.Normalize();
        capsuleValues.Children.Clear();
        detailRows.Children.Clear();
        smallValues.Clear();
        bigValues.Clear();
        bars.Clear();
        ResetWidgetCards();
        var summary = options.SummaryMetrics();
        bool iconOnly = summary.Count == 0;
        compactWidth = iconOnly ? CompactHeight : 52 + 63 * summary.Count;
        capsule.Width = compactWidth;
        capsuleFace.Padding = iconOnly ? new Thickness(0) : new Thickness(8, 0, 12, 0);
        capsuleBrand.Margin = iconOnly ? new Thickness(0) : new Thickness(0, 0, 9, 0);
        ((StackPanel)capsuleFace.Child).HorizontalAlignment = iconOnly ? HorizontalAlignment.Center : HorizontalAlignment.Left;
        string tone = options.Tint == "Verde" ? "#274742" : options.Tint == "Grafite" ? "#333941" : "#432F60";
        capsuleBrand.Background = UI.Brush(tone);
        panel.Background = PanelBackground(options.Tint);
        foreach (string metric in summary) {
            string color = MetricColors[Array.IndexOf(MetricNames, metric)];
            string caption = metric == "Temperaturas" ? "TEMP" : metric == "Tempo ligado" ? "ATIVO" : metric;
            var label = UI.Text(caption, 10, color, true);
            var value = UI.Text("—", 12, "#F5F3FA", true);
            var group = UI.Stack(label, value);
            group.Width = 61;
            group.VerticalAlignment = VerticalAlignment.Center;
            capsuleValues.Children.Add(group);
            smallValues[metric] = value;
        }
        var rowCards = new List<Border>();
        foreach (string metric in options.Metrics) {
            int index = Array.IndexOf(MetricNames, metric);
            string color = MetricColors[index];
            bool wide = metric == "Volume" || metric == "Clima";
            bool three = index < 3;
            if (wide || (rowCards.Count > 0 && ((int)rowCards[0].Tag < 3) != three)) AddWidgetRow(rowCards);
            var card = BuildWidgetCard(metric, index, color);
            if (wide) detailRows.Children.Add(card);
            else {
                rowCards.Add(card);
                if (rowCards.Count == (three ? 3 : 2)) AddWidgetRow(rowCards);
            }
        }
        AddWidgetRow(rowCards);
        if (placement.IsEnabled || preview) Reposition();
    }

    public void Update(Snapshot snapshot, double? fps) {
        if (options == null) return;
        double? ram = snapshot.RamTotal == 0 ? (double?)null : snapshot.RamPercent;
        double capacity = snapshot.Disks.Sum(d => (double)d.Total);
        double free = snapshot.Disks.Sum(d => (double)d.Free);
        UpdateOptionalWidgets();
        foreach (string metric in options.Metrics.Union(smallValues.Keys)) {
            string value, shortValue;
            double? percentage = null;
            switch (metric) {
                case "CPU": percentage = snapshot.Cpu; value = shortValue = Format.Percent(percentage); break;
                case "GPU": percentage = snapshot.Gpu; value = shortValue = Format.Percent(percentage); break;
                case "RAM": percentage = ram; value = shortValue = Format.Percent(percentage); break;
                case "Temperaturas":
                    value = "CPU " + Format.Temp(snapshot.CpuTemp) + "  ·  GPU " + Format.Temp(snapshot.GpuTemp);
                    shortValue = Format.Temp(snapshot.CpuTemp ?? snapshot.GpuTemp);
                    break;
                case "Rede": value = "↓ " + Format.Rate(snapshot.Download) + "   ↑ " + Format.Rate(snapshot.Upload);
                    shortValue = (snapshot.Download * 8 / 1000000).ToString("0.#") + " M"; break;
                case "FPS": value = shortValue = fps.HasValue ? fps.Value.ToString("0") + " FPS" : "—"; break;
                case "Volume": case "Clima": case "Bateria": case "Relógio": continue;
                case "Tempo ligado":
                    shortValue = snapshot.Uptime.TotalDays >= 1 ? snapshot.Uptime.ToString(@"d\d\ hh\h") : snapshot.Uptime.ToString(@"hh\h\ mm\m");
                    value = shortValue; break;
                default: percentage = capacity > 0 ? (double?)(100 * (capacity - free) / capacity) : null;
                    shortValue = percentage.HasValue ? Format.Bytes(free) : "—"; value = percentage.HasValue ? shortValue + " livres" : shortValue; break;
            }
            SetWidgetReading(metric, shortValue, value);
            ProgressBar bar;
            if (bars.TryGetValue(metric, out bar)) {
                double newValue = percentage ?? 0;
                double previous = bar.Value;
                if (Math.Abs(newValue - previous) >= .1) {
                    bar.BeginAnimation(ProgressBar.ValueProperty, null);
                    bar.Value = newValue;
                    if (expanded && CanAnimate && percentage.HasValue)
                        bar.BeginAnimation(ProgressBar.ValueProperty, new DoubleAnimation(previous, newValue, Frame) {
                            FillBehavior = FillBehavior.Stop
                        });
                }
            }
        }
    }

    public void Start() {
        foregroundHook = SetWinEventHook(3, 3, IntPtr.Zero, foregroundChanged, 0, 0, 0);
        placement.Start();
        stacking.Start();
        Reposition();
    }

    bool CanPeek { get { return options != null && !options.ClickToOpen && (panelInUse == null || !panelInUse()); } }
    
    internal static Brush PanelBackground(string tint) {
        var gradient = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 1) };
        gradient.GradientStops.Add(new GradientStop(Color.FromRgb(18, 18, 21), 0));
        gradient.GradientStops.Add(new GradientStop(Color.FromRgb(23, 22, 27), .58));
        string accent = tint == "Verde" ? "#1E2826" : tint == "Grafite" ? "#23252A" : "#251D2D";
        gradient.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(accent), 1));
        gradient.Freeze();
        return gradient;
    }

    internal void ClosePeek() {
        hover.Stop();
        closeDelay.Stop();
        expanded = false;
        if (panel.Visibility == Visibility.Visible) FinishClose(++change);
    }

    internal void SetCardHost(ContentControl host) {
        if (cardHost == host) return;
        if (cardHost != null) cardHost.Content = null;
        else detailScroll.Content = null;
        cardHost = host;
        if (host == null) detailScroll.Content = detailRows;
        else host.Content = detailRows;
    }

    void SetExpanded(bool value) {
        if (expanded == value) return;
        expanded = value;
        long transition = ++change;
        bool animate = CanAnimate;
        if (value) {
            panel.Visibility = Visibility.Visible;
            Reposition();
            if (animate) {
                panel.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, Frame));
                panelSlide.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(dockAtTop ? -11 : 11, 0, Frame) {
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                });
            } else {
                panel.BeginAnimation(OpacityProperty, null);
                panelSlide.BeginAnimation(TranslateTransform.YProperty, null);
            }
            return;
        }
        if (!animate) { FinishClose(transition); return; }
        var fade = new DoubleAnimation(panel.Opacity, 0, TimeSpan.FromMilliseconds(120));
        fade.Completed += (sender, args) => FinishClose(transition);
        panel.BeginAnimation(OpacityProperty, fade);
        panelSlide.BeginAnimation(TranslateTransform.YProperty,
            new DoubleAnimation(panelSlide.Y, dockAtTop ? -8 : 8, TimeSpan.FromMilliseconds(120)));
    }

    bool CanAnimate { get { return options.Animate && UI.MotionEnabled && SystemParameters.ClientAreaAnimation; } }

    void FinishClose(long transition) {
        if (transition != change) return;
        panel.Visibility = Visibility.Collapsed;
        panel.BeginAnimation(OpacityProperty, null);
        panelSlide.BeginAnimation(TranslateTransform.YProperty, null);
        Reposition();
    }

    void Reposition() {
        if (options == null) return;
        var screen = options.FollowWindow ? Forms.Screen.FromPoint(monitorPoint()) : Forms.Screen.PrimaryScreen;
        if (screen == null) return;
        workArea = screen.WorkingArea;
        monitorBounds = screen.Bounds;
        Drawing.Rectangle taskbar, notificationArea;
        IntPtr shell;
        bool hasTaskbar = FindTaskbar(screen, out taskbar, out notificationArea, out shell);
        taskbarWindow = shell;
        if (preview && !hasTaskbar) taskbar = InferredTaskbar(workArea, monitorBounds);
        if ((!preview && (!hasTaskbar || FullscreenOnMonitor())) || taskbar.IsEmpty) {
            LoseAnchor();
            return;
        }
        var handle = new WindowInteropHelper(this).EnsureHandle();
        var source = PresentationSource.FromVisual(this);
        if (source != null) scale = source.CompositionTarget.TransformToDevice.M11;
        bool showingPanel = panel.Visibility == Visibility.Visible;
        bool vertical = taskbar.Height > taskbar.Width;
        bool leftEdge = vertical && taskbar.Left <= monitorBounds.Left + 3;
        dockAtTop = !vertical && taskbar.Top <= monitorBounds.Top + 3;
        int thickness = vertical ? taskbar.Width : taskbar.Height;
        double factor = Math.Min(1, (thickness - 4) / (CompactHeight * scale));
        if (factor <= 0) return;
        var compactTransform = new TransformGroup();
        compactTransform.Children.Add(new ScaleTransform(factor, factor));
        if (vertical) compactTransform.Children.Add(new RotateTransform(leftEdge ? 90 : -90));
        capsule.LayoutTransform = compactTransform;
        int span = (int)Math.Floor((vertical ? taskbar.Height : taskbar.Width) / scale);
        double visibleWidth = Math.Min(compactWidth, span);
        capsule.Width = visibleWidth;
        int capsuleLength = (int)Math.Ceiling(visibleWidth * factor * scale);
        int capsuleThickness = (int)Math.Ceiling(CompactHeight * factor * scale);
        int inset = (int)Math.Round(options.Inset * scale);
        if (hasTaskbar) InspectControls(shell, taskbar);
        int? position = FindFreeSlot(taskbar, notificationArea, hasTaskbar ? shellControls : new Drawing.Rectangle[0],
            vertical, capsuleLength, inset, scale, options.Right, options.Center);
        if (!position.HasValue) {
            LoseAnchor();
            return;
        }
        int along = position.Value;
        var capsuleRect = vertical
            ? new Drawing.Rectangle(taskbar.Left + (thickness - capsuleThickness) / 2, along, capsuleThickness, capsuleLength)
            : new Drawing.Rectangle(along, taskbar.Top + (thickness - capsuleThickness) / 2, capsuleLength, capsuleThickness);
        anchor = capsuleRect;
        taskbarBounds = taskbar;
        var bounds = capsuleRect;
        if (showingPanel) {
            panel.Width = Math.Min(ExpandedWidth, Math.Max(100, workArea.Width / scale - 16));
            var contentSize = new Size(panel.Width - 31, double.PositiveInfinity);
            panelHeader.Measure(contentSize);
            detailRows.Measure(contentSize);
            int gap = (int)Math.Round(5 * scale);
            int availableHeight = vertical ? workArea.Height
                : dockAtTop ? workArea.Bottom - taskbar.Bottom : taskbar.Top - workArea.Top;
            double contentHeight = panelHeader.DesiredSize.Height + detailRows.DesiredSize.Height;
            panel.Height = Math.Max(1, Math.Min(31 + contentHeight, availableHeight / scale - 12));
            int width = (int)Math.Ceiling(panel.Width * scale);
            int height = (int)Math.Ceiling(panel.Height * scale);
            var panelRect = PanelPlacement(width, height, gap);
            bounds = Drawing.Rectangle.Union(bounds, panelRect);
            Canvas.SetLeft(panel, (panelRect.X - bounds.Left) / scale);
            Canvas.SetTop(panel, (panelRect.Y - bounds.Top) / scale);
        }
        Canvas.SetLeft(capsule, (capsuleRect.Left - bounds.Left) / scale);
        Canvas.SetTop(capsule, (capsuleRect.Top - bounds.Top) / scale);
        Width = bounds.Width / scale;
        Height = bounds.Height / scale;
        SetWindowPos(handle, IntPtr.Zero, bounds.Left, bounds.Top, 0, 0, NoSize | NoActivate | NoOwnerZOrder | 0x0004);
        if (!IsVisible) Show();
        KeepAboveTaskbar(handle, taskbarWindow);
        if (PositionChanged != null) PositionChanged();
    }

    void LoseAnchor() {
        anchor = Drawing.Rectangle.Empty;
        hover.Stop();
        closeDelay.Stop();
        expanded = false;
        change++;
        panel.Visibility = Visibility.Collapsed;
        panel.BeginAnimation(OpacityProperty, null);
        panelSlide.BeginAnimation(TranslateTransform.YProperty, null);
        if (IsVisible) Hide();
        if (PositionChanged != null) PositionChanged();
    }

    internal bool HasAnchor { get { return !anchor.IsEmpty && IsVisible; } }
    internal bool IsPeekVisible { get { return panel.Visibility == Visibility.Visible; } }
    internal double DockedHeight { get { return Math.Max(1, workArea.Height / scale - 16); } }

    Drawing.Rectangle PanelPlacement(int width, int height, int gap) {
        bool vertical = taskbarBounds.Height > taskbarBounds.Width;
        bool left = vertical && taskbarBounds.Left <= monitorBounds.Left + 3;
        int x = vertical ? (left ? taskbarBounds.Right + gap : taskbarBounds.Left - width - gap)
            : anchor.Left + (anchor.Width - width) / 2;
        int y = vertical ? anchor.Top + (anchor.Height - height) / 2
            : dockAtTop ? taskbarBounds.Bottom + gap : taskbarBounds.Top - height - gap;
        x = Math.Max(workArea.Left, Math.Min(x, workArea.Right - width));
        y = Math.Max(workArea.Top, Math.Min(y, workArea.Bottom - height));
        return new Drawing.Rectangle(x, y, width, height);
    }

    internal bool PositionPanel(Window target) {
        if (!HasAnchor || !target.IsVisible) return false;
        var handle = new WindowInteropHelper(target).Handle;
        NativeRect bounds;
        if (!GetWindowRect(handle, out bounds)) return false;
        var old = bounds.Rectangle;
        var next = PanelPlacement(old.Width, old.Height, (int)Math.Round(5 * scale));
        if (old.Location != next.Location)
            SetWindowPos(handle, IntPtr.Zero, next.X, next.Y, 0, 0, NoSize | NoActivate | NoOwnerZOrder | 0x0004);
        return true;
    }

    // Explorer can raise its taskbar above other topmost windows after it loses focus.
    // Restack only when Explorer is above us, leaving other desktop popups alone.
    internal static void KeepAboveTaskbar(IntPtr widget, IntPtr taskbar) {
        if (widget == IntPtr.Zero || taskbar == IntPtr.Zero) return;
        // Enumerate from the top because some shell windows live in a different Z-order band.
        for (IntPtr above = GetTopWindow(IntPtr.Zero); above != IntPtr.Zero; above = GetWindow(above, 2)) {
            if (above == widget) return;
            if (above != taskbar) continue;
            SetWindowPos(widget, TopmostWindow, 0, 0, 0, 0, NoSize | NoMove | NoActivate | NoOwnerZOrder);
            return;
        }
    }

    void InspectControls(IntPtr shell, Drawing.Rectangle bounds) {
        if (shell != inspectedTaskbar || bounds != inspectedBounds) {
            inspectedTaskbar = shell;
            inspectedBounds = bounds;
            shellControls = new Drawing.Rectangle[0];
            nextInspection = DateTime.MinValue;
        }
        if (inspecting || DateTime.UtcNow < nextInspection) return;
        inspecting = true;
        nextInspection = DateTime.UtcNow.AddSeconds(3);
        Task.Run(() => ReadShellControls(shell)).ContinueWith(result => Dispatcher.BeginInvoke(new Action(() => {
            inspecting = false;
            if (result.IsFaulted) { System.Diagnostics.Debug.WriteLine(result.Exception); return; }
            if (closed || inspectedTaskbar != shell || inspectedBounds != bounds) return;
            shellControls = result.Result;
            Reposition();
        })));
    }

    static Drawing.Rectangle[] ReadShellControls(IntPtr shell) {
        try {
            var root = AutomationElement.FromHandle(shell);
            var condition = new OrCondition(new[] { ControlType.Button, ControlType.CheckBox, ControlType.MenuItem,
                ControlType.Edit, ControlType.SplitButton, ControlType.TabItem, ControlType.Hyperlink, ControlType.ComboBox }
                .Select(type => (System.Windows.Automation.Condition)new PropertyCondition(AutomationElement.ControlTypeProperty, type)).ToArray());
            var cache = new CacheRequest();
            cache.Add(AutomationElement.BoundingRectangleProperty);
            cache.Add(AutomationElement.IsOffscreenProperty);
            using (cache.Activate()) {
                return root.FindAll(TreeScope.Descendants, condition).Cast<AutomationElement>()
                    .Where(element => !element.Cached.IsOffscreen && !element.Cached.BoundingRectangle.IsEmpty)
                    .Select(element => {
                        Rect rect = element.Cached.BoundingRectangle;
                        return Drawing.Rectangle.FromLTRB((int)Math.Floor(rect.Left), (int)Math.Floor(rect.Top),
                            (int)Math.Ceiling(rect.Right), (int)Math.Ceiling(rect.Bottom));
                    }).ToArray();
            }
        } catch (ElementNotAvailableException) {
            return new Drawing.Rectangle[0];
        } catch (COMException) {
            return new Drawing.Rectangle[0];
        } catch (ArgumentException) {
            return new Drawing.Rectangle[0];
        }
    }

    internal static int? FindFreeSlot(Drawing.Rectangle bar, Drawing.Rectangle tray, IEnumerable<Drawing.Rectangle> controls,
        bool vertical, int length, int inset, double scale, bool right, bool centered = false) {
        int start = vertical ? bar.Top : bar.Left;
        int end = vertical ? bar.Bottom : bar.Right;
        int gap = (int)Math.Ceiling(8 * scale);
        var occupied = new List<Tuple<int, int>>();
        foreach (var original in controls) {
            var rect = Drawing.Rectangle.Intersect(bar, original);
            if (rect.Width <= 0 || rect.Height <= 0) continue;
            // Some shell providers expose a host as a button; it is not an individual hit target.
            if ((vertical ? rect.Height : rect.Width) > (end - start) / 2) continue;
            int first = vertical ? rect.Top : rect.Left;
            int last = vertical ? rect.Bottom : rect.Right;
            occupied.Add(Tuple.Create(Math.Max(start, first - gap), Math.Min(end, last + gap)));
        }
        // Keep the Windows widgets/Start area and tray clear when Explorer reports incomplete bounds.
        int lead = (int)Math.Round((vertical ? 52 : 164) * scale);
        int trail = (int)Math.Round((vertical ? 112 : 212) * scale);
        occupied.Add(Tuple.Create(start, Math.Min(end, start + lead)));
        int trayStart = tray.Width > 0 && tray.Height > 0 ? (vertical ? tray.Top : tray.Left) : end - trail;
        occupied.Add(Tuple.Create(Math.Max(start, Math.Min(end, trayStart - gap)), end));
        if (occupied.Count == 2) {
            int center = start + (end - start) / 2;
            int reserve = (int)Math.Round(170 * scale);
            occupied.Add(Tuple.Create(Math.Max(start, center - reserve), Math.Min(end, center + reserve)));
        }
        var slots = new List<Tuple<int, int>>();
        int cursor = start;
        foreach (var interval in occupied.OrderBy(interval => interval.Item1)) {
            if (interval.Item1 - cursor >= length) slots.Add(Tuple.Create(cursor, interval.Item1));
            cursor = Math.Max(cursor, interval.Item2);
        }
        if (end - cursor >= length) slots.Add(Tuple.Create(cursor, end));
        if (slots.Count == 0) return null;
        if (centered) {
            int center = start + (end - start - length) / 2;
            return slots.Select(s => Math.Max(s.Item1, Math.Min(center, s.Item2 - length)))
                .OrderBy(x => Math.Abs(x - center)).First();
        }
        var slot = right ? slots[slots.Count - 1] : slots[0];
        int offset = Math.Min(inset, slot.Item2 - slot.Item1 - length);
        return right ? slot.Item2 - length - offset : slot.Item1 + offset;
    }

    static bool FindTaskbar(Forms.Screen screen, out Drawing.Rectangle taskbar, out Drawing.Rectangle notificationArea, out IntPtr shell) {
        var monitor = screen.Bounds;
        var primary = FindWindow("Shell_TrayWnd", null);
        var candidate = screen.Primary ? primary : FindWindowEx(IntPtr.Zero, IntPtr.Zero, "Shell_SecondaryTrayWnd", null);
        while (candidate != IntPtr.Zero) {
            NativeRect rect;
            if (IsWindowVisible(candidate) && GetWindowRect(candidate, out rect)) {
                var visible = Drawing.Rectangle.Intersect(monitor, rect.Rectangle);
                if (visible.Width >= 16 && visible.Height >= 16 &&
                    (visible.Width >= monitor.Width / 2 || visible.Height >= monitor.Height / 2)) {
                    taskbar = visible;
                    var tray = FindWindowEx(candidate, IntPtr.Zero, "TrayNotifyWnd", null);
                    notificationArea = tray != IntPtr.Zero && GetWindowRect(tray, out rect)
                        ? Drawing.Rectangle.Intersect(visible, rect.Rectangle) : Drawing.Rectangle.Empty;
                    shell = candidate;
                    return true;
                }
            }
            if (screen.Primary) break;
            candidate = FindWindowEx(IntPtr.Zero, candidate, "Shell_SecondaryTrayWnd", null);
        }
        taskbar = notificationArea = Drawing.Rectangle.Empty;
        shell = IntPtr.Zero;
        return false;
    }

    static Drawing.Rectangle InferredTaskbar(Drawing.Rectangle work, Drawing.Rectangle monitor) {
        if (work.Bottom < monitor.Bottom) return Drawing.Rectangle.FromLTRB(monitor.Left, work.Bottom, monitor.Right, monitor.Bottom);
        if (work.Top > monitor.Top) return Drawing.Rectangle.FromLTRB(monitor.Left, monitor.Top, monitor.Right, work.Top);
        if (work.Left > monitor.Left) return Drawing.Rectangle.FromLTRB(monitor.Left, monitor.Top, work.Left, monitor.Bottom);
        if (work.Right < monitor.Right) return Drawing.Rectangle.FromLTRB(work.Right, monitor.Top, monitor.Right, monitor.Bottom);
        return Drawing.Rectangle.FromLTRB(monitor.Left, monitor.Bottom - 48, monitor.Right, monitor.Bottom);
    }

    internal Drawing.Rectangle CapsuleBounds {
        get { return VisualBounds(capsule); }
    }

    internal Drawing.Rectangle PanelBounds {
        get { return VisualBounds(panel); }
    }

    static Drawing.Rectangle VisualBounds(FrameworkElement element) {
        var first = element.PointToScreen(new Point());
        var last = element.PointToScreen(new Point(element.ActualWidth, element.ActualHeight));
        return Drawing.Rectangle.FromLTRB((int)Math.Min(first.X, last.X), (int)Math.Min(first.Y, last.Y),
            (int)Math.Max(first.X, last.X), (int)Math.Max(first.Y, last.Y));
    }

    bool FullscreenOnMonitor() {
        IntPtr foreground = Native.GetForegroundWindow();
        uint process;
        Native.GetWindowThreadProcessId(foreground, out process);
        if (foreground == IntPtr.Zero || foreground == GetShellWindow() || process == (uint)ProcessId) return false;
        NativeRect bounds;
        // A maximized app can have invisible resize borders beyond the working area.
        if (DwmGetWindowAttribute(foreground, 9, out bounds, Marshal.SizeOf(typeof(NativeRect))) != 0 &&
            !GetWindowRect(foreground, out bounds)) return false;
        return CoversMonitor(bounds.Rectangle, monitorBounds, IsZoomed(foreground),
            (Native.GetWindowLong(foreground, -16) & 0x00C00000) == 0x00C00000);
    }

    internal static bool CoversMonitor(Drawing.Rectangle frame, Drawing.Rectangle monitor, bool maximized, bool caption) {
        if (maximized && caption) return false;
        return frame.Left <= monitor.Left + 2 && frame.Top <= monitor.Top + 2 &&
            frame.Right >= monitor.Right - 2 && frame.Bottom >= monitor.Bottom - 2;
    }

    static readonly int ProcessId = System.Diagnostics.Process.GetCurrentProcess().Id;
    [StructLayout(LayoutKind.Sequential)]
    struct NativeRect {
        public int Left, Top, Right, Bottom;
        public Drawing.Rectangle Rectangle { get { return Drawing.Rectangle.FromLTRB(Left, Top, Right, Bottom); } }
    }
    [DllImport("user32.dll")]
    static extern bool GetWindowRect(IntPtr hwnd, out NativeRect rectangle);
    [DllImport("user32.dll")]
    static extern IntPtr GetShellWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern IntPtr FindWindow(string className, string windowName);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern IntPtr FindWindowEx(IntPtr parent, IntPtr after, string className, string windowName);
    [DllImport("user32.dll")]
    static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")]
    static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll")]
    static extern IntPtr GetTopWindow(IntPtr hwnd);
    [DllImport("user32.dll")]
    static extern IntPtr GetWindow(IntPtr hwnd, uint command);
    [DllImport("user32.dll")]
    static extern bool IsZoomed(IntPtr hwnd);
    [DllImport("dwmapi.dll")]
    static extern int DwmGetWindowAttribute(IntPtr hwnd, int attribute, out NativeRect bounds, int size);
    delegate void WinEventCallback(IntPtr hook, uint eventId, IntPtr hwnd, int objectId, int childId, uint thread, uint time);
    [DllImport("user32.dll")]
    static extern IntPtr SetWinEventHook(uint min, uint max, IntPtr module, WinEventCallback callback, uint process, uint thread, uint flags);
    [DllImport("user32.dll")]
    static extern bool UnhookWinEvent(IntPtr hook);

    internal void ShowPreview(bool open) {
        preview = true;
        SetExpanded(open);
        Reposition();
    }
}
}
