using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Forms = System.Windows.Forms;
using Drawing = System.Drawing;

namespace LuaMonitor {
public sealed class TaskbarWidgetOptions {
    public bool Enabled, Right, FollowWindow, ClickToOpen;
    public bool Animate = true;
    public int Inset = 24;
    public string Tint = "Violeta";
    public List<string> Metrics = new List<string> { "CPU", "GPU", "RAM", "Temperaturas", "Rede" };

    public void Normalize() {
        Inset = Math.Max(8, Math.Min(240, Inset));
        if (Tint != "Violeta" && Tint != "Verde" && Tint != "Grafite") Tint = "Violeta";
        var valid = (Metrics ?? new List<string>()).Where(TaskbarWidget.MetricNames.Contains).Distinct().ToList();
        Metrics = valid.Count == 0 ? new List<string> { "CPU" } : valid;
    }
}

public sealed class TaskbarWidget : Window {
    internal static readonly string[] MetricNames = { "CPU", "GPU", "RAM", "Temperaturas", "Rede", "FPS", "Disco" };
    static readonly string[] MetricIcons = { "hardware", "gaming", "processes", "hardware", "network", "gaming", "storage" };
    static readonly string[] MetricColors = { "#B9A8FF", "#85DAD6", "#9BD8AE", "#FFBD8A", "#97B6FA", "#E2A9ED", "#DBC7A3" };
    const int CompactHeight = 40;
    const int ExpandedWidth = 340;
    static readonly TimeSpan Frame = TimeSpan.FromMilliseconds(190);

    readonly Func<Drawing.Point> monitorPoint;
    readonly DispatcherTimer hover, closeDelay, placement;
    readonly Button capsule;
    readonly Border capsuleFace, panel;
    readonly Grid layout = new Grid();
    readonly StackPanel capsuleValues = new StackPanel { Orientation = Orientation.Horizontal };
    readonly StackPanel detailRows = new StackPanel();
    readonly ScrollViewer detailScroll;
    readonly Button pin;
    readonly TranslateTransform panelSlide = new TranslateTransform();
    readonly Dictionary<string, TextBlock> smallValues = new Dictionary<string, TextBlock>();
    readonly Dictionary<string, TextBlock> bigValues = new Dictionary<string, TextBlock>();
    readonly Dictionary<string, ProgressBar> bars = new Dictionary<string, ProgressBar>();
    TaskbarWidgetOptions options;
    bool expanded, pinned, preview;
    double compactWidth, panelHeight, scale = 1;
    Drawing.Rectangle workArea, monitorBounds;
    HorizontalAlignment anchor;
    bool dockAtTop;
    long change;

    public TaskbarWidget(ResourceDictionary styles, Func<Drawing.Point> monitorPoint, Action openApp, Action edit) {
        this.monitorPoint = monitorPoint;
        Title = "LUA • Widget da barra de tarefas";
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        ShowActivated = false;
        ShowInTaskbar = false;
        Topmost = true;
        ResizeMode = ResizeMode.NoResize;
        FontFamily = UI.Font;
        Width = 200;
        Height = CompactHeight;
        UseLayoutRounding = true;
        UI.SmoothText(this);
        foreach (System.Collections.DictionaryEntry resource in styles) Resources[resource.Key] = resource.Value;
        SourceInitialized += (sender, args) => {
            var hwnd = new WindowInteropHelper(this).Handle;
            CaptureWindowStyle.Apply(this, false);
            HwndSource.FromHwnd(hwnd).AddHook(WindowMessage);
        };

        var brand = new Border {
            Width = 25, Height = 25, CornerRadius = new CornerRadius(13),
            Margin = new Thickness(0, 0, 9, 0),
            Child = new Viewbox { Width = 17, Height = 17, Child = UI.Moon() }
        };
        var line = new StackPanel { Orientation = Orientation.Horizontal };
        line.Children.Add(brand);
        line.Children.Add(capsuleValues);
        capsuleFace = new Border {
            Height = CompactHeight, CornerRadius = new CornerRadius(20), Padding = new Thickness(8, 0, 12, 0),
            BorderThickness = new Thickness(1), BorderBrush = UI.Brush("#534A67"), Child = line
        };
        brand.Background = UI.Brush("#59448C");
        capsule = new Button { Content = capsuleFace, Height = CompactHeight, Padding = new Thickness(0), Margin = new Thickness(0), Cursor = Cursors.Hand };
        var template = new ControlTemplate(typeof(Button));
        template.VisualTree = new FrameworkElementFactory(typeof(ContentPresenter));
        capsule.Template = template;
        AutomationProperties.SetName(capsule, "Expandir ou fixar informações do LUA");
        capsule.Click += (sender, args) => TogglePin();
        capsule.MouseRightButtonUp += (sender, args) => { edit(); args.Handled = true; };

        detailScroll = new ScrollViewer { Content = detailRows, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var list = new DockPanel { LastChildFill = true };
        var headerTitle = UI.Text("Visão rápida", 20, "#F5F3FA", true);
        var header = new Grid { Margin = new Thickness(0, 0, 0, 10) };
        header.ColumnDefinitions.Add(new ColumnDefinition());
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        header.Children.Add(headerTitle);
        pin = WidgetIconButton("pin", "Fixar painel", TogglePin);
        var settings = WidgetIconButton("settings", "Editar widget", edit);
        var controls = new StackPanel { Orientation = Orientation.Horizontal };
        controls.Children.Add(pin);
        controls.Children.Add(settings);
        Grid.SetColumn(controls, 1);
        header.Children.Add(controls);
        DockPanel.SetDock(header, Dock.Top);
        list.Children.Add(header);
        var open = UI.Button("Abrir painel do LUA  →", openApp);
        open.MinHeight = 32;
        open.Padding = new Thickness(6);
        open.Margin = new Thickness(0, 9, 0, 0);
        DockPanel.SetDock(open, Dock.Bottom);
        list.Children.Add(open);
        list.Children.Add(detailScroll);
        panel = new Border {
            Width = ExpandedWidth, Child = list, Padding = new Thickness(14), RenderTransform = panelSlide,
            CornerRadius = new CornerRadius(22), BorderThickness = new Thickness(1),
            BorderBrush = UI.Brush("#423B50"), Visibility = Visibility.Collapsed
        };
        layout.Children.Add(panel);
        layout.Children.Add(capsule);
        Content = layout;

        hover = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(125) };
        hover.Tick += (sender, args) => { hover.Stop(); if (capsule.IsMouseOver && !options.ClickToOpen) SetExpanded(true); };
        closeDelay = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(255) };
        closeDelay.Tick += (sender, args) => { closeDelay.Stop(); if (!IsMouseOver && !pinned) SetExpanded(false); };
        capsule.MouseEnter += (sender, args) => { if (!expanded && !options.ClickToOpen) hover.Start(); };
        MouseEnter += (sender, args) => closeDelay.Stop();
        MouseLeave += (sender, args) => { hover.Stop(); if (!pinned && expanded) closeDelay.Start(); };
        placement = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        placement.Tick += (sender, args) => Reposition();
        Closed += (sender, args) => { hover.Stop(); closeDelay.Stop(); placement.Stop(); };
    }

    IntPtr WindowMessage(IntPtr hwnd, int message, IntPtr wp, IntPtr lp, ref bool handled) {
        if (message == 0x21) { handled = true; return new IntPtr(3); }
        if (message == 0x02e0 || message == 0x007e) Dispatcher.BeginInvoke(new Action(() => {
            if (placement.IsEnabled) Reposition();
        }));
        return IntPtr.Zero;
    }

    Button WidgetIconButton(string icon, string label, Action click) {
        var button = UI.IconButton(icon, label, click);
        button.Width = button.Height = 31;
        button.MinHeight = 0;
        button.Margin = new Thickness(4, 0, 0, 0);
        return button;
    }

    public void Configure(TaskbarWidgetOptions next) {
        options = next;
        options.Normalize();
        capsuleValues.Children.Clear();
        detailRows.Children.Clear();
        smallValues.Clear();
        bigValues.Clear();
        bars.Clear();
        int summaryCount = Math.Min(3, options.Metrics.Count);
        compactWidth = 52 + 63 * summaryCount;
        capsule.Width = compactWidth;
        string tone = options.Tint == "Verde" ? "#274742" : options.Tint == "Grafite" ? "#333941" : "#432F60";
        capsuleFace.Background = new LinearGradientBrush((Color)ColorConverter.ConvertFromString(tone), Color.FromRgb(19, 18, 25), 10);
        panel.Background = new LinearGradientBrush((Color)ColorConverter.ConvertFromString(tone), Color.FromRgb(19, 18, 25), 135);
        for (int i = 0; i < options.Metrics.Count; i++) {
            string metric = options.Metrics[i];
            int index = Array.IndexOf(MetricNames, metric);
            string color = MetricColors[index];
            if (i < summaryCount) {
                var label = UI.Text(metric == "Temperaturas" ? "TEMP" : metric, 10, color, true);
                var value = UI.Text("—", 12, "#F5F3FA", true);
                var group = UI.Stack(label, value);
                group.Width = 61;
                group.VerticalAlignment = VerticalAlignment.Center;
                capsuleValues.Children.Add(group);
                smallValues[metric] = value;
            }
            var icon = new Border { Width = 28, Height = 28, CornerRadius = new CornerRadius(10),
                Background = UI.Brush("#343044"), Child = UI.Icon(MetricIcons[index], color, 15),
                Margin = new Thickness(0, 0, 9, 0) };
            var header = new StackPanel { Orientation = Orientation.Horizontal };
            header.Children.Add(icon);
            header.Children.Add(UI.Text(metric, 12, "#F5F3FA", true));
            var reading = UI.Text("—", 13, "#F5F3FA", true);
            bigValues[metric] = reading;
            var row = UI.Stack(UI.Row(header, reading));
            if (index < 3 || metric == "Disco") {
                var bar = new ProgressBar { Minimum = 0, Maximum = 100, Height = 3,
                    Foreground = UI.Brush(color), Background = UI.Brush("#3A3646"), Margin = new Thickness(37, 3, 0, 0) };
                bars.Add(metric, bar);
                row.Children.Add(bar);
            }
            detailRows.Children.Add(new Border { Child = row, Background = UI.Brush("#24212E"),
                CornerRadius = new CornerRadius(12), Padding = new Thickness(8, 2, 9, 4), Margin = new Thickness(0, 0, 0, 4) });
        }
        if (placement.IsEnabled || preview) Reposition();
    }

    public void Update(Snapshot snapshot, double? fps) {
        if (options == null) return;
        double? ram = snapshot.RamTotal == 0 ? (double?)null : snapshot.RamPercent;
        double capacity = snapshot.Disks.Sum(d => (double)d.Total);
        double free = snapshot.Disks.Sum(d => (double)d.Free);
        foreach (string metric in options.Metrics) {
            string value, shortValue;
            double? percentage = null;
            switch (metric) {
                case "CPU": percentage = snapshot.Cpu; value = shortValue = Format.Percent(percentage); break;
                case "GPU": percentage = snapshot.Gpu; value = shortValue = Format.Percent(percentage); break;
                case "RAM": percentage = ram; value = shortValue = Format.Percent(percentage); break;
                case "Temperaturas":
                    value = "CPU " + Format.Temp(snapshot.CpuTemp) + "  ·  GPU " + Format.Temp(snapshot.GpuTemp);
                    shortValue = Format.Temp(snapshot.CpuTemp ?? snapshot.GpuTemp);
                    break;
                case "Rede": value = "↓ " + Format.Rate(snapshot.Download) + "   ↑ " + Format.Rate(snapshot.Upload);
                    shortValue = (snapshot.Download * 8 / 1000000).ToString("0.#") + " M"; break;
                case "FPS": value = shortValue = fps.HasValue ? fps.Value.ToString("0") + " FPS" : "—"; break;
                default: percentage = capacity > 0 ? (double?)(100 * (capacity - free) / capacity) : null;
                    shortValue = percentage.HasValue ? Format.Bytes(free) : "—"; value = percentage.HasValue ? shortValue + " livres" : shortValue; break;
            }
            TextBlock small;
            if (smallValues.TryGetValue(metric, out small) && small.Text != shortValue) small.Text = shortValue;
            if (bigValues[metric].Text != value) bigValues[metric].Text = value;
            ProgressBar bar;
            if (bars.TryGetValue(metric, out bar)) {
                double newValue = percentage ?? 0;
                double previous = bar.Value;
                if (Math.Abs(newValue - previous) >= .1) {
                    bar.BeginAnimation(ProgressBar.ValueProperty, null);
                    bar.Value = newValue;
                    if (expanded && CanAnimate && percentage.HasValue)
                        bar.BeginAnimation(ProgressBar.ValueProperty, new DoubleAnimation(previous, newValue, Frame) {
                            FillBehavior = FillBehavior.Stop
                        });
                }
            }
        }
    }

    public void Start() {
        placement.Start();
        Reposition();
    }

    void TogglePin() {
        pinned = !pinned;
        pin.ToolTip = pinned ? "Desafixar painel" : "Fixar painel";
        pin.Background = UI.Brush(pinned ? "#51436C" : "#201D2A");
        AutomationProperties.SetName(pin, (string)pin.ToolTip);
        SetExpanded(pinned);
    }

    void SetExpanded(bool value) {
        if (expanded == value) return;
        expanded = value;
        long transition = ++change;
        bool animate = CanAnimate;
        if (value) {
            panel.Visibility = Visibility.Visible;
            Reposition();
            if (animate) {
                panel.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, Frame));
                panelSlide.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(dockAtTop ? -11 : 11, 0, Frame) {
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                });
            } else {
                panel.BeginAnimation(OpacityProperty, null);
                panelSlide.BeginAnimation(TranslateTransform.YProperty, null);
            }
            return;
        }
        if (!animate) { FinishClose(transition); return; }
        var fade = new DoubleAnimation(panel.Opacity, 0, TimeSpan.FromMilliseconds(120));
        fade.Completed += (sender, args) => FinishClose(transition);
        panel.BeginAnimation(OpacityProperty, fade);
        panelSlide.BeginAnimation(TranslateTransform.YProperty,
            new DoubleAnimation(panelSlide.Y, dockAtTop ? -8 : 8, TimeSpan.FromMilliseconds(120)));
    }

    bool CanAnimate { get { return options.Animate && UI.MotionEnabled && SystemParameters.ClientAreaAnimation; } }

    void FinishClose(long transition) {
        if (transition != change) return;
        panel.Visibility = Visibility.Collapsed;
        panel.BeginAnimation(OpacityProperty, null);
        panelSlide.BeginAnimation(TranslateTransform.YProperty, null);
        Reposition();
    }

    void Reposition() {
        if (options == null) return;
        var screen = options.FollowWindow ? Forms.Screen.FromPoint(monitorPoint()) : Forms.Screen.PrimaryScreen;
        if (screen == null) return;
        workArea = screen.WorkingArea;
        monitorBounds = screen.Bounds;
        dockAtTop = workArea.Top - monitorBounds.Top >= 20;
        if (!preview && FullscreenOnMonitor()) {
            if (IsVisible) Hide();
            if (pinned) TogglePin();
            SetExpanded(false);
            return;
        }
        var handle = new WindowInteropHelper(this).EnsureHandle();
        var source = PresentationSource.FromVisual(this);
        if (source != null) scale = source.CompositionTarget.TransformToDevice.M11;
        bool showingPanel = panel.Visibility == Visibility.Visible;
        anchor = options.Right ? HorizontalAlignment.Right : HorizontalAlignment.Left;
        capsule.HorizontalAlignment = anchor;
        capsule.VerticalAlignment = dockAtTop ? VerticalAlignment.Top : VerticalAlignment.Bottom;
        panel.VerticalAlignment = dockAtTop ? VerticalAlignment.Bottom : VerticalAlignment.Top;
        if (showingPanel) {
            panel.Width = Math.Min(ExpandedWidth, Math.Max(compactWidth, workArea.Width / scale - 20));
            detailRows.Measure(new Size(panel.Width - 31, double.PositiveInfinity));
            panelHeight = Math.Min(116 + detailRows.DesiredSize.Height, Math.Max(123, workArea.Height / scale - CompactHeight - 24));
            panel.Height = panelHeight;
        }
        Width = showingPanel ? panel.Width : compactWidth;
        Height = showingPanel ? panelHeight + CompactHeight + 5 : CompactHeight;
        int inset = (int)Math.Round(options.Inset * scale);
        int width = (int)Math.Ceiling(Width * scale);
        int height = (int)Math.Ceiling(Height * scale);
        int x = options.Right ? workArea.Right - width - inset : workArea.Left + inset;
        x = Math.Max(workArea.Left, Math.Min(x, workArea.Right - width));
        int y = dockAtTop ? workArea.Top + 5 : workArea.Bottom - height - 5;
        SetWindowPos(handle, IntPtr.Zero, x, Math.Max(workArea.Top, y), 0, 0, 0x0001 | 0x0004 | 0x0010);
        if (!IsVisible) Show();
    }

    bool FullscreenOnMonitor() {
        IntPtr foreground = Native.GetForegroundWindow();
        uint process;
        Native.GetWindowThreadProcessId(foreground, out process);
        if (foreground == IntPtr.Zero || foreground == GetShellWindow() || process == (uint)ProcessId) return false;
        NativeRect bounds;
        return GetWindowRect(foreground, out bounds) && bounds.Left <= monitorBounds.Left + 2 &&
            bounds.Top <= monitorBounds.Top + 2 && bounds.Right >= monitorBounds.Right - 2 &&
            bounds.Bottom >= monitorBounds.Bottom - 2 && !workArea.Equals(monitorBounds);
    }

    static readonly int ProcessId = System.Diagnostics.Process.GetCurrentProcess().Id;
    [StructLayout(LayoutKind.Sequential)]
    struct NativeRect { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")]
    static extern bool GetWindowRect(IntPtr hwnd, out NativeRect rectangle);
    [DllImport("user32.dll")]
    static extern IntPtr GetShellWindow();
    [DllImport("user32.dll")]
    static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);

    internal void ShowPreview(bool open) {
        preview = true;
        SetExpanded(open);
        Reposition();
    }
}
}
