using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Text.RegularExpressions;
namespace LuaFpsHost {
public static class CaptureHost {
    [STAThread]public static int Main(string[] args){
        string name=Arg(args,"--pipe"),session=Arg(args,"--session");int target;
        if(!int.TryParse(Arg(args,"--pid"),out target)||target<0||name==null||session==null||!Regex.IsMatch(session,"^LUA_FPS_[a-f0-9]{32}$")||!name.StartsWith(session+"_",StringComparison.Ordinal)||!Regex.IsMatch(name,"^[A-Za-z0-9_\\-]+$"))return 2;
        Process capture=null;object writeGate=new object();int current=-1,sequence=0;string activeSession=null;string exe=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PresentMon.exe");
        Action stop=()=>{var owned=capture;capture=null;if(owned!=null){try{if(!owned.HasExited)owned.Kill();owned.WaitForExit(2500);owned.Dispose();}catch{}}if(activeSession!=null){try{using(var process=Process.Start(new ProcessStartInfo(exe,"--session_name "+activeSession+" --terminate_existing_session"){UseShellExecute=false,CreateNoWindow=true})){if(!process.WaitForExit(2000))process.Kill();}}catch{}activeSession=null;}};
        try{using(var pipe=new NamedPipeClientStream(".",name,PipeDirection.InOut,PipeOptions.Asynchronous)){pipe.Connect(20000);using(var writer=new StreamWriter(pipe,new UTF8Encoding(false),4096,true){AutoFlush=true})using(var reader=new StreamReader(pipe,Encoding.UTF8,false,4096,true)){
            Action<string> send=text=>{if(text==null)return;lock(writeGate){try{writer.WriteLine(text);}catch{}}};
            Action<int> select=pid=>{
                if(current==pid&&(pid==0||(capture!=null&&!capture.HasExited)))return;
                stop();current=pid;if(pid==0){send("LUA_STATUS:Aguardando jogo • assistente pronto");return;}
                activeSession=session+"_"+(++sequence);
                var owned=new Process{StartInfo=new ProcessStartInfo(exe,"--process_id "+pid+" --output_stdout --v2_metrics --track_frame_type --no_console_stats --session_name "+activeSession){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true},EnableRaisingEvents=true};capture=owned;
                owned.OutputDataReceived+=(s,e)=>{if(capture==owned)send(e.Data);};owned.ErrorDataReceived+=(s,e)=>{if(capture==owned)send(e.Data);};owned.Exited+=(s,e)=>{if(capture==owned)send("LUA_STATUS:Captura interrompida. Reative em Métricas e detecção.");};
                try{owned.Start();owned.BeginOutputReadLine();owned.BeginErrorReadLine();}catch(Exception ex){send("LUA_STATUS:Não foi possível iniciar PresentMon: "+ex.Message);stop();}
            };
            select(target);string command;while((command=reader.ReadLine())!=null){if(command=="STOP")break;int pid;if(command.StartsWith("TARGET ",StringComparison.Ordinal)&&int.TryParse(command.Substring(7),out pid)&&pid>=0)select(pid);}
        }}}catch{return 1;}finally{stop();}
        return 0;
    }
    static string Arg(string[] args,string name){int i=Array.IndexOf(args,name);return i>=0&&i+1<args.Length?args[i+1]:null;}
}
}
