﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace LuaFpsHost {
public static class CaptureHost {
    [STAThread] public static int Main(string[] args){
        string name=Arg(args,"--pipe"),session=Arg(args,"--session");int target;
        if(!int.TryParse(Arg(args,"--pid"),out target)||target<=0||name==null||session==null||!Regex.IsMatch(session,"^LUA_FPS_[a-f0-9]{32}$")||!name.StartsWith(session+"_",StringComparison.Ordinal)||!Regex.IsMatch(name,"^[A-Za-z0-9_\\-]+$"))return 2;
        Process capture=null;object writeGate=new object();
        try{using(var pipe=new NamedPipeClientStream(".",name,PipeDirection.InOut,PipeOptions.Asynchronous)){pipe.Connect(20000);using(var writer=new StreamWriter(pipe,new UTF8Encoding(false),4096,true){AutoFlush=true})using(var reader=new StreamReader(pipe,Encoding.UTF8,false,4096,true)){
            Action<string> send=text=>{if(text==null)return;lock(writeGate){try{writer.WriteLine(text);}catch{try{if(capture!=null&&!capture.HasExited)capture.Kill();}catch{}}}};
            string exe=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PresentMon.exe");
            capture=new Process{StartInfo=new ProcessStartInfo(exe,"--process_id "+target+" --output_stdout --v2_metrics --track_frame_type --no_console_stats --session_name "+session+" --terminate_on_proc_exit"){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true}};
            capture.OutputDataReceived+=(s,e)=>send(e.Data);capture.ErrorDataReceived+=(s,e)=>send(e.Data);capture.Start();capture.BeginOutputReadLine();capture.BeginErrorReadLine();
            var commands=new Thread(()=>{try{while(reader.ReadLine()!=null){break;}}catch{}finally{try{if(!capture.HasExited)capture.Kill();}catch{}}}){IsBackground=true};commands.Start();
            capture.WaitForExit();capture.WaitForExit();send("LUA_STATUS:PresentMon encerrou com código "+capture.ExitCode+".");
        }}}catch{return 1;}finally{if(capture!=null){try{if(!capture.HasExited)capture.Kill();capture.Dispose();}catch{}}try{using(var stop=Process.Start(new ProcessStartInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PresentMon.exe"),"--session_name "+session+" --terminate_existing_session"){UseShellExecute=false,CreateNoWindow=true})){if(!stop.WaitForExit(2000))stop.Kill();}}catch{}}
        return 0;
    }
    static string Arg(string[] args,string name){int i=Array.IndexOf(args,name);return i>=0&&i+1<args.Length?args[i+1]:null;}
}
}
