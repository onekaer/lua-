using System;
using System.Globalization;
using System.IO;
using System.Text;
using Microsoft.Win32;
namespace LuaMonitor {
// Read-only, fixed-location telemetry. No commands or user paths cross into the service.
public static class SensorServiceInfo {
    public const string Name="LuaCpuSensors";
    public static string DirectoryPath{get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"LUA Sensors");}}
    public static string ExecutablePath{get{return Path.Combine(DirectoryPath,"LuaSensorsHost.exe");}}
    public static string Command{get{return "\""+ExecutablePath+"\" --service";}}
    public static string TelemetryPath{get{return Path.Combine(DirectoryPath,"cpu-temperature.txt");}}
    public static bool Installed(){try{using(var key=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\"+Name)){return key!=null&&string.Equals(key.GetValue("ImagePath") as string,Command,StringComparison.OrdinalIgnoreCase)&&File.Exists(ExecutablePath);}}catch{return false;}}
    public static bool Parse(string text,DateTime now,out string line){line=null;if(text==null||text.Length>512)return false;var parts=text.Split(new[]{'\n'},2);long ticks;if(parts.Length!=2||!long.TryParse(parts[0],out ticks)||ticks<DateTime.MinValue.Ticks||ticks>DateTime.MaxValue.Ticks)return false;double age=(now-new DateTime(ticks,DateTimeKind.Utc)).TotalSeconds;if(age < -2||age>6)return false;string value=parts[1].Trim();double temperature;if(value.StartsWith("TEMP:")&&double.TryParse(value.Substring(5),NumberStyles.Float,CultureInfo.InvariantCulture,out temperature)&&!double.IsNaN(temperature)&&!double.IsInfinity(temperature)&&temperature>0&&temperature<=150){line=value;return true;}if(value=="STATUS:Sensor da CPU sem leitura. Confira o PawnIO e a permissão."){line=value;return true;}return false;}
    public static bool TryRead(out string line){line=null;try{using(var file=new FileStream(TelemetryPath,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){if(file.Length>512)return false;using(var reader=new StreamReader(file,Encoding.UTF8))return Parse(reader.ReadToEnd(),DateTime.UtcNow,out line);}}catch{return false;}}
}
}
