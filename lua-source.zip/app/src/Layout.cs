using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace LuaMonitor {
public static partial class UI {
    public static bool Compact=true,MotionEnabled=true;
    public static readonly FontFamily Font=new FontFamily("Segoe UI");
    public static Canvas Moon(){
        var canvas=new Canvas{Width=34,Height=36};
        var geometry=Geometry.Combine(new EllipseGeometry(new Point(18,18),14,14),new EllipseGeometry(new Point(24,12),12,12),GeometryCombineMode.Exclude,null);
        canvas.Children.Add(new System.Windows.Shapes.Path{Data=geometry,Fill=Brush("#EAEAF2")});
        var star=new System.Windows.Shapes.Ellipse{Width=3,Height=3,Fill=Brush("#84A7F7")};Canvas.SetLeft(star,26);Canvas.SetTop(star,6);canvas.Children.Add(star);return canvas;
    }
    public static void Enter(FrameworkElement element,double distance=7){
        if(!MotionEnabled)return;
        var fade=new DoubleAnimation(0,1,TimeSpan.FromMilliseconds(140)){FillBehavior=FillBehavior.Stop};fade.Completed+=(s,e)=>{element.Opacity=1;};element.BeginAnimation(UIElement.OpacityProperty,fade);

    }
    public static Grid Inline(params UIElement[] children){var g=new Grid();for(int i=0;i<children.Length;i++){g.ColumnDefinitions.Add(new ColumnDefinition());var item=children[i] as FrameworkElement;if(item!=null)item.Margin=new Thickness(i==0?0:6,0,i==children.Length-1?0:6,10);Grid.SetColumn(children[i],i);g.Children.Add(children[i]);}return g;}
    public static Grid Adaptive(params UIElement[] children){if(!Compact)return Inline(children);var g=new Grid();for(int i=0;i<children.Length;i++){g.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});var item=children[i] as FrameworkElement;if(item!=null)item.Margin=new Thickness(0,0,0,12);Grid.SetRow(children[i],i);g.Children.Add(children[i]);}return g;}
}
public sealed partial class DesktopController {
    bool compact=true;
    Dictionary<string,Button> compactButtons=new Dictionary<string,Button>();
    void AddCompactNav(string id,string icon,string label){
        var glyph=UI.Icon(id,"#9B9BA4",20);
        var b=new Button{Content=glyph,Style=(Style)window.FindResource("IconNav"),ToolTip=label};b.Click+=(s,e)=>BuildPage(id);
        Find<UniformGrid>("CompactNavPanel").Children.Add(b);compactButtons[id]=b;System.Windows.Automation.AutomationProperties.SetName(b,label);
    }
    void SelectNavigation(){
        foreach(var pair in compactButtons){bool active=pair.Key==page||(page=="cleanup"&&pair.Key=="storage");pair.Value.Background=UI.Brush(active?"#252929":"Transparent");((FluentIcon)pair.Value.Content).Tint=UI.Brush(active?"#F0F1EF":"#A5AAA7");}
    }
    void SetMode(bool small,bool animate=true){
        if(widgetSurface){compact=true;UI.Compact=true;BuildPage(page);return;}compact=small;UI.Compact=small;Find<Border>("RootSurface").LayoutTransform=new ScaleTransform(prefs.UiScale,prefs.UiScale);window.WindowState=WindowState.Normal;
        window.FontFamily=UI.Font;Find<ContentControl>("LogoHost").Content=UI.Moon();
        Find<Border>("Sidebar").Visibility=small?Visibility.Collapsed:Visibility.Visible;
        Find<ColumnDefinition>("SidebarColumn").Width=new GridLength(small?0:220);
        Find<Border>("CompactNavigation").Visibility=small?Visibility.Visible:Visibility.Collapsed;
        Find<RowDefinition>("CompactNavRow").Height=new GridLength(small?60:0);
        Find<RowDefinition>("HeaderRow").Height=new GridLength(small?66:60);
        Find<RowDefinition>("PageHeadingRow").Height=new GridLength(small?33:68);
        Find<Grid>("CompactActions").Visibility=small?Visibility.Visible:Visibility.Collapsed;
        Find<RowDefinition>("ActionsRow").Height=new GridLength(small?60:0);
        Find<TextBlock>("PageDescription").Visibility=small?Visibility.Collapsed:Visibility.Visible;
        Find<TextBlock>("ShortcutFooter").Visibility=small?Visibility.Collapsed:Visibility.Visible;
        Find<StackPanel>("Brand").HorizontalAlignment=small?HorizontalAlignment.Center:HorizontalAlignment.Left;
        Find<StackPanel>("Brand").Margin=small?new Thickness(-25,0,0,0):new Thickness(11,0,0,0);
        Find<TextBlock>("BrandSubtitle").Visibility=small?Visibility.Collapsed:Visibility.Visible;
        Find<Button>("MinButton").Visibility=small?Visibility.Collapsed:Visibility.Visible;
        Find<Grid>("ContentArea").Margin=small?new Thickness(18,1,18,0):new Thickness(24,16,24,12);
        title.FontSize=small?13:28;
        Find<Button>("ExpandButton").Content=UI.Icon(small?"expand":"compact",size:16);
        Find<Button>("ExpandButton").ToolTip=small?"Expandir painel":"Voltar ao modo compacto";
        window.Topmost=small;window.ShowInTaskbar=!small;
        var area=SystemParameters.WorkArea;
        window.Width=small?Math.Min(420*prefs.UiScale,area.Width-12):Math.Min(1280*prefs.UiScale,area.Width-30);
        window.Height=small?Math.Min(770*prefs.UiScale,area.Height-12):Math.Min(860*prefs.UiScale,area.Height-30);
        window.Left=small?area.Right-window.Width-4:area.Left+(area.Width-window.Width)/2;
        window.Top=small?area.Bottom-window.Height-4:area.Top+(area.Height-window.Height)/2;
        RoundOpaqueWindow();BuildPage(page);if(animate)UI.Enter(Find<Border>("RootSurface"),small?8:3);
    }
    void CompactHome(){
        var temperatures=UI.Stack(UI.Text("Temperaturas",14,"#C5C5CD",true));
        var cpu=UI.Card(UI.Stack(UI.Label("CPU"),Value(s=>Format.Temp(s.CpuTemp),23,"#F1F1F4",true)),10);
        var gpu=UI.Card(UI.Stack(UI.Label("GPU"),Value(s=>Format.Temp(s.GpuTemp),23,"#F1F1F4",true)),10);
        cpu.Background=UI.Brush("#1B1D1D");gpu.Background=UI.Brush("#1B1D1D");cpu.ToolTip="Temperatura real da CPU • clique para ativar ou reconectar";cpu.Cursor=System.Windows.Input.Cursors.Hand;cpu.MouseLeftButtonUp+=(s,e)=>CpuSensorDialog();
        temperatures.Children.Add(UI.Inline(cpu,gpu));
        var card=UI.Stack(temperatures,ThinLine(),UI.Text("Uso de hardware",14,"#C5C5CD",true));if(widgetSurface&&widgetId=="home"&&prefs.ShowFps){card.Children.Insert(0,HomeWidgetFps());card.Children.Insert(1,ThinLine());}
        card.Children.Add(UI.Row(UI.Label("CPU"),Value(s=>Format.Percent(s.Cpu),15,"#E9E9EE",true)));
        card.Children.Add(Chart(CpuHistory,"#E5BD67",32));
        card.Children.Add(UI.Row(UI.Label("GPU"),Value(s=>Format.Percent(s.Gpu),15,"#E9E9EE",true)));
        card.Children.Add(Chart(GpuHistory,"#74CBB2",32));
        card.Children.Add(ThinLine());
        card.Children.Add(UI.Row(UI.Text("Memória",14,"#C5C5CD",true),Value(s=>Format.Percent(s.RamPercent),13,"#AABBE0",true)));
        card.Children.Add(Value(s=>Format.Bytes(s.RamTotal-s.RamAvailable)+" / "+Format.Bytes(s.RamTotal),11,"#ABABB4"));
        card.Children.Add(Bar(s=>s.RamPercent));
        card.Children.Add(ThinLine());
        card.Children.Add(UI.Row(Value(s=>"↓ "+Format.Rate(s.Download),11,"#A3C7E3"),Value(s=>"↑ "+Format.Rate(s.Upload),11,"#A4BAE6")));
        var free=UI.Row(UI.Text("ESPAÇO LIVRE",11,"#BCC8DF",true),Value(s=>Format.Bytes(s.Disks.Sum(d=>(double)d.Free)),18,"#D7E5FF",true));var freeCard=UI.Card(free,8);freeCard.Background=UI.Brush("#1A2421");freeCard.BorderBrush=UI.Brush("#2C3934");freeCard.Margin=new Thickness(0,7,0,0);card.Children.Add(freeCard);
        var outer=UI.Card(card,16);outer.Margin=new Thickness(0);body.Children.Add(outer);
    }
    Border ThinLine(){return new Border{Height=1,Background=UI.Brush("#2B2D2D"),Margin=new Thickness(0,9,0,9)};}
    Border SmallMetric(string label,Func<Snapshot,string> value,string note){return UI.Card(UI.Stack(UI.Text(label,9,"#AFAFB8",true),Value(value,20,"#EFEFF4",true),UI.Text(note,9,"#91919B")),11);}
    void CompactNetworkMetrics(){
        var download=UI.Card(UI.Stack(UI.Text("↓ DOWNLOAD",9,"#AFAFB8",true),Value(s=>Format.Rate(s.Download),20,"#92C8EA",true),Value(s=>Format.Bytes(s.Download)+"/s",10,"#93939F"),Chart(DownHistory,"#82C5E8",27,true)),12);
        var upload=UI.Card(UI.Stack(UI.Text("↑ UPLOAD",9,"#AFAFB8",true),Value(s=>Format.Rate(s.Upload),20,"#9EBBF1",true),Value(s=>Format.Bytes(s.Upload)+"/s",10,"#93939F"),Chart(UpHistory,"#9EBBF1",27,true)),12);
        body.Children.Add(UI.Inline(download,upload));
    }
}
}
