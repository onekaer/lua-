using System;
using System.IO;
using System.Runtime.InteropServices;
namespace LuaMonitor {
public static class DesktopShortcut {
    public static string Create(string folder,string executable){
        executable=Path.GetFullPath(executable);if(!File.Exists(executable))throw new FileNotFoundException("Executável do LUA não encontrado.",executable);
        Directory.CreateDirectory(folder);object shellObject=null,linkObject=null;
        try{shellObject=Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));dynamic shell=shellObject;
            for(int n=0;n<100;n++){
                string path=Path.Combine(folder,n==0?"LUA.lnk":"LUA Monitor"+(n==1?"":" "+n)+".lnk");
                linkObject=shell.CreateShortcut(path);dynamic link=linkObject;
                bool owned=!File.Exists(path)||string.Equals((string)link.TargetPath,executable,StringComparison.OrdinalIgnoreCase)||((string)link.Description??"").StartsWith("LUA • Monitor",StringComparison.Ordinal);
                if(!owned){Marshal.FinalReleaseComObject(linkObject);linkObject=null;continue;}
                link.TargetPath=executable;link.WorkingDirectory=Path.GetDirectoryName(executable);link.Arguments="";link.Description="LUA • Monitor, capturas e organização";link.IconLocation=executable+",0";link.Save();return path;
            }
            throw new IOException("Não foi possível escolher um nome livre para o atalho.");
        }finally{if(linkObject!=null)Marshal.FinalReleaseComObject(linkObject);if(shellObject!=null)Marshal.FinalReleaseComObject(shellObject);}
    }
}
public sealed partial class DesktopController {
    void EnsureDesktopShortcut(){if(verify||sharedOwner!=null)return;string current=System.Reflection.Assembly.GetExecutingAssembly().Location;if(prefs.DesktopShortcutDone&&string.Equals(prefs.DesktopShortcutTarget,current,StringComparison.OrdinalIgnoreCase))return;try{DesktopShortcut.Create(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),current);prefs.DesktopShortcutDone=true;prefs.DesktopShortcutTarget=current;Save();}catch{}}
    void CreateDesktopShortcut(){if(sharedOwner!=null){sharedOwner.CreateDesktopShortcut();return;}try{string current=System.Reflection.Assembly.GetExecutingAssembly().Location;DesktopShortcut.Create(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),current);prefs.DesktopShortcutDone=true;prefs.DesktopShortcutTarget=current;Save();ShowToast("Atalho criado","O LUA está na sua Área de Trabalho.");}catch(Exception ex){Notice("Não foi possível criar o atalho: "+ex.Message);}}
}
}
