﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using Forms=System.Windows.Forms;
namespace LuaMonitor {
public static class ShortcutKeys {
    public static bool Parse(string text,out uint modifiers,out uint key){modifiers=0;key=0;if(string.IsNullOrWhiteSpace(text))return false;foreach(string part in text.Split('+')){if(part.Equals("Ctrl",StringComparison.OrdinalIgnoreCase))modifiers|=2;else if(part.Equals("Alt",StringComparison.OrdinalIgnoreCase))modifiers|=1;else if(part.Equals("Shift",StringComparison.OrdinalIgnoreCase))modifiers|=4;else{Forms.Keys value;if(!Enum.TryParse<Forms.Keys>(part,true,out value))return false;key=(uint)value;}}return modifiers!=0&&key>0&&key<256;}
    public static string FromEvent(KeyEventArgs e){Key key=e.Key==Key.System?e.SystemKey:e.Key;if(key==Key.LeftCtrl||key==Key.RightCtrl||key==Key.LeftAlt||key==Key.RightAlt||key==Key.LeftShift||key==Key.RightShift||key==Key.LWin||key==Key.RWin)return null;var mods=Keyboard.Modifiers;if((mods&ModifierKeys.Windows)!=0||mods==ModifierKeys.None)return null;return ((mods&ModifierKeys.Control)!=0?"Ctrl+":"")+((mods&ModifierKeys.Alt)!=0?"Alt+":"")+((mods&ModifierKeys.Shift)!=0?"Shift+":"")+((Forms.Keys)KeyInterop.VirtualKeyFromKey(key)).ToString();}
}
public sealed partial class DesktopController {
    Dictionary<int,string> VideoKeys(){return new Dictionary<int,string>{{77,prefs.Hotkey},{83,prefs.WorkspaceKey},{78,prefs.Clip30Key},{79,prefs.Clip60Key},{80,prefs.RecordKey},{81,prefs.Clip120Key},{82,prefs.PrintKey}};}
    void SetVideoKey(int id,string value){switch(id){case 77:prefs.Hotkey=value;break;case 83:prefs.WorkspaceKey=value;break;case 78:prefs.Clip30Key=value;break;case 79:prefs.Clip60Key=value;break;case 80:prefs.RecordKey=value;break;case 81:prefs.Clip120Key=value;break;case 82:prefs.PrintKey=value;break;}}
    bool ApplyVideoKey(int id,string value){if(sharedOwner!=null)return sharedOwner.ApplyVideoKey(id,value);uint modifiers,key;if(!ShortcutKeys.Parse(value,out modifiers,out key)){ShowToast("Atalho inválido","Use Ctrl, Alt ou Shift junto de outra tecla.");return false;}var others=VideoKeys().Where(p=>p.Key!=id).Select(p=>p.Value);if(others.Any(k=>string.Equals(k,value,StringComparison.OrdinalIgnoreCase))){ShowToast("Atalho já usado no LUA","Escolha uma combinação diferente para cada ação.");return false;}if(VideoKeys()[id]==value)return true;
        if(!verify){var handle=new WindowInteropHelper(window).Handle;if(!Native.RegisterHotKey(handle,199,modifiers|0x4000,key)){ShowToast("Atalho indisponível","Essa combinação já está sendo usada por outro aplicativo.");return false;}Native.UnregisterHotKey(handle,199);}SetVideoKey(id,value);if(!verify)RegisterVideoShortcuts();Save();return true;
    }
    void RegisterVideoShortcuts(){if(sharedOwner!=null){sharedOwner.RegisterVideoShortcuts();return;}var handle=new WindowInteropHelper(window).Handle;videoHotkeyError="";foreach(var pair in VideoKeys()){Native.UnregisterHotKey(handle,pair.Key);uint modifiers,key;if(!ShortcutKeys.Parse(pair.Value,out modifiers,out key)||!Native.RegisterHotKey(handle,pair.Key,modifiers|0x4000,key))videoHotkeyError+=pair.Value+" indisponível. ";}}
    UIElement ShortcutField(string label,int id){string saved=VideoKeys()[id];var field=new TextBox{Text=saved,IsReadOnly=true,Padding=new Thickness(10),Margin=new Thickness(0,5,0,12),ToolTip="Clique e pressione a combinação desejada"};field.GotKeyboardFocus+=(s,e)=>{field.Text="Pressione o novo atalho…";};field.LostKeyboardFocus+=(s,e)=>field.Text=VideoKeys()[id];field.PreviewKeyDown+=(s,e)=>{if(e.Key==Key.Tab)return;e.Handled=true;if(e.Key==Key.Escape){field.Text=VideoKeys()[id];Keyboard.ClearFocus();return;}string value=ShortcutKeys.FromEvent(e);if(value!=null){if(ApplyVideoKey(id,value))field.Text=value;else field.Text=VideoKeys()[id];Keyboard.ClearFocus();}};return UI.Stack(UI.Label(label),field);}
    UIElement CaptureShortcutOptions(){return UI.Stack(UI.Text("Clique em um campo e pressione a combinação desejada. Esc cancela. Os atalhos funcionam com o painel recolhido.",12,"#9999AC"),ShortcutField("Iniciar / parar gravação",80),ShortcutField("Salvar últimos 30 segundos",78),ShortcutField("Salvar último minuto",79),ShortcutField("Salvar últimos 2 minutos",81),ShortcutField("Tirar print",82),ShortcutField("Sobreposição de FPS e métricas",77),ShortcutField("Sobreposição completa",83),UI.Text(videoHotkeyError==""?"Use combinações diferentes para cada ação.":videoHotkeyError,11,"#AAAABD"));}
}
}
