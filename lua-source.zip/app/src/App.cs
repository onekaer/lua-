using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using Forms=System.Windows.Forms;

namespace LuaMonitor {
public static class Entry {
    static Mutex single;
    public static string EventName(string name){return "Local\\LuaMonitor_"+name+"_"+WindowsIdentity.GetCurrent().User.Value;}
    [STAThread] public static int Main(string[] args){
        bool verify=args.Contains("--verify");
        int dataIndex=Array.IndexOf(args,"--data"); if(dataIndex>=0&&dataIndex+1<args.Length)Preferences.DataDir=Path.GetFullPath(args[dataIndex+1]);
        if(args.Contains("--verify-sensor-service"))return DistributionChecks.RunSensorService();if(args.Contains("--verify-package"))return DistributionChecks.Run();if(args.Contains("--update-smoke")&&Preferences.DataDir!=Preferences.DefaultDataDir){Directory.CreateDirectory(Preferences.DataDir);File.WriteAllText(Path.Combine(Preferences.DataDir,"update-smoke.txt"),AppUpdate.Current);return 0;}if(args.Contains("--apply-update"))return UpdateInstaller.Run(args);
        int waitIndex=Array.IndexOf(args,"--wait-parent");if(waitIndex>=0&&waitIndex+1<args.Length){int parent;if(int.TryParse(args[waitIndex+1],out parent))try{using(var p=Process.GetProcessById(parent))p.WaitForExit(15000);}catch{}}
        if(!verify){bool created;single=new Mutex(true,"Local\\LuaMonitor_Desktop_"+WindowsIdentity.GetCurrent().User.Value,out created);if(!created){try{using(var signal=EventWaitHandle.OpenExisting(EventName(args.Contains("--overlay")?"Overlay":"Main")))signal.Set();}catch{MessageBox.Show("O LUA já está aberto. Clique no ícone da bandeja, ao lado do relógio.","LUA");}single.Dispose();return 0;}}
        var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};SynchronizationContext.SetSynchronizationContext(new DispatcherSynchronizationContext(app.Dispatcher));
        app.DispatcherUnhandledException+=(s,e)=>{try{Directory.CreateDirectory(Preferences.DataDir);File.AppendAllText(Path.Combine(Preferences.DataDir,"error.log"),DateTime.Now+" "+e.Exception+Environment.NewLine);}catch{}MessageBox.Show("O LUA encontrou um erro: "+e.Exception.Message,"LUA");e.Handled=true;};
        try{var controller=new DesktopController(app,verify);controller.Start(args);app.Run();return controller.ExitCode;}
        catch(Exception ex){if(verify){File.WriteAllText(Path.Combine(Preferences.DataDir,"fatal.txt"),ex.ToString());return 1;}MessageBox.Show(ex.Message,"LUA • não foi possível iniciar");return 1;}
        finally{if(single!=null){try{single.ReleaseMutex();}catch{}single.Dispose();}}
    }
}
public sealed partial class DesktopController {
    Application app; Window window; StackPanel body,nav; TextBlock title,description,footer;
    Preferences prefs; MonitorService service; FpsReader fps=new FpsReader(); Snapshot snapshot=new Snapshot(); Inventory inventory=new Inventory();
    DispatcherTimer timer; Task sampling=Task.FromResult(0); bool closing,verify; Forms.NotifyIcon tray; OverlayWindow overlay; HwndSource source;
    EventWaitHandle showSignal,overlaySignal; RegisteredWaitHandle showWait,overlayWait;
    string page="home",hotkeyError=""; Border overlayPreviewHost; List<Action<Snapshot>> updates=new List<Action<Snapshot>>(); List<Sparkline> charts=new List<Sparkline>();
    Dictionary<string,Button> navButtons=new Dictionary<string,Button>();
    public List<double> CpuHistory=new List<double>(),GpuHistory=new List<double>(),RamHistory=new List<double>(),DownHistory=new List<double>(),UpHistory=new List<double>();
    CancellationTokenSource scanCancel; ScanResult scanResult; ScanProgress scanProgress; bool scanning; string scanRoot=Environment.GetFolderPath(Environment.SpecialFolder.UserProfile); StackPanel scanArea;
    ProcessReader processReader=new ProcessReader(); List<ProcessValue> processes=new List<ProcessValue>(); StackPanel processArea; string processSearch="",processSort="Memória"; DateTime processRead=DateTime.MinValue; bool processReading;
    string pingResult="Verifique a latência e a perda de pacotes para um endereço."; bool pingBusy;
    int targetPid; string targetName=""; bool exiting; DateTime lastNotification=DateTime.MinValue; public int ExitCode;
    public DesktopController(Application a,bool test,DesktopController owner=null){sharedOwner=owner;app=a;verify=test;prefs=owner==null?Preferences.Load():owner.prefs;prefs.UpgradeDefaults();UI.CacheLimitMb=prefs.CacheMb;UI.FoldStates=prefs.Folds;UI.FoldSave=Save;UI.HighContrast=prefs.HighContrast||SystemParameters.HighContrast;if(!prefs.GridDefaultApplied){prefs.GamesGrid=true;prefs.GridDefaultApplied=true;}EnsureProfiles();service=owner==null?new MonitorService(prefs):owner.service;if(owner!=null){fps=owner.fps;snapshot=owner.snapshot;inventory=owner.inventory;recorder=owner.recorder;}using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("LUA.MainWindow.xaml"))window=(Window)XamlReader.Load(stream);if(owner==null)app.MainWindow=window;
        body=Find<StackPanel>("PageBody");nav=Find<StackPanel>("NavPanel");title=Find<TextBlock>("PageTitle");description=Find<TextBlock>("PageDescription");footer=Find<TextBlock>("Footer");
        Find<Border>("TitleBar").MouseLeftButtonDown+=(s,e)=>{
            if(e.ClickCount==2)ToggleMaximized();
            else if(!taskbarDocked)try{window.DragMove();}catch(InvalidOperationException){}
        };
        window.PreviewKeyDown+=(s,e)=>{
            if(e.Key==Key.Escape&&taskbarDocked){ window.Hide(); e.Handled=true; }
        };
        window.IsVisibleChanged+=(s,e)=>{ if(!window.IsVisible)ReleaseTaskbarPanel(); };
        Find<Button>("MinButton").Click+=(s,e)=>window.WindowState=WindowState.Minimized;
        Find<Button>("MinButton").ToolTip="Minimizar janela";
        System.Windows.Automation.AutomationProperties.SetName(Find<Button>("MinButton"),"Minimizar janela");
        Find<Button>("TrayButton").Click+=(s,e)=>window.Close();
        Find<Button>("ExpandButton").Click+=(s,e)=>SetMode(!compact);
        Find<Button>("MaximizeButton").Click+=(s,e)=>ToggleMaximized();
        window.StateChanged+=(s,e)=>UpdateMaximizeButton();
        UpdateMaximizeButton();
        Find<Button>("CloseButton").Click+=(s,e)=>window.Close();
        window.SizeChanged+=(s,e)=>UpdateWindowNavigation(e.NewSize.Width);
        window.FontFamily=UI.Font;UI.SmoothText(window);window.SizeChanged+=(s,e)=>RoundOpaqueWindow();Find<Button>("TrayButton").Content=UI.Icon("close",size:17);Find<Button>("CloseButton").Content=UI.Icon("close",size:17);Find<Button>("MinButton").Content=UI.Icon("minimize",size:17);
        Find<Button>("NavSettingsButton").Content=UI.Icon("settings",size:16);Find<Button>("NavSettingsButton").Click+=(s,e)=>BuildPage("settings");Find<StackPanel>("Brand").ToolTip="Voltar ao Início";Find<StackPanel>("Brand").MouseLeftButtonDown+=(s,e)=>{BuildPage("home");e.Handled=true;};
        Find<Button>("UpdateTitleButton").Click+=(s,e)=>InstallAppUpdate();Find<Button>("UpdateCompactButton").Click+=(s,e)=>InstallAppUpdate();
        window.Closing+=(s,e)=>{if(!closing&&sharedOwner!=null){e.Cancel=true;window.Hide();sharedOwner.HideWidget(this);return;}if(!closing){e.Cancel=true;if(taskbarDocked||prefs.MinimizeOnClose)window.Hide();else ExitApp();}};
        window.SourceInitialized+=(s,e)=>{source=HwndSource.FromHwnd(new WindowInteropHelper(window).Handle);source.AddHook(MessageHook);RoundOpaqueWindow();if(!verify&&sharedOwner==null)RegisterShortcut();};
        AddNav("home","\uE80F","Início");AddNav("hardware","\uE950","Hardware");AddNav("network","\uE774","Rede e internet");AddNav("storage","\uEDA2","Armazenamento");AddNav("processes","\uE9D9","Processos");AddNav("gaming","\uE7FC","Jogos e FPS");AddNav("analysis","\uE9F9","Analisar PC");AddNav("overlay","\uE91B","Sobreposição");
        AddNav("games","\uE7FC","Jogos");AddNav("recording","\uE714","Capturas");AddNav("gallery","\uE91B","Galeria");AddNav("tools","\uE713","Ferramentas");AddNav("cleanup","\uE74D","Limpeza e duplicados");AddCompactNav("settings","\uE713","Configurações");
        SetupNavigation();
        UI.MotionEnabled=prefs.Animations;ApplyAccent();SetMode(true,false);
    }
    T Find<T>(string name) where T:class {return (T)window.FindName(name);}
    void AddNav(string id,string icon,string label) {
        var content=new Grid();
        content.ColumnDefinitions.Add(new ColumnDefinition { Width=GridLength.Auto });
        content.ColumnDefinitions.Add(new ColumnDefinition());
        var glyph=UI.Icon(id=="tools"?"grid":id,"#B2AFBC",18);
        glyph.Margin=new Thickness(0,0,11,0);
        content.Children.Add(glyph);
        var caption=UI.Text(id=="cleanup"?"Limpeza":label,14,"#C4C1CD");
        caption.TextWrapping=TextWrapping.NoWrap;
        caption.TextTrimming=TextTrimming.CharacterEllipsis;
        Grid.SetColumn(caption,1);
        content.Children.Add(caption);
        var button=new Button { Content=content, Style=(Style)window.FindResource("Nav"), ToolTip=label };
        System.Windows.Automation.AutomationProperties.SetName(button,label);
        button.Click+=(s,e)=>BuildPage(id);
        navButtons[id]=button;
        AddCompactNav(id,icon,label);
    }
    public void Start(string[] args){
        if(!verify){EnsureDesktopShortcut();Save();SetupTray();showSignal=new EventWaitHandle(false,EventResetMode.AutoReset,Entry.EventName("Main"));overlaySignal=new EventWaitHandle(false,EventResetMode.AutoReset,Entry.EventName("Overlay"));showWait=ThreadPool.RegisterWaitForSingleObject(showSignal,(s,t)=>window.Dispatcher.BeginInvoke(new Action(ShowExpandedMain)),null,-1,false);overlayWait=ThreadPool.RegisterWaitForSingleObject(overlaySignal,(s,t)=>window.Dispatcher.BeginInvoke(new Action(ToggleOverlay)),null,-1,false);}SetMode(verify&&!args.Contains("--expanded"),false);window.Show();UI.Enter(Find<Border>("RootSurface"));if(args.Contains("--tray"))window.Hide();
        timer=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(prefs.Interval)};timer.Tick+=async(s,e)=>await SampleAsync();timer.Start();
        if(!verify||!args.Contains("--verify-appearance"))InitializeInventory();
        Task.Run(()=>LocalHistory.TrimCache(prefs.CacheMb));if(!verify)ApplyTaskbarWidget();StartPlaytime();var initial=SampleAsync();var catalogLoad=LoadGames();if(!verify){EnsureAutoReplay();CheckAppUpdates(false);if(prefs.CpuSensorAssist&&CpuSensorBridge.DriverInstalled())StartCpuSensors(false,true);} if(args.Contains("--overlay"))ToggleOverlay();
        if(verify)window.Dispatcher.BeginInvoke(new Action(async()=>await Verify()),DispatcherPriority.ApplicationIdle);
    }
    void SetupTray(){trayRecording=new System.Drawing.Icon(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"src","LUA-recording.ico"),Forms.SystemInformation.SmallIconSize);tray=new Forms.NotifyIcon{Text="LUA • Monitor do sistema",Visible=true,Icon=trayNormal=new System.Drawing.Icon(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"src","LUA.ico"),Forms.SystemInformation.SmallIconSize)};var menu=new Forms.ContextMenuStrip();menu.Items.Add("Abrir LUA compacto",null,(s,e)=>{SetMode(true,false);ShowMain();});menu.Items.Add("Abrir LUA",null,(s,e)=>ShowExpandedMain());menu.Items.Add("Sobreposição completa ("+prefs.WorkspaceKey+")",null,(s,e)=>ToggleWorkspace());menu.Items.Add("Sobreposição ("+prefs.Hotkey+")",null,(s,e)=>ToggleOverlay());menu.Items.Add("Galeria",null,(s,e)=>{ShowMain();BuildPage("gallery");});menu.Items.Add("Tirar print",null,(s,e)=>TakeScreenshot());menu.Items.Add("Gravação e clipes",null,(s,e)=>{ShowMain();BuildPage("gallery");ShowCaptureDialog();});menu.Items.Add("Iniciar / parar gravação",null,(s,e)=>ToggleRecording());menu.Items.Add("Salvar últimos 30 s",null,(s,e)=>SaveReplay(30));menu.Items.Add("Salvar último 1 min",null,(s,e)=>SaveReplay(60));menu.Items.Add("Desligar buffer",null,(s,e)=>{if(recorder!=null&&recorder.Replaying)ToggleReplay();});menu.Items.Add("Editar widget da barra de tarefas",null,(s,e)=>EditTaskbarWidget());menu.Items.Add("Configurações",null,(s,e)=>{ShowMain();BuildPage("settings");});menu.Items.Add(new Forms.ToolStripSeparator());menu.Items.Add("Sair do LUA",null,(s,e)=>ExitApp());tray.ContextMenuStrip=menu;tray.MouseClick+=(s,e)=>{if(e.Button==Forms.MouseButtons.Left)ShowExpandedMain();};}
    void ShowMain(){
        if(sharedOwner==null&&workspaceBar!=null&&workspaceBar.IsVisible)SetWorkspace(false);
        window.Show();
        if(window.WindowState==WindowState.Minimized)window.WindowState=WindowState.Normal;
        if(!DockTaskbarPanel()&&taskbarHomeHost!=null)SetMode(true,false);
        window.Activate();
        UI.Enter(Find<Border>("RootSurface"));
    }
    void Save(){if(verify)return;try{prefs.Save();}catch(Exception ex){Notice("Não foi possível salvar: "+ex.Message);}}
    void ApplyAccent(){string color=prefs.Accent=="Cinza"?"#B2B2B9":UI.Violet;window.Resources["Accent"]=UI.Brush(color);}
    void RegisterShortcut(){if(sharedOwner!=null){sharedOwner.RegisterShortcut();return;}RegisterVideoShortcuts();IntPtr h=new WindowInteropHelper(window).Handle;Native.UnregisterHotKey(h,77);uint modifiers=0,key=0;foreach(string part in prefs.Hotkey.Split('+')){if(part=="Ctrl")modifiers|=2;else if(part=="Shift")modifiers|=4;else if(part=="Alt")modifiers|=1;else{Forms.Keys parsed;if(Enum.TryParse<Forms.Keys>(part,true,out parsed))key=(uint)parsed;}}hotkeyError=key!=0&&Native.RegisterHotKey(h,77,modifiers|0x4000,key)?"":"Esse atalho está em uso. Escolha outro nas configurações.";Find<TextBlock>("ShortcutFooter").Text=hotkeyError==""?prefs.Hotkey+"  ·  Sobreposição":"Atalho indisponível";}
    IntPtr MessageHook(IntPtr hwnd,int msg,IntPtr wp,IntPtr lp,ref bool handled){
        if(msg==0x0024&&!widgetSurface&&!compact&&lp!=IntPtr.Zero){SetMaximizedBounds(hwnd,lp);handled=true;return IntPtr.Zero;}
        if(widgetSurface&&msg==0x21&&sharedOwner!=null&&!sharedOwner.workspaceTyping){handled=true;return new IntPtr(3);}if(msg==0x0312&&wp.ToInt32()==83){ToggleWorkspace();handled=true;}else if(msg==0x0312&&wp.ToInt32()==78){SaveReplay(30);handled=true;}else if(msg==0x0312&&wp.ToInt32()==79){SaveReplay(60);handled=true;}else if(msg==0x0312&&wp.ToInt32()==80){ToggleRecording();handled=true;}else if(msg==0x0312&&wp.ToInt32()==81){SaveReplay(120);handled=true;}else if(msg==0x0312&&wp.ToInt32()==82){TakeScreenshot();handled=true;}else if(msg==0x0312&&wp.ToInt32()==77){uint pid;Native.GetWindowThreadProcessId(Native.GetForegroundWindow(),out pid);RememberForegroundGame();ToggleOverlay();handled=true;}return IntPtr.Zero;}
    void ToggleOverlay(){if(sharedOwner!=null){sharedOwner.ToggleOverlay();return;}if(overlay==null)overlay=new OverlayWindow(prefs);if(overlay.IsVisible)overlay.Hide();else{RememberForegroundGame();EnsureAutomaticFps();if(workspaceEditing)SetWorkspace(false);prefs.OverlayLocked=true;if(window.IsVisible)window.Hide();overlay.Update(snapshot,fps);overlay.Show();overlay.Apply();ReturnToGame();}if(page=="overlay")BuildPage("overlay");}
    void AddHistory(List<double> history,double? v){history.Add(v ?? double.NaN);if(history.Count>60)history.RemoveAt(0);}
    async Task SampleAsync(){if(exiting||!sampling.IsCompleted)return;try{var task=Task.Run(()=>service.Sample());sampling=task;snapshot=await task;if(exiting)return;if(cpuSensor!=null)cpuSensor.Apply(snapshot);if(!snapshot.CpuTemp.HasValue&&!CpuSensorBridge.DriverInstalled())snapshot.CpuTempNote="PawnIO não instalado. Clique na temperatura para ativar.";RememberForegroundGame();EnsureAutomaticFps();fps.Update();RecordGameFps();AddHistory(CpuHistory,snapshot.Cpu);AddHistory(GpuHistory,snapshot.Gpu);AddHistory(RamHistory,snapshot.RamPercent);AddHistory(DownHistory,snapshot.Download*8/1000000);AddHistory(UpHistory,snapshot.Upload*8/1000000);Refresh();if(page=="processes"&&window.IsVisible&&(DateTime.Now-processRead).TotalSeconds>=5)ReadProcesses();CheckAlerts();CheckGameProfiles();CheckRecordingHealth();RememberCaptureForeground();if(!verify){EnsureAutoReplay();if(DateTime.UtcNow>=nextUpdateCheck&&!updateChecking)CheckAppUpdates(false);TryAutoUpdate();}}catch(Exception ex){footer.Text="Falha de coleta: "+ex.Message;}}
    void Refresh(){UpdateUpdateControls();foreach(var update in updates)update(snapshot);foreach(var chart in charts)chart.RefreshFrame();footer.Text=compact?"Ativo há "+snapshot.Uptime.Days+"d "+snapshot.Uptime.Hours+"h   ·   Atualizado "+snapshot.Time.ToString("HH:mm:ss"):"Atualizado "+snapshot.Time.ToString("HH:mm:ss")+"   •   Ativo há "+snapshot.Uptime.Days+"d "+snapshot.Uptime.Hours+"h "+snapshot.Uptime.Minutes+"m   •   "+prefs.Interval+" ms";if(tray!=null)tray.Text=("LUA | CPU "+Format.Percent(snapshot.Cpu)+" | RAM "+Format.Percent(snapshot.RamPercent));if(overlay!=null&&overlay.IsVisible)overlay.Update(snapshot,fps);UpdateVideo();if(taskbarWidget!=null)taskbarWidget.Update(snapshot,fps.Fps);if(sharedOwner==null)RefreshWidgets();}
    void CheckAlerts(){if(verify||tray==null||!prefs.Notifications||(DateTime.Now-lastNotification).TotalMinutes<5)return;string warning=AttentionAlerts.Message(snapshot,prefs);if(warning!=null){lastNotification=DateTime.Now;ShowToast("LUA • Atenção",warning);}}
    TextBlock Value(Func<Snapshot,string> value,double size=13,string color="#ECECEC",bool bold=false){var t=UI.Text(value(snapshot),size,color,bold);updates.Add(s=>t.Text=value(s));return t;}
    Sparkline Chart(List<double> history,string color=UI.FocusColor,double height=40,bool auto=false){var c=new Sparkline{Values=history,Color=(Color)ColorConverter.ConvertFromString(color),Height=height,AutoScale=auto,Margin=new Thickness(0,10,0,0)};charts.Add(c);return c;}
    ProgressBar Bar(Func<Snapshot,double> val,string color=null){var b=new ProgressBar{Value=val(snapshot),Margin=new Thickness(0,12,0,2)};if(color!=null)b.Foreground=UI.Brush(color);updates.Add(s=>{double next=Math.Max(0,Math.Min(100,val(s))),previous=b.Value;if(UI.MotionEnabled&&b.IsVisible&&Math.Abs(previous-next)>.05){b.Value=next;b.BeginAnimation(System.Windows.Controls.Primitives.RangeBase.ValueProperty,new System.Windows.Media.Animation.DoubleAnimation(previous,next,TimeSpan.FromMilliseconds(200)){EasingFunction=new System.Windows.Media.Animation.CubicEase{EasingMode=System.Windows.Media.Animation.EasingMode.EaseOut}});}else{b.BeginAnimation(System.Windows.Controls.Primitives.RangeBase.ValueProperty,null);b.Value=next;}});return b;}
    void Notice(string text){ShowToast("LUA",text);}
    void OpenPath(string path){try{Process.Start(new ProcessStartInfo(path){UseShellExecute=true});}catch(Exception ex){Notice(ex.Message);}}
    void Section(string text){body.Children.Add(new TextBlock{Text=text,FontSize=10,FontWeight=FontWeights.SemiBold,Foreground=UI.Brush("#929292"),Margin=new Thickness(0,4,0,12)});}
    static readonly Dictionary<string, string[]> PageTitles = new Dictionary<string, string[]> {
        { "home", new[] { "Visão geral", "Acompanhe o desempenho do seu computador." } },
        { "hardware", new[] { "Hardware", "Peças e sensores disponíveis." } },
        { "games", new[] { "Jogos", "Biblioteca e horas jogadas." } },
        { "sessions", new[] { "Jogos", "Sessões locais e totais por conta." } },
        { "gaming", new[] { "Jogos", "FPS do jogo e tempo por quadro." } },
        { "recording", new[] { "Capturas", "Grave, salve clipes e tire prints." } },
        { "gallery", new[] { "Galeria", "Seus vídeos, clipes e prints." } },
        { "capture-settings", new[] { "Ajustes de captura", "Qualidade, áudio, perfis e atalhos." } },
        { "tools", new[] { "Ferramentas", "Diagnóstico, rede e armazenamento." } },
        { "processes", new[] { "Processos", "Uso de recursos por aplicativo." } },
        { "analysis", new[] { "Analisar PC", "Diagnóstico local de hardware e sistema." } },
        { "network", new[] { "Rede e internet", "Tráfego, interfaces e qualidade da conexão." } },
        { "storage", new[] { "Armazenamento", "Espaço e atividade das unidades." } },
        { "cleanup", new[] { "Limpeza e duplicados", "Revise os arquivos antes de enviar à Lixeira." } },
        { "overlay", new[] { "Sobreposição", "Métricas por cima do jogo." } },
        { "settings", new[] { "Configurações", "Personalize a interface e os recursos do LUA." } }
    };

    void BuildPage(string id){
        if(id=="recording"&&!widgetSurface)id="gallery";
        UI.Compact=compact;
        page=id;
        UI.FoldPage=id;
        if(taskbarWidget!=null)taskbarWidget.SetCardHost(null);
        taskbarHomeHost=null;
        updates.Clear();
        charts.Clear();
        body.Children.Clear();
        scanArea=null;
        processArea=null;
        overlayPreviewHost=null;
        Find<ScrollViewer>("ContentScroll").ScrollToTop();
        gamesArea=null;
        cleanupArea=null;
        replayButton=null;
        galleryRecording=null;
        playtimeSummary=null;
        ResetGameExperience();
        captureWidgetRoot=null;
        speedText=null;
        galleryArea=null;
        if(galleryThumbCancel!=null)galleryThumbCancel.Cancel();

        title.Text=PageTitles[id][0];
        ApplyPageHeading();
        description.Text=PageTitles[id][1];
        SelectNavigation();
        AddSectionNavigation(id);
        switch(id){
            case "home":
                if(taskbarDocked&&taskbarWidget!=null)DockedHome();
                else if(compact)CompactHome();
                else Home();
                AddContinueGame();
                break;
            case "hardware":Hardware();break;
            case "games":Games();break;
            case "sessions":PlaytimeSessions();break;
            case "gaming":Gaming();break;
            case "recording":CaptureWidgetPage();break;
            case "gallery":Gallery();break;
            case "capture-settings":CaptureSettingsPage();break;
            case "tools":ToolsPage();break;
            case "processes":Processes();break;
            case "analysis":Analysis();break;
            case "network":Network();break;
            case "storage":Storage();break;
            case "cleanup":Cleanup();break;
            case "overlay":Overlay();break;
            case "settings":Settings();break;
        }
        Refresh();
        if(!widgetSurface)UI.Enter(body);
    }
    Border Metric(string label,Func<Snapshot,string> value,Func<Snapshot,string> sub,List<double> history,string color){var s=UI.Stack(UI.Row(UI.Text(label,11,"#B4B4B4",true),UI.Text("●",9,color)),Value(value,31,"#F1F1F1",true),Value(sub,11,"#989898"),Chart(history,color,44));return UI.Card(s);}
    void Hardware(){
        string gpu=inventory.Gpu=="Não disponível"?string.Join("\n",snapshot.Sensors.Where(x=>x.Device.Contains("NVIDIA")||x.Device.Contains("Radeon")||x.Device.Contains("Intel Graphics")).Select(x=>x.Device).Distinct().ToArray()):inventory.Gpu;
        var info=UI.Stack(UI.Text("Seu computador",17,"#E5E5E5",true),UI.Line(),Info("Processador",inventory.Cpu),Info("Placa de vídeo",string.IsNullOrEmpty(gpu)?"Não disponível":gpu),Info("Placa-mãe",inventory.Board),Info("Memória",inventory.Ram=="Não disponível"?Format.Bytes(snapshot.RamTotal)+" de RAM • detalhes dos módulos indisponíveis":inventory.Ram),Info("Unidades físicas",inventory.Disks),Info("Sistema",inventory.Os));body.Children.Add(UI.Card(info));
        var head=UI.Stack(UI.Row(UI.Text("Sensores",17,"#E5E5E5",true),UI.Button("Atualizar",()=>BuildPage("hardware"))),Value(s=>s.SensorStatus,11,"#9C9C9C"),UI.Text("Temperaturas, frequência, potência, ventoinhas, tensão e sensores de discos aparecem quando o hardware permite. CPU usa o maior sensor de temperatura; GPU usa a maior carga detectada.",11,"#939393"),CpuSensorOptions());body.Children.Add(UI.Card(UI.Fold("Sensores • detalhes e permissões",head)));
        if(snapshot.Sensors.Count==0){body.Children.Add(UI.Card(UI.Text("Sem leituras de sensores neste momento. A coleta básica de CPU, RAM, rede e espaço continua funcionando. Alguns sensores do LibreHardwareMonitor 0.9.6 precisam do driver PawnIO instalado pelo fornecedor; o LUA não instala drivers automaticamente.",12,"#C1C1C1")));return;}
        foreach(var group in snapshot.Sensors.GroupBy(x=>x.Device)){var panel=UI.Stack(UI.Text(group.Key,14,"#D1D1D1",true));foreach(var sensor in group.Take(80)){string device=sensor.Device,name=sensor.Name,type=sensor.Type;panel.Children.Add(UI.Row(UI.Label(sensor.Name),Value(s=>{var v=s.Sensors.FirstOrDefault(x=>x.Device==device&&x.Name==name&&x.Type==type);return v==null?"—":v.Value.ToString("0.0")+" "+v.Unit;},12)));}body.Children.Add(UI.Card(UI.Fold(group.Key,panel)));}
    }
    UIElement Info(string label,string text){var s=UI.Stack(UI.Text(label.ToUpperInvariant(),9,"#909090",true),UI.Text(text,13,"#DEDEDE"));s.Margin=new Thickness(0,0,0,14);return s;}
    void Network(){
        SpeedPanel();SpeedHistoryPanel();
        if(compact)CompactNetworkMetrics();else body.Children.Add(UI.Columns(Metric("↓ RECEBIMENTO",s=>Format.Rate(s.Download),s=>Format.Bytes(s.Download)+"/s",DownHistory,"#83D2E5"),Metric("↑ ENVIO",s=>Format.Rate(s.Upload),s=>Format.Bytes(s.Upload)+"/s",UpHistory,"#96B9FF")));
        var select=UI.Stack(UI.Text("Interface monitorada",16,"#DCDCDC",true),UI.Text("O gráfico mostra o tráfego de uso, não a velocidade máxima do seu plano. A taxa do link abaixo é a capacidade da conexão local.",11,"#9A9A9A"));var nicChoices=new Dictionary<string,string>{{"Todas as interfaces ativas",""}};foreach(var n in snapshot.Networks)nicChoices[n.Name+" • "+n.Id]=n.Id;string selected=nicChoices.FirstOrDefault(x=>x.Value==prefs.NetworkId).Key??nicChoices.First().Key;select.Children.Add(UI.Choice(nicChoices.Keys,selected,v=>{prefs.NetworkId=nicChoices[v];Save();}));body.Children.Add(UI.Card(select));
        if(snapshot.Networks.Count==0)body.Children.Add(UI.Card(UI.Text("Nenhuma interface de rede ativa.")));
        foreach(var nic in snapshot.Networks){string id=nic.Id;var panel=UI.Stack(UI.Row(UI.Text(nic.Name,16,"#DCDCDC",true),UI.Text("● CONECTADA",9,"#C0C0C0")),UI.Text(nic.Type+" • "+nic.Address,11,"#9A9A9A"),UI.Row(UI.Label("Taxa do link local"),UI.Text(Format.Rate(nic.Speed/8.0))),UI.Row(UI.Label("Recebido pela interface"),Value(s=>{var n=s.Networks.FirstOrDefault(x=>x.Id==id);return n==null?"Desconectada":Format.Bytes(n.Received);})),UI.Row(UI.Label("Enviado pela interface"),Value(s=>{var n=s.Networks.FirstOrDefault(x=>x.Id==id);return n==null?"—":Format.Bytes(n.Sent);})));body.Children.Add(UI.Card(panel));}
        var host=new TextBox{Text="1.1.1.1",Margin=new Thickness(0,12,0,4)};var result=UI.Text(pingResult,12,"#BFBFBF");var test=UI.Button(pingBusy?"Testando…":"Testar conexão",async()=>{if(pingBusy)return;pingBusy=true;result.Text="Enviando 4 pacotes…";string address=host.Text.Trim();pingResult=await Task.Run(()=>Ping(address));pingBusy=false;result.Text=pingResult;});var pingPanel=UI.Stack(UI.Text("Latência e perda de pacotes",16,"#DCDCDC",true),UI.Text("Informe um IP ou domínio. O teste envia 4 pacotes ICMP; bloqueios de ICMP também podem causar falhas.",11,"#9A9A9A"),host,test,result);body.Children.Add(UI.Card(pingPanel));
    }
    string Ping(string host){try{if(string.IsNullOrWhiteSpace(host)||host.Length>253)return "Endereço inválido.";var values=new List<long>();using(var ping=new System.Net.NetworkInformation.Ping()){for(int i=0;i<4;i++){try{var reply=ping.Send(host,1500);if(reply.Status==System.Net.NetworkInformation.IPStatus.Success)values.Add(reply.RoundtripTime);}catch{}}}return values.Count==0?"Sem resposta ICMP. Isso, sozinho, não indica que a internet está offline.":"Latência média: "+values.Average().ToString("0.0")+" ms   •   Perda: "+((4-values.Count)*25)+"%   •   "+values.Count+"/4 respostas";}catch(Exception ex){return ex.Message;}}
    void Storage(){
        body.Children.Add(UI.Button("Limpeza, grandes e duplicados →",()=>BuildPage("cleanup"),true));
        Section("SUAS UNIDADES");if(snapshot.Disks.Count>0){var panels=new List<UIElement>();foreach(var disk in snapshot.Disks){string name=disk.Name;var content=UI.Stack(UI.Text(name+"  "+disk.Label,16,"#E3E3E3",true),Value(s=>{var d=s.Disks.FirstOrDefault(x=>x.Name==name);return d==null?"—":Format.Bytes(d.Total-d.Free)+" / "+Format.Bytes(d.Total);},19),Bar(s=>{var d=s.Disks.FirstOrDefault(x=>x.Name==name);return d==null?0:d.UsedPercent;}),Value(s=>{var d=s.Disks.FirstOrDefault(x=>x.Name==name);return d==null?"—":Format.Bytes(d.Free)+" livres";},11,"#9F9F9F"),UI.Button("Analisar unidade",()=>StartScan(name)));panels.Add(UI.Card(content));if(panels.Count==2){body.Children.Add(UI.Columns(panels.ToArray()));panels.Clear();}}if(panels.Count>0)body.Children.Add(UI.Columns(panels.ToArray()));}
        body.Children.Add(UI.Card(UI.Stack(UI.Text("Atividade dos discos",16,"#DCDCDC",true),UI.Row(UI.Label("Leitura total"),Value(s=>s.DiskRead.HasValue?Format.Bytes(s.DiskRead.Value)+"/s":"—")),UI.Row(UI.Label("Gravação total"),Value(s=>s.DiskWrite.HasValue?Format.Bytes(s.DiskWrite.Value)+"/s":"—")))));
        var path=new TextBox{Text=scanRoot,Margin=new Thickness(0,12,0,3)};var actions=new ActionGrid();actions.Children.Add(UI.Button("Escolher pasta",()=>{using(var dialog=new Forms.FolderBrowserDialog{Description="Escolha a pasta para analisar",SelectedPath=Directory.Exists(path.Text)?path.Text:scanRoot}){if(dialog.ShowDialog()==Forms.DialogResult.OK){path.Text=dialog.SelectedPath;scanRoot=dialog.SelectedPath;}}}));actions.Children.Add(UI.Button("Analisar espaço",()=>StartScan(path.Text),true));actions.Children.Add(UI.Button("Cancelar",()=>{if(scanCancel!=null)scanCancel.Cancel();}));body.Children.Add(UI.Card(UI.Stack(UI.Text("O que está ocupando espaço?",18,"#E5E5E5",true),UI.Text("Análise sob demanda. Pastas, arquivos grandes e locais sem acesso. Links e junções são ignorados. Tamanhos são lógicos; compressão, arquivos esparsos e hard links podem diferir do espaço físico.",11,"#9F9F9F"),path,actions)));
        scanArea=new StackPanel();body.Children.Add(scanArea);RenderScan();
    }
    async void StartScan(string root){if(scanning){Notice("Já existe uma análise em andamento. Cancele ou espere a conclusão.");return;}if(!Directory.Exists(root)){Notice("Essa pasta não existe ou não está acessível.");return;}scanRoot=root;scanCancel=new CancellationTokenSource();scanning=true;scanResult=null;scanProgress=new ScanProgress{Path=root};if(page!="storage")BuildPage("storage");else RenderScan();var token=scanCancel.Token;try{scanResult=await Task.Run(()=>SpaceScanner.Scan(root,token,p=>window.Dispatcher.BeginInvoke(new Action(()=>{scanProgress=p;RenderScan();}))));}catch(Exception ex){Notice("A análise não pôde continuar: "+ex.Message);}finally{scanning=false;scanCancel.Dispose();scanCancel=null;RenderScan();}}
    void RenderScan(){if(scanArea==null)return;scanArea.Children.Clear();if(scanning){var p=scanProgress??new ScanProgress();scanArea.Children.Add(UI.Card(UI.Stack(UI.Text("Analisando…",18,"#9ABEFF",true),UI.Text(p.Files.ToString("N0")+" arquivos • "+Format.Bytes(p.Bytes)+" • "+p.Skipped+" locais ignorados",12),UI.Text(p.Path,10,"#969696"),new ProgressBar{IsIndeterminate=true,Margin=new Thickness(0,14,0,0)})));return;}if(scanResult==null)return;var r=scanResult;scanArea.Children.Add(UI.Card(UI.Stack(UI.Text(r.Cancelled?"Análise cancelada • resultado parcial":"Análise concluída",18,"#C0C0C0",true),UI.Text(r.Root,11,"#9D9D9D"),UI.Text(Format.Bytes(r.Bytes)+" • "+r.Files.ToString("N0")+" arquivos • "+r.Duration.TotalSeconds.ToString("0.0")+" s",14),UI.Text(r.Skipped+" locais ignorados: acesso negado, links ou arquivos alterados durante a leitura.",11,"#A6A6A6"),UI.Button("Exportar resultado CSV",ExportScan))));
        var folders=UI.Stack(UI.Text("Pastas que mais ocupam espaço",16,"#DCDCDC",true));foreach(var item in r.Folders.Take(30)){var entry=item;var label=UI.Text(entry.Path=="Arquivos na raiz"?entry.Path:Path.GetFileName(entry.Path.TrimEnd('\\')),12,"#D0D0D0");label.ToolTip=entry.Path;folders.Children.Add(UI.Row(label,UI.Text(Format.Bytes(entry.Bytes),13,"#E7E7E7",true)));folders.Children.Add(new ProgressBar{Value=r.Bytes==0?0:entry.Bytes*100.0/r.Bytes,Margin=new Thickness(0,2,0,8)});if(entry.IsDirectory)folders.Children.Add(UI.Button("Explorar pasta  →",()=>StartScan(entry.Path)));}scanArea.Children.Add(UI.Card(folders));
        var files=UI.Stack(UI.Text("50 maiores arquivos",16,"#DCDCDC",true));foreach(var item in r.LargeFiles){var entry=item;var name=UI.Text(Path.GetFileName(entry.Path),12,"#D0D0D0");name.ToolTip=entry.Path;files.Children.Add(UI.Row(name,UI.Text(Format.Bytes(entry.Bytes),12)));files.Children.Add(UI.Text(Path.GetDirectoryName(entry.Path),10,"#8F8F8F"));files.Children.Add(UI.Button("Mostrar no Explorer",()=>{try{Process.Start("explorer.exe","/select,\""+entry.Path+"\"");}catch(Exception ex){Notice(ex.Message);}}));}scanArea.Children.Add(UI.Card(files));}
    void ExportScan(){if(scanResult==null)return;var dialog=new SaveFileDialog{Filter="CSV|*.csv",FileName="LUA-armazenamento.csv"};if(dialog.ShowDialog(window)!=true)return;try{var csv=new StringBuilder("Tipo;Caminho;Bytes\r\n");foreach(var entry in scanResult.Folders.Concat(scanResult.LargeFiles))csv.AppendLine((entry.IsDirectory?"Pasta":"Arquivo")+";"+CsvCell(entry.Path)+";"+entry.Bytes);File.WriteAllText(dialog.FileName,csv.ToString(),new UTF8Encoding(true));}catch(Exception ex){Notice(ex.Message);}}
    static string CsvCell(string s){if(s.Length>0&&"=+-@".Contains(s[0]))s="'"+s;return "\""+s.Replace("\"","\"\"")+"\"";}
    void Processes(){var filters=UI.Stack(UI.Label("Ordenar por"),UI.Choice(new[]{"Memória","CPU","Nome"},processSort,v=>{processSort=v;RenderProcesses();}));body.Children.Add(UI.Card(UI.Stack(UI.Text("Consumo por aplicativo",17,"#E5E5E5",true),UI.Search(processSearch,"Buscar processo ou PID…",v=>{processSearch=v;RenderProcesses();},filters),UI.Fold("Sobre as leituras",UI.Text("CPU média entre amostras, normalizada pelo total de threads. RAM é o conjunto de trabalho; páginas compartilhadas podem aparecer em mais de um processo. Atualiza a cada 5 s nesta página.",11,"#9999AC")),UI.Button("Atualizar agora",()=>ReadProcesses()))));processArea=new StackPanel();body.Children.Add(processArea);RenderProcesses();ReadProcesses();}
    async void ReadProcesses(){if(processReading)return;processReading=true;try{processes=await Task.Run(()=>processReader.Read());processRead=DateTime.Now;RenderProcesses();}finally{processReading=false;}}
    void RenderProcesses(){if(processArea==null)return;processArea.Children.Clear();var items=processes.Where(p=>p.Name.IndexOf(processSearch,StringComparison.OrdinalIgnoreCase)>=0||p.Id.ToString().Contains(processSearch));items=processSort=="CPU"?items.OrderByDescending(p=>p.Cpu??-1):processSort=="Nome"?items.OrderBy(p=>p.Name):items.OrderByDescending(p=>p.Memory);var panel=UI.Stack(UI.Row(UI.Text("APLICATIVO / PID",10,"#929292",true),UI.Text("CPU           RAM",10,"#929292",true)));foreach(var p in items.Take(60)){var name=UI.Text(p.Name+"   #"+p.Id,12,"#D9D9D9");panel.Children.Add(UI.Row(name,UI.Text((p.Cpu.HasValue?p.Cpu.Value.ToString("0.0")+"%":"—")+"     "+Format.Bytes(p.Memory),12)));panel.Children.Add(new Border{Height=1,Background=UI.Brush("#383838"),Margin=new Thickness(0,6,0,6)});}if(processes.Count==0)panel.Children.Add(UI.Text("Lendo processos…",12,"#9F9F9F"));processArea.Children.Add(UI.Card(panel));}
    void Gaming(){
        if(compact)body.Children.Add(UI.Inline(SmallMetric("FPS",x=>FpsText(fps.Fps),"jogo detectado"),SmallMetric("FRAME",x=>fps.FrameMs.HasValue?fps.FrameMs.Value.ToString("0.0")+" ms":"—","média • 2 s")));
        else body.Children.Add(UI.Columns(Metric("FPS",x=>FpsText(fps.Fps),x=>fps.Target>0?fps.TargetName:"Aguardando jogo",new List<double>(),"#8CB2FF"),Metric("TEMPO POR FRAME",x=>fps.FrameMs.HasValue?fps.FrameMs.Value.ToString("0.00")+" ms":"—",x=>"Média dos últimos 2 segundos",new List<double>(),"#87D4DF")));
        var optional=new List<UIElement>();if(prefs.ShowFpsLow)optional.Add(SmallMetric("1% LOW",x=>FpsText(fps.Low),"até 600 frames / 10 s"));if(prefs.ShowFpsMinimum)optional.Add(SmallMetric("FPS MÍNIMO",x=>FpsText(fps.Minimum),"menor média • sessão"));if(prefs.ShowFpsMaximum)optional.Add(SmallMetric("FPS MÁXIMO",x=>FpsText(fps.Maximum),"maior média • sessão"));if(optional.Count>0)body.Children.Add(UI.Inline(optional.ToArray()));
        body.Children.Add(UI.Card(UI.Stack(Value(x=>fps.Target>0?fps.TargetName+" • "+fps.Status:(fpsAutoBlocked?fps.Status:"Abra um jogo da sua biblioteca para medir o FPS automaticamente."),12,"#BDBDBD"),UI.Fold("Métricas e detecção",UI.Stack(UI.Check("Detectar FPS automaticamente",prefs.AutoFps,v=>{prefs.AutoFps=v;fpsAutoBlocked=false;if(!v)fps.Stop();Save();}),UI.Check("Mostrar 1% low",prefs.ShowFpsLow,v=>SetFpsOption("low",v)),UI.Check("Mostrar FPS mínimo",prefs.ShowFpsMinimum,v=>SetFpsOption("min",v)),UI.Check("Mostrar FPS máximo",prefs.ShowFpsMaximum,v=>SetFpsOption("max",v)),UI.Text("As opções também valem para a sobreposição. Mínimo e máximo são as menores e maiores médias de 2 s observadas no jogo atual. 1% low usa até 600 frames dos últimos 10 s e exige pelo menos 100. Não somamos FPS de programas diferentes.",11,"#AAAABC"),UI.Text("O jogo em foco é reconhecido pelas pastas da biblioteca. Jogos portáteis podem ser adicionados em Jogos instalados. A permissão do Windows é solicitada quando a captura precisa iniciar; um cancelamento não gera pedidos repetidos.",11,"#AAAABC"),UI.Button("Reativar detecção de FPS",RetryAutomaticFps),Value(x=>FpsDiagnosis(),11,"#AAAABC"))))));
        if(!widgetSurface)body.Children.Add(GameFpsTimeline());
        DlssPanel();body.Children.Add(UI.Card(UI.Stack(UI.Text("Jogue com suas métricas à vista",16,"#DDDDDD",true),UI.Text("Use janela sem bordas para maior compatibilidade. Personalize posição, tamanho, transparência e métricas da sobreposição.",12,"#9F9F9F"),UI.Button("Personalizar sobreposição  →",()=>BuildPage("overlay")))));
    }
    void Overlay(){
        body.Children.Add(WorkspaceOptions());
        body.Children.Add(UI.Card(ShortcutField("Atalho da sobreposição de FPS e métricas",77)));
        var actions=new ActionGrid();actions.Children.Add(UI.Button(overlay!=null&&overlay.IsVisible?"Ocultar sobreposição":"Mostrar sobreposição",ToggleOverlay,true));actions.Children.Add(UI.Button("Criar atalho da sobreposição",()=>CreateShortcut(true)));
        body.Children.Add(UI.Card(UI.Stack(UI.Text("Sempre por perto",18,"#E6E6E6",true),UI.Text("Use "+prefs.Hotkey+" em qualquer aplicativo para mostrar ou esconder. Ative a captura em Jogos → FPS para ver os frames do processo selecionado.",12,"#A5A5A5"),actions,UI.Text(hotkeyError==""?"Janela e sem bordas • sem injeção no jogo":hotkeyError,11,"#B2B2B2"))));
        var metrics=UI.Stack(UI.Text("Métricas visíveis",16,"#DEDEDE",true),UI.Check("Processador / CPU",prefs.ShowCpu,v=>{prefs.ShowCpu=v;OverlayChanged();}),UI.Check("Placa de vídeo / GPU",prefs.ShowGpu,v=>{prefs.ShowGpu=v;OverlayChanged();}),UI.Check("Memória RAM",prefs.ShowRam,v=>{prefs.ShowRam=v;OverlayChanged();}),UI.Check("Rede: recebimento e envio",prefs.ShowNetwork,v=>{prefs.ShowNetwork=v;OverlayChanged();}),UI.Check("Detectar FPS automaticamente",prefs.AutoFps,v=>{prefs.AutoFps=v;fpsAutoBlocked=false;if(!v)fps.Stop();Save();}),UI.Check("FPS",prefs.ShowFps,v=>{prefs.ShowFps=v;OverlayChanged();}),UI.Check("1% low",prefs.ShowFpsLow,v=>{prefs.ShowFpsLow=v;OverlayChanged();}),UI.Check("FPS mínimo",prefs.ShowFpsMinimum,v=>{prefs.ShowFpsMinimum=v;OverlayChanged();}),UI.Check("FPS máximo",prefs.ShowFpsMaximum,v=>{prefs.ShowFpsMaximum=v;OverlayChanged();}),UI.Check("Temperaturas da CPU e GPU",prefs.ShowTemps,v=>{prefs.ShowTemps=v;OverlayChanged();}));
        var layout=UI.Stack(UI.Text("Aparência e posição",16,"#DEDEDE",true),UI.Label("Posição no monitor do cursor"),UI.Choice(new[]{"Superior esquerdo","Superior direito","Inferior esquerdo","Inferior direito"},prefs.OverlayPosition,v=>{prefs.OverlayPosition=v;OverlayChanged();}),UI.Label("Opacidade"),Slider(.25,1,prefs.OverlayOpacity,v=>{prefs.OverlayOpacity=v;OverlayChanged();},v=>(v*100).ToString("0")+"%"),UI.Label("Tamanho"),Slider(.7,2,prefs.OverlayScale,v=>{prefs.OverlayScale=v;OverlayChanged();},v=>(v*100).ToString("0")+"%"),UI.Check("Bloquear posição e permitir cliques através",prefs.OverlayLocked,v=>{prefs.OverlayLocked=v;OverlayChanged();}),UI.Text("Desbloqueie para arrastar. Ao reabrir, a sobreposição volta ao canto escolhido. Em tela cheia exclusiva, use o modo sem bordas do jogo.",11,"#9F9F9F"));body.Children.Add(UI.Columns(UI.Card(metrics),UI.Card(layout)));
        overlayPreviewHost=new Border{HorizontalAlignment=HorizontalAlignment.Left,Margin=new Thickness(0,12,0,0)};UpdateOverlayPreview();body.Children.Add(UI.Card(UI.Stack(UI.Text("Prévia das métricas atuais",16,"#DEDEDE",true),overlayPreviewHost)));
    }
    UIElement Slider(double min,double max,double current,Action<double> update,Func<double,string> format){var value=UI.Text(format(current),11,"#B0B0B0");var slider=new Slider{Minimum=min,Maximum=max,Value=current,Margin=new Thickness(0,10,0,8),TickFrequency=.05,IsSnapToTickEnabled=true};slider.ValueChanged+=(s,e)=>{value.Text=format(slider.Value);update(slider.Value);};return UI.Stack(slider,value);}
    void UpdateOverlayPreview(){if(overlayPreviewHost==null)return;var preview=new OverlayWindow(prefs);preview.Update(snapshot,fps);var content=preview.Content as Border;preview.Content=null;content.LayoutTransform=Transform.Identity;content.Opacity=1;overlayPreviewHost.Child=content;preview.Close();}
    void OverlayChanged(){Save();UpdateOverlayPreview();var owner=sharedOwner??this;if(owner.overlay!=null){owner.overlay.Update(owner.snapshot,owner.fps);owner.overlay.Apply();}foreach(var child in owner.widgetControllers.Values)if(child.window.IsVisible&&(child.widgetId=="home"||child.widgetId=="gaming"))child.BuildPage(child.widgetId);}
    void Settings(){
        var readability=UI.Stack(UI.Label("Escala da interface"),UI.Choice(new[]{"100%","125%","150%"},
            (prefs.UiScale*100).ToString("0")+"%",v=>{prefs.UiScale=double.Parse(v.TrimEnd('%'))/100;Save();SetMode(compact,false);}),
            UI.Check("Texto com maior contraste",prefs.HighContrast,v=>{prefs.HighContrast=v;UI.HighContrast=v;Save();BuildPage("settings");}));
        var general=UI.Stack(UI.Check("Iniciar com o Windows, na bandeja",prefs.StartWithWindows,v=>SetStartup(v)),UI.Check("Fechar a janela mantém o LUA na bandeja",prefs.MinimizeOnClose,v=>{prefs.MinimizeOnClose=v;Save();}),UI.Check("Animações suaves",prefs.Animations,v=>{prefs.Animations=v;UI.MotionEnabled=v;Save();}),UI.Label("Intervalo de atualização"),UI.Choice(new[]{"500 ms • rápido","1500 ms • equilibrado","3000 ms • econômico","5000 ms • mínimo"},prefs.Interval==500?"500 ms • rápido":prefs.Interval==3000?"3000 ms • econômico":prefs.Interval==5000?"5000 ms • mínimo":"1500 ms • equilibrado",v=>{prefs.Interval=int.Parse(v.Split(' ')[0]);if(sharedOwner!=null)sharedOwner.timer.Interval=TimeSpan.FromMilliseconds(prefs.Interval);else if(timer!=null)timer.Interval=TimeSpan.FromMilliseconds(prefs.Interval);Save();}));
        general.Children.Add(UI.Label("Cor de destaque"));
        general.Children.Add(UI.Choice(new[]{"Violeta","Cinza"},prefs.Accent,v=>{prefs.Accent=v;ApplyAccent();Save();}));
        general.Children.Add(UI.Fold("Leitura e acessibilidade",readability));
        body.Children.Add(UI.Card(UI.Fold("Geral",general)));
        body.Children.Add(TaskbarSettings());
        body.Children.Add(PageCard("Sobreposição","Métricas e janelas por cima do jogo","overlay",()=>BuildPage("overlay")));
        body.Children.Add(PageCard("Captura","Qualidade, áudio, clipes e atalhos","recording",()=>BuildPage("capture-settings")));
        var advanced=UI.Stack(UI.Check("Ler sensores avançados de hardware",prefs.Sensors,v=>{prefs.Sensors=v;Save();}),
            UI.Text("Reabra o LUA depois de alterar a leitura dos sensores.",11,"#A4A4A4"),
            UI.Fold("Temperatura da CPU e permissões",CpuSensorOptions()));
        body.Children.Add(UI.Card(UI.Fold("Avançado",advanced)));
        ActivityOptions();
        var alerts=AttentionOptions();
        var about=UI.Stack(UI.Text("LUA "+AppUpdate.Current+" • Beta",17,"#E6E6E6",true),UI.Text("Aplicativo nativo para Windows 10/11 x64. Monitoramento local sem conta. Capas consultam a Steam e teste de velocidade usa a Cloudflare; arquivos pessoais não são enviados.",12,"#A4A4A4"),UI.Line(),UI.Text("Motores incluídos\nLibreHardwareMonitor 0.9.6 • sensores\nPresentMon 2.6.0 • eventos de frames\nAPIs do Windows • CPU, memória, rede e discos",11,"#B1B1B1"),UI.Button("Criar atalho na Área de Trabalho",CreateDesktopShortcut),UI.Button("Abrir pasta de dados",()=>{Directory.CreateDirectory(Preferences.DataDir);OpenPath(Preferences.DataDir);}),UI.Button("Reabrir como administrador",RestartAdmin),UI.Button("Sair do LUA",ExitApp));body.Children.Add(UI.Card(alerts));body.Children.Add(UI.Fold("Sobre o LUA e atualizações",UI.Stack(UpdateOptions(),UI.Card(about)),true));
    }
    void SetStartup(bool enabled){try{using(var key=Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run")){if(enabled)key.SetValue("LuaMonitor","\""+Assembly.GetExecutingAssembly().Location+"\" --tray");else key.DeleteValue("LuaMonitor",false);}prefs.StartWithWindows=enabled;Save();}catch(Exception ex){Notice("Não foi possível alterar a inicialização: "+ex.Message);}}
    void CreateShortcut(bool isOverlay){try{string desktop=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);string path=Path.Combine(desktop,isOverlay?"LUA - Sobreposição.lnk":"LUA Monitor.lnk");if(File.Exists(path)){Notice("O atalho já existe na área de trabalho.");return;}Type type=Type.GetTypeFromProgID("WScript.Shell");dynamic shell=Activator.CreateInstance(type);dynamic link=shell.CreateShortcut(path);link.TargetPath=Assembly.GetExecutingAssembly().Location;link.Arguments=isOverlay?"--overlay":"";link.WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory;link.Description=isOverlay?"Iniciar o LUA com a sobreposição":"LUA • Monitor do sistema";link.IconLocation=Assembly.GetExecutingAssembly().Location+",0";link.Save();System.Runtime.InteropServices.Marshal.FinalReleaseComObject(link);System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell);Notice("Atalho criado na área de trabalho.");}catch(Exception ex){Notice("Não foi possível criar o atalho: "+ex.Message);}}
    void RestartAdmin(){if(sharedOwner!=null){sharedOwner.RestartAdmin();return;}if(new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator)){Notice("O LUA já está executando como administrador.");return;}try{var psi=new ProcessStartInfo(Assembly.GetExecutingAssembly().Location,"--wait-parent "+Process.GetCurrentProcess().Id){UseShellExecute=true,Verb="runas",WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory};Process.Start(psi);ExitApp();}catch(System.ComponentModel.Win32Exception ex){Notice("A reinicialização não foi concluída: "+ex.Message);}}
    async void ExitApp(){if(sharedOwner!=null){sharedOwner.ExitApp();return;}if(exiting)return;CloseWorkspace();StopPlaytime();CloseTaskbarWidget();exiting=true;closing=true;if(timer!=null)timer.Stop();if(scanCancel!=null)scanCancel.Cancel();if(libraryCancel!=null)libraryCancel.Cancel();if(cleanupCancel!=null)cleanupCancel.Cancel();if(speedCancel!=null)speedCancel.Cancel();if(cpuSensor!=null)cpuSensor.Dispose();if(recorder!=null){recorder.CancelStart();while(videoBusy)await Task.Delay(100);try{await recorder.Shutdown();}catch{}recorder.Dispose();}if(showWait!=null)showWait.Unregister(null);if(overlayWait!=null)overlayWait.Unregister(null);if(showSignal!=null)showSignal.Dispose();if(overlaySignal!=null)overlaySignal.Dispose();if(source!=null){foreach(int hotkey in new[]{77,78,79,80,81,82,83})Native.UnregisterHotKey(new WindowInteropHelper(window).Handle,hotkey);source.RemoveHook(MessageHook);}if(tray!=null){tray.Visible=false;var icon=tray.Icon;tray.Dispose();if(trayNormal!=null)trayNormal.Dispose();if(trayRecording!=null)trayRecording.Dispose();}try{await sampling;}catch{}await Task.Run(()=>{fps.Dispose();service.Dispose();});if(mediaViewer!=null)mediaViewer.Close();MediaServices.Dispose();if(overlay!=null)overlay.Close();if(recordingHud!=null)recordingHud.Close();if(luaToast!=null)luaToast.Close();if(galleryThumbCancel!=null){galleryThumbCancel.Cancel();galleryThumbCancel.Dispose();}app.Shutdown();}
    async Task Verify(){
        string dir=Path.Combine(Preferences.DataDir,"verification");Directory.CreateDirectory(dir);var checks=new List<string>();try{
            if(Environment.GetCommandLineArgs().Contains("--verify-taskbar")){await VerifyTaskbarWidget(checks,dir);checks.Add("RESULTADO: PASSOU");File.WriteAllLines(Path.Combine(dir,"checks.txt"),checks);ExitCode=0;ExitApp();return;}if(Environment.GetCommandLineArgs().Contains("--verify-appearance")){await VerifyAppearance(checks,dir);checks.Add("RESULTADO: PASSOU");File.WriteAllLines(Path.Combine(dir,"checks.txt"),checks);ExitCode=0;ExitApp();return;}if(Environment.GetCommandLineArgs().Contains("--verify-playtime")){await VerifyPlaytimeUi(checks,dir);checks.Add("RESULTADO: PASSOU");File.WriteAllLines(Path.Combine(dir,"checks.txt"),checks);ExitCode=0;ExitApp();return;}if(Environment.GetCommandLineArgs().Contains("--verify-alerts")){await AttentionChecks(checks,dir);checks.Add("RESULTADO: PASSOU");File.WriteAllLines(Path.Combine(dir,"checks.txt"),checks);ExitCode=0;ExitApp();return;}if(Environment.GetCommandLineArgs().Contains("--verify-mp4")){await Mp4Checks(checks,dir);checks.Add("RESULTADO: PASSOU");File.WriteAllLines(Path.Combine(dir,"checks.txt"),checks);ExitCode=0;ExitApp();return;}if(Environment.GetCommandLineArgs().Contains("--verify-public")){await PublicPreviewChecks(checks,dir);checks.Add("RESULTADO: PASSOU");File.WriteAllLines(Path.Combine(dir,"checks.txt"),checks);ExitCode=0;ExitApp();return;}if(Environment.GetCommandLineArgs().Contains("--verify-ui")){await FpsAndFocusChecks(checks,dir);await RefinementChecks(checks,dir);await UpdateInstallChecks(checks,dir);await TemperatureChecks(checks,dir);checks.Add("RESULTADO: PASSOU");File.WriteAllLines(Path.Combine(dir,"checks.txt"),checks);ExitCode=0;ExitApp();return;}await sampling;await Task.Delay(1800);await SampleAsync();checks.Add("CPU real: "+Format.Percent(snapshot.Cpu));checks.Add("RAM real: "+Format.Bytes(snapshot.RamTotal));checks.Add("Sensores: "+snapshot.SensorStatus);checks.Add("Discos: "+snapshot.Disks.Count);checks.Add("Redes: "+snapshot.Networks.Count);
            if(snapshot.RamTotal==0||!snapshot.Cpu.HasValue)throw new Exception("Coleta básica inválida");
            if(!compact||window.Width>430||window.AllowsTransparency||window.ResizeMode!=ResizeMode.NoResize)throw new Exception("Modo compacto ou janela sem bordas incorreto");
            int windowStyle=Native.GetWindowLong(new WindowInteropHelper(window).Handle,-16);if((windowStyle&0x00C40000)!=0)throw new Exception("Moldura nativa ainda presente");
            checks.Add("Padrão compacto, janela opaca sem moldura nativa e doze abas: correto");
            GlyphTypeface face;if(!new Typeface(UI.Font,FontStyles.Normal,FontWeights.Normal,FontStretches.Normal).TryGetGlyphTypeface(out face)||face.FontUri.AbsoluteUri.IndexOf("segoe",StringComparison.OrdinalIgnoreCase)<0)throw new Exception("Fonte Segoe UI não foi carregada");checks.Add("Fonte nativa Segoe UI + antialiasing grayscale configurados: correto");
            foreach(bool small in new[]{true,false}){
                SetMode(small,false);
                foreach(string id in PageTitles.Keys){
                    if(id=="settings")Find<Button>("NavSettingsButton").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                    else if(MainNavigation.Contains(id))(small?compactButtons[id]:navButtons[id]).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                    else BuildPage(id);
                    await Task.Delay(350);window.UpdateLayout();UI.Capture(window,Path.Combine(dir,(small?"compact-":"expanded-")+id+".png"));if(page!=id)throw new Exception("Navegação não abriu "+id);checks.Add("Navegação e renderização "+(small?"compacta: ":"ampliada: ")+id);
                }
            }
            Find<Button>("ExpandButton").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));if(!compact)throw new Exception("Botão de retorno ao compacto falhou");
            Find<Button>("ExpandButton").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));if(compact)throw new Exception("Botão de expandir falhou");
            SetMode(true,false);checks.Add("Expandir e recolher pelo botão: correto");
            window.Close();if(window.IsVisible)throw new Exception("Fechar não recolheu para bandeja");ShowMain();if(!window.IsVisible)throw new Exception("Reabertura do painel falhou");checks.Add("Fechar para bandeja e reabrir: correto");
            var folder=Path.Combine(Preferences.DataDir,"scan-fixture");Directory.CreateDirectory(Path.Combine(folder,"A"));Directory.CreateDirectory(Path.Combine(folder,"B"));File.WriteAllBytes(Path.Combine(folder,"A","small.dat"),new byte[1024]);File.WriteAllBytes(Path.Combine(folder,"B","large.dat"),new byte[4096]);var r=await Task.Run(()=>SpaceScanner.Scan(folder,CancellationToken.None,p=>{}));if(r.Bytes!=5120||r.Files!=2||r.Folders[0].Bytes!=4096||r.LargeFiles[0].Bytes!=4096)throw new Exception("Soma ou ordenação do scanner incorreta");checks.Add("Scanner: tamanhos, contagem, pastas e arquivos corretos");
            var cancelled=new CancellationTokenSource();cancelled.Cancel();var partial=SpaceScanner.Scan(folder,cancelled.Token,p=>{});if(!partial.Cancelled)throw new Exception("Scanner não cancelou");checks.Add("Scanner: cancelamento correto");
            var fake=new FpsReader();fake.Target=999;fake.Feed("Application,ProcessID,SwapChainAddress,MsBetweenPresents");for(int i=0;i<120;i++)fake.Feed("\"test,game.exe\",999,0xA,16.6667");fake.Feed("other.exe,1000,0xA,1");fake.Update();if(!fake.Fps.HasValue||Math.Abs(fake.Fps.Value-60)>.1||!fake.Low.HasValue)throw new Exception("Parser FPS incorreto");checks.Add("FPS: CSV com aspas, filtro PID, média e 1% low corretos (fixture sintética isolada)");fake.Dispose();
            await FpsAndFocusChecks(checks,dir);await AdditionalChecks(checks,dir);await FeatureChecks(checks,dir);await InterfaceChecks(checks,dir);await FullChecks(checks,dir);await UpdateChecks(checks,dir);await ReplayChecks(checks,dir);await RefinementChecks(checks,dir);await UpdateInstallChecks(checks,dir);await TemperatureChecks(checks,dir);
            var tempPrefs=new Preferences{Interval=3000,OverlayOpacity=.6,Hotkey="Alt+F11",PrintKey="Ctrl+Alt+F6",NavigationOrder=new List<string>{"gallery","home"},HiddenNavigation=new List<string>{"network"}};tempPrefs.Save();var loaded=Preferences.Load();if(loaded.Interval!=3000||loaded.Hotkey!="Alt+F11"||loaded.PrintKey!="Ctrl+Alt+F6"||loaded.NavigationOrder[0]!="gallery"||!loaded.HiddenNavigation.Contains("network"))throw new Exception("Preferências não persistiram");checks.Add("Preferências: gravação e leitura corretas");
            IntPtr h=new WindowInteropHelper(window).Handle;bool registered=Native.RegisterHotKey(h,78,2|4|0x4000,(uint)Forms.Keys.F12);if(registered)Native.UnregisterHotKey(h,78);checks.Add("Atalho global Win32: "+(registered?"registrado e liberado":"tecla ocupada no host"));
            overlay=new OverlayWindow(prefs);if(workspaceEditing)SetWorkspace(false);prefs.OverlayLocked=true;if(window.IsVisible)window.Hide();overlay.Update(snapshot,fps);overlay.Show();overlay.Apply();ReturnToGame();await Task.Delay(200);UI.Capture(overlay,Path.Combine(dir,"live-overlay.png"));int style=Native.GetWindowLong(new WindowInteropHelper(overlay).Handle,-20);if((style&0x20)==0)throw new Exception("Overlay bloqueado captura cliques");checks.Add("Overlay: janela topmost e clique através verificados");overlay.Hide();
            SetMode(true,false);BuildPage("home");await Task.Delay(250);UI.Capture(window,Path.Combine(dir,"tray.png"));checks.Add("Painel compacto com navegação completa: renderizado");
            var probe=new FpsReader();int probePid=Process.GetCurrentProcess().Id;string probeName="LUA (teste de integração)";string[] probeArgs=Environment.GetCommandLineArgs();int probeAt=Array.IndexOf(probeArgs,"--verify-fps-pid");if(probeAt>=0&&probeAt+1<probeArgs.Length&&int.TryParse(probeArgs[probeAt+1],out probePid)){using(var game=Process.GetProcessById(probePid))probeName=game.ProcessName;}probe.Start(probePid,probeName,!Environment.GetCommandLineArgs().Contains("--verify-fps-elevated"));var animationBar=new ProgressBar{IsIndeterminate=true,Width=600,Height=20};body.Children.Add(animationBar);if(Environment.GetCommandLineArgs().Contains("--verify-fps-elevated")){for(int attempt=0;attempt<200;attempt++){await Task.Delay(200);probe.Update();if(probe.Fps.HasValue)break;}}else{await Task.Delay(2500);probe.Update();}checks.Add("PresentMon real • "+probeName+" PID "+probePid+" • "+probe.ReceivedFrames+" quadros: "+probe.Status+" | FPS: "+(probe.Fps.HasValue?probe.Fps.Value.ToString("0.0"):"não disponível nesta sessão"));probe.Dispose();body.Children.Remove(animationBar);
            checks.Add("Inventário WMI: "+(inventory.Errors.Count==0?"disponível":string.Join(" | ",inventory.Errors.ToArray())));
            BuildPage("home");window.Hide();using(var own=Process.GetCurrentProcess()){TimeSpan cpuBefore=own.TotalProcessorTime;var watch=Stopwatch.StartNew();await Task.Delay(10000);own.Refresh();double cpuUse=(own.TotalProcessorTime-cpuBefore).TotalMilliseconds/watch.Elapsed.TotalMilliseconds/Environment.ProcessorCount*100;checks.Add("Consumo após inicialização, 10 s na bandeja: CPU média "+cpuUse.ToString("0.00")+"% | RAM "+Format.Bytes(own.WorkingSet64));}
            File.WriteAllText(Path.Combine(dir,"diagnostico-real.txt"),Report());checks.Add("RESULTADO: PASSOU");ExitCode=0;
        }catch(Exception ex){checks.Add("RESULTADO: FALHOU\n"+ex);ExitCode=1;}
        File.WriteAllLines(Path.Combine(dir,"checks.txt"),checks);ExitApp();
    }
}
}
