using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Forms=System.Windows.Forms;
namespace LuaMonitor {
public sealed partial class DesktopController {
    ScreenRecorder recorder;bool videoBusy;TextBlock videoStatus,videoDetail;Button recordButton,replayButton;System.Drawing.Icon trayNormal,trayRecording;string videoHotkeyError="",captureAction="";
    ScreenRecorder Recorder {get{if(sharedOwner!=null)return sharedOwner.Recorder;if(recorder==null)recorder=new ScreenRecorder();return recorder;}}
    Button quickClipButton;
    StackPanel capturesRecent;
    int capturesRead;

    void RecordingPage(){
        if(widgetSurface&&widgetId=="recording"){CaptureWidgetPage();return;}
        videoStatus=UI.Text("Pronto para gravar", 13, "#F0EDF4", true);
        videoDetail=UI.Text("Buffer desligado", 12, "#BBB7C4");
        recordButton=UI.Button("Gravar",ToggleRecording,true);
        quickClipButton=UI.Button("Salvar clipe",()=>SaveReplay(prefs.QuickClipSeconds));
        var actions=new System.Windows.Controls.Primitives.UniformGrid { Rows=2, Columns=2 };
        foreach(var button in new[] { recordButton, quickClipButton, UI.Button("Tirar print",TakeScreenshot),
            UI.Button("Galeria",()=>BuildPage("gallery")) }){
            button.Margin=new Thickness(3,3,3,3);
            actions.Children.Add(button);
        }
        var status=UI.Stack(videoStatus,videoDetail,actions);
        actions.Margin=new Thickness(0,8,0,0);
        body.Children.Add(UI.Card(status,16));
        body.Children.Add(PageCard("Ajustes de captura","Qualidade, microfone, clipes e perfis","settings",()=>BuildPage("capture-settings")));
        capturesRecent=new StackPanel();
        body.Children.Add(UI.Card(UI.Stack(UI.Text("Capturas recentes",15,"#EFEAF4",true),capturesRecent)));
        LoadRecentCaptures();
        UpdateVideo();
    }
    
    async void LoadRecentCaptures(){
        var target=capturesRecent;
        if(target==null)return;
        int request=++capturesRead;
        string folder=prefs.Video.Folder;
        var files=await Task.Run(()=>MediaLibrary.Scan(folder).OrderByDescending(item=>item.Date).Take(3).ToList());
        if(exiting||capturesRecent!=target||request!=capturesRead)return;
        target.Children.Clear();
        if(files.Count==0)target.Children.Add(UI.Text("As próximas capturas aparecem aqui.",12,"#AEABB7"));
        foreach(var item in files){
            string kind=item.Kind=="Prints"?"Print":item.Kind=="Clipes"?"Clipe":"Vídeo";
            target.Children.Add(PageCard(MediaServices.Title(item),kind+" · "+item.Date.ToString("g"),
                kind=="Print"?"screenshot":kind=="Clipe"?"replay":"recording",()=>OpenMedia(item)));
        }
    }

    void CaptureSettingsPage(){
        replayButton=UI.Button("Ativar buffer",ToggleReplay);var clips=new ActionGrid();clips.Children.Add(UI.Button("Últimos 30 s",()=>SaveReplay(30)));clips.Children.Add(UI.Button("Último 1 min",()=>SaveReplay(60)));clips.Children.Add(UI.Button("Últimos 2 min",()=>SaveReplay(120)));
        var replayOptions=UI.Stack(UI.Check("Manter histórico sempre ativo",prefs.ReplayAlwaysOn,v=>SetAlwaysReplay(v)),UI.Text("O histórico guarda os momentos anteriores enquanto o LUA está aberto. Salvar clipe exporta esse histórico, sem iniciar uma gravação nova.",12,"#9999AC"),UI.Choice(new[]{"Guardar 30 segundos","Guardar 1 minuto","Guardar 2 minutos"},prefs.Video.ReplaySeconds==30?"Guardar 30 segundos":prefs.Video.ReplaySeconds==120?"Guardar 2 minutos":"Guardar 1 minuto",v=>{prefs.Video.ReplaySeconds=v.Contains("30")?30:v.Contains("2")?120:60;prefs.QuickClipSeconds=Math.Min(prefs.QuickClipSeconds,prefs.Video.ReplaySeconds);Save();RestartReplayHistory();}),replayButton,clips);
        body.Children.Add(UI.Card(UI.Fold("Clipes retroativos",replayOptions),14));
        var screens=Forms.Screen.AllScreens.Select((screen,index)=>(index+1)+" • "+screen.DeviceName+" • "+screen.Bounds.Width+"×"+screen.Bounds.Height).ToArray();
        var choices=UI.Stack(UI.Label("Monitor"),UI.Choice(screens,screens[Math.Max(0,Math.Min(screens.Length-1,prefs.Video.Screen))],v=>{prefs.Video.Screen=Array.IndexOf(screens,v);Save();}),UI.Label("Resolução e fluidez"),UI.Choice(new[]{"720p","1080p","Resolução do monitor"},prefs.Video.Height==720?"720p":prefs.Video.Height==1080?"1080p":"Resolução do monitor",v=>{prefs.Video.Height=v=="720p"?720:v=="1080p"?1080:0;Save();}),UI.Choice(new[]{"30 FPS • leve","60 FPS • fluido"},prefs.Video.Fps==60?"60 FPS • fluido":"30 FPS • leve",v=>{prefs.Video.Fps=v.StartsWith("60")?60:30;Save();}),UI.Choice(new[]{"4 Mbps • econômico","8 Mbps • equilibrado","16 Mbps • alta qualidade"},prefs.Video.Bitrate==4?"4 Mbps • econômico":prefs.Video.Bitrate==16?"16 Mbps • alta qualidade":"8 Mbps • equilibrado",v=>{prefs.Video.Bitrate=v.StartsWith("4")?4:v.StartsWith("16")?16:8;Save();}),UI.Check("Mostrar cursor no vídeo",prefs.Video.Cursor,v=>{prefs.Video.Cursor=v;Save();}),UI.Label("Posição do indicador flutuante"),UI.Choice(new[]{"Superior direito","Superior esquerdo","Inferior direito","Inferior esquerdo"},prefs.CaptureHudPosition,v=>{prefs.CaptureHudPosition=v;Save();SyncRecordingHud();}),UI.Text("Qualidade, monitor e áudio valem para a próxima captura. Dispositivos e volumes ficam em Áudio e microfone.",11,"#9999AC"));
        choices.Children.Add(UI.Label("Motor de captura"));choices.Children.Add(UI.Choice(new[]{"Automático","Duplicação DXGI","Captura compatível"},prefs.Video.Engine,v=>{prefs.Video.Engine=v;Save();}));choices.Children.Add(UI.Label("Finalizar se o espaço livre cair abaixo de"));choices.Children.Add(UI.Choice(new[]{"300 MB","500 MB","1000 MB","2000 MB"},prefs.Video.StopFreeMb+" MB",v=>{prefs.Video.StopFreeMb=int.Parse(v.Split(' ')[0]);Save();}));choices.Children.Add(UI.Button("Testar captura • prévia de 3 s",TestCapturePreview));body.Children.Add(UI.Card(UI.Fold("Qualidade e captura",choices),14));
        body.Children.Add(UI.Card(UI.Fold("Áudio e microfone",AudioOptions())));body.Children.Add(UI.Card(UI.Fold("Perfis por jogo",ProfileOptions())));
        body.Children.Add(UI.Card(UI.Fold("Atalhos de captura",CaptureShortcutOptions()),14));
        var folder=UI.Text(prefs.Video.Folder,11,"#9999AC");var destinations=new ActionGrid();destinations.Children.Add(UI.Button("Escolher pasta",()=>{using(var dialog=new Forms.FolderBrowserDialog{Description="Pasta para capturas do LUA",SelectedPath=Directory.Exists(prefs.Video.Folder)?prefs.Video.Folder:""})if(dialog.ShowDialog()==Forms.DialogResult.OK){prefs.Video.Folder=dialog.SelectedPath;folder.Text=prefs.Video.Folder;Save();}}));destinations.Children.Add(UI.Button("Abrir pasta",()=>{Directory.CreateDirectory(prefs.Video.Folder);OpenPath(prefs.Video.Folder);}));
        body.Children.Add(UI.Card(UI.Fold("Pasta e arquivos",UI.Stack(folder,destinations,UI.Text("Vídeos, Clipes e Prints ficam separados em subpastas. Captura o monitor e suas janelas visíveis. Para jogos que não aparecem, use janela sem bordas.",11,"#9999AC"))),14));UpdateVideo();
    }
    async void ToggleRecording(){if(sharedOwner!=null){sharedOwner.ToggleRecording();return;}if(videoBusy)return;captureAction=Recorder.Recording?"Finalizando vídeo":"Iniciando gravação";videoBusy=true;UpdateVideo();try{if(Recorder.Recording){await Recorder.StopRecording();galleryTab="Vídeos";VideoBalloon(Recorder.Status);}else await Recorder.StartRecording(VideoOptions(true));}catch(Exception ex){if(recorder!=null)recorder.Status=ex.Message;if(!exiting)Notice(ex.Message);}finally{videoBusy=false;UpdateVideo();}}
    async void ToggleReplay(){if(sharedOwner!=null){sharedOwner.ToggleReplay();return;}if(videoBusy)return;prefs.ReplayAlwaysOn=!Recorder.Replaying;Save();captureAction=Recorder.Replaying?"Desligando buffer":"Iniciando buffer";videoBusy=true;UpdateVideo();try{if(Recorder.Replaying)await Recorder.StopReplay();else await Recorder.StartReplay(VideoOptions(false));VideoBalloon(Recorder.Status);}catch(Exception ex){if(recorder!=null)recorder.Status=ex.Message;if(!exiting)Notice(ex.Message);}finally{videoBusy=false;UpdateVideo();}}
    async void SaveReplay(int seconds){if(sharedOwner!=null){sharedOwner.SaveReplay(seconds);return;}if(videoBusy){ShowClipToast("Aguarde um instante",captureAction=="Salvando clipe"?"Um clipe já está sendo salvo.":"O histórico está sendo preparado.");return;}if(!Recorder.Replaying&&!prefs.ReplayAlwaysOn){ShowClipToast("Histórico pausado","Ative os clipes retroativos em Capturas → Ajustes de captura.");return;}if(!Recorder.Replaying){EnsureAutoReplay();ShowClipToast("Histórico ainda começando","Aguarde alguns segundos para haver momentos anteriores disponíveis.");return;}captureAction="Salvando clipe";videoBusy=true;UpdateVideo();try{await Recorder.SaveClip(seconds,Path.Combine(prefs.Video.Folder,"Clipes"));galleryTab="Clipes";ShowClipToast("Clipe salvo",Recorder.LastClipSeconds+" s anteriores ao clique"+(Recorder.LastClipSeconds<seconds?" • histórico disponível":""));if(page=="gallery")await LoadGallery();LoadRecentCaptures();foreach(var child in widgetControllers.Values)if(child.page=="gallery"&&child.window.IsVisible)await child.LoadGallery();}catch(Exception ex){ShowClipToast("Não foi possível salvar o clipe",ex.Message);}finally{videoBusy=false;captureAction="";UpdateVideo();}}
    void VideoBalloon(string text){ShowToast("LUA • Capturas",text,()=>{ShowMain();BuildPage("gallery");});if(page=="gallery")LoadGallery();LoadRecentCaptures();}
    void UpdateVideo(){
        var owner=sharedOwner??this;
        var current=owner.recorder;
        bool active=current!=null&&current.Recording;
        bool replaying=current!=null&&current.Replaying;
        bool busy=owner.videoBusy;
        UpdateCaptureWidget();
        if(tray!=null&&trayNormal!=null)tray.Icon=active?trayRecording:trayNormal;
        SyncRecordingHud();
        if(page=="recording"&&videoStatus!=null){
            videoStatus.Text=busy?(string.IsNullOrEmpty(owner.captureAction)?"Preparando…":owner.captureAction+"…")
                :active?"Gravação em andamento":"Pronto para gravar";
            videoDetail.Text=replaying?"Buffer ativo · "+current.AvailableSeconds()+" s disponíveis":prefs.ReplayAlwaysOn?"Preparando buffer de clipes…":"Buffer de clipes desligado";
            string label=active?"Parar e salvar":"Gravar";
            if(!Equals(System.Windows.Automation.AutomationProperties.GetName(recordButton), label))
                UI.ButtonLabel(recordButton,label);
            recordButton.IsEnabled=!busy;
            quickClipButton.IsEnabled=!busy&&(replaying||prefs.ReplayAlwaysOn);
        }
        if(page=="capture-settings"&&replayButton!=null){
            string label=replaying?"Pausar histórico":"Ativar histórico";
            if(!Equals(System.Windows.Automation.AutomationProperties.GetName(replayButton), label))
                UI.ButtonLabel(replayButton,label);
            replayButton.IsEnabled=!busy;
        }
        if(active){
            footer.Text="● Gravação em andamento";
            if(tray!=null)tray.Text="LUA • Gravando vídeo";
        }
    }
}
}
