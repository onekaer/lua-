using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Forms=System.Windows.Forms;
namespace LuaMonitor {
public sealed partial class DesktopController {
    ScreenRecorder recorder;bool videoBusy;TextBlock videoStatus,videoDetail;Button recordButton,replayButton;System.Drawing.Icon trayNormal,trayRecording;string videoHotkeyError="",captureAction="";
    ScreenRecorder Recorder {get{if(sharedOwner!=null)return sharedOwner.Recorder;if(recorder==null)recorder=new ScreenRecorder();return recorder;}}
    Button quickClipButton;
    Window captureDialog;

    void ShowCaptureDialog() {
        if (captureDialog != null) { captureDialog.Activate(); return; }
        CreateCaptureDialog().ShowDialog();
    }

    Window CreateCaptureDialog() {
        videoStatus = UI.Text("Pronto para gravar", 15, "#F4EFF8", true);
        videoDetail = UI.Text("", 12, "#BAAFC9");
        var elapsed = UI.Text("00:00", 20, "#DED0F1", true);
        var status = UI.Row(UI.Stack(videoStatus,videoDetail),elapsed);
        var statusCard = UI.Card(status, 12);
        statusCard.Background = UI.Brush(UI.Surface);
        recordButton = LibraryButton("Iniciar gravação", ToggleRecording, true);
        recordButton.Margin = new Thickness(0,0,0,8);
        quickClipButton = LibraryButton("Salvar clipe", () => SaveReplay(prefs.QuickClipSeconds), glyph:"\uE8C8");
        var panel = UI.Stack(statusCard, recordButton);
        var dialog = NewDialog("Nova captura", panel);
        var print = LibraryButton("Tirar print", () => {
            dialog.Close();
            window.Dispatcher.InvokeAsync(TakeScreenshot, DispatcherPriority.ApplicationIdle);
        }, glyph:"\uE722");
        panel.Children.Add(UI.Inline(quickClipButton,print));
        var settings = LibraryButton("Ajustes de captura", () => {
            dialog.Close();
            BuildPage("capture-settings");
        }, glyph:"\uE713");
        panel.Children.Add(UI.Inline(settings, LibraryButton("Fechar", dialog.Close)));
        captureDialog = dialog;
        dialog.Background = UI.Brush(UI.AppBackground);
        ((Border)dialog.Content).Background = dialog.Background;
        dialog.PreviewKeyDown += (s,e) => {
            if (e.Key == Key.Escape) { e.Handled = true; dialog.Close(); }
        };
        var clock = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        clock.Tick += (s,e) => {
            var current = (sharedOwner ?? this).recorder;
            var time = current != null ? current.RecordingElapsed : TimeSpan.Zero;
            elapsed.Text = time.ToString(time.TotalHours >= 1 ? @"hh\:mm\:ss" : @"mm\:ss");
        };
        dialog.Loaded += (s,e) => clock.Start();
        dialog.Closed += (s,e) => {
            clock.Stop();
            captureDialog = null;
            videoStatus = videoDetail = null;
            recordButton = quickClipButton = null;
        };
        UpdateVideo();
        return dialog;
    }
    void CaptureSettingsPage(){
        replayButton=UI.Button("Ativar buffer",ToggleReplay);var clips=new ActionGrid();clips.Children.Add(UI.Button("Últimos 30 s",()=>SaveReplay(30)));clips.Children.Add(UI.Button("Último 1 min",()=>SaveReplay(60)));clips.Children.Add(UI.Button("Últimos 2 min",()=>SaveReplay(120)));
        var replayOptions=UI.Stack(UI.Check("Manter histórico sempre ativo",prefs.ReplayAlwaysOn,v=>SetAlwaysReplay(v)),UI.Text("O histórico guarda os momentos anteriores enquanto o LUA está aberto. Salvar clipe exporta esse histórico, sem iniciar uma gravação nova.",12,"#9999AC"),UI.Choice(new[]{"Guardar 30 segundos","Guardar 1 minuto","Guardar 2 minutos"},prefs.Video.ReplaySeconds==30?"Guardar 30 segundos":prefs.Video.ReplaySeconds==120?"Guardar 2 minutos":"Guardar 1 minuto",v=>{prefs.Video.ReplaySeconds=v.Contains("30")?30:v.Contains("2")?120:60;prefs.QuickClipSeconds=Math.Min(prefs.QuickClipSeconds,prefs.Video.ReplaySeconds);Save();RestartReplayHistory();}),replayButton,clips);
        body.Children.Add(UI.Card(UI.Fold("Clipes retroativos",replayOptions),14));
        var screens=Forms.Screen.AllScreens.Select((screen,index)=>(index+1)+" • "+screen.DeviceName+" • "+screen.Bounds.Width+"×"+screen.Bounds.Height).ToArray();
        var choices=UI.Stack(UI.Label("Monitor"),UI.Choice(screens,screens[Math.Max(0,Math.Min(screens.Length-1,prefs.Video.Screen))],v=>{prefs.Video.Screen=Array.IndexOf(screens,v);Save();}),UI.Label("Resolução e fluidez"),UI.Choice(new[]{"720p","1080p","Resolução do monitor"},prefs.Video.Height==720?"720p":prefs.Video.Height==1080?"1080p":"Resolução do monitor",v=>{prefs.Video.Height=v=="720p"?720:v=="1080p"?1080:0;Save();}),UI.Choice(new[]{"30 FPS • leve","60 FPS • fluido"},prefs.Video.Fps==60?"60 FPS • fluido":"30 FPS • leve",v=>{prefs.Video.Fps=v.StartsWith("60")?60:30;Save();}),UI.Choice(new[]{"4 Mbps • econômico","8 Mbps • equilibrado","16 Mbps • alta qualidade"},prefs.Video.Bitrate==4?"4 Mbps • econômico":prefs.Video.Bitrate==16?"16 Mbps • alta qualidade":"8 Mbps • equilibrado",v=>{prefs.Video.Bitrate=v.StartsWith("4")?4:v.StartsWith("16")?16:8;Save();}),UI.Check("Mostrar cursor no vídeo",prefs.Video.Cursor,v=>{prefs.Video.Cursor=v;Save();}),UI.Label("Posição do indicador flutuante"),UI.Choice(new[]{"Superior direito","Superior esquerdo","Inferior direito","Inferior esquerdo"},prefs.CaptureHudPosition,v=>{prefs.CaptureHudPosition=v;Save();SyncRecordingHud();}),UI.Text("Qualidade, monitor e áudio valem para a próxima captura. Dispositivos e volumes ficam em Áudio e microfone.",11,"#9999AC"));
        choices.Children.Add(UI.Label("Motor de captura"));choices.Children.Add(UI.Choice(new[]{"Automático","Duplicação DXGI","Captura compatível"},prefs.Video.Engine,v=>{prefs.Video.Engine=v;Save();}));choices.Children.Add(UI.Label("Finalizar se o espaço livre cair abaixo de"));choices.Children.Add(UI.Choice(new[]{"300 MB","500 MB","1000 MB","2000 MB"},prefs.Video.StopFreeMb+" MB",v=>{prefs.Video.StopFreeMb=int.Parse(v.Split(' ')[0]);Save();}));choices.Children.Add(UI.Button("Testar captura • prévia de 3 s",TestCapturePreview));body.Children.Add(UI.Card(UI.Fold("Qualidade e captura",choices),14));
        body.Children.Add(UI.Card(UI.Fold("Áudio e microfone",AudioOptions())));body.Children.Add(UI.Card(UI.Fold("Perfis por jogo",ProfileOptions())));
        body.Children.Add(UI.Card(UI.Fold("Atalhos de captura",CaptureShortcutOptions()),14));
        var folder=UI.Text(prefs.Video.Folder,11,"#9999AC");var destinations=new ActionGrid();destinations.Children.Add(UI.Button("Escolher pasta",()=>{using(var dialog=new Forms.FolderBrowserDialog{Description="Pasta para capturas do LUA",SelectedPath=Directory.Exists(prefs.Video.Folder)?prefs.Video.Folder:""})if(dialog.ShowDialog()==Forms.DialogResult.OK){prefs.Video.Folder=dialog.SelectedPath;folder.Text=prefs.Video.Folder;Save();}}));destinations.Children.Add(UI.Button("Abrir pasta",()=>{Directory.CreateDirectory(prefs.Video.Folder);OpenPath(prefs.Video.Folder);}));
        body.Children.Add(UI.Card(UI.Fold("Pasta e arquivos",UI.Stack(folder,destinations,UI.Text("Vídeos, Clipes e Prints ficam separados em subpastas. Captura o monitor e suas janelas visíveis. Para jogos que não aparecem, use janela sem bordas.",11,"#9999AC"))),14));UpdateVideo();
    }
    async void ToggleRecording(){if(sharedOwner!=null){sharedOwner.ToggleRecording();return;}if(videoBusy)return;captureAction=Recorder.Recording?"Finalizando vídeo":"Iniciando gravação";videoBusy=true;UpdateVideo();try{if(Recorder.Recording){await Recorder.StopRecording();VideoBalloon(Recorder.Status);}else await Recorder.StartRecording(VideoOptions(true));}catch(Exception ex){if(recorder!=null)recorder.Status=ex.Message;if(!exiting)Notice(ex.Message);}finally{videoBusy=false;UpdateVideo();}}
    async void ToggleReplay(){if(sharedOwner!=null){sharedOwner.ToggleReplay();return;}if(videoBusy)return;prefs.ReplayAlwaysOn=!Recorder.Replaying;Save();captureAction=Recorder.Replaying?"Desligando buffer":"Iniciando buffer";videoBusy=true;UpdateVideo();try{if(Recorder.Replaying)await Recorder.StopReplay();else await Recorder.StartReplay(VideoOptions(false));VideoBalloon(Recorder.Status);}catch(Exception ex){if(recorder!=null)recorder.Status=ex.Message;if(!exiting)Notice(ex.Message);}finally{videoBusy=false;UpdateVideo();}}
    async void SaveReplay(int seconds){if(sharedOwner!=null){sharedOwner.SaveReplay(seconds);return;}if(videoBusy){ShowClipToast("Aguarde um instante",captureAction=="Salvando clipe"?"Um clipe já está sendo salvo.":"O histórico está sendo preparado.");return;}if(!Recorder.Replaying&&!prefs.ReplayAlwaysOn){ShowClipToast("Histórico pausado","Ative os clipes retroativos em Galeria → Nova captura → Ajustes de captura.");return;}if(!Recorder.Replaying){EnsureAutoReplay();ShowClipToast("Histórico ainda começando","Aguarde alguns segundos para haver momentos anteriores disponíveis.");return;}captureAction="Salvando clipe";videoBusy=true;UpdateVideo();try{await Recorder.SaveClip(seconds,Path.Combine(prefs.Video.Folder,"Clipes"));ShowClipToast("Clipe salvo",Recorder.LastClipSeconds+" s anteriores ao clique"+(Recorder.LastClipSeconds<seconds?" • histórico disponível":""));await RefreshCaptureGalleries();}catch(Exception ex){ShowClipToast("Não foi possível salvar o clipe",ex.Message);}finally{videoBusy=false;captureAction="";UpdateVideo();}}
    async void VideoBalloon(string text){ShowToast("LUA • Capturas",text,()=>{ShowMain();BuildPage("gallery");});await RefreshCaptureGalleries();}
    void UpdateVideo(){
        var owner=sharedOwner??this;
        var current=owner.recorder;
        bool active=current!=null&&current.Recording;
        bool replaying=current!=null&&current.Replaying;
        bool busy=owner.videoBusy;
        UpdateCaptureWidget();
        if(tray!=null&&trayNormal!=null)tray.Icon=active?trayRecording:trayNormal;
        SyncRecordingHud();
        if (galleryRecording != null) {galleryRecording.Visibility = active ? Visibility.Visible : Visibility.Collapsed;galleryRecording.IsEnabled = !busy;}
        if(videoStatus!=null){
            videoStatus.Text=busy?(string.IsNullOrEmpty(owner.captureAction)?"Preparando…":owner.captureAction+"…")
                :active?"Gravação em andamento":"Pronto para gravar";
            videoDetail.Text=replaying?"Buffer ativo · "+current.AvailableSeconds()+" s disponíveis":prefs.ReplayAlwaysOn?"Preparando buffer de clipes…":"Buffer de clipes desligado";
            string label=active?"Parar e salvar":"Iniciar gravação";
            if(!Equals(System.Windows.Automation.AutomationProperties.GetName(recordButton), label))
                UI.ButtonLabel(recordButton,label);
            recordButton.IsEnabled=!busy;
            quickClipButton.IsEnabled=!busy&&(replaying||prefs.ReplayAlwaysOn);
        }
        if(page=="capture-settings"&&replayButton!=null){
            string label=replaying?"Pausar histórico":"Ativar histórico";
            if(!Equals(System.Windows.Automation.AutomationProperties.GetName(replayButton), label))
                UI.ButtonLabel(replayButton,label);
            replayButton.IsEnabled=!busy;
        }
        if(active){
            footer.Text="● Gravação em andamento";
            if(tray!=null)tray.Text="LUA • Gravando vídeo";
        }
    }
}
}
