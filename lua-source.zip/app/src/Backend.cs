﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using LibreHardwareMonitor.Hardware;

namespace LuaMonitor {
public class Preferences {
    public List<string> NavigationOrder=new List<string>(),HiddenNavigation=new List<string>();
    public string RecordKey="Ctrl+Shift+R",Clip30Key="Ctrl+Shift+F8",Clip60Key="Ctrl+Shift+F9",Clip120Key="Ctrl+Shift+F7",PrintKey="Ctrl+Shift+P",CaptureHudPosition="Superior direito";
    public RecordingOptions Video = new RecordingOptions();
    public int CacheMb=200,CompactVisibleCount=7;public double UiScale=1;public bool HighContrast=false,AutoProfiles=false;public string ConnectionLabel="",ActiveProfile="Uso diário";public List<CaptureProfile> Profiles=new List<CaptureProfile>();public Dictionary<string,bool> Folds=new Dictionary<string,bool>();
    public bool GamesGrid=true,GridDefaultApplied=false,ReplayAlwaysOn=true;public int QuickClipSeconds=30;public string WorkspaceKey="Ctrl+Shift+Space";public Dictionary<string,WidgetPlacement> Widgets=new Dictionary<string,WidgetPlacement>();
    public string UpdateSource="";public bool AutoUpdate=false;
    public bool CpuSensorAssist=true;public int Interval = 1500;
    public bool Animations = true, AutoFps = true;
    public List<string> GameFolders = new List<string>();
    public bool Sensors = true, StartWithWindows = false, MinimizeOnClose = true, Notifications = true;
    public int CpuWarning = 90, RamWarning = 90;
    public string Hotkey = "Ctrl+Shift+O", Accent = "Azul", OverlayPosition = "Superior esquerdo";
    public double OverlayOpacity = .88, OverlayScale = 1;
    public bool ShowCpu = true, ShowGpu = true, ShowRam = true, ShowNetwork = true, ShowFps = true, ShowTemps = true;
    public bool OverlayLocked = true;
    public string NetworkId = "";
    public static readonly string DefaultDataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "LUA");
    public static string DataDir = DefaultDataDir;
    public static Preferences Load() {
        try { string path=Path.Combine(DataDir,"settings.json");if(DataDir==DefaultDataDir&&!File.Exists(path)){string legacy=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"OrbitMonitor","settings.json");if(File.Exists(legacy))path=legacy;}
            var p = new JavaScriptSerializer().Deserialize<Preferences>(File.ReadAllText(path));if(p.Video==null)p.Video=new RecordingOptions();if(string.IsNullOrWhiteSpace(p.Video.Folder))p.Video.Folder=new RecordingOptions().Folder;if(p.GameFolders==null)p.GameFolders=new List<string>();if(p.Accent=="Verde")p.Accent="Cinza";if(p.Profiles==null)p.Profiles=new List<CaptureProfile>();if(p.Folds==null)p.Folds=new Dictionary<string,bool>();p.UiScale=Math.Max(1,Math.Min(1.5,p.UiScale));p.Interval = Math.Max(500, Math.Min(10000,p.Interval)); p.OverlayOpacity = Math.Max(.25, Math.Min(1,p.OverlayOpacity)); p.OverlayScale = Math.Max(.7, Math.Min(2,p.OverlayScale)); return p; } catch { return new Preferences(); }
    }
    public void Save() {
        Directory.CreateDirectory(DataDir);
        string target = Path.Combine(DataDir,"settings.json"), temp = target + ".tmp";
        File.WriteAllText(temp,new JavaScriptSerializer().Serialize(this));
        if (File.Exists(target)) File.Replace(temp,target,null); else File.Move(temp,target);
    }
}
public static class Format {
    public static string Bytes(double n) { string[] u = {"B","KB","MB","GB","TB"}; int i=0; while(n>=1024 && i<4){n/=1024;i++;} return n.ToString(i<2?"0":"0.0",CultureInfo.GetCultureInfo("pt-BR"))+" "+u[i]; }
    public static string Percent(double? v) { return v.HasValue ? v.Value.ToString("0")+"%" : "—"; }
    public static string Temp(double? v) { return v.HasValue ? v.Value.ToString("0")+" °C" : "—"; }
    public static string Rate(double n) { return (n*8/1000000).ToString("0.00",CultureInfo.GetCultureInfo("pt-BR"))+" Mbps"; }
}
public class SensorValue { public string Device,Name,Type,Unit; public double Value; }
public class DiskValue { public string Name,Label; public long Total,Free; public double UsedPercent { get { return Total==0?0:(Total-Free)*100.0/Total; } } }
public class NetValue { public string Id,Name,Address,Type; public long Speed,Received,Sent; }
public class Snapshot {
    public DateTime Time = DateTime.Now;
    public double? Cpu,Gpu,CpuTemp,GpuTemp;
    public ulong RamTotal,RamAvailable,CommitTotal,CommitAvailable;
    public double RamPercent { get { return RamTotal==0?0:(RamTotal-RamAvailable)*100.0/RamTotal; } }
    public double Download,Upload;
    public double? DiskRead,DiskWrite;
    public TimeSpan Uptime;
    public List<SensorValue> Sensors = new List<SensorValue>();
    public List<DiskValue> Disks = new List<DiskValue>();
    public List<NetValue> Networks = new List<NetValue>();
    public string CpuTempNote="Clique na temperatura para ativar o sensor da CPU.";public string SensorStatus="Iniciando sensores…";
}
public class Native {
    [StructLayout(LayoutKind.Sequential)] public struct MEMORY { public uint Length,Load; public ulong TotalPhys,AvailPhys,TotalPage,AvailPage,TotalVirtual,AvailVirtual,AvailExtended; }
    [DllImport("kernel32.dll")] public static extern bool GlobalMemoryStatusEx(ref MEMORY m);
    [DllImport("kernel32.dll")] public static extern bool GetSystemTimes(out long idle,out long kernel,out long user);
    [DllImport("kernel32.dll")] public static extern ulong GetTickCount64();
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr handle,out uint process);
    [DllImport("user32.dll",SetLastError=true)] public static extern bool RegisterHotKey(IntPtr hwnd,int id,uint modifiers,uint key);
    [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hwnd,int id);
    [DllImport("user32.dll",EntryPoint="GetWindowLong")] public static extern int GetWindowLong(IntPtr hwnd,int index);
    [DllImport("user32.dll",EntryPoint="SetWindowLong")] public static extern int SetWindowLong(IntPtr hwnd,int index,int value);
}
// English PDH paths avoid depending on the language of the Windows counters.
public sealed class DiskCounters : IDisposable {
    IntPtr query,read,write;
    [StructLayout(LayoutKind.Explicit)] struct Value { [FieldOffset(0)] public uint Status; [FieldOffset(8)] public double Number; }
    [DllImport("pdh.dll",CharSet=CharSet.Unicode)] static extern uint PdhOpenQuery(string source,IntPtr user,out IntPtr q);
    [DllImport("pdh.dll",CharSet=CharSet.Unicode)] static extern uint PdhAddEnglishCounter(IntPtr q,string path,IntPtr user,out IntPtr c);
    [DllImport("pdh.dll")] static extern uint PdhCollectQueryData(IntPtr q);
    [DllImport("pdh.dll")] static extern uint PdhGetFormattedCounterValue(IntPtr c,uint format,out uint type,out Value v);
    [DllImport("pdh.dll")] static extern uint PdhCloseQuery(IntPtr q);
    public DiskCounters() { try { PdhOpenQuery(null,IntPtr.Zero,out query); PdhAddEnglishCounter(query,@"\PhysicalDisk(_Total)\Disk Read Bytes/sec",IntPtr.Zero,out read); PdhAddEnglishCounter(query,@"\PhysicalDisk(_Total)\Disk Write Bytes/sec",IntPtr.Zero,out write); PdhCollectQueryData(query); } catch {} }
    double? Get(IntPtr c) { uint t; Value v; if(c==IntPtr.Zero || PdhGetFormattedCounterValue(c,0x200,out t,out v)!=0 || v.Status>1)return null; return Math.Max(0,v.Number); }
    public void Sample(Snapshot s) { try { if(query!=IntPtr.Zero){PdhCollectQueryData(query);s.DiskRead=Get(read);s.DiskWrite=Get(write);} } catch {} }
    public void Dispose(){ if(query!=IntPtr.Zero){PdhCloseQuery(query);query=IntPtr.Zero;} }
}
public sealed class MonitorService : IDisposable {
    Preferences prefs; Computer computer; DiskCounters diskCounters;
    bool sensorTried; string sensorError="";
    long oldIdle,oldKernel,oldUser; bool cpuPrimed;
    Dictionary<string,long[]> oldNet=new Dictionary<string,long[]>();
    Stopwatch elapsed=Stopwatch.StartNew(); double previousTime;
    public MonitorService(Preferences p){ prefs=p; }
    void OpenSensors(){
        if(sensorTried || !prefs.Sensors)return; sensorTried=true;
        try { computer=new Computer { IsCpuEnabled=true,IsGpuEnabled=true,IsMemoryEnabled=true,IsMotherboardEnabled=true,IsStorageEnabled=true,IsNetworkEnabled=false,IsControllerEnabled=false }; computer.Open(); }
        catch(Exception ex){ sensorError=ex.GetBaseException().Message; try{if(computer!=null)computer.Close();}catch{} computer=null; }
    }
    void ReadHardware(IHardware hw,Snapshot s){
        try {
            hw.Update(); string type=hw.HardwareType.ToString(); bool gpu=type.StartsWith("Gpu"),cpu=type=="Cpu";
            foreach(var sensor in hw.Sensors){
                if(!sensor.Value.HasValue)continue; double v=sensor.Value.Value; if(double.IsNaN(v)||double.IsInfinity(v))continue;
                string kind=sensor.SensorType.ToString();
                // Some low-level providers return zero when access to a temperature register fails.
                if(kind=="Temperature"&&(v<=0||v>150))continue;
                string unit=kind=="Temperature"?"°C":kind=="Load"||kind=="Control"||kind=="Level"?"%":kind=="Clock"?"MHz":kind=="Fan"?"RPM":kind=="Power"?"W":kind=="Voltage"?"V":kind=="Data"?"GB":kind=="SmallData"?"MB":kind=="Throughput"?"B/s":"";
                s.Sensors.Add(new SensorValue {Device=hw.Name,Name=sensor.Name,Type=kind,Value=v,Unit=unit});
                if(cpu&&kind=="Temperature")s.CpuTemp=Math.Max(s.CpuTemp??v,v);
                if(gpu&&kind=="Temperature"&&sensor.Name.IndexOf("hot",StringComparison.OrdinalIgnoreCase)<0&&sensor.Name.IndexOf("memory",StringComparison.OrdinalIgnoreCase)<0)s.GpuTemp=Math.Max(s.GpuTemp??v,v);
                if(gpu&&kind=="Load"&&(sensor.Name.IndexOf("core",StringComparison.OrdinalIgnoreCase)>=0||sensor.Name.IndexOf("3D",StringComparison.OrdinalIgnoreCase)>=0))s.Gpu=Math.Max(s.Gpu??v,v);
            }
            foreach(var sub in hw.SubHardware)ReadHardware(sub,s);
        }catch(Exception ex){sensorError=ex.GetBaseException().Message;}
    }
    public Snapshot Sample(){
        Snapshot s=new Snapshot(); double now=elapsed.Elapsed.TotalSeconds,dt=now-previousTime; previousTime=now;
        long idle,kernel,user; if(Native.GetSystemTimes(out idle,out kernel,out user)){
            long total=(kernel-oldKernel)+(user-oldUser); if(cpuPrimed&&total>0)s.Cpu=Math.Max(0,Math.Min(100,100.0*(total-(idle-oldIdle))/total));
            oldIdle=idle;oldKernel=kernel;oldUser=user;cpuPrimed=true;
        }
        Native.MEMORY mem=new Native.MEMORY(); mem.Length=(uint)Marshal.SizeOf(typeof(Native.MEMORY));
        if(Native.GlobalMemoryStatusEx(ref mem)){s.RamTotal=mem.TotalPhys;s.RamAvailable=mem.AvailPhys;s.CommitTotal=mem.TotalPage;s.CommitAvailable=mem.AvailPage;}
        s.Uptime=TimeSpan.FromMilliseconds(Native.GetTickCount64());
        try { foreach(var drive in DriveInfo.GetDrives()){try{ if(drive.IsReady&&drive.DriveType==DriveType.Fixed)s.Disks.Add(new DiskValue{Name=drive.Name,Label=drive.VolumeLabel,Total=drive.TotalSize,Free=drive.AvailableFreeSpace});}catch{}} }catch{}
        try{
            var seen=new HashSet<string>();
            foreach(var nic in NetworkInterface.GetAllNetworkInterfaces()){
                if(nic.OperationalStatus!=OperationalStatus.Up||nic.NetworkInterfaceType==NetworkInterfaceType.Loopback||nic.NetworkInterfaceType==NetworkInterfaceType.Tunnel)continue;
                try {
                    var stat=nic.GetIPStatistics(); var n=new NetValue {Id=nic.Id,Name=nic.Name,Type=nic.NetworkInterfaceType.ToString(),Speed=nic.Speed,Received=stat.BytesReceived,Sent=stat.BytesSent,Address=string.Join(" • ",nic.GetIPProperties().UnicastAddresses.Where(x=>x.Address.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork).Select(x=>x.Address.ToString()).ToArray())};
                    s.Networks.Add(n);seen.Add(nic.Id); long[] previous;
                    if(oldNet.TryGetValue(nic.Id,out previous)&&dt>0&&(prefs.NetworkId==""||prefs.NetworkId==nic.Id)){s.Download+=Math.Max(0,n.Received-previous[0])/dt;s.Upload+=Math.Max(0,n.Sent-previous[1])/dt;}
                    oldNet[nic.Id]=new long[]{n.Received,n.Sent};
                }catch{}
            }
            foreach(string id in oldNet.Keys.Where(x=>!seen.Contains(x)).ToArray())oldNet.Remove(id);
        }catch{}
        if(diskCounters==null)diskCounters=new DiskCounters(); diskCounters.Sample(s);
        OpenSensors();
        if(prefs.Sensors&&computer!=null){foreach(var hw in computer.Hardware)ReadHardware(hw,s);s.SensorStatus=s.Sensors.Count>0?"Sensores disponíveis: "+s.Sensors.Count:"Nenhum sensor acessível";}
        else s.SensorStatus=prefs.Sensors?"Sensores indisponíveis":"Sensores desativados";
        if(!string.IsNullOrEmpty(sensorError))s.SensorStatus+=" • "+sensorError;
        return s;
    }
    public void Dispose(){try{if(computer!=null)computer.Close();}catch{} if(diskCounters!=null)diskCounters.Dispose();}
}
public class Inventory {
    public string Cpu="Carregando…",Gpu="Carregando…",Board="—",Os="Windows",Ram="—",Disks="—";
    public List<string> Errors=new List<string>();
    string Query(string cls,Func<ManagementBaseObject,string> read){
        try { using(var search=new ManagementObjectSearcher("SELECT * FROM "+cls)){using(var items=search.Get()){return string.Join("\n",items.Cast<ManagementBaseObject>().Select(read).Distinct().ToArray());}} }
        catch(Exception ex){Errors.Add(cls+": "+ex.Message);return "Não disponível";}
    }
    public static Inventory Load(){ var i=new Inventory(); i.Cpu=i.Query("Win32_Processor",x=>x["Name"]+" • "+x["NumberOfCores"]+" núcleos / "+x["NumberOfLogicalProcessors"]+" threads"); i.Gpu=i.Query("Win32_VideoController",x=>x["Name"]+" • driver "+x["DriverVersion"]); i.Board=i.Query("Win32_BaseBoard",x=>x["Manufacturer"]+" "+x["Product"]); i.Os=i.Query("Win32_OperatingSystem",x=>x["Caption"]+" • build "+x["BuildNumber"]); i.Ram=i.Query("Win32_PhysicalMemory",x=>Format.Bytes(Convert.ToDouble(x["Capacity"]))+" • "+x["Speed"]+" MHz • "+x["Manufacturer"]); i.Disks=i.Query("Win32_DiskDrive",x=>x["Model"]+" • "+Format.Bytes(Convert.ToDouble(x["Size"])));
        try {using(var key=Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0")){if(i.Cpu=="Não disponível"&&key!=null)i.Cpu=key.GetValue("ProcessorNameString", "CPU").ToString().Trim()+" • "+Environment.ProcessorCount+" threads";}
            using(var key=Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\BIOS")){if(i.Board=="Não disponível"&&key!=null)i.Board=key.GetValue("BaseBoardManufacturer","")+" "+key.GetValue("BaseBoardProduct","");}
            using(var key=Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion")){if(i.Os=="Não disponível"&&key!=null)i.Os="Windows • build "+key.GetValue("CurrentBuildNumber","")+" • "+key.GetValue("DisplayVersion","");}
        }catch{}
        return i;
    }
}
public class ProcessValue { public int Id; public string Name; public long Memory; public double? Cpu; }
public class ProcessReader {
    Dictionary<int,Tuple<long,double>> old=new Dictionary<int,Tuple<long,double>>(); Stopwatch clock=Stopwatch.StartNew();
    public List<ProcessValue> Read(){
        var result=new List<ProcessValue>(); var next=new Dictionary<int,Tuple<long,double>>(); double now=clock.Elapsed.TotalSeconds;
        foreach(var p in Process.GetProcesses()){using(p){try{long ticks=p.TotalProcessorTime.Ticks; Tuple<long,double> prior; double? cpu=null; if(old.TryGetValue(p.Id,out prior)&&now>prior.Item2&&ticks>=prior.Item1)cpu=Math.Min(100,(ticks-prior.Item1)/10000000.0/(now-prior.Item2)/Environment.ProcessorCount*100); next[p.Id]=Tuple.Create(ticks,now); result.Add(new ProcessValue{Id=p.Id,Name=p.ProcessName,Memory=p.WorkingSet64,Cpu=cpu});}catch{}}}
        old=next;return result;
    }
}
public class SpaceEntry { public string Path; public long Bytes; public bool IsDirectory; }
public class ScanResult { public string Root; public long Bytes,Files; public int Skipped; public bool Cancelled; public List<SpaceEntry> Folders=new List<SpaceEntry>(),LargeFiles=new List<SpaceEntry>(); public TimeSpan Duration; }
public class ScanProgress { public long Bytes,Files; public int Skipped; public string Path; }
public static class SpaceScanner {
    public static ScanResult Scan(string root,CancellationToken token,Action<ScanProgress> progress){
        root=Path.GetFullPath(root); var watch=Stopwatch.StartNew(); var r=new ScanResult {Root=root}; var totals=new Dictionary<string,long>(StringComparer.OrdinalIgnoreCase); var stack=new Stack<Tuple<string,string>>(); stack.Push(Tuple.Create(root,"Arquivos na raiz")); long last=0;
        try{
            if((File.GetAttributes(root)&FileAttributes.ReparsePoint)!=0)throw new IOException("Escolha uma pasta física. Links e junções não são percorridos.");
            while(stack.Count>0){token.ThrowIfCancellationRequested(); var item=stack.Pop();
                try{
                    foreach(string path in Directory.EnumerateFileSystemEntries(item.Item1)){
                        token.ThrowIfCancellationRequested();
                        try{
                            var attrs=File.GetAttributes(path); if((attrs&FileAttributes.ReparsePoint)!=0){r.Skipped++;continue;}
                            if((attrs&FileAttributes.Directory)!=0){string group=item.Item1.Equals(root,StringComparison.OrdinalIgnoreCase)?path:item.Item2; stack.Push(Tuple.Create(path,group)); if(!totals.ContainsKey(group))totals[group]=0;}
                            else {long size=new FileInfo(path).Length; r.Bytes+=size;r.Files++; if(!totals.ContainsKey(item.Item2))totals[item.Item2]=0;totals[item.Item2]+=size;
                                if(r.LargeFiles.Count<50||size>r.LargeFiles[r.LargeFiles.Count-1].Bytes){r.LargeFiles.Add(new SpaceEntry{Path=path,Bytes=size});r.LargeFiles=r.LargeFiles.OrderByDescending(x=>x.Bytes).Take(50).ToList();}
                            }
                        }catch(UnauthorizedAccessException){r.Skipped++;}catch(IOException){r.Skipped++;}catch(System.Security.SecurityException){r.Skipped++;}
                        if(watch.ElapsedMilliseconds-last>=400){last=watch.ElapsedMilliseconds;progress(new ScanProgress{Files=r.Files,Bytes=r.Bytes,Skipped=r.Skipped,Path=path});}
                    }
                }catch(UnauthorizedAccessException){r.Skipped++;}catch(IOException){r.Skipped++;}catch(System.Security.SecurityException){r.Skipped++;}
            }
        }catch(OperationCanceledException){r.Cancelled=true;}
        r.Folders=totals.Select(x=>new SpaceEntry{Path=x.Key,Bytes=x.Value,IsDirectory=x.Key!="Arquivos na raiz"}).OrderByDescending(x=>x.Bytes).ToList();r.Duration=watch.Elapsed;return r;
    }
}
public sealed class FpsReader : IDisposable {
    class Chain {public Queue<Tuple<DateTime,double>> App=new Queue<Tuple<DateTime,double>>(),Display=new Queue<Tuple<DateTime,double>>();public Queue<Tuple<DateTime,string>> Types=new Queue<Tuple<DateTime,string>>();public double LastCpu=-1,AppMs,DisplayMs;public long AppFrames,DisplayFrames;}
    FpsCapture capture;readonly object gate=new object();Dictionary<string,Chain> chains=new Dictionary<string,Chain>();string[] headers;string captureError="";
    public long ReceivedFrames;public DateTime LastFrameUtc;public int Generation;public volatile string Status="Captura desligada";public int Target;public string TargetName="Nenhum jogo selecionado",FrameGeneration="Sem identificação disponível";public double? Fps,FrameMs,Low,DisplayedFps;
    public bool Running {get{return capture!=null&&capture.Running;}}
    static int Column(string[] cols,string name){return Array.FindIndex(cols,c=>c.Trim().TrimStart('\ufeff').Equals(name,StringComparison.OrdinalIgnoreCase));}
    public static string[] Csv(string line){var fields=new List<string>();var field=new StringBuilder();bool quote=false;for(int i=0;i<line.Length;i++){char c=line[i];if(c=='"'){if(quote&&i+1<line.Length&&line[i+1]=='"'){field.Append('"');i++;}else quote=!quote;}else if(c==','&&!quote){fields.Add(field.ToString());field.Clear();}else field.Append(c);}fields.Add(field.ToString());return fields.ToArray();}
    string Field(string[] cols,string name){int index=Column(headers,name);return index>=0&&index<cols.Length?cols[index]:"";}
    double Number(string[] cols,string name){double value;return double.TryParse(Field(cols,name),NumberStyles.Float,CultureInfo.InvariantCulture,out value)&&!double.IsNaN(value)&&!double.IsInfinity(value)?value:-1;}
    public void Feed(string line){if(string.IsNullOrWhiteSpace(line))return;if(line.IndexOf("access denied",StringComparison.OrdinalIgnoreCase)>=0){captureError="Captura sem permissão. Inicie novamente e aceite a solicitação do Windows.";Status=captureError;return;}if(line.StartsWith("error:",StringComparison.OrdinalIgnoreCase)){captureError=line;Status=line;return;}var cols=Csv(line);lock(gate){if(Column(cols,"msBetweenPresents")>=0||Column(cols,"FrameTime")>=0){headers=cols;Status="Formato do PresentMon reconhecido • aguardando quadros";return;}if(headers==null)return;int pid;if(!int.TryParse(Field(cols,"ProcessID"),out pid)||pid!=Target)return;
        string key=Field(cols,"SwapChainAddress");Chain chain;if(!chains.TryGetValue(key,out chain)){if(chains.Count>=32)return;chains[key]=chain=new Chain();}var now=DateTime.UtcNow;string type=Field(cols,"FrameType");bool application=type==""||type=="Application";double ms=Number(cols,"msBetweenPresents");if(ms<0)ms=Number(cols,"FrameTime");if(application){double cpu=Number(cols,"CPUStartQPCTime");if(cpu<0)cpu=Number(cols,"CPUStartTime");if(cpu>=0){ms=chain.LastCpu<0?-1:cpu-chain.LastCpu;chain.LastCpu=cpu;}if(ms>0&&ms<=10000){chain.App.Enqueue(Tuple.Create(now,ms));chain.AppFrames++;chain.AppMs+=ms;}}
        double displayed=Number(cols,"DisplayedTime");if(displayed>0&&displayed<=10000){chain.Display.Enqueue(Tuple.Create(now,displayed));chain.DisplayFrames++;chain.DisplayMs+=displayed;}if(type!=""&&type!="Application"&&type!="Unknown"&&type!="NotSet"&&type!="Repeated")chain.Types.Enqueue(Tuple.Create(now,type));while(chain.App.Count>600)chain.App.Dequeue();while(chain.Display.Count>1200)chain.Display.Dequeue();while(chain.Types.Count>600)chain.Types.Dequeue();ReceivedFrames++;LastFrameUtc=now;Status="Capturando • "+TargetName;}}
    string Dominant(){var now=DateTime.UtcNow;return chains.OrderByDescending(pair=>pair.Value.App.Count(x=>(now-x.Item1).TotalSeconds<=2)).ThenByDescending(pair=>pair.Value.Display.Count(x=>(now-x.Item1).TotalSeconds<=2)).Select(pair=>pair.Key).FirstOrDefault();}
    public FpsTotals Totals(string key=null){lock(gate){key=key??Dominant();Chain chain;if(key==null||!chains.TryGetValue(key,out chain))return null;return new FpsTotals{Chain=key,Generation=Generation,AppFrames=chain.AppFrames,AppMs=chain.AppMs,DisplayFrames=chain.DisplayFrames,DisplayMs=chain.DisplayMs};}}
    public void Update(){lock(gate){var now=DateTime.UtcNow;foreach(var c in chains.Values){while(c.App.Count>0&&(now-c.App.Peek().Item1).TotalSeconds>10)c.App.Dequeue();while(c.Display.Count>0&&(now-c.Display.Peek().Item1).TotalSeconds>10)c.Display.Dequeue();while(c.Types.Count>0&&(now-c.Types.Peek().Item1).TotalSeconds>2)c.Types.Dequeue();}string key=Dominant();Chain chain=key==null?null:chains[key];Fps=FrameMs=Low=DisplayedFps=null;FrameGeneration="Sem identificação disponível";if(chain!=null){var active=chain.App.Where(x=>(now-x.Item1).TotalSeconds<=2).Select(x=>x.Item2).ToArray();if(active.Length>1){FrameMs=active.Average();Fps=1000/FrameMs.Value;var history=chain.App.Select(x=>x.Item2).ToArray();if(history.Length>=100)Low=1000/history.OrderByDescending(x=>x).Take((int)Math.Ceiling(history.Length*.01)).Average();}var display=chain.Display.Where(x=>(now-x.Item1).TotalSeconds<=2).Select(x=>x.Item2).ToArray();if(display.Length>1)DisplayedFps=1000/display.Average();if(chain.Types.Count>0)FrameGeneration="Quadros gerados identificados • "+chain.Types.Last().Item2;}if(Running&&capture!=null&&!capture.WaitingPermission&&Fps==null&&captureError=="")Status=ReceivedFrames>0?"Sem quadros recentes • "+TargetName:"Aguardando quadros • "+TargetName+" • PID "+Target;}}
    public void Start(int pid,string name,bool testNoElevation=false){Stop();ReceivedFrames=0;LastFrameUtc=DateTime.MinValue;Target=pid;TargetName=name;captureError="";Status="Iniciando captura…";var owned=new FpsCapture();capture=owned;try{owned.Start(pid,line=>{if(capture==owned)Feed(line);},status=>{if(capture==owned)Status=captureError==""?status:captureError;},testNoElevation);}catch(Exception ex){Status="Erro de captura: "+ex.Message;owned.Dispose();}}
    public void Stop(){var owned=capture;capture=null;if(owned!=null)owned.Dispose();lock(gate){Generation++;chains.Clear();headers=null;Fps=FrameMs=Low=DisplayedFps=null;FrameGeneration="Sem identificação disponível";}captureError="";Status="Captura desligada";}
    public void Dispose(){Stop();}
}
public class FpsTotals {public string Chain;public int Generation;public long AppFrames,DisplayFrames;public double AppMs,DisplayMs;}
}
