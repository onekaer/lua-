using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace LuaMonitor {
public class PlaytimeImportRow { public string Name, Platform, Account; public double Hours; }
public sealed partial class DesktopController {
    PlaytimeStore playtime;
    DispatcherTimer playtimeTimer;
    bool playtimeScanning;
    DateTime playtimeLastScan, playtimeCatalogRefresh;
    readonly System.Diagnostics.Stopwatch playtimeClock = System.Diagnostics.Stopwatch.StartNew();
    double playtimeLastTick;
    StackPanel playtimeSummary;
    readonly List<KeyValuePair<GameEntry, TextBlock>> playtimeLabels = new List<KeyValuePair<GameEntry, TextBlock>>();
    PlaytimeStore Playtime { get { return sharedOwner == null ? playtime : sharedOwner.Playtime; } }
    static string Hours(double seconds) { return (seconds / 3600).ToString("0.0", CultureInfo.CurrentCulture) + " h"; }
    void StartPlaytime() {
        if (verify || sharedOwner != null) return;
        playtime = new PlaytimeStore(Path.Combine(Preferences.DataDir, "playtime.json"));
        playtimeTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
        playtimeTimer.Tick += async (s, e) => await ScanPlaytime();
        playtimeTimer.Start();
    }
    async Task ScanPlaytime() {
        if (playtimeScanning || exiting || Playtime == null || Playtime.Data == null) return;
        playtimeScanning = true;
        try {
            if (DateTime.UtcNow >= playtimeCatalogRefresh) {
                await LoadGames(true);
                playtimeCatalogRefresh = DateTime.UtcNow.AddMinutes(5);
            }
            foreach (var installed in library.Games) {
                var game = Playtime.Register(installed.Name, installed.Platform);
                if (string.IsNullOrEmpty(game.Folder)) game.Folder = installed.Folder;
            }
            var processes = await Task.Run(() => PlaytimeStore.Processes());
            if (exiting) return;
            int previousCount = Playtime.Data.Games.Count;
            foreach (var process in processes) {
                if (Playtime.Data.Games.Any(g => !string.IsNullOrEmpty(g.Executable) && PlaytimeStore.Matches(g, process))) continue;
                var detected = EmulatorPlaytime.Read(process.Path, process.Title);
                if (detected == null) continue;
                var game = Playtime.Register(detected.Name, detected.Platform);
                if (string.IsNullOrEmpty(game.Executable)) {
                    game.Executable = process.Path; game.WindowTitle = detected.Token;
                }
            }
            // Also match every installed location when the same title exists in multiple stores.
            var candidates = Playtime.Data.Games.ToList();
            foreach (var installed in library.Games) {
                var known = Playtime.Find(installed.Name);
                if (!string.IsNullOrEmpty(known.Executable)) continue;
                candidates.Add(new TrackedGame { Id = known.Id, Folder = installed.Folder });
            }
            var trackedById = Playtime.Data.Games.ToDictionary(game => game.Id);
            var running = new HashSet<string>();
            foreach (var process in processes) {
                var match = candidates.Where(g => PlaytimeStore.Matches(g, process))
                    .OrderByDescending(g => !string.IsNullOrEmpty(g.Executable))
                    .ThenByDescending(g => (g.WindowTitle ?? "").Length)
                    .ThenByDescending(g => (g.Folder ?? "").Length).FirstOrDefault();
                if (match != null && running.Add(match.Id)) trackedById[match.Id].LastExecutable = process.Path;
            }
            double nowTick = playtimeClock.Elapsed.TotalSeconds;
            DateTime now = DateTime.UtcNow;
            double elapsed = nowTick - playtimeLastTick;
            if ((now - playtimeLastScan).TotalSeconds > 15) elapsed = 0;
            var previouslyActive = new HashSet<string>(Playtime.Active.Keys);
            Playtime.Tick(running, elapsed, now);
            playtimeLastTick = nowTick;
            playtimeLastScan = now;
            Playtime.Save();
            if (previousCount != Playtime.Data.Games.Count) RenderGames();
            if (!previouslyActive.SetEquals(Playtime.Active.Keys)) RenderSessionList();
        } catch (Exception ex) { Playtime.Error = "Contagem: " + ex.Message; }
        finally {
            playtimeScanning = false;
            RenderPlaytimeSummary();
            RenderContinueGame();
            foreach (var label in playtimeLabels) label.Value.Text = GameHours(label.Key);
        }
    }
    void StopPlaytime() {
        if (playtimeTimer != null) playtimeTimer.Stop();
        if (playtime == null) return;
        try { playtime.Active.Clear(); playtime.Save(); } catch (Exception ex) { Notice("Não foi possível salvar as horas: " + ex.Message); }
    }
    string GameHours(GameEntry game) {
        var tracked = Playtime == null ? null : Playtime.Find(game.Name);
        return tracked == null ? "Horas ainda não registradas" : Hours(tracked.TotalSeconds) + (Playtime.Active.ContainsKey(tracked.Id) ? " • Jogando agora" : " jogadas");
    }
    TextBlock GameHoursLabel(GameEntry game) {
        var label = UI.Text(GameHours(game), 11, "#ACBDE3");
        playtimeLabels.Add(new KeyValuePair<GameEntry, TextBlock>(game, label)); return label;
    }
    List<GameEntry> GamesWithPlaytime() {
        var result = library.Games.ToList();
        if (Playtime == null || Playtime.Data == null) return result;
        var names = new HashSet<string>(result.Select(g => PlaytimeStore.Identity(g.Name)));
        foreach (var game in Playtime.Data.Games.Where(g => !names.Contains(g.Id))) {
            result.Add(TrackedLibraryEntry(game));
        }
        return result;
    }
    double TotalGameSeconds(GameEntry game) {
        var tracked = Playtime == null ? null : Playtime.Find(game.Name);
        return tracked == null ? 0 : tracked.TotalSeconds;
    }
    UIElement PlaytimePanel() {
        playtimeSummary = new StackPanel();
        var quickActions = UI.Inline(UI.Button("Importar horas", () => ShowGameImportOptions(null)),
            UI.Button("Adicionar jogo", ShowGameAddOptions, true));
        RenderPlaytimeSummary();
        return UI.Stack(quickActions, playtimeSummary);
    }
    void RenderPlaytimeSummary() {
        if (playtimeSummary == null) return;
        playtimeSummary.Children.Clear();
        if (Playtime == null) { playtimeSummary.Children.Add(UI.Text("Contagem disponível durante o uso normal do LUA.", 12)); return; }
        if (Playtime.Error != null) playtimeSummary.Children.Add(UI.Text(Playtime.Error, 12, "#FFB1BC"));
        if (Playtime.Data == null) return;
        playtimeSummary.Children.Add(UI.Text(Hours(Playtime.Data.Games.Sum(g => g.TotalSeconds)) + " no total", 20, "#EEEEF4", true));
        foreach (var pair in Playtime.Active) {
            var game = Playtime.Data.Games.First(g => g.Id == pair.Key);
            playtimeSummary.Children.Add(UI.Text(game.Name + " • sessão " + TimeSpan.FromSeconds(pair.Value.Seconds).ToString(@"hh\:mm\:ss") + " • total " + Hours(game.TotalSeconds), 12, "#ACBDE3"));
        }
    }
    TextBox PlaytimeField(StackPanel panel, string label, string value) {
        panel.Children.Add(UI.Label(label));
        var field = new TextBox { Text = value ?? "", Margin = new Thickness(0, 3, 0, 8), Padding = new Thickness(8) };
        System.Windows.Automation.AutomationProperties.SetName(field, label);
        panel.Children.Add(field); return field;
    }
    bool RequirePlaytime() {
        if (Playtime != null && Playtime.Data != null) return true;
        Notice(Playtime == null ? "A contagem está disponível durante o uso normal do LUA." : Playtime.Error); return false;
    }
    void ShowGameImportOptions(string gameName) {
        if (!RequirePlaytime()) return;
        ShowGameChoices("Importar horas",
            Tuple.Create("Conta Steam", (Action)ImportSteamPlaytime),
            Tuple.Create("Contas Steam deste PC", (Action)ImportLocalSteam),
            Tuple.Create("Arquivo CSV ou JSON", (Action)ImportPlaytimeFile),
            Tuple.Create("Informar horas por conta", (Action)(() => ImportPlaytimeDialog(gameName))));
    }

    void ShowGameAddOptions() {
        ShowGameChoices("Adicionar jogo",
            Tuple.Create("Detectar jogos instalados", (Action)(async () => await LoadGames(true))),
            Tuple.Create("Adicionar pasta de instalação", (Action)AddGameFolder),
            Tuple.Create("Cadastrar executável ou emulador", (Action)AddTrackedGame));
    }

    void ShowGameChoices(string title, params Tuple<string, Action>[] choices) {
        var actions = new StackPanel();
        var dialog = NewDialog(title, actions);
        foreach (var choice in choices)
            actions.Children.Add(UI.Button(choice.Item1, () => { dialog.Close(); choice.Item2(); }));
        var cancel = UI.Button("Cancelar", () => dialog.Close());
        cancel.IsCancel = true;
        actions.Children.Add(cancel);
        dialog.ShowDialog();
    }
    void AddTrackedGame() {
        if (!RequirePlaytime()) return;
        var picker = new Microsoft.Win32.OpenFileDialog { Filter = "Executável (*.exe)|*.exe", Title = "Selecione o executável do jogo ou emulador" };
        if (picker.ShowDialog(window) != true) return;
        var fields = new StackPanel();
        var name = PlaytimeField(fields, "Nome do jogo (use o mesmo nome para reunir lojas e contas)", Path.GetFileNameWithoutExtension(picker.FileName));
        var title = PlaytimeField(fields, "Emulador: trecho exclusivo do título da janela durante o jogo", "");
        fields.Children.Add(UI.Text("Para jogos nativos, deixe o título vazio. Para emulação, informe o nome ou identificador exibido na janela do emulador. A contagem acompanha o processo, inclusive em segundo plano.", 11));
        var dialog = NewDialog("Adicionar jogo ao acompanhamento", fields);
        ((StackPanel)dialog.Tag).Children.Add(UI.Button("Salvar jogo", async () => {
            try {
                if (IsEmulator(picker.FileName) && string.IsNullOrWhiteSpace(title.Text)) throw new ArgumentException("Informe o identificador do jogo na janela do emulador.");
                var game = Playtime.Register(name.Text, string.IsNullOrWhiteSpace(title.Text) ? "Executável local" : "Emulador");
                game.Executable = Path.GetFullPath(picker.FileName); game.WindowTitle = title.Text.Trim();
                Playtime.Save(); dialog.Close();
                await (sharedOwner ?? this).ScanPlaytime(); RenderPlaytimeSummary(); RenderGames();
            } catch (Exception ex) { Notice(ex.Message); }
        }, true));
        dialog.ShowDialog();
    }
    static bool IsEmulator(string path) { return Regex.IsMatch(Path.GetFileNameWithoutExtension(path), "^(pcsx2|rpcs3|dolphin|duckstation|ppsspp|cemu|ryujinx|eden|azahar|yuzu|suyu|mgba|melonds|desmume|xenia|dosbox|retroarch)", RegexOptions.IgnoreCase); }
    void ImportPlaytimeDialog(string gameName) {
        if (!RequirePlaytime()) return;
        var fields = new StackPanel();
        var name = PlaytimeField(fields, "Jogo", gameName);
        string platform = "Steam";
        fields.Children.Add(UI.Label("Plataforma"));
        fields.Children.Add(UI.Choice(new[] { "Steam", "Xbox", "Battle.net", "Epic Games", "Riot Games", "EA", "Ubisoft", "Rockstar", "GOG", "Hydra", "Emulador", "Outra" }, platform, v => platform = v));
        var account = PlaytimeField(fields, "Identificação da conta", "");
        var hours = PlaytimeField(fields, "Total de horas informado pela plataforma", "");
        fields.Children.Add(UI.Text("A mesma conta e plataforma são atualizadas ao importar novamente. Contas diferentes são somadas. Na importação, preservamos o maior entre a soma das contas e o total atual. Novas sessões são acrescentadas depois. Totais sem datas não permitem uma união exata; uma atualização nunca reduz o total.", 11));
        var dialog = NewDialog("Importar horas anteriores", fields);
        var actions = new ActionGrid();
        actions.Children.Add(UI.Button("Revisar horas da conta", () => {
            double value;
            if (!double.TryParse(hours.Text, NumberStyles.Number, CultureInfo.CurrentCulture, out value) || !PlaytimeStore.ValidSeconds(value * 3600)) { Notice("Informe uma quantidade válida de horas."); return; }
            try {
                ReviewPlaytimeImport(new List<PlaytimeImportRow> {
                    new PlaytimeImportRow { Name = name.Text, Platform = platform, Account = account.Text, Hours = value }
                }, () => dialog.Close());
            } catch (Exception ex) { Notice(ex.Message); }
        }, true));
        actions.Children.Add(UI.Button("Salvar modelo de arquivo…", () => {
            var save = new Microsoft.Win32.SaveFileDialog { Filter = "CSV|*.csv|JSON|*.json", FileName = "modelo-horas" };
            if (save.ShowDialog(dialog) == true) try {
                File.WriteAllText(save.FileName, string.Equals(Path.GetExtension(save.FileName), ".csv", StringComparison.OrdinalIgnoreCase)
                    ? "Name,Platform,Account,Hours\r\nNome do jogo,Steam,Minha conta,12.5\r\n"
                    : "[{\"Name\":\"Nome do jogo\",\"Platform\":\"Steam\",\"Account\":\"Minha conta\",\"Hours\":12.5}]");
            } catch (Exception ex) { Notice(ex.Message); }
        }));
        ((StackPanel)dialog.Tag).Children.Add(actions); dialog.ShowDialog();
    }
    void ImportPlaytimeFile() {
        var picker = new Microsoft.Win32.OpenFileDialog { Filter = "Histórico CSV ou JSON|*.csv;*.json" };
        if (picker.ShowDialog(window) != true) return;
        try {
            if (new FileInfo(picker.FileName).Length > 8 * 1024 * 1024) throw new InvalidDataException("O arquivo excede 8 MB.");
            var rows = string.Equals(Path.GetExtension(picker.FileName), ".csv", StringComparison.OrdinalIgnoreCase)
                ? ReadPlaytimeCsv(picker.FileName)
                : new JavaScriptSerializer { MaxJsonLength = 8 * 1024 * 1024 }.Deserialize<List<PlaytimeImportRow>>(File.ReadAllText(picker.FileName));
            ReviewPlaytimeImport(rows);
        } catch (Exception ex) { Notice("Importação: " + ex.Message); }
    }
    static List<PlaytimeImportRow> ReadPlaytimeCsv(string path) {
        string header;
        using (var reader = new StreamReader(path)) header = reader.ReadLine() ?? "";
        var rows = new List<PlaytimeImportRow>();
        using (var csv = new Microsoft.VisualBasic.FileIO.TextFieldParser(path)) {
            bool semicolon = header.Contains(";");
            csv.SetDelimiters(semicolon ? ";" : ",");
            var columns = csv.ReadFields() ?? new string[0];
            var expected = new[] { "Name", "Platform", "Account", "Hours" };
            if (!columns.SequenceEqual(expected, StringComparer.OrdinalIgnoreCase))
                throw new InvalidDataException("O cabeçalho CSV precisa ter Name, Platform, Account e Hours.");
            while (!csv.EndOfData) {
                var fields = csv.ReadFields();
                double hours;
                if (fields == null || fields.Length != 4 || rows.Count == 20000 ||
                    !double.TryParse(semicolon ? fields[3].Replace(',', '.') : fields[3],
                        NumberStyles.Float, CultureInfo.InvariantCulture, out hours))
                    throw new InvalidDataException("Linha CSV inválida ou acima do limite de 20.000 registros.");
                rows.Add(new PlaytimeImportRow { Name = fields[0], Platform = fields[1], Account = fields[2], Hours = hours });
            }
        }
        return rows;
    }

    void ReviewPlaytimeImport(List<PlaytimeImportRow> rows, Action confirmed = null) {
        if (rows == null || rows.Count == 0 || rows.Count > 20000 || rows.Any(r => r == null || string.IsNullOrWhiteSpace(r.Name) || r.Name.Length > 300 || string.IsNullOrWhiteSpace(r.Platform) || string.IsNullOrWhiteSpace(r.Account) || !PlaytimeStore.ValidSeconds(r.Hours * 3600)))
            throw new InvalidDataException("Cada registro precisa de Name, Platform, Account e Hours válidos.");
        if (rows.GroupBy(r => PlaytimeStore.Identity(r.Name) + "\n" + PlaytimeStore.Identity(r.Platform) + "\n" + PlaytimeStore.Identity(r.Account)).Any(g => g.Count() > 1))
            throw new InvalidDataException("O arquivo contém registros repetidos do mesmo jogo, plataforma e conta.");
        var list = new StackPanel();
        foreach (var row in rows) list.Children.Add(UI.Text(row.Name + " • " + row.Platform + " • " + row.Account + " • " + Hours(row.Hours * 3600), 12));
        var dialog = NewDialog("Revisar " + rows.Count + " registros", new ScrollViewer { Content = list, MaxHeight = 340 });
        ((StackPanel)dialog.Tag).Children.Add(UI.Button("Confirmar importação", () => {
            try {
                foreach (var row in rows) Playtime.Import(row.Name, row.Platform, row.Account, row.Hours * 3600);
                Playtime.Save();
                dialog.Close();
                if (confirmed != null) confirmed();
                RenderPlaytimeSummary();
                RenderGames();
                RenderContinueGame();
                RenderSessionList();
            } catch (Exception ex) { Notice(ex.Message); }
        }, true)); dialog.ShowDialog();
    }
    void ImportSteamPlaytime() {
        if (!RequirePlaytime()) return;
        var fields = new StackPanel();
        var account = PlaytimeField(fields, "SteamID64 da conta", "");
        fields.Children.Add(UI.Label("Chave pessoal da Steam Web API (usada somente nesta consulta)"));
        var key = new PasswordBox { Padding = new Thickness(8) }; fields.Children.Add(key);
        fields.Children.Add(UI.Text("A biblioteca e os detalhes dos jogos precisam estar acessíveis à API. Repita para outras contas. A chave é enviada somente à Steam e não é salva pelo LUA.", 11));
        var status = UI.Text("", 11); fields.Children.Add(status);
        var dialog = NewDialog("Importar horas da Steam", fields);
        Button button = null;
        button = UI.Button("Consultar e revisar", async () => {
            if (!Regex.IsMatch(account.Text.Trim(), "^[0-9]{17}$") || !Regex.IsMatch(key.Password.Trim(), "^[a-fA-F0-9]{32}$")) { status.Text = "Informe SteamID64 e chave válidos."; return; }
            string steamId = account.Text.Trim(), apiKey = key.Password.Trim(); button.IsEnabled = false; status.Text = "Consultando Steam…";
            try {
                var rows = await Task.Run(() => {
                    var request = (HttpWebRequest)WebRequest.Create("https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key=" + apiKey + "&steamid=" + steamId + "&include_appinfo=1&include_played_free_games=1");
                    request.Timeout = 30000; request.ReadWriteTimeout = 30000;
                    string json;
                    using (var response = request.GetResponse()) using (var reader = new StreamReader(response.GetResponseStream())) json = reader.ReadToEnd();
                    var payload = new JavaScriptSerializer { MaxJsonLength = 8 * 1024 * 1024 }.Deserialize<SteamPlaytimeResponse>(json);
                    if (payload == null || payload.response == null || payload.response.games == null) throw new InvalidDataException("Biblioteca indisponível. Verifique a privacidade e os dados da conta.");
                    return payload.response.games.Where(g => !string.IsNullOrWhiteSpace(g.name)).Select(g => new PlaytimeImportRow { Name = g.name, Platform = "Steam", Account = steamId, Hours = g.playtime_forever / 60.0 }).ToList();
                });
                key.Clear(); ReviewPlaytimeImport(rows); status.Text = "Consulta concluída.";
            } catch (WebException) { status.Text = "Falha ao consultar a Steam. Verifique a conexão, a chave e a privacidade da conta."; }
            catch (Exception ex) { status.Text = ex.Message; }
            finally { button.IsEnabled = true; }
        }, true);
        ((StackPanel)dialog.Tag).Children.Add(button); dialog.ShowDialog();
    }
    async void ImportLocalSteam() {
        if (!RequirePlaytime()) return;
        try {
            await LoadGames();
            var games = library.Games.ToArray(); var notices = new List<string>();
            var rows = await Task.Run(() => SteamLocalPlaytime.Scan(games, notices));
            if (notices.Count > 0) Notice(string.Join("\n", notices.Take(8)));
            if (rows.Count == 0) { Notice("Nenhuma hora local encontrada para os jogos Steam instalados. Para importar também jogos desinstalados, use Importar conta Steam."); return; }
            ReviewPlaytimeImport(rows);
        } catch (Exception ex) { Notice("Steam local: " + ex.Message); }
    }
}
public class SteamPlaytimeResponse { public SteamPlaytimeLibrary response; }
public class SteamPlaytimeLibrary { public List<SteamPlaytimeGame> games; }
public class SteamPlaytimeGame { public string name; public double playtime_forever; }
}
