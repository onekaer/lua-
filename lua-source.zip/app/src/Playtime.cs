using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Runtime.InteropServices;

namespace LuaMonitor {
public class TrackedGame {
    public string Id, Name, Platform, Folder, Executable, WindowTitle;
    public double Seconds, BaselineSeconds, BaselineLocalSeconds;
    public List<ImportedPlaytime> Imports = new List<ImportedPlaytime>();
    public double TotalSeconds { get { return Math.Max(Seconds, BaselineSeconds + Math.Max(0, Seconds - BaselineLocalSeconds)); } }
}
public class ImportedPlaytime { public string Platform, Account; public double Seconds; }
public class PlaySession { public string GameId, StartedUtc, EndedUtc; public double Seconds; }
public class PlaytimeData {
    public int Version = 1;
    public List<TrackedGame> Games = new List<TrackedGame>();
    public List<PlaySession> Sessions = new List<PlaySession>();
}
public class RunningGameProcess { public string Path, Title; public bool HasWindow; }
public sealed class PlaytimeStore {
    readonly string path;
    public PlaytimeData Data;
    public string Error;
    public readonly Dictionary<string, PlaySession> Active = new Dictionary<string, PlaySession>();
    public PlaytimeStore(string file) {
        path = file;
        if (!File.Exists(file)) { Data = new PlaytimeData(); return; }
        try {
            Data = Serializer().Deserialize<PlaytimeData>(File.ReadAllText(file));
            if (Data == null || Data.Version != 1 || Data.Games == null || Data.Sessions == null ||
                Data.Games.Any(g => g == null || string.IsNullOrWhiteSpace(g.Id) || g.Imports == null || !ValidSeconds(g.Seconds) || !ValidSeconds(g.BaselineSeconds) || !ValidSeconds(g.BaselineLocalSeconds) ||
                    g.Imports.Any(i => i == null || !ValidSeconds(i.Seconds))) ||
                Data.Games.Select(g => g.Id).Distinct().Count() != Data.Games.Count ||
                Data.Sessions.Any(s => s == null || string.IsNullOrWhiteSpace(s.GameId) || !ValidSeconds(s.Seconds)))
                throw new InvalidDataException("Formato do histórico inválido.");
        } catch (Exception ex) { Data = null; Error = "Histórico preservado. Não foi possível carregar: " + ex.Message; }
    }
    static JavaScriptSerializer Serializer() { return new JavaScriptSerializer { MaxJsonLength = 32 * 1024 * 1024 }; }
    public static bool ValidSeconds(double value) { return !double.IsNaN(value) && !double.IsInfinity(value) && value >= 0 && value <= 31557600000; }
    public static string Identity(string name) { return (name ?? "").Trim().Normalize(NormalizationForm.FormKC).ToUpperInvariant(); }
    public TrackedGame Find(string name) { return Data == null ? null : Data.Games.FirstOrDefault(g => g.Id == Identity(name)); }
    public TrackedGame Register(string name, string platform) {
        if (Data == null) throw new InvalidOperationException(Error);
        if (string.IsNullOrWhiteSpace(name) || name.Length > 300) throw new ArgumentException("Informe um nome de jogo válido.");
        var game = Find(name);
        if (game == null) { game = new TrackedGame { Id = Identity(name), Name = name.Trim(), Platform = platform }; Data.Games.Add(game); }
        return game;
    }
    public static bool Matches(TrackedGame game, RunningGameProcess process) {
        if (string.IsNullOrEmpty(process.Path)) return false;
        bool exact = !string.IsNullOrEmpty(game.Executable) && string.Equals(game.Executable, process.Path, StringComparison.OrdinalIgnoreCase);
        if (!string.IsNullOrEmpty(game.WindowTitle)) return exact && (process.Title ?? "").IndexOf(game.WindowTitle, StringComparison.OrdinalIgnoreCase) >= 0;
        if (!string.IsNullOrEmpty(game.Executable)) return exact;
        if (!process.HasWindow || string.IsNullOrEmpty(game.Folder)) return false;
        string filename = Path.GetFileNameWithoutExtension(process.Path);
        if (Regex.IsMatch(filename, "^(pcsx2|rpcs3|dolphin|duckstation|ppsspp|cemu|ryujinx|eden|azahar|yuzu|suyu|mgba|melonds|desmume|xenia|dosbox|retroarch)", RegexOptions.IgnoreCase)) return false;
        if (Regex.IsMatch(filename, "launcher|updat|unins|crash|report|setup|install|anti.?cheat|helper|redist|webview|cef", RegexOptions.IgnoreCase)) return false;
        return process.Path.StartsWith(game.Folder.TrimEnd('\\', '/') + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
    }
    public void Tick(IEnumerable<string> running, double elapsed, DateTime now) {
        if (Data == null) return;
        var current = new HashSet<string>(running);
        // Gaps include sleep, a suspended app or a failed scan. Never backfill them.
        bool continuous = elapsed > 0 && elapsed <= 15;
        foreach (string id in Active.Keys.ToArray()) {
            var session = Active[id];
            if (!current.Contains(id) || !continuous) { Active.Remove(id); continue; }
            var game = Data.Games.First(g => g.Id == id);
            game.Seconds += elapsed;
            session.Seconds += elapsed;
            session.EndedUtc = now.ToString("o");
        }
        foreach (string id in current) {
            if (Active.ContainsKey(id) || !Data.Games.Any(g => g.Id == id)) continue;
            var session = new PlaySession { GameId = id, StartedUtc = now.ToString("o"), EndedUtc = now.ToString("o") };
            Active.Add(id, session);
            Data.Sessions.Add(session);
        }
    }
    public void Import(string name, string platform, string account, double seconds) {
        if (!ValidSeconds(seconds) || string.IsNullOrWhiteSpace(platform) || string.IsNullOrWhiteSpace(account))
            throw new ArgumentException("Informe plataforma, conta e horas válidas.");
        var game = Register(name, platform);
        double previousTotal = game.TotalSeconds;
        var old = game.Imports.FirstOrDefault(i => Identity(i.Platform) == Identity(platform) && Identity(i.Account) == Identity(account));
        if (old == null) { old = new ImportedPlaytime { Platform = platform.Trim(), Account = account.Trim() }; game.Imports.Add(old); }
        old.Seconds = seconds;
        // Import totals have no session dates. Keep the higher snapshot, then add future local sessions.
        game.BaselineSeconds = Math.Max(previousTotal, game.Imports.Sum(i => i.Seconds));
        game.BaselineLocalSeconds = game.Seconds;
    }
    public void Save() {
        if (Data == null) return;
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        string temp = path + ".tmp";
        File.WriteAllText(temp, Serializer().Serialize(Data), new UTF8Encoding(false));
        if (File.Exists(path)) File.Replace(temp, path, path + ".bak"); else File.Move(temp, path);
        Error = null;
    }
    public static List<RunningGameProcess> Processes() {
        var result = new List<RunningGameProcess>();
        var windows = new Dictionary<int, List<string>>();
        EnumWindows((handle, parameter) => {
            if (!IsWindowVisible(handle)) return true;
            uint pid; GetWindowThreadProcessId(handle, out pid);
            var title = new StringBuilder(2048); GetWindowText(handle, title, title.Capacity);
            if (title.Length == 0) return true;
            List<string> titles;
            if (!windows.TryGetValue((int)pid, out titles)) windows[(int)pid] = titles = new List<string>();
            titles.Add(title.ToString()); return true;
        }, IntPtr.Zero);
        foreach (var process in Process.GetProcesses()) {
            using (process) { try {
                var module = process.MainModule;
                if (module == null) continue;
                string executable = module.FileName;
                List<string> titles;
                if (windows.TryGetValue(process.Id, out titles)) {
                    foreach (string title in titles) result.Add(new RunningGameProcess { Path = executable, Title = title, HasWindow = true });
                } else result.Add(new RunningGameProcess { Path = executable, Title = "", HasWindow = false });
            } catch (System.ComponentModel.Win32Exception) { } catch (InvalidOperationException) { } }
        }
        return result;
    }
    delegate bool WindowCallback(IntPtr window, IntPtr parameter);
    [DllImport("user32.dll")] static extern bool EnumWindows(WindowCallback callback, IntPtr parameter);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr window, StringBuilder text, int count);
}
}
