﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public class ActivityItem {public DateTime Time;public string Title,Text;}
public class SpeedHistoryItem {public DateTime Time;public string Connection;public double Download,Upload,Latency;}
public static class LocalHistory {
    static readonly object gate=new object();
    public static List<T> Read<T>(string name){lock(gate)try{return new JavaScriptSerializer().Deserialize<List<T>>(File.ReadAllText(Path.Combine(Preferences.DataDir,name)))??new List<T>();}catch{return new List<T>();}}
    public static void Write<T>(string name,IEnumerable<T> values){lock(gate){Directory.CreateDirectory(Preferences.DataDir);File.WriteAllText(Path.Combine(Preferences.DataDir,name),new JavaScriptSerializer().Serialize(values.Take(100).ToList()));}}
    public static void Add(string title,string text){var list=Read<ActivityItem>("notifications.json");list.Insert(0,new ActivityItem{Time=DateTime.Now,Title=title,Text=text});Write("notifications.json",list);}
    public static long TrimCache(int megabytes,bool clear=false){string root=Path.GetFullPath(Path.Combine(Preferences.DataDir,"thumbnails"));if(!Directory.Exists(root)||(File.GetAttributes(root)&FileAttributes.ReparsePoint)!=0)return 0;var files=new DirectoryInfo(root).GetFiles("*.jpg").Where(f=>(f.Attributes&FileAttributes.ReparsePoint)==0).OrderBy(f=>f.LastWriteTimeUtc).ToList();long bytes=files.Sum(f=>f.Length),removed=0,limit=Math.Max(10,megabytes)*1024L*1024;foreach(var file in files){if(!clear&&bytes<=limit)break;try{long size=file.Length;file.Delete();bytes-=size;removed+=size;}catch{}}return removed;}
}
public sealed partial class DesktopController {
    void ActivityOptions(){var list=LocalHistory.Read<ActivityItem>("notifications.json");var entries=new StackPanel();foreach(var item in list.Take(30))entries.Children.Add(UI.Stack(UI.Text(item.Title+" • "+item.Time.ToString("dd/MM HH:mm"),12,"#DDDDE8",true),UI.Text(item.Text,11,"#AAAABC"),UI.Line()));if(list.Count==0)entries.Children.Add(UI.Text("Ainda não há avisos."));body.Children.Add(UI.Card(UI.Fold("Histórico de avisos",UI.Stack(entries,UI.Button("Limpar histórico",()=>{LocalHistory.Write("notifications.json",new ActivityItem[0]);BuildPage("settings");})))));
        body.Children.Add(UI.Card(UI.Fold("Cache de miniaturas",UI.Stack(UI.Text("Prévias são locais e podem ser refeitas. Apagar o cache preserva os vídeos, clipes, prints e capas escolhidas.",12,"#AAAABC"),UI.Choice(new[]{"100 MB","200 MB","500 MB"},prefs.CacheMb+" MB",v=>{prefs.CacheMb=int.Parse(v.Split(' ')[0]);UI.CacheLimitMb=prefs.CacheMb;Save();Task.Run(()=>LocalHistory.TrimCache(prefs.CacheMb));}),UI.Button("Limpar miniaturas agora",async()=>{long bytes=await Task.Run(()=>LocalHistory.TrimCache(prefs.CacheMb,true));ShowToast("Cache limpo",Format.Bytes(bytes)+" liberados. Suas capturas foram mantidas.");})))));
    }
    void SpeedHistoryPanel(){var entries=LocalHistory.Read<SpeedHistoryItem>("speed-history.json");var name=new TextBox{Text=prefs.ConnectionLabel,Margin=new Thickness(0,6,0,10)};name.TextChanged+=(s,e)=>{prefs.ConnectionLabel=name.Text.Trim();Save();};var panel=UI.Stack(UI.Text("Dê um nome à conexão para comparar testes: Wi-Fi casa, cabo, VPN…",11,"#AAAABC"),name);foreach(var item in entries.Take(10))panel.Children.Add(UI.Stack(UI.Text(item.Connection+" • "+item.Time.ToString("dd/MM HH:mm"),12,"#DDDDE8",true),UI.Text("↓ "+item.Download.ToString("0.0")+" Mbps   ↑ "+item.Upload.ToString("0.0")+" Mbps   "+item.Latency.ToString("0")+" ms",12),UI.Line()));if(entries.Count==0)panel.Children.Add(UI.Text("Os próximos testes aparecerão aqui."));if(entries.Count>=2)panel.Children.Add(UI.Text("Último × anterior: download "+(entries[0].Download-entries[1].Download).ToString("+0.0;-0.0;0.0")+" Mbps • upload "+(entries[0].Upload-entries[1].Upload).ToString("+0.0;-0.0;0.0")+" Mbps",12,"#B5C9EF"));panel.Children.Add(UI.Button("Limpar testes salvos",()=>{LocalHistory.Write("speed-history.json",new SpeedHistoryItem[0]);BuildPage("network");}));body.Children.Add(UI.Card(UI.Fold("Histórico e comparação de conexões",panel)));}
    void SaveSpeedHistory(){if(speedResult==null)return;var entries=LocalHistory.Read<SpeedHistoryItem>("speed-history.json");entries.Insert(0,new SpeedHistoryItem{Time=speedResult.Time,Connection=string.IsNullOrWhiteSpace(prefs.ConnectionLabel)?"Rota padrão do Windows":prefs.ConnectionLabel,Download=speedResult.Download,Upload=speedResult.Upload,Latency=speedResult.Latency});LocalHistory.Write("speed-history.json",entries);}
    UIElement FilterChips(string[] labels,Action reset){var row=new WrapPanel{Margin=new Thickness(0,6,0,6)};foreach(string value in labels.Where(x=>!string.IsNullOrEmpty(x)))row.Children.Add(new Border{Background=UI.Brush("#293B56"),CornerRadius=new CornerRadius(7),Padding=new Thickness(8,4,8,4),Margin=new Thickness(0,0,6,5),Child=UI.Text(value,11,"#C7D8F5")});if(row.Children.Count>0){var clear=UI.Button("Limpar filtros",reset);clear.MinHeight=30;clear.Padding=new Thickness(8,4,8,4);row.Children.Add(clear);}return row;}
}
}
