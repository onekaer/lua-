﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task FeatureChecks(List<string> checks,string dir){
        await LoadGames();File.WriteAllLines(Path.Combine(dir,"game-covers.txt"),library.Games.Select(g=>g.Name+" | "+g.Platform+" | "+g.SteamId+" | "+g.CoverPath));int covers=library.Games.Count(g=>GameCovers.Image(g.CoverPath)!=null);checks.Add("Capas reais locais ou oficiais: "+covers+" / "+library.Games.Count+" no momento da verificação");
        gameOrder="Maior tamanho";gameSize="Acima de 50 GB";gamePlatform="Steam";BuildPage("games");window.UpdateLayout();UI.Capture(window,Path.Combine(dir,"library-filtered.png"));gameSize="Todos os tamanhos";gamePlatform="Todas as plataformas";gameSearch="__no_such_game__";RenderGames();if(!gamesArea.Children.OfType<System.Windows.Controls.TextBlock>().Any(t=>t.Text.StartsWith("Nenhum jogo corresponde")))throw new Exception("Estado vazio do filtro incorreto");gameSearch="";RenderGames();checks.Add("Biblioteca: busca, filtro de plataforma/tamanho, ordenação e estado vazio verificados");
        using(var icon=new System.Drawing.Icon(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"src","LUA.ico"),16,16)){if(icon.Width!=16||icon.Height!=16)throw new Exception("Ícone não tem resolução nativa 16 px");}checks.Add("Ícone da bandeja: variante 16 px nativa carregada de ICO multirresolução");
        if(Environment.GetCommandLineArgs().Contains("--verify-network")){var result=await Task.Run(()=>InternetSpeed.Run(false,CancellationToken.None,text=>{}));speedResult=result;if(result.Download<=0||result.Upload<=0||result.Bytes!=30000000)throw new Exception("Teste de velocidade retornou valores inválidos");checks.Add("Teste HTTPS real Cloudflare: download "+result.Download.ToString("0.0")+" Mbps; upload "+result.Upload.ToString("0.0")+" Mbps; latência "+result.Latency.ToString("0")+" ms; orçamento 30 MB correto");}
        if(Environment.GetCommandLineArgs().Contains("--verify-video")){
            string output=Path.Combine(Preferences.DataDir,"video-check");Directory.CreateDirectory(output);var options=new RecordingOptions{Folder=output,Height=720,Fps=30,ReplaySeconds=60,Bitrate=4,Audio=true};
            using(var test=new ScreenRecorder()){
                bool guarded=false;try{await test.SaveClip(30,output);}catch(InvalidOperationException){guarded=true;}if(!guarded)throw new Exception("Clipe permitiu salvar buffer desligado");
                await test.StartRecording(options);await Task.Delay(4000);await test.StopRecording();string video=test.LastFile;string videoInfo=await ProbeVideo(video);if(videoInfo.IndexOf("h264")<0||videoInfo.IndexOf("aac")<0||videoInfo.IndexOf("720")<0)throw new Exception("Vídeo não tem H.264/AAC/720p: "+videoInfo);File.WriteAllText(Path.Combine(dir,"video-probe.json"),videoInfo);checks.Add("Captura REAL do monitor: H.264 + AAC, 720p, MP4 finalizado; encoder "+test.Encoder);
                await test.StartReplay(options);await Task.Delay(64000);string clip30=await test.SaveClip(30,output);string info30=await ProbeVideo(clip30);string clip60=await test.SaveClip(60,output);string info60=await ProbeVideo(clip60);File.WriteAllText(Path.Combine(dir,"clip30-probe.json"),info30);File.WriteAllText(Path.Combine(dir,"clip60-probe.json"),info60);
                var json=new System.Web.Script.Serialization.JavaScriptSerializer();var d30=json.Deserialize<Probe>(info30);var d60=json.Deserialize<Probe>(info60);double duration30,duration60;if(d30==null||d30.format==null||d60==null||d60.format==null||!double.TryParse(d30.format.duration,System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out duration30)||!double.TryParse(d60.format.duration,System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out duration60)||Math.Abs(duration30-30)>2||Math.Abs(duration60-60)>2)throw new Exception("Duração real dos clipes incorreta");
                if(test.AvailableSeconds()>60)throw new Exception("Buffer ultrapassou limite");await test.StopReplay();if(test.Active)throw new Exception("Captura permaneceu ativa após parada");checks.Add("Replay REAL: clipes de "+duration30.ToString("0.00")+" s e "+duration60.ToString("0.00")+" s com áudio; buffer limitado e encerramento correto");
            }
        }
    }
    class Probe {public ProbeFormat format;}
    class ProbeFormat {public string duration;}
    async Task<string> ProbeVideo(string file){using(var process=new Process{StartInfo=new ProcessStartInfo(Path.Combine(ScreenRecorder.Tools,"ffprobe.exe"),"-v error -show_streams -show_format -of json "+ScreenRecorder.Quote(file)){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true}}){process.Start();string json=await process.StandardOutput.ReadToEndAsync();await Task.Run(()=>process.WaitForExit());if(process.ExitCode!=0)throw new IOException("ffprobe não conseguiu ler o vídeo");return json;}}
}
}
