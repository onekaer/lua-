﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace LuaMonitor {
public class ActionGrid:Panel {
    int columns;double cellWidth;List<double> heights=new List<double>();List<UIElement> items;
    protected override Size MeasureOverride(Size size){items=InternalChildren.Cast<UIElement>().Where(c=>c.Visibility!=Visibility.Collapsed).ToList();double width=double.IsInfinity(size.Width)?(UI.Compact?340:800):size.Width;columns=Math.Max(1,Math.Min(items.Count,width>=600?3:width>=270?2:1));cellWidth=Math.Max(0,(width-(columns-1)*8)/columns);heights.Clear();for(int i=0;i<items.Count;i++){bool full=i==items.Count-1&&i%columns==0;items[i].Measure(new Size(full?width:cellWidth,double.PositiveInfinity));int row=i/columns;if(heights.Count<=row)heights.Add(0);heights[row]=Math.Max(heights[row],items[i].DesiredSize.Height);}return new Size(width,heights.Sum()+Math.Max(0,heights.Count-1)*8);}
    protected override Size ArrangeOverride(Size size){double y=0;for(int i=0;i<items.Count;i++){int row=i/columns,col=i%columns;if(col==0&&row>0)y+=heights[row-1]+8;bool full=i==items.Count-1&&col==0;items[i].Arrange(new Rect(col*(cellWidth+8),y,full?size.Width:cellWidth,heights[row]));}return size;}
}
public class SpeedArc:FrameworkElement {
    public double Progress;public string Color="#4C8DFF";
    protected override void OnRender(DrawingContext dc){double r=Math.Min(ActualWidth/2-16,92),cx=ActualWidth/2,cy=106;Draw(dc,cx,cy,r,270,UI.Brush("#34343B"));Draw(dc,cx,cy,r,Math.Max(0,Math.Min(1,Progress))*270,UI.Brush(Color));}
    void Draw(DrawingContext dc,double cx,double cy,double r,double sweep,Brush brush){if(sweep<=0)return;double start=135*Math.PI/180,end=(135+sweep)*Math.PI/180;var geometry=new StreamGeometry();using(var context=geometry.Open()){context.BeginFigure(new Point(cx+r*Math.Cos(start),cy+r*Math.Sin(start)),false,false);context.ArcTo(new Point(cx+r*Math.Cos(end),cy+r*Math.Sin(end)),new Size(r,r),0,sweep>180,SweepDirection.Clockwise,true,false);}geometry.Freeze();dc.DrawGeometry(null,new Pen(brush,8){StartLineCap=PenLineCap.Round,EndLineCap=PenLineCap.Round},geometry);}
}
public static partial class UI {
    public static int CacheLimitMb=200;public static bool HighContrast;public static string FoldPage="";public static Dictionary<string,bool> FoldStates=new Dictionary<string,bool>();public static Action FoldSave;
    public static string ContrastColor(string color){if(!HighContrast)return color;try{var c=(System.Windows.Media.Color)ColorConverter.ConvertFromString(color);int min=Math.Min(c.R,Math.Min(c.G,c.B)),max=Math.Max(c.R,Math.Max(c.G,c.B));if(min>=100&&max<=215&&max-min<55)return "#EEEEF5";}catch{}return color;}

    public static void ButtonLabel(Button button,string label){button.Content=new TextBlock{Text=label,FontFamily=Font,FontSize=12.5,TextWrapping=TextWrapping.Wrap,TextAlignment=TextAlignment.Center,VerticalAlignment=VerticalAlignment.Center};SmoothText((DependencyObject)button.Content);System.Windows.Automation.AutomationProperties.SetName(button,label);}
    public static Button IconButton(string icon,string hint,Action action){var button=new Button{Content=Icon(icon,size:18),Width=40,Height=40,Padding=new Thickness(0),Margin=new Thickness(0),ToolTip=hint,HorizontalContentAlignment=HorizontalAlignment.Center};System.Windows.Automation.AutomationProperties.SetName(button,hint);button.Click+=(s,e)=>action();return button;}
    public static Expander Fold(string title,UIElement content,bool expanded=false){string key=FoldPage+"|"+title;bool saved;if(FoldStates.TryGetValue(key,out saved))expanded=saved;var fold=new Expander{Header=title,Content=content,IsExpanded=expanded,Margin=new Thickness(0),Foreground=Brush("#C5C5D0")};fold.Expanded+=(s,e)=>{FoldStates[key]=true;if(FoldSave!=null)FoldSave();};fold.Collapsed+=(s,e)=>{FoldStates[key]=false;if(FoldSave!=null)FoldSave();};return fold;}
    public static Grid Search(string current,string hint,Action<string> changed,UIElement filters=null){
        var grid=new Grid();grid.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});grid.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        var inner=new Grid();inner.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(38)});inner.ColumnDefinitions.Add(new ColumnDefinition());if(filters!=null)inner.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(43)});
        var icon=Icon("search","#9A9AAE",17);icon.HorizontalAlignment=HorizontalAlignment.Center;inner.Children.Add(icon);
        var field=new TextBox{Text=current,MinWidth=0,BorderThickness=new Thickness(0),Background=Brushes.Transparent,Padding=new Thickness(0,10,8,10),FontSize=13,VerticalContentAlignment=VerticalAlignment.Center};System.Windows.Automation.AutomationProperties.SetName(field,hint);Grid.SetColumn(field,1);inner.Children.Add(field);
        var watermark=Text(hint,12,"#858594");watermark.IsHitTestVisible=false;watermark.Visibility=current.Length==0?Visibility.Visible:Visibility.Collapsed;Grid.SetColumn(watermark,1);inner.Children.Add(watermark);field.TextChanged+=(o,e)=>{watermark.Visibility=field.Text.Length==0?Visibility.Visible:Visibility.Collapsed;changed(field.Text);};
        var frame=new Border{Background=Brush("#202024"),BorderBrush=Brush("#44444F"),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(11),Height=44,Child=inner};grid.Children.Add(frame);
        field.IsKeyboardFocusWithinChanged+=(o,e)=>frame.BorderBrush=Brush(field.IsKeyboardFocusWithin?"#7397D9":"#44444F");
        if(filters!=null){var panel=new Border{Child=filters,Background=Brush("#222226"),BorderBrush=Brush("#383842"),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(11),Padding=new Thickness(12),Margin=new Thickness(0,10,0,0),Visibility=Visibility.Collapsed};Grid.SetRow(panel,1);grid.Children.Add(panel);Button toggle=null;toggle=IconButton("filter","Mostrar filtros",()=>{bool open=panel.Visibility!=Visibility.Visible;panel.Visibility=open?Visibility.Visible:Visibility.Collapsed;toggle.Background=Brush(open?"#2E405B":"Transparent");toggle.ToolTip=open?"Recolher filtros":"Mostrar filtros";});toggle.Width=34;toggle.Height=34;toggle.MinHeight=0;toggle.BorderThickness=new Thickness(0);toggle.Background=Brushes.Transparent;toggle.VerticalAlignment=VerticalAlignment.Center;toggle.HorizontalAlignment=HorizontalAlignment.Center;Grid.SetColumn(toggle,2);inner.Children.Add(toggle);}

        return grid;
    }
}
}
