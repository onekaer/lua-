﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
namespace LuaMonitor {
public class SpeedProgress {public bool Upload;public double Mbps,Ratio;}
public class SpeedResult {public double Download,Upload,Latency;public long Bytes;public DateTime Time;}
public static class InternetSpeed {
    static HttpWebRequest Request(string path){ServicePointManager.SecurityProtocol|=SecurityProtocolType.Tls12;var request=(HttpWebRequest)WebRequest.Create("https://speed.cloudflare.com/"+path);request.Timeout=30000;request.ReadWriteTimeout=15000;request.KeepAlive=true;request.AutomaticDecompression=DecompressionMethods.None;request.CachePolicy=new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);request.UserAgent="LUA/1.3";request.ServicePoint.ConnectionLimit=8;return request;}
    static long Transfer(bool upload,int bytes,CancellationToken token,Action<int> progress){
        var request=Request(upload?"__up":"__down?bytes="+bytes+"&r="+Guid.NewGuid().ToString("N"));
        using(token.Register(()=>request.Abort()))try{
            byte[] buffer=new byte[65536];long done=0;
            if(upload){request.Method="POST";request.ContentType="application/octet-stream";request.ContentLength=bytes;request.AllowWriteStreamBuffering=false;using(var stream=request.GetRequestStream()){while(done<bytes){token.ThrowIfCancellationRequested();int count=(int)Math.Min(buffer.Length,bytes-done);stream.Write(buffer,0,count);done+=count;progress(count);}}}
            using(var response=(HttpWebResponse)request.GetResponse())using(var stream=response.GetResponseStream()){int n;while((n=stream.Read(buffer,0,buffer.Length))>0){token.ThrowIfCancellationRequested();if(!upload){done+=n;progress(n);}}}
            if(!upload&&done!=bytes)throw new IOException("O servidor enviou uma resposta incompleta.");return done;
        }catch(WebException){token.ThrowIfCancellationRequested();throw;}
    }
    public static SpeedResult Run(bool full,CancellationToken token,Action<string> report,Action<SpeedProgress> progress=null){
        var result=new SpeedResult();var latency=new double[3];for(int i=0;i<3;i++){report("Medindo latência HTTPS…");var watch=Stopwatch.StartNew();Transfer(false,0,token,n=>{});latency[i]=watch.Elapsed.TotalMilliseconds;}Array.Sort(latency);result.Latency=latency[1];
        int download=full?25000000:6250000,upload=full?5000000:1250000;
        result.Download=Phase(false,download,token,report,progress);result.Bytes+=download*4L;
        result.Upload=Phase(true,upload,token,report,progress);result.Bytes+=upload*4L;result.Time=DateTime.Now;return result;
    }
    static double Phase(bool upload,int size,CancellationToken token,Action<string> report,Action<SpeedProgress> progress){
        long bytes=0;var watch=Stopwatch.StartNew();var workers=new Task[4];long last=0;
        for(int i=0;i<4;i++)workers[i]=Task.Run(()=>Transfer(upload,size,token,n=>{long total=Interlocked.Add(ref bytes,n);long ms=watch.ElapsedMilliseconds;if(ms-Interlocked.Read(ref last)>150&&Interlocked.Exchange(ref last,ms)<ms-100){if(progress!=null)progress(new SpeedProgress{Upload=upload,Mbps=total*8/Math.Max(.01,watch.Elapsed.TotalSeconds)/1000000,Ratio=total/(size*4.0)});report((upload?"↑ Envio":"↓ Recebimento")+" • "+(total*8/Math.Max(.01,watch.Elapsed.TotalSeconds)/1000000).ToString("0.0")+" Mbps • "+Format.Bytes(total));}}),token);
        try{Task.WaitAll(workers);}catch(AggregateException ex){token.ThrowIfCancellationRequested();throw ex.Flatten().InnerExceptions[0];}return bytes*8/Math.Max(.001,watch.Elapsed.TotalSeconds)/1000000;
    }
}
public sealed partial class DesktopController {
    CancellationTokenSource speedCancel;bool speedBusy,speedFull;SpeedResult speedResult;SpeedProgress speedLive;string speedStatus="Pronto para testar sua conexão";TextBlock speedText,speedValues,speedPhase,speedDown,speedUp,speedPing;Button speedStart,speedStop;SpeedArc speedArc;System.Windows.Controls.ProgressBar speedProgress;
    void SpeedPanel(){
        speedText=UI.Text(speedStatus,11,"#9999AF");speedText.Margin=new System.Windows.Thickness(0,10,0,0);speedValues=UI.Text("—",38,"#F0F0F8",true);speedValues.HorizontalAlignment=System.Windows.HorizontalAlignment.Center;speedPhase=UI.Text("PRONTO PARA TESTAR",11,"#9999B0",true);speedPhase.HorizontalAlignment=System.Windows.HorizontalAlignment.Center;
        speedArc=new SpeedArc{Height=195,Width=236,HorizontalAlignment=System.Windows.HorizontalAlignment.Center};var dial=new System.Windows.Controls.Grid{Height=195};dial.Children.Add(speedArc);var center=UI.Stack(speedPhase,speedValues,UI.Text("Mbps",12,"#9292A7"));center.HorizontalAlignment=System.Windows.HorizontalAlignment.Center;center.VerticalAlignment=System.Windows.VerticalAlignment.Center;center.Margin=new System.Windows.Thickness(0,18,0,0);dial.Children.Add(center);
        speedDown=UI.Text("—",UI.Compact?20:26,"#83ACFF",true);speedUp=UI.Text("—",UI.Compact?20:26,"#88D7E7",true);speedPing=UI.Text("—",UI.Compact?20:26,"#E6E6F0",true);
        var values=UI.Inline(SpeedTile("DOWNLOAD",speedDown,"Mbps"),SpeedTile("UPLOAD",speedUp,"Mbps"),SpeedTile("LATÊNCIA",speedPing,"ms HTTPS"));
        speedStart=UI.Button("Testar velocidade",RunSpeed,true);speedStop=UI.Button("Cancelar teste",()=>{if(speedCancel!=null)speedCancel.Cancel();});var actions=new ActionGrid();actions.Children.Add(speedStart);actions.Children.Add(speedStop);
        speedProgress=new System.Windows.Controls.ProgressBar{Height=3,Margin=new System.Windows.Thickness(0,10,0,0)};
        var settings=UI.Fold("Opções do teste",UI.Stack(UI.Choice(new[]{"Rápido • até 30 MB","Completo • até 120 MB"},speedFull?"Completo • até 120 MB":"Rápido • até 30 MB",v=>speedFull=v.StartsWith("Completo")),UI.Text("Download, upload e latência HTTPS até a Cloudflare, pela rota padrão do Windows. VPN, Wi-Fi e tráfego podem afetar o resultado. Nenhum arquivo pessoal é enviado.",11,"#9999AC")));
        body.Children.Add(UI.Card(UI.Stack(UI.Text("Teste de internet",18,"#E6E6F0",true),UI.Text("Sua conexão, em tempo real",12,"#9999AC"),dial,values,speedProgress,speedText,actions,settings),16));UpdateSpeed();
    }
    System.Windows.UIElement SpeedTile(string title,TextBlock value,string unit){var panel=UI.Stack(UI.Text(title,11,"#9E9EB0",true),value,UI.Text(unit,11,"#89899D"));return new System.Windows.Controls.Border{ClipToBounds=true,Background=UI.Brush("#202025"),CornerRadius=new System.Windows.CornerRadius(10),Padding=new System.Windows.Thickness(9,12,9,12),Child=panel};}
    async void RunSpeed(){if(speedBusy)return;speedBusy=true;speedLive=null;speedResult=null;speedCancel=new CancellationTokenSource();var token=speedCancel.Token;try{bool full=speedFull;speedStatus="Medindo latência…";UpdateSpeed();speedResult=await Task.Run(()=>InternetSpeed.Run(full,token,value=>window.Dispatcher.BeginInvoke(new Action(()=>{if(!speedBusy)return;speedStatus=value;UpdateSpeed();})),progress=>window.Dispatcher.BeginInvoke(new Action(()=>{if(!speedBusy)return;speedLive=progress;UpdateSpeed();}))));SaveSpeedHistory();speedStatus="Concluído às "+speedResult.Time.ToString("HH:mm")+" • "+Format.Bytes(speedResult.Bytes)+" de teste";}catch(OperationCanceledException){speedStatus="Teste cancelado";}catch(Exception ex){speedStatus="Não foi possível testar: "+ex.Message;}finally{speedBusy=false;speedCancel.Dispose();speedCancel=null;UpdateSpeed();}}
    void UpdateSpeed(){if(page!="network"||speedText==null)return;speedText.Text=speedStatus;speedStart.IsEnabled=!speedBusy;speedStop.IsEnabled=speedBusy;speedPhase.Text=speedBusy?(speedLive==null?"LATÊNCIA":speedLive.Upload?"TESTANDO UPLOAD":"TESTANDO DOWNLOAD"):speedResult==null?"PRONTO PARA TESTAR":"TESTE CONCLUÍDO";
        speedValues.Text=speedResult!=null?speedResult.Download.ToString("0.0"):speedLive!=null&&speedBusy?speedLive.Mbps.ToString("0.0"):"—";speedDown.Text=speedResult!=null?speedResult.Download.ToString("0.0"):speedLive!=null&&!speedLive.Upload?speedLive.Mbps.ToString("0.0"):"—";speedUp.Text=speedResult!=null?speedResult.Upload.ToString("0.0"):speedLive!=null&&speedLive.Upload?speedLive.Mbps.ToString("0.0"):"—";speedPing.Text=speedResult==null?"—":speedResult.Latency.ToString("0");speedArc.Progress=speedResult!=null?1:speedLive!=null?speedLive.Ratio:0;speedArc.Color=speedBusy&&speedLive!=null&&speedLive.Upload?"#83D2E5":"#4C8DFF";speedArc.InvalidateVisual();speedProgress.IsIndeterminate=speedBusy&&speedLive==null;speedProgress.Value=speedResult!=null?100:speedLive!=null?speedLive.Ratio*100:0;
    }
}
}
