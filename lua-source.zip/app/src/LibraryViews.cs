using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Forms=System.Windows.Forms;

namespace LuaMonitor {
public sealed partial class DesktopController {
    GameLibrary library=new GameLibrary();bool libraryLoaded,libraryLoading,libraryMeasuring;Task<GameLibrary> libraryTask;
    StackPanel gamesArea,cleanupArea;string gameSearch="",gameOrder="Recentes",gamePlatform="Todas as plataformas",gameSize="Todos os tamanhos";bool coversLoading;CancellationTokenSource libraryCancel,cleanupCancel;
    List<Control> cleanupInputs=new List<Control>();
    CleanupResult cleanupResult;string cleanupMode="Temporários antigos",cleanupFolder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Downloads"),cleanupStatus="";bool cleanupBusy;int cleanupPage;
    async Task LoadGames(bool refresh=false){
        if(libraryLoading){while(libraryLoading)await Task.Delay(25);return;}if(libraryLoaded&&!refresh)return;
        libraryLoading=true;try{var folders=prefs.GameFolders.ToArray();libraryTask=Task.Run(()=>GameCatalog.Discover(folders));library=await libraryTask;libraryLoaded=true;LoadCovers();}catch(Exception ex){library.Notices.Add(ex.Message);}finally{libraryLoading=false;RenderGames();RenderContinueGame();RenderSessionList();}
    }
    async void AddGameFolder(){
        using(var dialog=new Forms.FolderBrowserDialog{Description="Escolha a pasta de um jogo"}){
            if(dialog.ShowDialog()!=Forms.DialogResult.OK||prefs.GameFolders.Contains(dialog.SelectedPath,StringComparer.OrdinalIgnoreCase))return;
            prefs.GameFolders.Add(dialog.SelectedPath);
            Save();
            await LoadGames(true);
            MeasureGames(false);
        }
    }
    void Games(){
        AddLibrarySpotlight();
        playtimeSummary=new StackPanel { HorizontalAlignment=HorizontalAlignment.Right };
        var heading=UI.Row(UI.Text("Minha biblioteca",21,"#F2EEF9",true),playtimeSummary);
        heading.Margin=new Thickness(0,0,0,8);
        body.Children.Add(heading);
        body.Children.Add(LibraryToolbar());
        gamesArea=new StackPanel();
        body.Children.Add(gamesArea);
        RenderGames();
        LoadGames().ContinueWith(t=>window.Dispatcher.BeginInvoke(new Action(()=>MeasureGames(false))));
    }
    async void MeasureGames(bool all){
        if(libraryMeasuring)return;await LoadGames();libraryMeasuring=true;libraryCancel=new CancellationTokenSource();var token=libraryCancel.Token;
        try{foreach(var game in library.Games.Where(g=>all||!g.Bytes.HasValue).ToArray()){token.ThrowIfCancellationRequested();game.SizeSource="Medindo…";RenderGames();var result=await Task.Run(()=>SpaceScanner.Scan(game.Folder,token,p=>{}));if(result.Cancelled)break;game.Bytes=result.Bytes;game.Skipped=result.Skipped;game.SizeSource=result.Skipped==0?"Medido na pasta":"Medido parcialmente • "+result.Skipped+" itens sem acesso";RenderGames();}}catch(OperationCanceledException){}catch(Exception ex){library.Notices.Add("Medição: "+ex.Message);}finally{libraryMeasuring=false;libraryCancel.Dispose();libraryCancel=null;RenderGames();}
    }
    void RenderGames(){if(!window.Dispatcher.CheckAccess()){if(!exiting)window.Dispatcher.BeginInvoke(new Action(RenderGames));return;}if(exiting||gamesArea==null)return;gamesArea.Children.Clear();playtimeLabels.Clear();
        var allGames=GamesWithPlaytime();
        RenderPlaytimeSummary();
        if(gamePlatform!="Todas as plataformas"||gameSize!="Todos os tamanhos"||gameSearch!="")
            gamesArea.Children.Add(FilterChips(new[]{gamePlatform=="Todas as plataformas"?null:gamePlatform,gameSize=="Todos os tamanhos"?null:gameSize,gameSearch==""?null:"Busca: "+gameSearch},()=>{gamePlatform="Todas as plataformas";gameSize="Todos os tamanhos";gameSearch="";BuildPage("games");}));
        var compare=CultureInfo.CurrentCulture.CompareInfo;
        var filtered=allGames.Where(g=>(compare.IndexOf(g.Name,gameSearch.Trim(),CompareOptions.IgnoreCase|CompareOptions.IgnoreNonSpace)>=0||
            compare.IndexOf(g.Platform??"",gameSearch.Trim(),CompareOptions.IgnoreCase|CompareOptions.IgnoreNonSpace)>=0)&&(gamePlatform=="Todas as plataformas"||g.Platform==gamePlatform));
        long min=gameSize=="Acima de 10 GB"?10L<<30:gameSize=="Acima de 50 GB"?50L<<30:gameSize=="Acima de 100 GB"?100L<<30:0;
        if(min>0)filtered=filtered.Where(g=>g.Bytes.HasValue&&g.Bytes.Value>=min);if(gameSize=="Tamanho pendente")filtered=filtered.Where(g=>!g.Bytes.HasValue);
        if(gameOrder=="Recentes"){
            var recent=Playtime==null||Playtime.Data==null?new Dictionary<string,DateTime>():Playtime.Data.Sessions
                .Where(s=>s.Seconds>0).GroupBy(s=>s.GameId).ToDictionary(group=>group.Key,group=>group.Select(SessionLast).Max());
            filtered=filtered.OrderByDescending(g=>{
                DateTime last;
                return recent.TryGetValue(PlaytimeStore.Identity(g.Name),out last)?last:DateTime.MinValue;
            }).ThenBy(g=>g.Name);
        } else
            filtered=gameOrder=="Mais jogados"?filtered.OrderByDescending(TotalGameSeconds):gameOrder=="Maior tamanho"?filtered.OrderByDescending(g=>g.Bytes??-1):gameOrder=="Menor tamanho"?filtered.OrderBy(g=>g.Bytes??long.MaxValue):gameOrder=="Plataforma"?filtered.OrderBy(g=>g.Platform).ThenBy(g=>g.Name):filtered.OrderBy(g=>g.Name);
        var entries=filtered.ToList();
        if(entries.Count!=allGames.Count)gamesArea.Children.Add(UI.Text(entries.Count+" resultados",11,"#ABA3B7"));
        GameGridPanel tiles=null;if(prefs.GamesGrid&&entries.Count>0){tiles=new GameGridPanel();gamesArea.Children.Add(tiles);}
        foreach(var entry in entries){
            if(tiles!=null){tiles.Children.Add(GameTile(entry));continue;}
            var panel=UI.Stack(UI.Text(entry.Name,15,"#E8E8EF",true),UI.Text(entry.Platform,11,"#ACBDE3"),GameHoursLabel(entry),UI.Text(entry.Bytes.HasValue?Format.Bytes(entry.Bytes.Value):entry.TrackingOnly?"Histórico":"Tamanho pendente",20,"#EEEEF4",true),UI.Text(entry.SizeSource,10,"#9999A5"));
            var actions=GameActions(entry);panel.Children.Add(actions);panel.ToolTip=entry.Folder;
            var row=new Grid();row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(84)});row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
            var cover=GamePosterButton(entry,120,72);
            row.Children.Add(cover);Grid.SetColumn(panel,1);row.Children.Add(panel);gamesArea.Children.Add(UI.Card(row,12));
        }
        if(libraryLoaded&&entries.Count==0&&allGames.Count>0)gamesArea.Children.Add(UI.Text("Nenhum jogo corresponde aos filtros.",12));
        if(libraryLoaded&&allGames.Count==0)gamesArea.Children.Add(UI.Card(UI.Text("Nenhum jogo na biblioteca. Use Adicionar jogo para detectar instalações ou cadastrar um executável.",12)));
        if(library.Notices.Count>0)gamesArea.Children.Add(UI.Text(string.Join("\n",library.Notices.Distinct().Take(8)),10,"#C0B294"));
    }
    async void LoadCovers(){
        if(coversLoading)return;
        coversLoading=true;
        var current=library;
        try{
            foreach(var game in current.Games.ToArray()){
                if(exiting||current!=library)break;
                await Task.Run(()=>GameCovers.Resolve(game));
                if(exiting||current!=library)break;
                RenderGames();
                RenderContinueGame();
            }
        }finally{
            coversLoading=false;
            if(!exiting&&current!=library)LoadCovers();
            else if(!exiting){RenderGames();RenderContinueGame();RenderSessionList();}
        }
    }
    void ChooseCover(GameEntry game){var dialog=new Microsoft.Win32.OpenFileDialog{Filter="Imagens|*.jpg;*.jpeg;*.png;*.webp;*.bmp"};if(dialog.ShowDialog(window)!=true)return;try{if(GameCovers.Image(dialog.FileName)==null)throw new IOException("Formato de imagem não suportado.");string target=GameCovers.CachePath(game);Directory.CreateDirectory(Path.GetDirectoryName(target));File.Copy(dialog.FileName,target,true);game.CoverPath=target;game.CoverSource="Capa escolhida por você";continueGameKey=spotlightKey=null;RenderGames();RenderContinueGame();RenderSessionList();}catch(Exception ex){Notice(ex.Message);}}
    void Cleanup(){
        cleanupInputs.Clear();
        var path=new TextBox{Text=cleanupFolder,Margin=new Thickness(0,7,0,6)};path.TextChanged+=(s,e)=>cleanupFolder=path.Text;cleanupInputs.Add(path);
        var actions=new ActionGrid();actions.Children.Add(UI.Button("Escolher pasta",()=>{using(var dialog=new Forms.FolderBrowserDialog{Description="Escolha uma pasta pessoal",SelectedPath=Directory.Exists(cleanupFolder)?cleanupFolder:""})if(dialog.ShowDialog()==Forms.DialogResult.OK){cleanupFolder=dialog.SelectedPath;path.Text=cleanupFolder;}}));actions.Children.Add(UI.Button("Analisar para limpeza",FindCleanup,true));actions.Children.Add(UI.Button("Cancelar",()=>{if(cleanupCancel!=null)cleanupCancel.Cancel();}));
        var modes=UI.Choice(new[]{"Temporários antigos","Arquivos grandes","Duplicados"},cleanupMode,v=>{cleanupMode=v;cleanupResult=null;RenderCleanup();});cleanupInputs.Add(modes);
        body.Children.Add(UI.Button("← Voltar ao armazenamento",()=>BuildPage("storage")));
        body.Children.Add(UI.Card(UI.Stack(UI.Text("Limpeza com revisão",18,"#E7E7EF",true),UI.Text("Nada é removido ao analisar. Selecione os arquivos, confira a prévia e envie à Lixeira. Windows, aplicativos, dados internos e jogos detectados ficam protegidos.",12,"#A5A5B0"),modes,UI.Text("Temporários: mais de 7 dias. Grandes: a partir de 100 MB. Duplicados: mesmo tamanho e SHA-256 do conteúdo, mantendo uma cópia.",11,"#9999A5"),path,actions)));
        cleanupArea=new StackPanel();body.Children.Add(cleanupArea);RenderCleanup();
    }
    async void FindCleanup(){if(cleanupBusy)return;if(cleanupMode!="Temporários antigos"&&!Directory.Exists(cleanupFolder)){Notice("Escolha uma pasta acessível.");return;}cleanupBusy=true;cleanupResult=null;cleanupStatus="Localizando arquivos…";cleanupCancel=new CancellationTokenSource();cleanupPage=0;RenderCleanup();try{await LoadGames();string mode=cleanupMode,folder=cleanupFolder;var token=cleanupCancel.Token;var roots=library.Games.Select(g=>g.Folder).ToArray();cleanupResult=await Task.Run(()=>CleanupEngine.Find(folder,mode,roots,token,text=>window.Dispatcher.BeginInvoke(new Action(()=>{cleanupStatus=text;RenderCleanup();}))));}catch(Exception ex){cleanupStatus=ex.Message;}finally{cleanupBusy=false;cleanupCancel.Dispose();cleanupCancel=null;RenderCleanup();}}
    void RenderCleanup(){if(cleanupArea==null)return;foreach(var control in cleanupInputs)control.IsEnabled=!cleanupBusy;cleanupArea.Children.Clear();if(cleanupBusy){cleanupArea.Children.Add(UI.Card(UI.Stack(UI.Text("Analisando…",16,"#9AB9F3",true),UI.Text(cleanupStatus,11),new ProgressBar{IsIndeterminate=true,Margin=new Thickness(0,12,0,0)})));return;}if(cleanupResult==null){if(cleanupStatus!="")cleanupArea.Children.Add(UI.Text(cleanupStatus,12));return;}
        var result=cleanupResult;var selected=result.Files.Where(f=>f.Selected).ToList();var actions=new ActionGrid();actions.Children.Add(UI.Button("Enviar seleção à Lixeira",RecycleSelection,true));actions.Children.Add(UI.Button("Marcar tudo",()=>{CleanupSelection.MarkAll(result);RenderCleanup();}));actions.Children.Add(UI.Button("Desmarcar tudo",()=>{foreach(var f in result.Files)f.Selected=false;RenderCleanup();}));if(result.Files.Any(f=>f.Group!=null))actions.Children.Add(UI.Button("Selecionar cópias extras",()=>{foreach(var group in result.Files.GroupBy(f=>f.Group)){bool first=true;foreach(var f in group){f.Selected=!first;first=false;}}RenderCleanup();}));
        cleanupArea.Children.Add(UI.Card(UI.Stack(UI.Text(result.Cancelled?"Análise parcial • cancelada":"Prévia • "+result.Mode,17,"#E5E5ED",true),UI.Text(result.Files.Count+" arquivos • "+result.Skipped+" locais ignorados",11),UI.Text(selected.Count+" selecionados • "+Format.Bytes(selected.Sum(f=>(double)f.Bytes)),14,"#A8BFE9",true),UI.Text("Marcar tudo abrange todas as páginas. Para duplicados, mantém uma cópia de cada grupo. O espaço é liberado ao esvaziar a Lixeira.",10,"#A2A2AE"),actions)));
        foreach(var item in result.Files.Skip(cleanupPage*60).Take(60)){var entry=item;var checkbox=UI.Check(Path.GetFileName(entry.Path)+" • "+Format.Bytes(entry.Bytes),entry.Selected,v=>{entry.Selected=v;RenderCleanup();});var panel=UI.Stack(checkbox,UI.Text(entry.Path,10,"#9999A5"));if(entry.Hash!=null)panel.Children.Add(UI.Text("Conteúdo idêntico • SHA-256 "+entry.Hash.Substring(0,12),9,"#9DB4DF"));cleanupArea.Children.Add(UI.Card(panel,13));}
        var pages=new ActionGrid();if(cleanupPage>0)pages.Children.Add(UI.Button("← Anteriores",()=>{cleanupPage--;RenderCleanup();}));if((cleanupPage+1)*60<result.Files.Count)pages.Children.Add(UI.Button("Próximos →",()=>{cleanupPage++;RenderCleanup();}));cleanupArea.Children.Add(pages);
    }
    async void RecycleSelection(){if(cleanupResult==null||cleanupBusy)return;var selected=cleanupResult.Files.Where(f=>f.Selected).ToList();if(selected.Count==0){Notice("Selecione os arquivos na prévia.");return;}if(MessageBox.Show(window,"Enviar "+selected.Count+" arquivos ("+Format.Bytes(selected.Sum(f=>(double)f.Bytes))+") à Lixeira?\n\nA seleção está listada nesta página. Para duplicados, uma cópia íntegra deve permanecer. Arquivos alterados desde a análise serão ignorados.","LUA • Confirmar seleção",MessageBoxButton.YesNo,MessageBoxImage.Question,MessageBoxResult.No)!=MessageBoxResult.Yes)return;
        cleanupBusy=true;cleanupStatus="Verificando e enviando a seleção…";var all=cleanupResult.Files.ToList();RenderCleanup();try{var errors=await RecycleBin.OnSta(()=>CleanupEngine.Recycle(selected,all,library.Games.Select(g=>g.Folder).ToArray()));int removed=selected.Count(f=>!File.Exists(f.Path));cleanupResult.Files=cleanupResult.Files.Where(f=>File.Exists(f.Path)).ToList();foreach(var f in cleanupResult.Files)f.Selected=false;Notice(removed+" arquivos enviados à Lixeira."+(errors.Count>0?"\n\n"+string.Join("\n",errors.Take(8)):""));}catch(Exception ex){Notice(ex.Message);}finally{cleanupBusy=false;RenderCleanup();}
    }
    void CaptureSelectedGame(){if(targetPid<=0){Notice("Abra um jogo reconhecido da biblioteca para medir o FPS.");return;}fps.Start(targetPid,targetName);Refresh();}
}
}
