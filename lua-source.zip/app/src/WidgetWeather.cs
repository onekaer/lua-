using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Script.Serialization;

namespace LuaMonitor {
public sealed class WidgetCity {
    public string name, admin1, country;
    public double? latitude, longitude;
    [ScriptIgnore]
    public bool Valid { get { return !string.IsNullOrWhiteSpace(name) && latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180; } }
    [ScriptIgnore]
    public string Name { get { return string.Join(", ", new[] { name, admin1, country }.Where(s => !string.IsNullOrWhiteSpace(s)).Distinct()); } }
}

internal sealed class WidgetCityResponse { public List<WidgetCity> results; }
internal sealed class WidgetWeatherResponse { public WidgetWeatherReading current; }
internal sealed class WidgetWeatherReading { public double? temperature_2m; public int? weather_code; }

internal static class WidgetWeather {
    public static List<WidgetCity> Search(string text) {
        var result = ReadJson<WidgetCityResponse>("https://geocoding-api.open-meteo.com/v1/search?count=8&language=pt&name=" + Uri.EscapeDataString(text));
        return (result == null || result.results == null ? new List<WidgetCity>() : result.results)
            .Where(city => city != null && city.Valid).ToList();
    }

    public static WidgetWeatherReading Read(WidgetCity city) {
        var invariant = CultureInfo.InvariantCulture;
        string url = "https://api.open-meteo.com/v1/forecast?current=temperature_2m,weather_code&latitude=" +
            city.latitude.Value.ToString(invariant) + "&longitude=" + city.longitude.Value.ToString(invariant);
        var response = ReadJson<WidgetWeatherResponse>(url);
        var weather = response == null ? null : response.current;
        if (weather == null || !weather.temperature_2m.HasValue) throw new InvalidDataException("Temperatura indisponível.");
        return weather;
    }

    static T ReadJson<T>(string url) {
        var request = (HttpWebRequest)WebRequest.Create(url);
        request.Timeout = 8000;
        request.ReadWriteTimeout = 8000;
        using (var response = request.GetResponse())
        using (var reader = new StreamReader(response.GetResponseStream()))
            return new JavaScriptSerializer().Deserialize<T>(reader.ReadToEnd());
    }

    internal static string Description(int? code) {
        if (!code.HasValue) return "Condição indisponível";
        if (code == 0) return "Céu limpo";
        if (code == 1 || code == 2) return "Parcialmente nublado";
        if (code == 3) return "Nublado";
        if (code <= 48) return "Neblina";
        if (code <= 57) return "Garoa";
        if (code <= 67 || (code >= 80 && code <= 82)) return "Chuva";
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return "Neve";
        if (code >= 95 && code <= 99) return "Trovoadas";
        return "Condição indisponível";
    }
}
}
