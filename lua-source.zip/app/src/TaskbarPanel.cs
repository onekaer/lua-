using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace LuaMonitor {
public sealed partial class DesktopController {
    bool taskbarDocked;
    ContentControl taskbarHomeHost;

    void ToggleTaskbarPanel() {
        if (taskbarDocked && window.IsVisible) {
            window.Hide();
            return;
        }
        if (!compact) SetMode(true, false);
        if (!window.IsVisible) BuildPage("home");
        ShowMain();
    }

    bool DockTaskbarPanel() {
        if (widgetSurface || !compact || !window.IsVisible || taskbarWidget == null || !taskbarWidget.HasAnchor) return false;
        bool attach = !taskbarDocked;
        taskbarDocked = true;
        taskbarWidget.ClosePeek();
        var surface = Find<Border>("RootSurface");
        surface.Background = TaskbarWidget.PanelBackground(prefs.Taskbar.Tint);
        surface.BorderBrush = UI.Brush("#37323E");
        window.Topmost = true;
        var close = Find<Button>("TrayButton");
        close.ToolTip = "Recolher painel para a barra";
        System.Windows.Automation.AutomationProperties.SetName(close, "Recolher painel para a barra");
        if (attach && page == "home") BuildPage("home");
        RepositionTaskbarPanel();
        return taskbarDocked;
    }

    void RepositionTaskbarPanel() {
        if (!taskbarDocked || !window.IsVisible || taskbarWidget == null) return;
        if (!taskbarWidget.HasAnchor) {
            if (taskbarEditor == null) window.Hide();
            return;
        }
        double height = Math.Min(640 * prefs.UiScale, taskbarWidget.DockedHeight);
        if (Math.Abs(window.Height - height) >= 1) {
            window.MinHeight = Math.Min(500, height);
            window.Height = height;
            window.UpdateLayout();
        }
        taskbarWidget.PositionPanel(window);
    }

    void ReleaseTaskbarPanel() {
        if (!taskbarDocked) return;
        taskbarDocked = false;
        if (taskbarWidget != null) taskbarWidget.SetCardHost(null);
        var surface = Find<Border>("RootSurface");
        surface.Background = UI.Brush("#0E0F0F");
        surface.BorderBrush = UI.Brush("#262828");
        var close = Find<Button>("TrayButton");
        close.ToolTip = "Recolher para a bandeja";
        System.Windows.Automation.AutomationProperties.SetName(close, "Recolher para a bandeja");
        window.MinHeight = 500;
    }

    void DockedHome() {
        taskbarHomeHost = new ContentControl { HorizontalContentAlignment = HorizontalAlignment.Stretch };
        body.Children.Add(taskbarHomeHost);
        taskbarWidget.SetCardHost(taskbarHomeHost);
        AddOverviewLinks(true);
    }

    void AddOverviewLinks(bool includeSummary) {
        if (includeSummary) {
            var network = Value(s => "↓ " + Format.Rate(s.Download) + " · ↑ " + Format.Rate(s.Upload), 11, "#B0ADB9");
            var storage = Value(s => Format.Bytes(s.Disks.Sum(d => (double)d.Free)) + " livres", 11, "#B0ADB9");
            var networkCard = PageCard("Rede", network, "network", () => BuildPage("network"));
            var storageCard = PageCard("Armazenamento", storage, "storage", () => BuildPage("storage"));
            body.Children.Add(UI.Inline(networkCard, storageCard));
        }
        body.Children.Add(PageCard("Detalhes do hardware", "Componentes e sensores", "hardware", () => BuildPage("hardware")));
    }

}
}
