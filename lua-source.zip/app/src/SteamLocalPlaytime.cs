using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace LuaMonitor {
// Local Steam format researched against PlayCounter (MIT), see licenses/PlayCounter.txt.
public static class SteamLocalPlaytime {
    public static Dictionary<string, object> Parse(string text) {
        if (text.Length > 16 * 1024 * 1024) throw new InvalidDataException("Arquivo Steam muito grande.");
        var root = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        var parents = new Stack<Dictionary<string, object>>();
        var current = root;
        string key = null;
        foreach (Match token in Regex.Matches(text, "//[^\\r\\n]*|\"((?:\\\\.|[^\"\\\\])*)\"|([{}])", RegexOptions.None, TimeSpan.FromSeconds(3))) {
            if (token.Value.StartsWith("//")) continue;
            if (token.Value == "{") {
                if (key == null || parents.Count >= 64) throw new InvalidDataException("Estrutura VDF inválida.");
                var child = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                current[key] = child; parents.Push(current); current = child; key = null;
            } else if (token.Value == "}") {
                if (key != null || parents.Count == 0) throw new InvalidDataException("Estrutura VDF inválida.");
                current = parents.Pop();
            } else {
                string value = token.Groups[1].Value.Replace("\\\"", "\"").Replace("\\\\", "\\");
                if (key == null) key = value; else { current[key] = value; key = null; }
            }
        }
        if (parents.Count != 0 || key != null) throw new InvalidDataException("Arquivo VDF incompleto.");
        return root;
    }
    static Dictionary<string, object> Child(Dictionary<string, object> parent, string name) {
        object value;
        return parent != null && parent.TryGetValue(name, out value) ? value as Dictionary<string, object> : null;
    }
    static double Minutes(Dictionary<string, object> app, string key) {
        object value; double minutes;
        return app.TryGetValue(key, out value) && double.TryParse(value as string, NumberStyles.None, CultureInfo.InvariantCulture, out minutes) && PlaytimeStore.ValidSeconds(minutes * 60) ? minutes : 0;
    }
    public static List<PlaytimeImportRow> Read(string text, string account, IDictionary<string, string> names) {
        var root = Parse(text);
        var apps = Child(Child(Child(Child(Child(root, "UserLocalConfigStore") ?? root, "Software"), "Valve"), "Steam"), "apps");
        if (apps == null) throw new InvalidDataException("O arquivo Steam não contém tempos de jogos.");
        var rows = new List<PlaytimeImportRow>();
        foreach (var pair in apps) {
            var app = pair.Value as Dictionary<string, object>;
            string name;
            if (app == null || !names.TryGetValue(pair.Key, out name)) continue;
            double minutes = Minutes(app, "Playtime") + Minutes(app, "PlaytimeDisconnected");
            if (minutes > 0) rows.Add(new PlaytimeImportRow { Name = name, Platform = "Steam", Account = account, Hours = minutes / 60 });
        }
        return rows;
    }
    public static List<PlaytimeImportRow> Scan(IEnumerable<GameEntry> installed, List<string> notices) {
        var games = installed.Where(g => !string.IsNullOrEmpty(g.SteamId)).ToList();
        var names = games.GroupBy(g => g.SteamId).ToDictionary(g => g.Key, g => g.First().Name);
        var roots = new HashSet<string>(games.Where(g => !string.IsNullOrWhiteSpace(g.SteamRoot)).Select(g => g.SteamRoot), StringComparer.OrdinalIgnoreCase);
        using (var steam = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")) {
            var path = steam == null ? null : steam.GetValue("SteamPath") as string;
            if (!string.IsNullOrWhiteSpace(path)) roots.Add(path);
        }
        roots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam"));
        var rows = new List<PlaytimeImportRow>();
        foreach (var root in roots) {
            string data = Path.Combine(root, "userdata");
            if (!Directory.Exists(data)) continue;
            try {
                foreach (var directory in Directory.GetDirectories(data)) {
                    uint accountId;
                    if (!uint.TryParse(Path.GetFileName(directory), out accountId) || accountId == 0) continue;
                    string file = Path.Combine(directory, "config", "localconfig.vdf");
                    if (!File.Exists(file)) continue;
                    try {
                        if (new FileInfo(file).Length > 16 * 1024 * 1024) throw new InvalidDataException("Arquivo excede 16 MB.");
                        rows.AddRange(Read(File.ReadAllText(file), (76561197960265728UL + accountId).ToString(CultureInfo.InvariantCulture), names));
                    } catch (Exception ex) { notices.Add("Conta local " + accountId + ": " + ex.Message); }
                }
            } catch (Exception ex) { notices.Add("Steam local: " + ex.Message); }
        }
        return rows.GroupBy(r => r.Account + "\n" + r.Name).Select(g => g.OrderByDescending(r => r.Hours).First()).ToList();
    }
}
}
