using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public sealed partial class DesktopController {
    async Task TemperatureChecks(List<string> checks,string dir){
        var fixture=new CpuSensorBridge();var invalid=new Snapshot();fixture.Feed("TEMP:0");fixture.Feed("TEMP:NaN");fixture.Feed("TEMP:160");fixture.Apply(invalid);if(invalid.CpuTemp.HasValue)throw new Exception("Temperatura inválida foi mostrada");fixture.Feed("TEMP:58.25");var valid=new Snapshot();fixture.Apply(valid);if(valid.CpuTemp!=58.25)throw new Exception("Leitura real do assistente não foi aplicada");fixture.Dispose();var stopped=new Snapshot();fixture.Apply(stopped);if(stopped.CpuTemp.HasValue)throw new Exception("Leitura antiga permaneceu após desligar");checks.Add("CPU: assistente separado, temperatura válida aplicada, zero/NaN/fora de faixa recusados e leitura descartada ao encerrar");
        if(Environment.GetCommandLineArgs().Contains("--verify-cpu-elevated")){if(!CpuSensorBridge.DriverInstalled())throw new Exception("PawnIO não instalado");StartCpuSensors();for(int n=0;n<250;n++){await Task.Delay(100);var real=new Snapshot();cpuSensor.Apply(real);if(real.CpuTemp.HasValue){snapshot.CpuTemp=real.CpuTemp;checks.Add("CPU REAL via assistente elevado e painel normal: "+real.CpuTemp.Value.ToString("0.00")+" °C • PawnIO instalado");break;}}if(!snapshot.CpuTemp.HasValue)throw new Exception("O assistente real não retornou temperatura");}
        double scaleSaved=prefs.UiScale;bool motion=UI.MotionEnabled;UI.MotionEnabled=false;try{foreach(double scale in new[]{1.0,1.25,1.5}){prefs.UiScale=scale;SetMode(true,false);BuildPage("home");window.UpdateLayout();var scroll=Find<ScrollViewer>("ContentScroll");if(scale==1&&scroll.ScrollableHeight>.5)throw new Exception("Início padrão ainda exige rolagem: "+scroll.ScrollableHeight);var free=CollectText(body);if(!free.Contains("ESPAÇO LIVRE"))throw new Exception("Espaço livre desapareceu");UI.Capture(window,Path.Combine(dir,"home-fitted-"+(scale*100).ToString("0")+".png"));}checks.Add("Início: espaço livre menor, valor destacado e altura rolável zero no modo padrão; renderização a 100%, 125% e 150%");}finally{prefs.UiScale=scaleSaved;UI.MotionEnabled=motion;SetMode(true,false);BuildPage("home");}
    }
}
}
