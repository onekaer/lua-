using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public static class AttentionAlerts {
    public static string Message(Snapshot snapshot,Preferences prefs){
        if(!prefs.Notifications)return null;
        if(snapshot.CpuTemp>=prefs.CpuWarning)return "CPU a "+Format.Temp(snapshot.CpuTemp);
        if(snapshot.RamPercent>=prefs.RamWarning)return "Memória em "+Format.Percent(snapshot.RamPercent);
        return null;
    }
}
public static class AttentionRegression {
    public static void Run(){
        if(new Preferences().Notifications)throw new Exception("Avisos vieram ativados por padrão");
        var json=new JavaScriptSerializer();var legacy=json.Deserialize<Preferences>("{\"Notifications\":true}");legacy.UpgradeDefaults();
        if(legacy.Notifications||!legacy.AttentionOptInUpdated)throw new Exception("Avisos antigos não foram desativados");
        legacy.Notifications=true;var restored=json.Deserialize<Preferences>(json.Serialize(legacy));restored.UpgradeDefaults();
        if(!restored.Notifications)throw new Exception("A escolha explícita de ativar avisos não foi preservada");
        var sample=new Snapshot{CpuTemp=95,RamTotal=100,RamAvailable=1};sample.Disks.Add(new DiskValue{Total=100,Free=0});
        if(AttentionAlerts.Message(sample,new Preferences())!=null)throw new Exception("Aviso emitido com opção desligada");
        if(AttentionAlerts.Message(sample,restored)!="CPU a 95 °C")throw new Exception("Aviso opcional da CPU falhou");
        sample.CpuTemp=35;if(AttentionAlerts.Message(sample,restored)!="Memória em 99%")throw new Exception("Aviso opcional da RAM falhou");
        sample.RamAvailable=80;if(AttentionAlerts.Message(sample,restored)!=null)throw new Exception("Disco cheio ainda gera aviso");
        restored.Notifications=false;restored.UpgradeDefaults();if(restored.Notifications)throw new Exception("Desativar avisos não foi preservado");
    }
}
public sealed partial class DesktopController {
    UIElement AttentionOptions(){return UI.Stack(UI.Text("Avisos de atenção",17,"#E6E6E6",true),UI.Check("Ativar avisos de atenção (CPU e RAM)",prefs.Notifications,value=>{prefs.Notifications=value;Save();}),UI.Text("Opcionais e desativados por padrão. O LUA não envia notificações de disco.",12,"#A4A4B4"),UI.Label("Temperatura da CPU"),Slider(60,110,prefs.CpuWarning,v=>{prefs.CpuWarning=(int)v;Save();},v=>v.ToString("0")+" °C"),UI.Label("Ocupação da RAM"),Slider(60,99,prefs.RamWarning,v=>{prefs.RamWarning=(int)v;Save();},v=>v.ToString("0")+"%"),UI.Text("Quando ativados, os avisos respeitam os limites acima e o intervalo de 5 minutos. O limite de temperatura depende do fabricante.",11,"#9F9F9F"));}
    async Task AttentionChecks(List<string> checks,string dir){
        if(Preferences.DataDir==Preferences.DefaultDataDir)throw new Exception("Use uma pasta de teste isolada para verificar avisos");
        AttentionRegression.Run();checks.Add("Avisos: padrão desligado, migração de configuração antiga, escolha posterior preservada, CPU/RAM opcionais e disco sem notificações");
        bool saved=prefs.Notifications;try{prefs.Notifications=false;var toggle=((StackPanel)AttentionOptions()).Children.OfType<CheckBox>().Single();if(toggle.IsChecked!=false)throw new Exception("Opção de avisos aparece marcada");toggle.IsChecked=true;prefs.Save();var loaded=Preferences.Load();loaded.UpgradeDefaults();if(!prefs.Notifications||!loaded.Notifications)throw new Exception("Ativar avisos pela configuração não persistiu");toggle.IsChecked=false;prefs.Save();loaded=Preferences.Load();loaded.UpgradeDefaults();if(prefs.Notifications||loaded.Notifications)throw new Exception("Desativar avisos pela configuração não persistiu");}finally{prefs.Notifications=saved;prefs.Save();}
        checks.Add("Configurações: checkbox inicia desmarcado e salva ativação/desativação em pasta isolada");
        var previous=recorder;bool busy=videoBusy;try{using(var test=new ScreenRecorder()){recorder=test;videoBusy=false;await test.StartRecording(new RecordingOptions{Folder=Path.Combine(Preferences.DataDir,"low-space-check"),Audio=false,Height=720,Fps=30,Bitrate=4});await Task.Delay(2500);LocalHistory.Write("notifications.json",new ActivityItem[0]);diskCheck=DateTime.MinValue;await ProtectRecording(_=>0);if(test.Active||!File.Exists(test.LastFile))throw new Exception("Proteção por pouco espaço deixou de finalizar o vídeo");if(LocalHistory.Read<ActivityItem>("notifications.json").Count!=0)throw new Exception("Proteção por pouco espaço ainda notificou");if(!(await ProbeVideo(test.LastFile)).Contains("h264"))throw new Exception("Vídeo protegido não ficou legível");}}finally{recorder=previous;videoBusy=busy;}
        checks.Add("Disco: pouco espaço simulado finalizou um MP4 real e legível sem gerar notificação; vídeo privado somente na pasta de teste");
    }
}
}
