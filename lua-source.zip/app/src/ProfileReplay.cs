﻿using System;
using System.Threading.Tasks;
namespace LuaMonitor {
public sealed partial class DesktopController {
    bool profileSwitching;
    async Task<bool> ApplyProfileWithReplay(CaptureProfile profile){if(sharedOwner!=null)return await sharedOwner.ApplyProfileWithReplay(profile);if(videoBusy||(recorder!=null&&recorder.Recording))return ApplyProfile(profile);if(recorder==null||!recorder.Replaying)return ApplyProfile(profile);bool applied=false;videoBusy=true;captureAction="Aplicando perfil";UpdateVideo();try{await recorder.StopReplay();videoBusy=false;applied=ApplyProfile(profile);videoBusy=true;if(prefs.ReplayAlwaysOn&&!exiting)await Recorder.StartReplay(VideoOptions(false));return applied;}catch(Exception ex){autoReplayAfter=DateTime.UtcNow.AddSeconds(10);ShowClipToast("Perfil e histórico",ex.Message);return false;}finally{videoBusy=false;captureAction="";UpdateVideo();}}
}
}
