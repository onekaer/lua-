using System.Windows;
using System.Windows.Controls;
namespace LuaMonitor {
public sealed partial class DesktopController {
    void UpdateUpdateControls(){
        var owner=sharedOwner??this;bool show=owner.availableUpdate!=null&&!widgetSurface;
        var titleButton=Find<Button>("UpdateTitleButton");var compactButton=Find<Button>("UpdateCompactButton");
        titleButton.Visibility=show&&!compact?Visibility.Visible:Visibility.Collapsed;compactButton.Visibility=show&&compact?Visibility.Visible:Visibility.Collapsed;
        foreach(var button in new[]{titleButton,compactButton}){button.Content=owner.updateBusy?"Atualizando…":"Atualizar";button.IsEnabled=!owner.updateBusy;button.ToolTip=show?"Instalar LUA "+owner.availableUpdate.Version:"Atualizações do LUA";}
        footer.Margin=new Thickness(0,0,show&&compact?96:0,0);footer.TextTrimming=TextTrimming.CharacterEllipsis;
    }
}
}
