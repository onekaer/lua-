using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
namespace LuaMonitor {
public class MediaInfo {public string Title="",Game="";public double Duration;public int Width,Height;public long Bytes,Stamp;public bool Favorite;}
public static class MediaServices {
    static Dictionary<string,MediaInfo> catalog;static readonly object gate=new object();static CaptureJob job;
    static string Index {get{return Path.Combine(Preferences.DataDir,"media-index.json");}}
    static Dictionary<string,MediaInfo> Catalog {get{lock(gate){if(catalog==null)try{catalog=new JavaScriptSerializer().Deserialize<Dictionary<string,MediaInfo>>(File.ReadAllText(Index));}catch{catalog=new Dictionary<string,MediaInfo>(StringComparer.OrdinalIgnoreCase);}return catalog;}}}
    public static MediaInfo Info(string path){lock(gate){MediaInfo info;if(!Catalog.TryGetValue(path,out info))Catalog[path]=info=new MediaInfo();return info;}}
    public static void Save() {
        lock (gate) {
            Directory.CreateDirectory(Preferences.DataDir);
            string index = Index;
            string temp = index + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try {
                File.WriteAllText(temp,new JavaScriptSerializer().Serialize(Catalog));
                if (File.Exists(index)) File.Replace(temp,index,null);
                else File.Move(temp,index);
            } finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
    public static void ToggleFavorite(string path) {
        lock (gate) {
            var info = Info(path);
            bool previous = info.Favorite;
            info.Favorite = !previous;
            try { Save(); }
            catch { info.Favorite = previous; throw; }
        }
    }
    public static string Title(GalleryItem item){var info=Info(item.Path);if(!string.IsNullOrWhiteSpace(info.Title))return info.Title;if(!item.Name.StartsWith("LUA_",StringComparison.OrdinalIgnoreCase))return Path.GetFileNameWithoutExtension(item.Name);return (item.Kind=="Vídeos"?"Gravação":item.Kind=="Clipes"?"Clipe":"Print")+" • "+item.Date.ToString("dd/MM • HH:mm");}
    public static async Task<string> Run(string executable,string args,CancellationToken token,int timeout=120000){using(var process=new Process{StartInfo=new ProcessStartInfo(Path.Combine(ScreenRecorder.Tools,executable),args){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true}}){process.Start();lock(gate){if(job==null)job=new CaptureJob();job.Add(process);}using(token.Register(()=>{try{if(!process.HasExited)process.Kill();}catch{}})){Task<string> error=process.StandardError.ReadToEndAsync();Task<string> output=process.StandardOutput.ReadToEndAsync();bool ended=await Task.Run(()=>process.WaitForExit(timeout));if(!ended){process.Kill();throw new IOException("O processamento demorou demais.");}string err=await error,result=await output;token.ThrowIfCancellationRequested();if(process.ExitCode!=0)throw new IOException(err.Length>900?err.Substring(err.Length-900):err);return result;}}}
    public static async Task<MediaInfo> Probe(GalleryItem item,CancellationToken token=default(CancellationToken)){token.ThrowIfCancellationRequested();var info=Info(item.Path);var file=new FileInfo(item.Path);if(info.Bytes==file.Length&&info.Stamp==file.LastWriteTimeUtc.Ticks)return info;if(item.Kind=="Prints"){using(var stream=File.OpenRead(item.Path)){var image=System.Windows.Media.Imaging.BitmapDecoder.Create(stream,System.Windows.Media.Imaging.BitmapCreateOptions.PreservePixelFormat,System.Windows.Media.Imaging.BitmapCacheOption.OnDemand).Frames[0];info.Width=image.PixelWidth;info.Height=image.PixelHeight;}}else{string json=await Run("ffprobe.exe","-v error -show_streams -show_format -of json "+ScreenRecorder.Quote(item.Path),token);var result=new JavaScriptSerializer().Deserialize<ProbeResult>(json);if(result.format!=null)double.TryParse(result.format.duration,NumberStyles.Float,CultureInfo.InvariantCulture,out info.Duration);var stream=result.streams==null?null:result.streams.FirstOrDefault(s=>s.codec_type=="video");if(stream!=null){info.Width=stream.width;info.Height=stream.height;}}info.Bytes=file.Length;info.Stamp=file.LastWriteTimeUtc.Ticks;Save();return info;}
    class ProbeResult {public ProbeStream[] streams;public ProbeFormat format;}class ProbeStream {public string codec_type;public int width,height;}class ProbeFormat {public string duration;}
    public static string Description(MediaInfo info){return (info.Duration>0?TimeSpan.FromSeconds(info.Duration).ToString(@"hh\:mm\:ss")+" • ":"")+(info.Width>0?info.Width+" × "+info.Height:"")+(string.IsNullOrWhiteSpace(info.Game)?"":" • "+info.Game);}
    public static double Seconds(string input){double value;if(double.TryParse(input.Replace(',','.'),NumberStyles.Float,CultureInfo.InvariantCulture,out value)&&value>=0&&value<86400)return value;string[] parts=input.Split(':');if(parts.Length<2||parts.Length>3)throw new ArgumentException("Use segundos, mm:ss ou hh:mm:ss.");value=0;foreach(string part in parts){double n;if(!double.TryParse(part,NumberStyles.Float,CultureInfo.InvariantCulture,out n)||n<0||n>=60)throw new ArgumentException("Tempo inválido.");value=value*60+n;}return value;}
    public static async Task<string> Trim(GalleryItem item,double start,double end,string root,CancellationToken token){var info=await Probe(item);if(start<0||end<=start||end>info.Duration+.05)throw new ArgumentException("Escolha um trecho dentro da duração do vídeo.");string folder=Path.Combine(root,"Clipes");Directory.CreateDirectory(folder);string target=Path.Combine(folder,"LUA_clipe_editado_"+DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss")+"_"+Guid.NewGuid().ToString("N").Substring(0,6)+".mp4"),temp=target+".partial.mp4";try{await Run("ffmpeg.exe","-hide_banner -loglevel error -nostdin -y -ss "+start.ToString("0.000",CultureInfo.InvariantCulture)+" -i "+ScreenRecorder.Quote(item.Path)+" -t "+(end-start).ToString("0.000",CultureInfo.InvariantCulture)+" -map 0:v:0 -map 0:a? -vf format=yuv420p -c:v libopenh264 -b:v 8M -c:a aac -b:a 160k -movflags +faststart "+ScreenRecorder.Quote(temp),token);if(new FileInfo(temp).Length<512)throw new IOException("O trecho não gerou um vídeo válido.");File.Move(temp,target);Info(target).Title=Title(item)+" • trecho";Info(target).Game=Info(item.Path).Game;Save();return target;}finally{if(File.Exists(temp))File.Delete(temp);}}
    public static string Rename(GalleryItem item,string title){string name=(title??"").Trim();if(name.Length==0||name.Length>120||name=="."||name==".."||name.IndexOfAny(Path.GetInvalidFileNameChars())>=0||name.EndsWith(".")||name.EndsWith(" "))throw new ArgumentException("Use um nome de 1 a 120 caracteres, sem símbolos de caminho.");string stem=item.Kind=="Clipes"&&Path.GetFileName(Path.GetDirectoryName(item.Path))!="Clipes"?"LUA_clipe_"+name:name;string target=Path.Combine(Path.GetDirectoryName(item.Path),stem+Path.GetExtension(item.Path));var info=Info(item.Path);if(!string.Equals(target,item.Path,StringComparison.OrdinalIgnoreCase)){if(File.Exists(target))throw new IOException("Já existe um arquivo com esse nome.");File.Move(item.Path,target);lock(gate){Catalog.Remove(item.Path);Catalog[target]=info;}}info.Title=name;Save();return target;}
    public static async Task Recycle(GalleryItem item){var file=new FileInfo(item.Path);if(!file.Exists||file.Length!=item.Bytes||file.LastWriteTime!=item.Date)throw new IOException("O arquivo mudou desde a listagem. Atualize a galeria.");if((file.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("Links não podem ser removidos pela galeria.");await RecycleBin.OnSta(()=>{RecycleBin.Send(item.Path);return true;});if(File.Exists(item.Path))throw new IOException("O Windows não enviou o arquivo à Lixeira.");lock(gate)Catalog.Remove(item.Path);Save();}
    public static void Dispose(){lock(gate){if(job!=null)job.Dispose();job=null;}}
}
}
