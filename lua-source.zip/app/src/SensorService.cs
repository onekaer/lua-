using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using LuaMonitor;

sealed class LuaCpuSensorService:ServiceBase {
    CancellationTokenSource cancel;Task worker;
    public LuaCpuSensorService(){ServiceName=SensorServiceInfo.Name;CanStop=true;AutoLog=false;}
    protected override void OnStart(string[] args){cancel=new CancellationTokenSource();worker=Task.Run(()=>{var computer=new LibreHardwareMonitor.Hardware.Computer{IsCpuEnabled=true};try{try{computer.Open();}catch{}while(!cancel.IsCancellationRequested){try{string line;try{line=LuaSensorsHost.ReadTemperature(computer);}catch{line="STATUS:Sensor da CPU sem leitura. Confira o PawnIO e a permissão.";}string temp=SensorServiceInfo.TelemetryPath+".new";File.WriteAllText(temp,DateTime.UtcNow.Ticks+"\n"+line,new UTF8Encoding(false));if(File.Exists(SensorServiceInfo.TelemetryPath))File.Replace(temp,SensorServiceInfo.TelemetryPath,null);else File.Move(temp,SensorServiceInfo.TelemetryPath);}catch{}if(cancel.Token.WaitHandle.WaitOne(1500))break;}}finally{try{computer.Close();}catch{}}});}
    protected override void OnStop(){if(cancel!=null){cancel.Cancel();if(worker!=null&&!worker.Wait(15000))throw new IOException("O sensor não encerrou no prazo.");cancel.Dispose();cancel=null;}try{File.Delete(SensorServiceInfo.TelemetryPath);}catch{}}
}

static class SensorServiceSetup {
    static readonly SecurityIdentifier Admins=new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null),SystemSid=new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),Users=new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid,null);
    static bool Admin(){return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);}
    static void NoLinks(string path){for(var item=new DirectoryInfo(path);item!=null;item=item.Parent){if(item.Exists&&(item.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("O destino do serviço contém um redirecionamento.");}}
    static DirectorySecurity Security(){var acl=new DirectorySecurity();acl.SetAccessRuleProtection(true,false);acl.SetOwner(Admins);foreach(var sid in new[]{Admins,SystemSid})acl.AddAccessRule(new FileSystemAccessRule(sid,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));acl.AddAccessRule(new FileSystemAccessRule(Users,FileSystemRights.ReadAndExecute,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));return acl;}
    static void ValidateAcl(FileSystemSecurity acl){var owner=(SecurityIdentifier)acl.GetOwner(typeof(SecurityIdentifier));if(owner!=Admins&&owner!=SystemSid)throw new IOException("O serviço contém um arquivo sem proprietário administrativo.");foreach(FileSystemAccessRule rule in acl.GetAccessRules(true,true,typeof(SecurityIdentifier))){if(rule.AccessControlType!=AccessControlType.Allow||rule.IdentityReference.Equals(Admins)||rule.IdentityReference.Equals(SystemSid))continue;var write=FileSystemRights.Write|FileSystemRights.Delete|FileSystemRights.DeleteSubdirectoriesAndFiles|FileSystemRights.ChangePermissions|FileSystemRights.TakeOwnership;if((rule.FileSystemRights&write)!=0)throw new IOException("O serviço permite alterações sem administrador.");}}
    internal static void ValidateDirectory(){NoLinks(SensorServiceInfo.DirectoryPath);ValidateAcl(Directory.GetAccessControl(SensorServiceInfo.DirectoryPath));foreach(string file in Directory.GetFiles(SensorServiceInfo.DirectoryPath)){if((File.GetAttributes(file)&FileAttributes.ReparsePoint)!=0)throw new IOException("Arquivo do serviço redirecionado.");ValidateAcl(File.GetAccessControl(file));}}
    static void Sc(string arguments){using(var process=Process.Start(new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"sc.exe"),arguments){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=SensorServiceInfo.DirectoryPath})){process.WaitForExit();if(process.ExitCode!=0)throw new IOException("O Windows não concluiu a alteração do serviço ("+process.ExitCode+").");}}
    static bool Exists(){foreach(var service in ServiceController.GetServices())using(service){if(service.ServiceName==SensorServiceInfo.Name)return true;}return false;}
    static void Stop(){using(var service=new ServiceController(SensorServiceInfo.Name)){service.Refresh();if(service.Status!=ServiceControllerStatus.Stopped){service.Stop();service.WaitForStatus(ServiceControllerStatus.Stopped,TimeSpan.FromSeconds(25));}}}
    static void CopyVerified(string name,string expected){string source=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,name),target=Path.Combine(SensorServiceInfo.DirectoryPath,name);if(string.Equals(source,target,StringComparison.OrdinalIgnoreCase))throw new IOException("Execute a instalação pela pasta do aplicativo.");if(File.Exists(target)&&(File.GetAttributes(target)&FileAttributes.ReparsePoint)!=0)throw new IOException("Arquivo de destino redirecionado.");using(var input=new FileStream(source,FileMode.Open,FileAccess.Read,FileShare.Read)){if(expected!=null){using(var hash=SHA256.Create()){string actual=BitConverter.ToString(hash.ComputeHash(input)).Replace("-","").ToLowerInvariant();if(actual!=expected)throw new IOException("Componente alterado: "+name);}input.Position=0;}using(var output=new FileStream(target,FileMode.Create,FileAccess.Write,FileShare.None))input.CopyTo(output);}var acl=new FileSecurity();acl.SetAccessRuleProtection(true,false);acl.SetOwner(Admins);foreach(var sid in new[]{Admins,SystemSid})acl.AddAccessRule(new FileSystemAccessRule(sid,FileSystemRights.FullControl,AccessControlType.Allow));acl.AddAccessRule(new FileSystemAccessRule(Users,FileSystemRights.ReadAndExecute,AccessControlType.Allow));File.SetAccessControl(target,acl);}
    public static int Install(){if(!Admin())return 5;bool existed=Exists();if(existed&&!SensorServiceInfo.Installed())throw new IOException("Já existe outro serviço com esse nome.");NoLinks(SensorServiceInfo.DirectoryPath);if(Directory.Exists(SensorServiceInfo.DirectoryPath))ValidateDirectory();else Directory.CreateDirectory(SensorServiceInfo.DirectoryPath,Security());if(existed)Stop();
        // Only this helper and the build-time verified dependency allowlist are installed.
        CopyVerified("LuaSensorsHost.exe",null);foreach(var item in SensorPayload.Files)CopyVerified(item.Key,item.Value);Directory.SetAccessControl(SensorServiceInfo.DirectoryPath,Security());ValidateDirectory();
        bool created=false;try{if(!existed){Sc("create "+SensorServiceInfo.Name+" binPath= \"\\\""+SensorServiceInfo.ExecutablePath+"\\\" --service\" start= auto obj= LocalSystem DisplayName= \"LUA - Sensores da CPU\"");created=true;}
        Sc("description "+SensorServiceInfo.Name+" \"Leitura local da temperatura da CPU para o LUA. Instalado por escolha do usuário; não recebe comandos do painel.\"");
        using(var service=new ServiceController(SensorServiceInfo.Name)){service.Start();service.WaitForStatus(ServiceControllerStatus.Running,TimeSpan.FromSeconds(25));}return 0;}catch{if(created){try{Stop();}catch{}try{Sc("delete "+SensorServiceInfo.Name);}catch{}}throw;}
    }
    public static int Remove(){if(!Admin())return 5;if(!Exists())return 0;if(!SensorServiceInfo.Installed())throw new IOException("O serviço não corresponde à instalação do LUA.");ValidateDirectory();Stop();Sc("delete "+SensorServiceInfo.Name);return 0;}
    public static int Verify(){if(!SensorServiceInfo.Installed())return 1;ValidateDirectory();using(var service=new ServiceController(SensorServiceInfo.Name)){if(service.Status!=ServiceControllerStatus.Running)return 2;}for(int n=0;n<20;n++){string line;if(SensorServiceInfo.TryRead(out line))return 0;Thread.Sleep(500);}return 3;}
}
