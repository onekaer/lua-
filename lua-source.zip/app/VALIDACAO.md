# Validação do LUA 1.10.1 Beta

Verificações em 13/10/2026. Compilação x64 concluída. Verificação de interface e pacote passaram em dados isolados.

- Captura com três ações e Galeria, altura compacta de 190 px, reabertura e seleção da duração do clipe preservadas.
- Movimento sem ativação, Digitar, clique através e barra incluída no print passaram nas verificações existentes via Win32.
- FPS com dados controlados, navegação, jogos/busca/grade/lista e escalas de 100%, 125% e 150% passaram.
- Instalador em pasta descartável, preservação de arquivos e rollback de arquivo bloqueado passaram.
- Controle de temperatura válida/ausente e início sem rolagem no tamanho padrão passaram.
- Prévias de Capturas e barra revisadas visualmente: sem Mic e sem Voltar ao jogo.
- Página: barra real atualizada na prévia de jogo e captura com três ações; recursos/âncoras/abas e pacote de fontes conferidos.

Esta rodada não repete gravação real ou benchmark de jogo, pois o ajuste remove controles da interface sem modificar os mecanismos de captura/FPS. Os testes completos desses mecanismos foram executados na versão 1.10.0; a tentativa real de FPS sem elevação não teve permissão naquela rodada. Não há garantia de compatibilidade universal. Executáveis continuam sem assinatura digital reconhecida.
