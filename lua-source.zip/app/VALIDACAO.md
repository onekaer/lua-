# Validação do LUA 1.10.0 Beta

Verificações locais em 13/10/2026. A rodada completa passou; após os últimos ajustes de interface, retorno de foco e Ctrl+Espaço, as verificações afetadas de interface/pacote passaram novamente.

- Compilação x64 do aplicativo e dos dois assistentes concluída.
- FPS: CSV v1/v2, filtro por PID, média, 1% low, mínimo/máximo, troca de jogo, reset da sessão e ausência de frames antigos passaram com dados controlados.
- Protocolo real do assistente: PID 17 → 18 → espera → 19, mesma instância, um capturador por vez e STOP sem filhos restantes. O PresentMon foi substituído por um emissor de teste nessa prova de transporte; não é um benchmark de jogo.
- Na tentativa real do PresentMon sem elevação, não houve quadros por falta de permissão. Não foi comprovada a medição real em jogos nesta rodada; não afirmamos compatibilidade universal.
- Seleção manual removida; FPS único na sobreposição; low/mínimo/máximo opcionais; FPS no topo do widget inicial com fonte 23 igual a CPU/GPU.
- Widgets editáveis conservam WS_EX_NOACTIVATE e retornam MA_NOACTIVATE. Movimento Win32 não trocou a janela em primeiro plano no teste. Digitar permite foco explicitamente; ao sair, o modo sem foco é restaurado.
- Janelas fixadas conservam clique através. A barra superior tem afinidade de captura zero e não é excluída do print.
- Ctrl+Espaço validado pelo parser, migração do padrão antigo e preservação de atalho personalizado.
- Atalho .lnk criado em pasta isolada; verificação não escreveu na Área de Trabalho real.
- Botões de atualização nos dois tamanhos, seção final de Configurações e distância de 8 px antes de Galeria/Analisar PC conferidos.
- Início padrão com altura rolável zero; renderizações em 100%, 125% e 150%. Escalas maiores/monitores menores podem exigir rolagem.
- Regressão completa: navegação, biblioteca/capas/filtros, limpeza com revisão, duplicados, áudio, gravação, clipes anteriores, galeria/player/corte, atalhos, widgets, instalador e rollback passaram.
- CPU: tratamento de temperatura válida/ausente e ciclo do assistente passaram. A leitura real com PawnIO foi validada na versão 1.9; esta rodada não repete a medição elevada.
- Prévias públicas usam somente a interface, capas e pastas de exemplo. Vídeos reais, dados pessoais e relatórios privados permanecem fora dos pacotes.

Limites: não foi comprovado desempenho idêntico à Xbox Game Bar, compatibilidade com todos os jogos/anticheats, tela cheia exclusiva, GPUs/CPUs, escalas entre monitores ou sessões prolongadas. Os executáveis próprios continuam sem assinatura digital reconhecida; o aviso do SmartScreen não foi removido.
