# Validação LUA 1.10.5 Beta

17/10/2026: compilação x64, pacote, interface e prévias passaram localmente. Testes verificam padrão desligado, migração de configurações antigas, ativação/desativação persistidas e avisos de CPU/RAM somente por escolha explícita. Disco cheio não gera aviso mesmo com a opção ativada.

Pouco espaço foi simulado na proteção de captura: um vídeo real de 2,5 segundos foi finalizado em MP4/H.264 legível, sem registro de notificação. Nenhum disco foi preenchido; o vídeo permanece somente na pasta de teste em work. Testes de interface, atalhos, sensores e atualizador em pastas isoladas também passaram. Nenhuma configuração pessoal foi alterada.

O CI confere novamente o pacote e o ciclo do serviço de sensores antes de publicar. Fontes Mac 0.1.4 preservados byte a byte; nenhuma alteração na edição Mac.
