# Validação do LUA 1.9

Testes locais em 13/10/2026; evidências em TESTES.txt.

- PawnIO 2.2.0 oficial instalado com autorização expressa. SHA-256 comparado ao anúncio do fornecedor e assinatura Authenticode válida.
- CPU AMD Ryzen 7 5700: sem elevação retornava zero, descartado; com permissão retornou aproximadamente 58–59 °C.
- Assistente elevado real conectado por canal local ao painel normal: 58,25 °C. O painel não precisa permanecer elevado.
- Zero, NaN, temperaturas fora de faixa e valores após desligar o assistente não foram mostrados como temperatura válida.
- Início padrão: bloco de espaço livre reduzido e altura rolável zero. Renderizações a 100%, 125%, 150%; escalas maiores podem exigir rolagem conforme a altura do monitor.
- Rodada completa: doze páginas, dois tamanhos, jogos/capas, limpeza, galeria/player/corte, áudio, gravação, clipes anteriores, atalhos, widgets, clique através e instalador/rollback passaram.
- Parser FPS e diferença de frames passaram em dados controlados. A sessão de FPS real sem elevação não obteve quadros; isso não é uma validação universal de FPS em jogos.
- Conferência de distribuição para CI: arquivos essenciais, assistentes, recursos incorporados, SVGs, versão, parser FPS e validação de temperatura passaram.

As imagens públicas mostram somente a interface, capas e mídias demonstrativas. Capturas reais de tela/microfone e relatórios detalhados permanecem em work, fora da distribuição. Compatibilidade com todos os jogos, sensores, GPUs, escalas entre monitores e sessões prolongadas não foi comprovada.
