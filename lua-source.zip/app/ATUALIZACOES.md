# LUA 1.12.0 Beta

A Galeria substitui Capturas na navegação principal. Reúne prints, clipes e gravações em uma grade com filtros, busca e favoritos. O botão Nova captura abre gravação, print, clipe retroativo e ajustes.

A tela Jogos usa um cabeçalho com importação de horas e cadastro de jogos, abas para Biblioteca, Sessões e FPS e um destaque horizontal para continuar jogando. A biblioteca exibe o total de horas e permite alternar entre a grade de capas e a lista.

## LUA 1.10.5 Beta

Avisos de atenção de CPU e RAM agora são opcionais e vêm desligados. Na primeira abertura após esta atualização, as configurações antigas também passam para desligado. Depois, a escolha de ativar ou desativar permanece salva.

A opção fica em Configurações > Avisos de atenção > Ativar avisos de atenção (CPU e RAM), junto dos limites de temperatura e memória. Não há avisos de espaço em disco. A captura continua finalizando o vídeo ao detectar pouco espaço, com informação no próprio painel e sem notificação flutuante.

Notificações de atualização e de ações como salvar um clipe continuam independentes dessa opção.
