# LUA 1.10.5 Beta

Avisos de atenção de CPU e RAM agora são opcionais e vêm desligados. Na primeira abertura após esta atualização, as configurações antigas também passam para desligado. Depois, a escolha de ativar ou desativar permanece salva.

A opção fica em Configurações > Avisos de atenção > Ativar avisos de atenção (CPU e RAM), junto dos limites de temperatura e memória. Não há avisos de espaço em disco. A captura continua finalizando o vídeo ao detectar pouco espaço, com informação no próprio painel e sem notificação flutuante.

Notificações de atualização e de ações como salvar um clipe continuam independentes dessa opção.
