# Atualizações oficiais do LUA

Página: https://onekaer.github.io/lua-/

Canal HTTPS: https://github.com/onekaer/lua-/releases/latest/download/LUA-atualizacoes.json

Este é o padrão da versão 1.9. Uma origem que o usuário já salvou é preservada; para sair do canal local, substitua-a pelo endereço acima nas Configurações.

O aplicativo consulta versões ao abrir e a cada 6 horas enquanto executa. Instalação automática é opcional. A instalação aguarda gravações/exportações, confere tamanho, SHA-256, caminhos e versão, mantém backup e reabre. O histórico temporário recomeça após reiniciar; capturas e preferências ficam nas suas pastas.

O repositório onekaer/lua- contém lua-source.zip, release.json e o workflow. Ao incrementar a versão e enviar os novos fontes, GitHub Actions compila, faz a conferência de distribuição, publica ZIP/JSON e atualiza a página. Versões publicadas são preservadas. O pacote base-v1.9.0 é um cache imutável das dependências, validado por SHA-256 antes da compilação.

Os testes do CI não substituem a verificação local em hardware/jogos reais. O histórico detalhado está nas notas e nos guias de cada versão.
