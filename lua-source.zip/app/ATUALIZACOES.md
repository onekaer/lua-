# Atualizações do LUA 1.10

Canal: https://github.com/onekaer/lua-/releases/latest/download/LUA-atualizacoes.json

Nova versão: notificação e botão azul Atualizar junto às Configurações no painel grande; botão pequeno no rodapé compacto. A configuração completa está no último grupo, Sobre o LUA e atualizações. Instalação automática é opcional. O aplicativo aguarda gravação/exportação, confere tamanho, SHA-256, caminhos e versão, mantém backup e reabre. Capturas e preferências são preservadas; o histórico temporário reinicia.

Os novos fontes e release.json acionam GitHub Actions, que usa a base imutável 1.9 apenas para dependências, recompila a versão, testa o pacote, publica ZIP/JSON e atualiza o GitHub Pages. Versões publicadas não são sobrescritas. Testes de CI não substituem os testes locais em jogos/hardware.
