# Horas jogadas no LUA 1.11.0

Abra Jogos instalados. O acompanhamento começa com o LUA e continua enquanto ele está na bandeja. O jogo pode ser iniciado pela Steam, Xbox, Epic, Battle.net, Riot, EA, Ubisoft, Rockstar, Hydra, por um atalho ou diretamente pelo executável.

## Detecção e cadastro

A biblioteca consulta instalações Steam, manifestos Epic, pastas XboxGames, registros de GOG e de jogos de EA, Ubisoft, Blizzard, Riot e Rockstar, além das pastas adicionadas pelo usuário. Ela é atualizada a cada cinco minutos e pelo botão Atualizar biblioteca. Uma instalação sem metadados acessíveis pode exigir cadastro.

Para um jogo portátil ou baixado pelo Hydra, escolha Adicionar executável / emulador e selecione o executável que realmente permanece aberto durante o jogo. Use o mesmo nome para reunir instalações e contas do mesmo título. O cadastro tem prioridade sobre a correspondência por pasta. Um jogo iniciado por qualquer caminho passa a ser acompanhado após o cadastro.

Os processos são consultados a cada cinco segundos. A contagem registra intervalos em que o jogo foi observado nas duas consultas consecutivas. Início e fim podem perder alguns segundos. Processos auxiliares comuns são excluídos da detecção por pasta, e vários processos correspondentes ao mesmo jogo contam uma vez. Jogos diferentes executados simultaneamente têm seus próprios tempos, portanto a soma da biblioteca pode exceder o tempo de relógio.

O tempo inclui menus e pausas internas enquanto o jogo continua aberto. Suspensões do PC e lacunas superiores a 15 segundos interrompem a sessão. O LUA não recupera tempo passado com ele fechado. Processos protegidos ou executados com permissões superiores podem ficar inacessíveis.

## Emuladores

RPCS3, PPSSPP, Ryujinx, Cemu e mGBA têm leitores para formatos reconhecidos de título da janela. Quando o jogo expõe o nome e identificador necessários, o LUA o adiciona e inicia a contagem. Janelas ociosas desses formatos são ignoradas.

Para PCSX2, Dolphin, DuckStation, RetroArch e outros emuladores, ou formatos personalizados dos leitores acima, cadastre o executável e um trecho exclusivo do título da janela durante o jogo, como nome ou serial. Esse trecho precisa desaparecer ao encerrar ou trocar o jogo. Emuladores sem um título que identifique o jogo exigem configuração adicional no próprio emulador. Compatibilidade universal e detecção de pausa interna não são garantidas.

## Importar contas e horas anteriores

| Opção | Dados disponíveis |
| --- | --- |
| Importar Steam deste PC | Horas armazenadas em localconfig.vdf nas contas locais, incluindo PlaytimeDisconnected. Os nomes são associados aos jogos instalados identificados. O cache pode estar desatualizado. |
| Importar conta Steam | Biblioteca e playtime_forever retornados pela Steam Web API. Requer SteamID64, chave pessoal válida e acesso aos detalhes dos jogos. Repita para cada conta. |
| Importar horas / contas | Valor informado pelo usuário para Steam, Xbox, Battle.net, Epic, Riot, EA, Ubisoft, Rockstar, GOG, Hydra, emulador ou outra origem. |
| Importar arquivo JSON | Lote no formato abaixo, com revisão antes da aplicação. Use Salvar modelo JSON para obter um exemplo. |

Login e importação remota de horas de Xbox, Epic, Battle.net, Riot, EA, Ubisoft, Rockstar e GOG ainda não estão integrados. A detecção local dos jogos e a contagem de novas sessões funcionam independentemente desses logins. Horas anteriores podem ser desconhecidas para uma plataforma ou conta.

```json
[
  {"Name":"Nome do jogo","Platform":"Steam","Account":"76561198000000001","Hours":12.5},
  {"Name":"Nome do jogo","Platform":"Xbox","Account":"Meu gamertag","Hours":8}
]
```

No JSON, Hours é um número de horas, usando ponto decimal. Cada combinação de nome, plataforma e conta aparece uma vez. Reimportar a mesma combinação atualiza seu snapshot. Para a mesma conta Steam, use o SteamID64 também nos registros manuais e arquivos, para corresponder à importação automática.

As contas de um mesmo nome de jogo são somadas. Em cada importação, o maior entre essa soma e o total já registrado vira a base. As novas sessões do LUA são acrescentadas depois. Um snapshot antigo nunca diminui o total. Exemplo: duas contas com 10 h e 5 h produzem 15 h. Mais 1 h registrada depois resulta em 16 h. Reimportar os mesmos valores mantém 16 h.

Essa regra evita somar integralmente períodos que podem estar presentes tanto nas contas quanto no LUA. Totais históricos sem datas não permitem uma união exata. Nomes diferentes permanecem separados. Importações de totais não inventam sessões antigas.

## Persistência e privacidade

Os dados ficam em playtime.json na pasta de dados do LUA, normalmente %LOCALAPPDATA%\LUA. Há gravação por substituição atômica e backup .bak. Erros são exibidos no painel. Se o histórico estiver inválido ou tiver uma versão desconhecida, o arquivo é preservado e a contagem fica indisponível para impedir sua substituição.

A consulta opcional Steam envia SteamID64 e chave somente para api.steampowered.com. A chave não é persistida. Os registros locais guardam nomes, executáveis cadastrados, identificadores de contas informados/importados e sessões. Os formatos de Steam e emuladores foram pesquisados com a referência PlayCounter, sob licença MIT incluída no pacote.

## Verificação desta versão

Passaram os testes de processos duplicados, limites de pasta, auxiliares, suspensão, contas, reimportação, novas sessões após importação, persistência, histórico inválido, VDF e títulos de emuladores. A integração foi exercitada com um processo real iniciado externamente. A interface foi renderizada nos modos compacto e ampliado com dados demonstrativos.

As consultas autenticadas de contas reais e o acompanhamento de jogos comerciais/emuladores físicos ainda exigem validação de uso. Os testes com formatos controlados não comprovam todas as versões de emuladores, launchers ou jogos protegidos.
