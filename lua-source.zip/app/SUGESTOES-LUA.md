# LUA 1.10 — mudanças e próximos passos

Incorporado: FPS automático sem seletor de processo; FPS único e estatísticas opcionais; FPS no Início da sobreposição; janelas sem ativação durante uso/movimento; teclado explícito; barra incluída no print; atalho de desktop na primeira abertura; Ctrl+Espaço padrão; notificações e botões de atualização; ajustes de espaço; site Beta com FPS/sobreposição e guia visual do GitHub.

Próximos passos que exigem trabalho próprio: identidade e assinatura de código reconhecida, avaliação da Microsoft Store, ampliar medição real de FPS e desempenho em mais jogos/GPUs, testes prolongados e suporte de tecnologias como DLSS via telemetria confiável.
