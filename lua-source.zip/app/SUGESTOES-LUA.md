# LUA 1.9 — melhorias incorporadas

- Temperatura da CPU com assistente separado, ativação/reconexão e instalação guiada do componente oficial.
- Espaço livre menor e Início padrão sem rolagem.
- Página de apresentação com imagens, recursos, instalação, dúvidas e download.
- Canal oficial HTTPS e workflow de publicação automática no GitHub.

Próximos passos: assinar os executáveis próprios, ampliar testes com outras GPUs/CPUs e monitores e integrar telemetria específica de jogos para confirmar tecnologias como DLSS quando disponível.
