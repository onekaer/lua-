# LUA 1.10.0 Beta

Desempenhos, capturas e organização para Windows 10/11 x64, com .NET Framework 4.8. O aplicativo abre compacto no canto e continua na bandeja ao fechar o painel.

## Abrir e instalar

Baixe o ZIP oficial, extraia a pasta inteira e abra LUA.exe. Mantenha bibliotecas, ícones e ferramentas juntos. Na primeira abertura, o LUA cria um atalho na Área de Trabalho. É possível recriá-lo em Configurações → Sobre o LUA e atualizações. Atalhos de outros aplicativos não são sobrescritos.

Esta versão está em beta e ainda não tem assinatura digital de um editor reconhecido. O SmartScreen pode mostrar um aviso de aplicativo desconhecido. Isso isoladamente não é uma detecção de vírus nem certifica a segurança do arquivo. Confira a origem e mantenha as proteções do Windows ativas. Veja DISTRIBUICAO.md.

## FPS automático

Abra um jogo reconhecido na biblioteca do LUA e mantenha-o em foco para identificá-lo. Não é mais necessário escolher um processo em uma lista nem iniciar a captura manualmente. Para jogos portáteis, adicione a pasta em Jogos instalados. A detecção automática pode ser desativada na seção retrátil Métricas e detecção da página Jogos e FPS.

Quando necessário, o assistente pede permissão ao Windows. Cancelar não causa pedidos repetidos; use Reativar detecção de FPS para tentar novamente. O mesmo assistente troca de jogo e fica em espera quando o jogo fecha, sem exigir uma nova elevação em cada troca durante a sessão. O painel principal continua com suas permissões normais. O PresentMon mede eventos por processo, sem injeção de código no jogo.

A interface usa um único FPS do jogo, sem uma segunda leitura “FPS da tela”. É a taxa média dos quadros do processo nos últimos 2 segundos; não somamos programas diferentes. Sem quadros recentes, mostra —. 1% low, FPS mínimo e FPS máximo são opcionais na página FPS e na sobreposição. O 1% low usa até 600 frames dos últimos 10 s, exigindo 100 frames. Mínimo e máximo são as menores/maiores médias de 2 s observadas no jogo atual; são reiniciados ao trocar de jogo. Não representam os picos instantâneos de um único quadro.

O widget Visão geral da sobreposição tem FPS acima das temperaturas, com fonte de 23 pontos, igual aos valores de CPU e GPU. O frametime é menor ao lado. A comparação manual com e sem DLSS continua disponível; um componente carregado não confirma a tecnologia ativa. A identificação automática de DLSS não é garantida.

## Sobreposição e atalhos

- Ctrl + Espaço: abre/fecha a sobreposição completa, com barra centralizada e janelas móveis.
- Ctrl + Shift + O: sobreposição de FPS e métricas.
- Ctrl + Shift + R: inicia/para gravação comum.
- Ctrl + Shift + F8 / F9 / F7: salva os últimos 30 / 60 / 120 segundos disponíveis.
- Ctrl + Shift + P: tira um print.

Todos podem ser personalizados nas Configurações/Capturas. O padrão antigo Ctrl + Shift + Espaço migra para Ctrl + Espaço; outros atalhos personalizados são preservados. Se outro programa já registrar a combinação, escolha uma disponível.

Mover janelas e usar seus botões mantém o foco no jogo por padrão. A movimentação usa reposicionamento sem ativação. Para escrever em pesquisas ou campos, ative Digitar na barra; o teclado passa às janelas do LUA e alguns jogos podem limitar FPS enquanto estão em segundo plano. Desative Digitar ou use Voltar ao jogo ao terminar. Janelas fixadas e métricas bloqueadas permitem cliques através fora da edição. A barra superior também aparece nas capturas; avisos e o indicador de gravação mantêm seu tratamento próprio.

Prefira janela sem bordas. Tela cheia exclusiva, anticheat e limitações do compositor podem impedir a exibição. Não há garantia de consumo zero nem de desempenho idêntico à Xbox Game Bar em todos os jogos.

## Hardware, rede e espaço

CPU, GPU, RAM, temperaturas disponíveis, processos, discos, tráfego e diagnóstico local. A temperatura da CPU pode exigir o PawnIO oficial e a permissão do assistente de sensores. Dados ausentes não são inventados. Rede permite testar download, upload e latência usando dados de teste da Cloudflare.

Armazenamento mostra espaço livre, pastas, arquivos grandes, temporários antigos e duplicados por conteúdo. Nada é removido só por analisar. Selecione ou marque tudo, revise e confirme o envio à Lixeira. Duplicados preservam uma cópia; Windows, aplicativo, dados internos e jogos detectados são protegidos. O diagnóstico não substitui teste físico de integridade do hardware.

## Jogos e capturas

Biblioteca em grade por padrão, capas oficiais quando disponíveis, busca, filtros por plataforma/tamanho, lista, Explorar e opções no menu de três pontos. Desinstalação pede confirmação. Detecção e capas dependem da plataforma.

Gravação, prints, áudio/microfone, atalhos e qualidade configuráveis. O buffer guarda os momentos anteriores enquanto está ativo e consome recursos de captura. Não pode recuperar algo ocorrido antes de sua ativação. O último segmento aberto é excluído: clipes podem terminar cerca de 1 s antes do clique. Salvar um clipe não inicia uma gravação comum. A gravação comum tem indicador com Parar; acesso à pasta é notificado ao finalizar, não ao começar.

A galeria separa vídeos, clipes e prints, com busca, ordenação por data, miniaturas e player. Mostrar na pasta e Excluir ficam nas ações do cartão. Capturas e preferências ficam nas pastas locais escolhidas; arquivos pessoais não são publicados pelo app.

## Atualizações

A nova versão gera uma notificação. O botão azul Atualizar fica junto das Configurações no painel grande e pequeno no rodapé compacto. A seção completa está no fim das Configurações, junto de Sobre o LUA. Instalação automática é opcional, aguarda gravação/exportação, verifica tamanho/SHA-256/versão e preserva backup.

Página: https://onekaer.github.io/lua-/

Downloads: https://github.com/onekaer/lua-/releases/latest

Canal: https://github.com/onekaer/lua-/releases/latest/download/LUA-atualizacoes.json

Se houver uma origem local antiga salva, troque-a pelo canal oficial nas Configurações. GitHub Actions compila, confere, publica o pacote/canal e atualiza o site quando os novos fontes e release.json são enviados. Licenças externas e fontes exigidos permanecem em THIRD-PARTY.md e licenses.
