# LUA 1.9 — Windows x64

Extraia a pasta inteira e abra **LUA.exe**. Mantenha `icons`, `tools`, `src/LUA.ico`, as DLLs e a configuração ao lado dele. Requer .NET Framework 4.8 no Windows 10/11 x64.

O painel abre compacto no canto inferior direito. As setas do cabeçalho ampliam/recolhem. As páginas principais ficam na barra de ícones; **Mais (…)** reúne as demais. Passe o mouse para ver os nomes. Todas as doze páginas continuam disponíveis. Clique na lua da bandeja para mostrar/recolher; o botão direito oferece os dois tamanhos e Sair.

## Início e barra de abas

**Galeria** e **Analisar PC** aparecem como ações rápidas somente no Início do painel compacto. Nas demais páginas, esse espaço fica livre para o conteúdo.

Em **Configurações → Navegação • editar barra de abas**, marque/desmarque os menus, use as setas ou arraste uma linha pelo título para mudar a ordem. Há perfis prontos Completo, Jogos e Minimalista. **Restaurar barra padrão** desfaz a personalização. As escolhas são salvas. Ocultar um ícone não remove a função. A engrenagem do cabeçalho sempre abre as Configurações; clicar na marca LUA volta ao Início, mesmo com essas abas ocultas.

## CPU, GPU, FPS e sobreposição

A sobreposição mostra **uso total da CPU e GPU em percentual**, separado das temperaturas, RAM e rede. Atalho padrão: **Ctrl + Shift + O**. Pode personalizar métricas, tamanho, fundo, posição e passagem de cliques.

Para FPS, abra o jogo, selecione o **processo do jogo** em **Jogos e FPS** e clique em **Iniciar captura**. Quando solicitado, aceite a permissão do Windows para **LuaFpsCapture.exe**, o componente incluído. O capturador separado obtém a permissão ETW; o painel continua respondendo enquanto ela é solicitada. O painel e a limpeza continuam com seus privilégios normais. O app não altera grupos, instala serviços ou injeta código no jogo.

Abrir a sobreposição também inicia a captura quando há um processo escolhido ou jogo reconhecido em primeiro plano. Essa opção pode ser desligada. Se o jogo não for reconhecido, selecione seu processo manualmente; evite selecionar só o launcher.

FPS é calculado pelas apresentações recentes do processo. Tempo por frame é a média dos últimos 2 s. O 1% low considera os piores 1% de até 600 frames/10 s, com mínimo de 100 amostras. É usada a swap chain mais ativa. Sem frames recentes aparece —, sem FPS simulado.

A sobreposição funciona em janela ou sem bordas. Tela cheia exclusiva e restrições de jogos podem impedir sua exibição. CPU/GPU são usos totais do hardware. Sensores indisponíveis são indicados, nunca estimados.

## Letras e ícones

Fonte nativa Segoe UI com antialiasing grayscale e layout ajustado ao DPI. O painel principal é opaco com cantos arredondados. A sobreposição mantém o texto opaco e suavizado, mudando apenas a transparência do fundo. Os ícones internos usam vetores Microsoft Fluent e desenhos próprios do LUA para os novos controles compactos. A lua da bandeja usa um ICO com nove tamanhos nativos, de 16 a 256 px, com suavização; a variante com ponto vermelho indica captura ativa. Nenhuma fonte ou configuração global do Windows é instalada/alterada.

## Limpeza de armazenamento

Em **Armazenamento**, clique em **Limpeza, grandes e duplicados**:

- Temporários antigos: pastas temporárias do usuário, sem alteração há pelo menos 7 dias.
- Arquivos grandes: a partir de 100 MB na pasta escolhida.
- Duplicados: mesmo tamanho e SHA-256 do conteúdo; nomes parecidos não bastam.

Analise, revise, marque os arquivos e clique em **Enviar seleção à Lixeira**. A confirmação mostra quantidade e tamanho. Nada vem selecionado por padrão. Em duplicados, **Marcar tudo** seleciona os resultados de todas as páginas; em duplicados, mantém uma cópia por grupo. **Selecionar cópias extras** também preserva uma cópia. Remover todas as cópias é bloqueado, e alterações após a análise são verificadas novamente.

Windows, Program Files, ProgramData, dados internos, o próprio LUA e jogos detectados são protegidos. Links/junções são ignorados. Arquivos bloqueados ou alterados são reportados. É usada a API moderna de reciclagem do Windows; não há exclusão permanente como alternativa implementada pelo app.

Os arquivos podem ser restaurados pela Lixeira. O espaço físico só é recuperado ao esvaziá-la no Windows. Tamanhos são lógicos: compressão, arquivos esparsos e hard links podem diferir do espaço físico. A análise pode ser cancelada.

## Jogos instalados

A biblioteca detecta Steam, Epic, GOG, Xbox e registros EA/Ubisoft/Battle.net/Riot/Rockstar acessíveis. Jogos portáteis ou sem metadados podem exigir **Adicionar jogo/pasta**. Nenhuma detecção automática garante localizar instalações sem registro.

Steam usa SizeOnDisk do manifesto, marcado como informado pela plataforma. Tamanhos ausentes são medidos em segundo plano. **Calcular tamanhos reais** mede todas as pastas novamente. A medição pode ser cancelada; resultados incompletos são marcados como parciais. O total soma apenas tamanhos conhecidos.

### Capas, busca e filtros

As capas reais vêm da biblioteca local da Steam, da loja oficial Steam e do catálogo Microsoft Store. A identificação usa o ID instalado; para outros launchers, a busca Steam exige título idêntico. Quando uma aplicação não possui capa vertical, pode ser usada sua arte oficial de loja. Sem correspondência, aparece Sem capa; **Trocar capa**, dentro do menu de três pontos de cada jogo, permite escolher sua imagem. As imagens ficam em cache local. Nenhuma capa é gerada artificialmente.

A biblioteca abre em grade, com seletores de grade/lista por ícones abaixo da pesquisa. Oferece busca por título/plataforma, ordem por maior tamanho, menor tamanho, nome e plataforma. Abra o ícone de filtros ao lado da pesquisa para escolher plataforma, faixas acima de 10/50/100 GB e tamanhos pendentes, atualizar, adicionar instalações e recalcular tamanhos. A biblioteca compacta mantém as capas visíveis logo abaixo dos controles. Redistribuíveis Steam e o launcher Minecraft não são contados como jogos. Para Minecraft Java detectado via Xbox, a pasta .minecraft existente é usada para medir seus dados reais.

## Teste de velocidade

Em **Rede e internet**, use **Testar velocidade**. O modo rápido transfere até 30 MB; o completo, até 120 MB. Mede download/upload em Mbps e latência HTTPS até a Cloudflare, com quatro transferências paralelas. Pode cancelar. Usa a rota padrão do Windows, inclusive VPN, independentemente da interface escolhida para o gráfico. Envia somente bytes gerados para o teste; arquivos pessoais e relatórios não são enviados. Não é o aplicativo oficial Speedtest by Ookla nem o teste oficial da Cloudflare; é uma medição do LUA usando o servidor público documentado.

## Gravação de tela e clipes

Na aba **Capturas**, escolha monitor, 720p/1080p/resolução do monitor, 30/60 FPS, qualidade 4/8/16 Mbps, áudio do PC, microfone, dispositivos, volumes separados e cursor. Clique **Iniciar gravação** e depois **Parar e salvar vídeo**. As capturas ficam em **Vídeos/LUA**, ou na pasta escolhida, separadas em **Videos**, **Clipes** e **Prints**. A galeria reúne todas as capturas. Qualidade, clipes, atalhos e pasta ficam em menus retráteis. As configurações valem para a próxima captura. O som do PC usa loopback WASAPI. Em **Áudio e microfone**, escolha a saída e o microfone, ative cada fonte e ajuste seus volumes independentemente. Dispositivos são abertos ao iniciar a captura; mudanças valem para a próxima sessão.

O histórico inicia automaticamente ao abrir o LUA e permanece ativo enquanto ele estiver na bandeja. Para recuperar momentos anteriores, mantenha o aplicativo aberto antes de jogar. Escolha guardar 30 s, 1 min ou 2 min e use os botões de salvar. Para mudar a duração de um buffer já ativo, desligue e reative. Se ainda não houver todo o período, salva somente o trecho disponível. O último segmento em gravação pode atrasar o final em cerca de 1 segundo. Não é possível recuperar momentos anteriores à ativação.

Atalhos globais:

- **Ctrl + Shift + R**: iniciar/parar gravação.
- **Ctrl + Shift + F8**: salvar últimos 30 s do buffer ativo.
- **Ctrl + Shift + F9**: salvar último minuto do buffer ativo.
- **Ctrl + Shift + F7**: salvar últimos 2 minutos.
- **Ctrl + Shift + P**: tirar print do monitor selecionado.
- **Ctrl + Shift + O**: sobreposição de métricas.

**Personalizar:** em Capturas → Atalhos de captura, clique no campo e pressione a combinação desejada. Esc cancela; Tab muda de campo. Conflitos com outras ações do LUA ou outros aplicativos são informados, e a escolha anterior é mantida.

As opções também ficam no menu da bandeja. O histórico automático é independente dos atalhos; se você o pausar manualmente, reative em Capturas para voltar a guardar os momentos anteriores. Atalhos ocupados por outro aplicativo são informados na aba Gravação. Não ativam o buffer automaticamente.

A gravação comum começa desligada; o histórico de clipes inicia automaticamente por padrão. Apenas a gravação comum exibe ponto vermelho na bandeja e indicador REC. O histórico de clipes trabalha em segundo plano, sem esse indicador. Durante a gravação, ele mostra **REC + cronômetro**. O histórico sozinho não mostra indicador REC. A posição pode ser escolhida nas opções de captura. Ele deixa os cliques passarem fora do botão **Parar**. Esse botão finaliza e salva a gravação sem abrir o painel e sem ativar uma janela sobre o jogo. Iniciar gravação não mostra notificação de pasta; a notificação com acesso à galeria aparece ao finalizar. No Windows compatível, o LUA solicita que o indicador e as notificações sejam excluídos dos arquivos gravados. **Sair do LUA** encerra as capturas e finaliza o vídeo. Fechar/recolher a janela apenas mantém o aplicativo na bandeja, inclusive uma captura já iniciada. Os processos de vídeo pertencem a um grupo Windows que os encerra se o LUA fechar inesperadamente. Nesse caso, o MKV parcial da gravação pode ser recuperado. Se a conversão MP4 falhar, o MKV original é preservado.

Usa H.264 com NVENC/AMF/QSV/Media Foundation quando disponível; há alternativa de software. O motor de vídeo é iniciado somente ao gravar ou ativar o buffer. O buffer temporário fica em LocalAppData/LUA/replay, com número limitado de segmentos, e é descartado ao desligá-lo; clipes salvos permanecem. Gravação e buffer simultâneos usam duas sessões de captura e mais recursos. Deixe pelo menos 600 MB livres para iniciar. A reserva configurável é monitorada a cada 5 s; ao atingir o limite, o LUA finaliza as capturas. Se faltar espaço para gerar também o MP4, mantém o MKV recuperável. O tamanho da reserva deve considerar a velocidade de gravação e a capacidade do disco.

Captura o monitor e suas janelas visíveis, incluindo informações que apareçam nele. Conteúdo protegido e alguns jogos em tela cheia exclusiva podem aparecer pretos; use janela sem bordas nesses casos. Os arquivos ficam neste PC.

## Outras funções

Monitoramento de CPU/GPU/RAM, inventário e sensores, rede por interface, teste de velocidade e latência, capacidade e atividade de discos, análise por pastas/maiores arquivos/CSV, processos com busca/ordenação, diagnóstico e relatório, inicialização opcional com o Windows, atalhos, avisos e intervalos de coleta.

Rede mostra tráfego de uso, não a velocidade máxima contratada. Sensores dependem do hardware, privilégios e eventualmente PawnIO; nenhum driver é instalado automaticamente. Diagnóstico não substitui benchmark, teste de estresse ou SMART completo.

Preferências ficam em `%LOCALAPPDATA%/LUA`. Não há conta nem telemetria do LUA. A busca de capas consulta serviços Steam/Microsoft; o teste de velocidade transfere dados gerados até a Cloudflare; o teste de latência envia pacotes ao endereço informado.

## Galeria e prints

A aba **Galeria** possui **Vídeos**, **Clipes** e **Prints** no topo. A busca filtra pelo nome do arquivo; o ícone ao lado abre ordenação (recentes, antigos, maior/menor tamanho, nome) e período (hoje, 7 dias, 30 dias). No painel amplo, as mídias ficam em duas colunas; no compacto, em uma.

**Tirar print** está em Capturas, Galeria, bandeja e no atalho escolhido. Usa o monitor selecionado em Qualidade e captura e salva PNG. Miniaturas de vídeos são geradas localmente; imagens não são enviadas. **Reproduzir/Abrir imagem** abre o visualizador interno do LUA, com pausa, linha do tempo, volume e visualização de prints; **Mostrar na pasta** seleciona o arquivo no Explorer. São listados arquivos da pasta de capturas e de suas subpastas conhecidas; vídeos antigos do LUA 1.3 na raiz continuam aparecendo. Clipes antigos são reconhecidos pelo prefixo LUA_clipe_.

## Notificações do LUA

As capturas, avisos e mensagens de uso agora utilizam uma notificação própria: fundo escuro, marca LUA, animação, fechamento e ação **Ver galeria** quando houver mídia. Só uma aparece por vez; uma mensagem nova substitui a anterior. O aviso se recolhe após 5 segundos e pausa enquanto o mouse está sobre ele. A solicitação de permissão do Windows e confirmações de remoção continuam sendo diálogos próprios dessas ações.

## Validação e fontes

Passaram as doze abas nos dois tamanhos, fonte e ícones, capas reais dos dez itens detectados nesta sessão, filtros e busca, scanner, análise de duplicados, retenção de uma cópia e envio à Lixeira somente de um arquivo descartável criado pelo teste.

Busca com filtro por ícone, botões alinhados, personalização/persistência da navegação, atalhos, notificação própria e indicador de gravação também passaram. A galeria foi conferida com arquivos demonstrativos da própria interface, após testar MP4 e PNG reais em separado. Os vídeos privados dos testes não acompanham a distribuição.

O teste real de velocidade rápida mediu download, upload e latência HTTPS, respeitando 30 MB. A captura real do monitor produziu H.264 + AAC em MP4, 720p, usando NVENC neste PC. Clipes reais de 30 e 60 segundos foram conferidos pelo leitor de mídia FFprobe, assim como o limite do buffer e o encerramento dos processos. Os vídeos privados de teste não acompanham a distribuição.

O leitor de FPS foi corrigido para a coluna **msBetweenPresents** do formato oficial v1. Na validação da versão 1.5, o PresentMon elevado recebeu **555 quadros reais do Bloons TD 6** e exibiu FPS positivo. A aba mostra PID, contagem de quadros, processo encerrado, falta de frames recentes e orientação para evitar selecionar o launcher. Isso confirmou a captura na versão 1.5 nesse jogo e neste PC, sem representar compatibilidade universal. A versão 1.6 usa o formato 2.x; veja a validação específica em VALIDACAO.md.

Código em `src`; `build.ps1` compila painel e capturador. `LUA.exe --verify --data "C:/pasta-de-testes"` verifica a interface e funções isoladas. A verificação padrão inclui uma captura curta local e um print para conferir o indicador e a galeria; as prévias públicas da galeria usam somente arquivos demonstrativos da interface LUA. O teste também abre o player, corta um arquivo demonstrativo, renomeia e envia somente um trecho descartável à Lixeira, grava brevemente com os dispositivos de áudio disponíveis e verifica a proteção de espaço com uma condição simulada. Acrescente `--verify-network` para um teste real de 30 MB; `--verify-video` para gravar um teste local e conferir clipes de 30/60 s (leva cerca de 2 minutos). Não limpa arquivos do usuário; somente arquivos descartáveis criados pelos testes são enviados à Lixeira. Use `--verify-fps-elevated --verify-fps-pid PID` para testar o processo de um jogo aberto, com a solicitação normal de permissão do Windows. Licenças, fontes e motores em `THIRD-PARTY.md` e `licenses`.

## Novidades da versão 1.5

- **Início alinhado:** Rede e Armazenamento têm o mesmo tamanho e os botões na mesma linha. Verificado nas escalas de 100%, 125% e 150%.
- **Player e edição:** a galeria mostra título amigável, duração, resolução e etiqueta de jogo editável. No player, abra **Cortar vídeo**, informe o início e o fim em segundos ou mm:ss e salve uma cópia na aba Clipes. O original permanece. Há cancelamento e envio à Lixeira com confirmação. Nesta versão os botões da galeria foram simplificados conforme solicitado: **Mostrar na pasta** à esquerda e **Excluir**, vermelho, à direita. A miniatura abre o player/imagem; os botões extras de reprodução e renomeação foram retirados.
- **Perfis de captura:** em Capturas, salve qualidade, fontes/volumes de áudio, atalhos, posição do indicador e métricas da sobreposição. Perfis podem ser vinculados ao executável de um jogo e aplicados ao entrar em primeiro plano, se essa opção estiver ligada. Não trocam enquanto gravação ou buffer estiver ativo. A pasta global é preservada.
- **Compatibilidade de captura:** escolha Automático, Duplicação DXGI ou Captura compatível (GDI). Neste pacote, o automático usa DXGI com um monitor e GDI com vários; DXGI explícito solicita um único monitor. **Testar captura • 3 s** abre uma prévia local para conferir imagem e compatibilidade antes de gravar por mais tempo.
- **Históricos:** Configurações reúne até 100 avisos locais; Rede guarda testes e compara os dois mais recentes. Dê um nome à conexão para identificá-la. O servidor usa a rota padrão do Windows.
- **Cache:** limite de 100/200/500 MB para miniaturas e opção de limpar apenas essas prévias, preservando capturas e capas.
- **Leitura e navegação:** escala do aplicativo, contraste reforçado, foco visível por teclado, nomes acessíveis nos ícones, menu Mais, filtros ativos com limpeza e menus retráteis que lembram seu estado. Estados de início, gravação, salvamento de clipe e finalização ficam separados.

O player depende dos codecs do Windows. Corte de vídeo recodifica localmente para H.264/AAC; pode consumir CPU. Não há envio das capturas para serviços externos. Consulte **VALIDACAO.md** para o resultado final e os limites dos testes; **SUGESTOES-LUA.md** registra as sugestões incorporadas.

## Sobreposição completa • versão 1.6

Em **Sobreposição** ou **Configurações**, abra **Sobreposição completa • janelas flutuantes**, ou use **Ctrl + Shift + Space**. A barra fica centralizada no topo do monitor do cursor e abre qualquer página habilitada na navegação: sistema, rede, armazenamento, jogos, FPS, capturas, galeria e configurações.

Arraste cada janela pelo título; redimensione pelas bordas. **Fixar** mantém uma janela visível ao voltar ao jogo. **Voltar ao jogo**, Esc quando uma janela estiver em foco, ou o atalho novamente encerra a edição: janelas não fixadas somem e as fixadas passam os cliques para o jogo e deixam de receber entrada. Reabra o modo para editar novamente. Posições, tamanhos e fixação são salvos. A opção Restaurar posições desfaz o layout. A coleta de sensores e FPS é compartilhada entre as janelas.

A sobreposição simples de **FPS e métricas** continua em **Ctrl + Shift + O**. Em **Sobreposição**, **Configurações** e **Capturas → Atalhos**, clique no campo correspondente e pressione sua combinação. O atalho da sobreposição completa é separado. Conflitos internos e combinações ocupadas são recusados. Ao abrir as métricas, o painel se recolhe e a janela abre bloqueada, sem capturar foco ou cliques. Desbloqueie somente para mover; bloqueie novamente antes de jogar. A exibição sobre tela cheia exclusiva depende do jogo/Windows; prefira janela sem bordas.

## Grade de jogos e galeria simplificada

Em Jogos instalados, escolha **Lista** ou **Grade**. A grade mantém capas reais, nomes, plataformas, tamanhos, busca e filtros. Adapta a quantidade de colunas à largura disponível, e sua escolha fica salva. O menu Mais usa borda escura arredondada própria. A rolagem vertical ocupa 5 px, com traço mais fino. Os indicadores textuais de transmissão foram retirados das páginas.

Na galeria, clique na **miniatura** para abrir o player ou print. As únicas ações no cartão são **Mostrar na pasta**, à esquerda, e **Excluir**, em vermelho, à direita. Excluir pede confirmação e envia à Lixeira, preservando a possibilidade de restauração pelo Windows.

## DLSS, FPS do jogo e FPS na tela

O leitor agora aceita o formato 2.x do PresentMon, além de manter compatibilidade com 1.x nos testes. **FPS do jogo** usa os intervalos de início dos frames da aplicação; **FPS na tela** usa a duração dos frames efetivamente exibidos quando disponível. Frames marcados como gerados pela instrumentação são separados. Essas métricas podem diferir por geração de frames, descarte ou apresentação; a diferença, sozinha, não comprova DLSS.

**Verificar componentes** consulta as DLLs carregadas pelo processo selecionado. Encontrar o componente DLSS/SR/FG **não comprova que está ativado**, e não encontrá-lo não comprova que está desligado. O LUA mostra estado não confirmado; não injeta código nem altera o jogo.

Para medir com e sem DLSS, abra **Jogos e FPS → Comparar com e sem DLSS**. Inicie a captura FPS, desligue o DLSS nas configurações do jogo e escolha **Medir sem DLSS • 20 s**; depois ligue e escolha **Medir com DLSS • 20 s**, mantendo a mesma cena, resolução e limite de FPS. Volte ao jogo durante cada medição. As etiquetas são **manuais**, os valores são medidos. Resultados ficam salvos por executável. Troca/encerramento da captura e falta de frames invalidam a medição. FPS renderizado com Frame Generation não equivale ao FPS que haveria com DLSS desligado.

Não há identificação automática universal de DLSS ativo, nem cálculo inventado de FPS sem DLSS. Métricas ausentes aparecem como —. Referências: [PresentMon 2.6](https://github.com/GameTechDev/PresentMon/blob/v2.6.0/README-ConsoleApplication.md), [DLSS NVIDIA](https://developer.nvidia.com/rtx/dlss).

## Novidades da versão 1.7

**Capturar na sobreposição:** a janela agora segue o formato compacto de quatro ações: print, salvar momento anterior, iniciar/parar vídeo e microfone. Abaixo aparecem o título da janela em uso, o histórico disponível e **Ver minhas capturas**, que abre a galeria flutuante. Os três pontos do rodapé escolhem clipes de 30, 60 ou 120 s. Se necessário, aumentar esse período reinicia o histórico para começar a preenchê-lo. A fixação continua no cabeçalho. O microfone pode ser alterado antes de iniciar vídeo; mudar essa fonte reinicia o histórico para aplicar o áudio escolhido.

**Histórico sempre ativo:** por padrão, o LUA inicia o buffer automaticamente e tenta retomá-lo após uma interrupção. Ele guarda somente o período selecionado, em segmentos locais limitados. O conteúdo temporário é descartado ao sair; clipes salvos permanecem. Proteção de espaço continua valendo. É possível pausar intencionalmente em Capturas. Enquanto o buffer está ativo, há captura contínua do monitor e do áudio escolhido, com consumo de CPU/GPU/disco correspondente.

**Salvar clipe não começa uma gravação nova.** O botão exporta somente segmentos já existentes anteriores ao instante do clique; o segmento ainda aberto é excluído. O final pode ficar aproximadamente 1 s antes do clique, dependendo da fronteira do segmento. Se o aplicativo acabou de abrir, salva apenas o período disponível e informa a duração efetiva. Não é possível recuperar o que aconteceu antes de o LUA/histórico estar ligado. Ao terminar, aparece apenas **Clipe salvo** no canto inferior, sem abrir painel/player/pasta e sem indicador REC. A gravação comum permanece independente.

**Galeria:** miniaturas na proporção 16:9, botão visual de reprodução, identificação de vídeo/clipe/print, duração na imagem e organização por Hoje/Ontem/data. Os controles de atualizar, print e filtros ficam compactos ao lado da busca. As ações continuam **Mostrar na pasta** e **Excluir** vermelho. A miniatura abre o player; no modo flutuante, a galeria também abre em uma janela móvel.

**Biblioteca de jogos:** grade padrão, seleção por ícones abaixo da busca, busca sem texto de preenchimento e ação **Explorar**. Os três pontos de cada jogo reúnem **Trocar capa**, detalhes, copiar caminho e **Desinstalar jogo**. A confirmação mostra jogo, plataforma, tamanho e pasta. Para Steam, abre a confirmação do jogo na própria Steam; para jogos com desinstalador registrado, abre esse programa. Quando não há um desinstalador identificável, abre Aplicativos instalados do Windows e orienta a localizar o jogo. Jogos portáteis podem ser removidos só da biblioteca, preservando os arquivos; use Explorar para gerenciar sua pasta. O LUA não declara um jogo removido só por abrir o desinstalador; atualize a biblioteca após concluir na plataforma.

**Limpeza:** **Marcar tudo** abrange todas as páginas de resultados. Em duplicados, deixa uma cópia de cada grupo desmarcada para preservá-la. A seleção ainda precisa ser revisada e confirmada antes de ir à Lixeira.

Veja `VALIDACAO.md` para a prova visual dos clipes anteriores ao clique e os testes desta versão.

Perfis de captura continuam disponíveis com o histórico permanente: a troca reinicia apenas o buffer para aplicar o novo perfil. Uma gravação comum em andamento permanece protegida e deve ser finalizada antes da troca.

## Novidades da versão 1.8

- Captura flutuante com visual próprio do LUA, quatro controles e um botão **Ver galeria**. A janela acompanha o conteúdo, inclusive se uma versão anterior salvou 420 × 600. O novo tamanho é 340 × 190.
- Botão direito sobre o controle de clipe escolhe 30 s, 60 s ou 120 s. O clique normal salva o histórico anterior; não inicia gravação comum.
- Janelas flutuantes sem marcador pontilhado. Mova pelo cabeçalho; redimensione as demais janelas pelas bordas. A captura mantém o tamanho compacto.
- Busca de jogos com filtro integrado e ícones de grade/lista na linha de baixo, ao lado de Gerenciar biblioteca.
- Galeria e Analisar PC no rodapé do Início. Espaço livre destacado; detalhes e grupos de sensores retráteis em Hardware.
- Correção de uma falha de acesso à interface ao carregar capas em segundo plano.

## Atualizações

**Configurações → Atualizações** fica no começo da página. O LUA verifica o canal ao abrir e, enquanto estiver executando, a cada 6 horas. Quando encontra uma versão mais recente, mostra **Instalar versão** nas Configurações e um aviso com ação no Início.

**Instalar novas versões automaticamente** é opcional e começa desativado. A instalação espera gravações e exportações terminarem, confere o download, preserva uma cópia dos arquivos substituídos e reabre o LUA. Configurações e capturas permanecem nas suas pastas. O histórico temporário recomeça após a reinicialização.

O canal pode ser um endereço HTTPS ou um arquivo local **LUA-atualizacoes.json**. A origem padrão da versão 1.9 é o canal oficial no GitHub. Na distribuição desta conversa, o canal local está em `outputs/LUA-atualizacoes.json`. Ao mover o aplicativo, use **Origem das atualizações → Escolher arquivo de versões** para apontar para o canal.

O canal oficial é publicado no GitHub Releases. Veja o endereço no fim deste guia e em `ATUALIZACOES.md`.

Para passar de uma versão anterior à 1.8, use **Sair do LUA** na bandeja e abra o novo `LUA.exe`. O mecanismo de atualização passa a estar disponível a partir da 1.8.

## Versão 1.9: temperatura e Início

A leitura da CPU pode exigir o PawnIO **e** permissão administrativa de leitura. O LUA usa um assistente separado, `LuaSensorsHost.exe`, mantendo o painel normal. Clique no bloco da temperatura ou abra Hardware → Sensores para instalar/ativar/reconectar. O instalador oficial é baixado do fornecedor, conferido por SHA-256 e só é executado após sua escolha e a confirmação do Windows. Não há instalação silenciosa sem escolha do usuário. A opção Solicitar leitura ao iniciar pode ser desativada. O assistente encerra junto com o app.

No PC de teste, AMD Ryzen 7 5700, o componente ausente foi instalado com autorização e a leitura real pelo assistente chegou a **58,25 °C**. O valor muda conforme a temperatura; não é uma estimativa fixa.

O bloco de espaço livre agora usa uma única linha e um valor menor. A página inicial compacta padrão passou no teste com altura rolável zero.

## Página e canal oficial

Página: https://onekaer.github.io/lua-/

Downloads: https://github.com/onekaer/lua-/releases/latest

Canal: https://github.com/onekaer/lua-/releases/latest/download/LUA-atualizacoes.json

A partir da 1.9, a origem padrão é o GitHub. Se você havia configurado um caminho local, troque a origem nas Configurações pelo canal acima para receber publicações pela internet. O JSON local ainda pode ser selecionado manualmente para testes/offline. O histórico de versões e a página são publicados pelo GitHub Actions quando a nova versão e os fontes são enviados ao repositório.
