param([Parameter(Mandatory=$true)][string]$Pacote,[Parameter(Mandatory=$true)][string]$Versao,[string]$Notas='Nova versão do LUA')
$ErrorActionPreference='Stop'
$luaPackage=Get-Item -LiteralPath $Pacote
$luaVersion=[Version]::Parse($Versao)
if($luaPackage.Extension -ne '.zip'){throw 'Selecione o ZIP completo do LUA.'}
$luaFeed=Join-Path $luaPackage.DirectoryName 'LUA-atualizacoes.json'
$luaJson=[ordered]@{Version=$luaVersion.ToString();Url=$luaPackage.Name;Sha256=(Get-FileHash -LiteralPath $luaPackage.FullName -Algorithm SHA256).Hash.ToLowerInvariant();Bytes=$luaPackage.Length;Notes=$Notas}|ConvertTo-Json
[IO.File]::WriteAllText($luaFeed+'.tmp',$luaJson,[Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath ($luaFeed+'.tmp') -Destination $luaFeed -Force
Write-Output ('Canal publicado: '+$luaFeed)
