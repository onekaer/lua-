# Componentes distribuídos

Os binários externos foram baixados das versões oficiais; seus fontes não foram modificados.

## LibreHardwareMonitor 0.9.6

- Distribuição original: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/tag/v0.9.6
- Código correspondente: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/tree/v0.9.6
- Arquivo de fontes: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/archive/refs/tags/v0.9.6.zip
- Licença: MPL 2.0, `licenses/LibreHardwareMonitor-MPL-2.0.txt`.
- Dependências e módulos incorporados: `licenses/LibreHardwareMonitor-ThirdParty.txt`.
- As bibliotecas BlackSharp.Core, DiskInfoToolkit, RAMSPDToolkit-NDD, HidSharp e System.* foram extraídas da mesma distribuição oficial, preservando os binários originais.
- A biblioteca é carregada dinamicamente; os arquivos DLL permanecem separados do executável para permitir substituição/recompilação compatível.

## Intel PresentMon 2.6.0

- Binário oficial incluído como `tools/PresentMon.exe` (nome original `PresentMon-2.6.0-x64.exe`).
- Versão: https://github.com/GameTechDev/PresentMon/releases/tag/v2.6.0
- Código correspondente: https://github.com/GameTechDev/PresentMon/tree/v2.6.0
- Licença MIT: `licenses/PresentMon-MIT.txt`.
- É iniciado como processo independente somente durante uma captura solicitada.

## Microsoft .NET Framework e Windows

O aplicativo usa o runtime já instalado. Os ícones Segoe vêm do próprio Windows e não são redistribuídos. A interface usa Segoe UI do próprio Windows.


## Microsoft Fluent UI System Icons

Ícones SVG oficiais renderizados como vetores WPF.

- Projeto e fontes: https://github.com/microsoft/fluentui-system-icons
- Licença MIT: `licenses/Fluent-MIT.txt`.

## FFmpeg 8.1 — processo de vídeo independente

- Binário dinâmico LGPL de BtbN, versão `n8.1.3-18-g46d899d7a0-20261013`, distribuído em `tools/video`. Não foi modificado. Não é ligado ao executável LUA.
- Distribuição da data: https://github.com/BtbN/FFmpeg-Builds/releases/tag/autobuild-2026-10-13-13-05
- Pacote: `ffmpeg-n8.1-latest-win64-lgpl-shared-8.1.zip`. SHA-256 do download: `6FBE3233F0B769CE6D906FC200EF0B874B681FA1554520F6880BFB45B4BEFA58`.
- Site: https://ffmpeg.org/ ; dispositivos: https://ffmpeg.org/ffmpeg-devices.html#gdigrab ; segmentação: https://ffmpeg.org/ffmpeg-formats.html#segment
- Licenças LGPL 3.0 e texto GPL referido pela LGPL em `licenses/FFmpeg-*.txt`; configuração completa em `licenses/FFmpeg-build.txt`.
- Fontes exatos do FFmpeg incluídos em `licenses/sources/FFmpeg-46d899d7a0.tar.gz`: https://github.com/FFmpeg/FFmpeg/tree/46d899d7a0
- Receitas de compilação e referências às dependências incluídas em `licenses/sources/FFmpeg-Builds-63ac3265.zip`: https://github.com/BtbN/FFmpeg-Builds/tree/63ac3265b0789ea16c7b1f8351cd2ad195a28722
- Os programas e DLLs permanecem separados e podem ser substituídos por builds compatíveis. Não há restrição de engenharia reversa sobre componentes LGPL. O código-fonte do LUA também está incluído.

## NAudio 2.2.1

- `NAudio.Core.dll` e `NAudio.Wasapi.dll`, pacotes oficiais NuGet 2.2.1, sem modificação; áudio WASAPI loopback.
- Código: https://github.com/naudio/NAudio/tree/v2.2.1 ; licença MIT preservada em `licenses/NAudio-MIT.txt`.

## Serviços externos opcionais

- Capas: Steam library assets e catálogo oficial Microsoft Store; as marcas e artes pertencem aos respectivos titulares, e são buscadas em execução, sem incluí-las como ativos próprios do LUA.
- Teste de velocidade: endpoints HTTPS públicos documentados em https://github.com/cloudflare/speedtest/blob/main/src/config/defaultConfig.ts ; implementação própria de transferência, sem incorporar o código do motor Cloudflare nem enviar resultados à API de logs.

Ícones grid.svg, list.svg, replay.svg, mic.svg, mic-off.svg e pin.svg: desenhos vetoriais próprios do LUA, sob a licença do projeto. Os demais ícones mantêm as licenças indicadas acima.

## PawnIO — componente opcional obtido do fornecedor

Instalador oficial 2.2.0: https://github.com/namazso/PawnIO.Setup/releases/download/2.2.0/PawnIO_setup.exe

SHA-256: 1f519a22e47187f70a1379a48ca604981c4fcf694f4e65b734aaa74a9fba3032

Fornecedor: https://pawnio.eu/ • fontes/licença: https://github.com/namazso/PawnIO

O instalador e o driver não são incluídos no ZIP do LUA. O app oferece download direto do fornecedor e instalação somente por escolha do usuário. O assistente LuaSensorsHost é código próprio e usa a biblioteca LibreHardwareMonitor já distribuída separadamente.
